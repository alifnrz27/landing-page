<div>
    <nav id="navbar"  x-cloak class="fixed border-gray-200 bg-white w-full z-50 duration-200 py-4 "
        x-data="{
                openSideBar : false,
                width : (window.innerWidth > 0) ? window.innerWidth : screen.width,
                bodyHeight: screen.height,
                }"
            @resize.window="
            width = (window.innerWidth > 0) ? window.innerWidth : screen.width;
            openSideBar = false;
            ">
        <div class="flex flex-wrap relative items-center justify-between h-12 mx-auto px-12 pt-2 mb-4">
            {{--  logo  --}}
            <div class="flex h-full" x-on:click="openSideBar=!openSideBar">
                <x-logo class="w-[28px] mr-1 text-dark-primary"/>
                <div style="font-weight: 600;" class="text-[20px] my-auto text-dark-primary hidden md:block">
                    {{ env('COMPANY_NAME') }}
                </div>
            </div>
            {{--  end logo  --}}

            <div x-show="(width > 1500) ? true : openSideBar" :class="(width < 1500) ? 'absolute w-[300px] bottom-10' : 'w-full '" style="top: 65px" class="md:block md:w-auto">
                <ul :class="(width > 1500) ? 'flex gap-2' : 'bg-slate-200 rounded-md'" class="my-auto"  style="transition: visibility 0s, opacity 1s linear;">
                    @if(auth()->user()->role_id != 5 && auth()->user()->role_id != 6)
                    <li>
                    <a href="{{route('owner.dashboard')}}" style="" class="block xl:w-[120px] text-center text-[12px] xl:text-[14px] px-3 {{ request()->is('owner/dashboard') ? 'text-black bg-gray-200 font-semibold' : 'text-gray-500 bg-transparent' }} hover:font-semibold rounded-sm py-2 duration-150 ease-in-out transition hover:text-black hover:bg-gray-200 cursor-pointer">DASHBOARD</a>
                    </li>
                    <li>
                        <a href="{{ route('owner.product') }}" class="block xl:w-[120px] text-center text-[12px] xl:text-[14px] px-3 {{ request()->is('owner/product') ? 'text-black bg-gray-200 font-semibold' : 'text-gray-500 bg-transparent' }} hover:font-semibold rounded-sm py-2 duration-150 ease-in-out transition hover:text-black hover:bg-gray-200 cursor-pointer">PRODUCT</a>
                    </li>
                    <li>
                    <a href="{{ route('owner.claim') }}" class="block xl:w-[120px] text-center text-[12px] xl:text-[14px] px-3 {{ request()->is('owner/claim') ? 'text-black bg-gray-200 font-semibold' : 'text-gray-500 bg-transparent' }} hover:font-semibold rounded-sm py-2 duration-150 ease-in-out transition hover:text-black hover:bg-gray-200 cursor-pointer">CLAIM</a>
                    </li>
                    <li>
                    <a href="{{ route('owner.promo') }}" class="block xl:w-[120px] text-center text-[12px] xl:text-[14px] px-3 {{ request()->is('owner/promo') ? 'text-black bg-gray-200 font-semibold' : 'text-gray-500 bg-transparent' }} hover:font-semibold rounded-sm py-2 duration-150 ease-in-out transition hover:text-black hover:bg-gray-200 cursor-pointer">PROMO</a>
                    </li>
                    @endif
                    @auth
                    @if(auth()->user()->role_id == 2 || auth()->user()->role_id == 5)
                    <li>
                    <a href="{{ route('owner.point') }}" class="block xl:w-[120px] text-center text-[12px] xl:text-[14px] px-3 {{ request()->is('owner/point') ? 'text-black bg-gray-200 font-semibold' : 'text-gray-500 bg-transparent' }} hover:font-semibold rounded-sm py-2 duration-150 ease-in-out transition hover:text-black hover:bg-gray-200 cursor-pointer">POINT</a>
                    </li>
                    @endif
                    @if(auth()->user()->role_id == 6)
                    <li>
                        <a href="{{ route('owner.cashiers') }}" class="block xl:w-[120px] text-center text-[12px] xl:text-[14px] px-3 {{ request()->is('owner/cashiers') ? 'text-black bg-gray-200 font-semibold' : 'text-gray-500 bg-transparent' }} hover:font-semibold rounded-sm py-2 duration-150 ease-in-out transition hover:text-black hover:bg-gray-200 cursor-pointer">CASHIER</a>
                        </li>
                    <li>
                    @endif
                    @if(auth()->user()->role_id == 2)
                    <a href="{{ route('owner.store') }}" class="block xl:w-[120px] text-center text-[12px] xl:text-[14px] px-3 {{ request()->is('owner/store') ? 'text-black bg-gray-200 font-semibold' : 'text-gray-500 bg-transparent' }} hover:font-semibold rounded-sm py-2 duration-150 ease-in-out transition hover:text-black hover:bg-gray-200 cursor-pointer">STORE</a>
                    </li>
                    <li>
                        <a href="{{ route('owner.users') }}" class="block xl:w-[120px] text-center text-[12px] xl:text-[14px] px-3 {{ request()->is('owner/users') ? 'text-black bg-gray-200 font-semibold' : 'text-gray-500 bg-transparent' }} hover:font-semibold rounded-sm py-2 duration-150 ease-in-out transition hover:text-black hover:bg-gray-200 cursor-pointer">USERS</a>
                    </li>
                    @endif
                    @endauth
                </ul>
            </div>
            {{--  login / profile  --}}
            @auth
            <div x-data="{
                open : false
                }" class="flex">
                @if(auth()->user()->image_path)
                <img @click="open=true" class="w-[28px] h-[28px] rounded-full hover:cursor-pointer hover:scale-105 shadow-md hover:shadow-lg" src="{{asset('src/img/background/astronaut.jpg')}}" />
                @else
                <div @click="open=true" style="font-weight: 600;background-color:#25AB4B;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;" class="w-[28px] h-[28px] rounded-full text-[13px] text-center flex justify-center items-center text-white hover:cursor-pointer">
                    {{generateInitials(auth()->user()->name)}}
                </div>
                @endif
                <div class="ml-2 flex">
                    <div class="max-w-[130px] hidden md:block">
                        <div style="font-weight: 400;font-size:16px" class="flex">
                            <div class="truncate text-dark-primary">
                                {{ auth()->user()->name }}
                            </div>
                        </div>
                        <div class="text-[14px] flex items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                <path d="M3.33333 10.6667L2 3.33335L5.66667 6.66669L8 2.66669L10.3333 6.66669L14 3.33335L12.6667 10.6667H3.33333ZM12.6667 12.6667C12.6667 13.0667 12.4 13.3334 12 13.3334H4C3.6 13.3334 3.33333 13.0667 3.33333 12.6667V12H12.6667V12.6667Z" fill="#FFA51E"/>
                            </svg>
                            <div class="pt-[2px] ml-[2px] text-gray-500 truncate">
                                {{ session('role') }}
                            </div>
                        </div>
                    </div>
                    <div>
                        <div>
                            <img @click="open=true" class="cursor-pointer" src="{{ asset('src/icons/md-more.svg') }}" />
                        </div>
                    </div>
                </div>
                <div x-show="open" @click.outside="open=false" class="fixed duration-300" style="z-index: 500">
                    <div class="down-arrow ml-4 absolute"></div>

                    <div class="w-[150px] mt-1 bg-primary rounded-md shadow-lg" style="margin-left:-100px;z-index:500">
                        <ul class="pb-5">
                            <li class="px-3 py-2 text-white border-b-2 border-secondary">
                                <a href="{{route('owner.profile')}}" class="w-full text-start">View Profile</a>
                            </li>
                            <li class="px-3 py-2 text-white border-b-2 border-secondary">
                                <form action="{{route('logout')}}" method="POST">
                                    @csrf
                                    <button type="submit" class="w-full text-start">Logout</button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            @else
            <div class="flex">
                <div x-show="(width > 1500)" class="my-auto block">
                    <a href="{{ route('login') }}" class="bg-primary text-white px-5 py-2 rounded-md mr-6 duration-300 ease-in-out hover:scale-110">Login</a>
                </div>
            </div>
            @endauth
        </div>
        <hr>
    </nav>
</div>
