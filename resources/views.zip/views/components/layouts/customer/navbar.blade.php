<div style="z-index: 70;height:70px" class="fixed no-select  bottom-0 w-screen md:w-full md:max-w-md max-w-full bg-white shadow-md border-t-2 max-h-screen overflow-auto flex flex-col justify-center" x-data="{
        openQR:false,
    }">
    <div style="position: relative;display:flex;justify-content: space-between;align-items: center;padding-left: 1.25rem;padding-right: 1.25rem;">
        <div class="gap-[0px] md:gap-[15px] lg:gap-[20px]" style="display: flex;align-items:center">
            <a href="{{ route('dashboard') }}" style="width: 3.5rem;" class="transform duration-200 px-2 py-1">
                <div class="flex flex-col gap-2 items-center">
                    <div>
                        <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path class=" @if($currentPage == 'dashboard') fill-[#D83232] @else fill-[#292D32] @endif" d="M21.36 8.37L14.43 2.83C13.36 1.97 11.63 1.97 10.57 2.82L3.64002 8.37C2.86002 8.99 2.36002 10.3 2.53002 11.28L3.86002 19.24C4.10002 20.66 5.46002 21.81 6.90002 21.81H18.1C19.53 21.81 20.9 20.65 21.14 19.24L22.47 11.28C22.63 10.3 22.13 8.99 21.36 8.37ZM12.5 15.5C11.12 15.5 10 14.38 10 13C10 11.62 11.12 10.5 12.5 10.5C13.88 10.5 15 11.62 15 13C15 14.38 13.88 15.5 12.5 15.5Z" />
                        </svg>
                    </div>
                    <div style="@if($currentPage == 'dashboard') font-weight:600; @endif" class="text-[8px] @if($currentPage == 'dashboard') text-[#DA0713] @endif md:text-[12px]">
                        Home
                    </div>
                </div>
            </a>
            <a href="{{ route('claim') }}" style="width: 3.5rem;" class="transform duration-200 px-2 py-1">
                <div class="flex flex-col gap-2 items-center">
                    <div>
                        <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path class=" @if($currentPage == 'claim') fill-[#D83232] @else fill-[#292D32] @endif" d="M22.42 16.75C22.09 19.41 19.91 21.59 17.25 21.92C15.64 22.12 14.14 21.68 12.97 20.82C12.3 20.33 12.46 19.29 13.26 19.05C16.27 18.14 18.64 15.76 19.56 12.75C19.8 11.96 20.84 11.8 21.33 12.46C22.18 13.64 22.62 15.14 22.42 16.75Z"/>
                            <path class=" @if($currentPage == 'claim') fill-[#D83232] @else fill-[#292D32] @endif" d="M10.49 2C6.08 2 2.5 5.58 2.5 9.99C2.5 14.4 6.08 17.98 10.49 17.98C14.9 17.98 18.48 14.4 18.48 9.99C18.47 5.58 14.9 2 10.49 2ZM9.55 8.87L11.96 9.71C12.83 10.02 13.25 10.63 13.25 11.57C13.25 12.65 12.39 13.54 11.34 13.54H11.25V13.59C11.25 14 10.91 14.34 10.5 14.34C10.09 14.34 9.75 14 9.75 13.59V13.53C8.64 13.48 7.75 12.55 7.75 11.39C7.75 10.98 8.09 10.64 8.5 10.64C8.91 10.64 9.25 10.98 9.25 11.39C9.25 11.75 9.51 12.04 9.83 12.04H11.33C11.56 12.04 11.74 11.83 11.74 11.57C11.74 11.22 11.68 11.2 11.45 11.12L9.04 10.28C8.18 9.98 7.75 9.37 7.75 8.42C7.75 7.34 8.61 6.45 9.66 6.45H9.75V6.41C9.75 6 10.09 5.66 10.5 5.66C10.91 5.66 11.25 6 11.25 6.41V6.47C12.36 6.52 13.25 7.45 13.25 8.61C13.25 9.02 12.91 9.36 12.5 9.36C12.09 9.36 11.75 9.02 11.75 8.61C11.75 8.25 11.49 7.96 11.17 7.96H9.67C9.44 7.96 9.26 8.17 9.26 8.43C9.25 8.77 9.31 8.79 9.55 8.87Z"/>
                        </svg>
                    </div>
                    <div style="@if($currentPage == 'claim') font-weight:600; @endif" class="text-[8px] @if($currentPage == 'claim') text-[#DA0713] @endif md:text-[12px]">
                        Claim
                    </div>
                </div>
            </a>
        </div>
        <div class="gap-[0px] md:gap-[15px] lg:gap-[20px]" style="display: flex;align-items:center">
            <a href="{{ route('promo') }}" style="width: 3.5rem;" class="transform duration-200 px-2 py-1">
                <div class="flex flex-col gap-2 items-center">
                    <div>
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path class=" @if($currentPage == 'promo') fill-[#D83232] @else fill-[#292D32] @endif" d="M21.3 10.84C21.69 10.84 22 10.53 22 10.14V9.20999C22 5.10999 20.75 3.85999 16.65 3.85999H7.35C3.25 3.85999 2 5.10999 2 9.20999V9.67999C2 10.07 2.31 10.38 2.7 10.38C3.6 10.38 4.33 11.11 4.33 12.01C4.33 12.91 3.6 13.63 2.7 13.63C2.31 13.63 2 13.94 2 14.33V14.8C2 18.9 3.25 20.15 7.35 20.15H16.65C20.75 20.15 22 18.9 22 14.8C22 14.41 21.69 14.1 21.3 14.1C20.4 14.1 19.67 13.37 19.67 12.47C19.67 11.57 20.4 10.84 21.3 10.84ZM9 8.87999C9.55 8.87999 10 9.32999 10 9.87999C10 10.43 9.56 10.88 9 10.88C8.45 10.88 8 10.43 8 9.87999C8 9.32999 8.44 8.87999 9 8.87999ZM15 15.88C14.44 15.88 13.99 15.43 13.99 14.88C13.99 14.33 14.44 13.88 14.99 13.88C15.54 13.88 15.99 14.33 15.99 14.88C15.99 15.43 15.56 15.88 15 15.88ZM15.9 9.47999L9.17 16.21C9.02 16.36 8.83 16.43 8.64 16.43C8.45 16.43 8.26 16.36 8.11 16.21C7.82 15.92 7.82 15.44 8.11 15.15L14.84 8.41999C15.13 8.12999 15.61 8.12999 15.9 8.41999C16.19 8.70999 16.19 9.18999 15.9 9.47999Z"/>
                        </svg>
                    </div>
                    <div style="@if($currentPage == 'promo') font-weight:600; @endif" class="text-[8px] @if($currentPage == 'promo') text-[#DA0713] @endif md:text-[12px]">
                        Promo
                    </div>
                </div>
            </a>
            <a href="{{ route('profile') }}" style="width: 3.5rem;" class="transform duration-200 px-2 py-1">
                <div class="flex flex-col gap-2 items-center">
                    <div>
                        <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path class=" @if($currentPage == 'profile') fill-[#D83232] @else fill-[#292D32] @endif" d="M12.5 2C9.88 2 7.75 4.13 7.75 6.75C7.75 9.32 9.76 11.4 12.38 11.49C12.46 11.48 12.54 11.48 12.6 11.49C12.62 11.49 12.63 11.49 12.65 11.49C12.66 11.49 12.66 11.49 12.67 11.49C15.23 11.4 17.24 9.32 17.25 6.75C17.25 4.13 15.12 2 12.5 2Z"/>
                            <path class=" @if($currentPage == 'profile') fill-[#D83232] @else fill-[#292D32] @endif" d="M17.58 14.15C14.79 12.29 10.24 12.29 7.43002 14.15C6.16002 15 5.46002 16.15 5.46002 17.38C5.46002 18.61 6.16002 19.75 7.42002 20.59C8.82002 21.53 10.66 22 12.5 22C14.34 22 16.18 21.53 17.58 20.59C18.84 19.74 19.54 18.6 19.54 17.36C19.53 16.13 18.84 14.99 17.58 14.15Z"/>
                        </svg>
                    </div>
                    <div style=" @if($currentPage == 'profile') font-weight:600; @endif" class="text-[8px] @if($currentPage == 'profile') text-[#DA0713] @endif md:text-[12px]">
                        Profile
                    </div>
                </div>
            </a>
        </div>
        <div @click="openQR=true" style="position: fixed; bottom: -20px;left: 50%;transform: translate(-50%, -50%); cursor-pointer " class="">
            <svg width="85" class="cursor-pointer" height="84" viewBox="0 0 85 84" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g filter="url(#filter0_d_16_2749)">
                    <rect x="12.6" y="4" width="60" height="60" rx="24" fill="url(#paint0_linear_16_2749)"/>
                    <path d="M25.9333 29.75C25.5261 29.75 25.1833 29.4072 25.1833 29V24.8333C25.1833 20.2768 28.8921 16.5833 33.4333 16.5833H37.6C38.0071 16.5833 38.35 16.9262 38.35 17.3333C38.35 17.7405 38.0071 18.0833 37.6 18.0833H33.4333C29.7071 18.0833 26.6833 21.1072 26.6833 24.8333V29C26.6833 29.4072 26.3405 29.75 25.9333 29.75Z" fill="white" stroke="white"/>
                    <path d="M59.2666 29.75C58.8595 29.75 58.5166 29.4072 58.5166 29V24.8333C58.5166 21.1072 55.4928 18.0833 51.7666 18.0833H47.6C47.1928 18.0833 46.85 17.7405 46.85 17.3333C46.85 16.9262 47.1928 16.5833 47.6 16.5833H51.7666C56.3078 16.5833 60.0166 20.2768 60.0166 24.8333V29C60.0166 29.4072 59.6738 29.75 59.2666 29.75Z" fill="white" stroke="white"/>
                    <path d="M51.7667 51.4167H49.2667C48.8595 51.4167 48.5167 51.0738 48.5167 50.6667C48.5167 50.2595 48.8595 49.9167 49.2667 49.9167H51.7667C55.4928 49.9167 58.5167 46.8928 58.5167 43.1667V40.6667C58.5167 40.2595 58.8595 39.9167 59.2667 39.9167C59.6739 39.9167 60.0167 40.2595 60.0167 40.6667V43.1667C60.0167 47.7232 56.3078 51.4167 51.7667 51.4167Z" fill="white" stroke="white"/>
                    <path d="M37.6 51.4167H33.4333C28.8921 51.4167 25.1833 47.7232 25.1833 43.1667V39C25.1833 38.5928 25.5261 38.25 25.9333 38.25C26.3405 38.25 26.6833 38.5928 26.6833 39V43.1667C26.6833 46.8928 29.7071 49.9167 33.4333 49.9167H37.6C38.0071 49.9167 38.35 50.2595 38.35 50.6667C38.35 51.0739 38.0071 51.4167 37.6 51.4167Z" fill="white" stroke="white"/>
                    <path d="M34.2666 23.25H37.6C38.4664 23.25 39.0497 23.4771 39.418 23.8439C39.786 24.2103 40.0166 24.7929 40.0166 25.6667V29C40.0166 29.8737 39.786 30.4564 39.418 30.8228C39.0497 31.1895 38.4664 31.4167 37.6 31.4167H34.2666C33.4002 31.4167 32.8169 31.1895 32.4486 30.8228C32.0807 30.4564 31.85 29.8737 31.85 29V25.6667C31.85 24.7929 32.0807 24.2103 32.4486 23.8439C32.8169 23.4771 33.4002 23.25 34.2666 23.25Z" fill="white" stroke="white"/>
                    <path d="M47.6 23.25H50.9333C51.7998 23.25 52.383 23.4771 52.7513 23.8439C53.1193 24.2103 53.35 24.7929 53.35 25.6667V29C53.35 29.8737 53.1193 30.4564 52.7513 30.8228C52.383 31.1895 51.7998 31.4167 50.9333 31.4167H47.6C46.7335 31.4167 46.1503 31.1895 45.7819 30.8228C45.414 30.4564 45.1833 29.8737 45.1833 29V25.6667C45.1833 24.7929 45.414 24.2103 45.7819 23.8439C46.1503 23.4771 46.7335 23.25 47.6 23.25Z" fill="white" stroke="white"/>
                    <path d="M34.2666 36.5833H37.6C38.4664 36.5833 39.0497 36.8105 39.418 37.1772C39.786 37.5436 40.0166 38.1263 40.0166 39V42.3333C40.0166 43.2071 39.786 43.7897 39.418 44.1561C39.0497 44.5229 38.4664 44.75 37.6 44.75H34.2666C33.4002 44.75 32.8169 44.5229 32.4486 44.1561C32.0807 43.7897 31.85 43.2071 31.85 42.3333V39C31.85 38.1263 32.0807 37.5436 32.4486 37.1772C32.8169 36.8105 33.4002 36.5833 34.2666 36.5833Z" fill="white" stroke="white"/>
                    <path d="M47.6 36.5833H50.9333C51.7998 36.5833 52.383 36.8105 52.7513 37.1772C53.1193 37.5436 53.35 38.1263 53.35 39V42.3333C53.35 43.2071 53.1193 43.7897 52.7513 44.1561C52.383 44.5229 51.7998 44.75 50.9333 44.75H47.6C46.7335 44.75 46.1503 44.5229 45.7819 44.1561C45.414 43.7897 45.1833 43.2071 45.1833 42.3333V39C45.1833 38.1263 45.414 37.5436 45.7819 37.1772C46.1503 36.8105 46.7335 36.5833 47.6 36.5833Z" fill="white" stroke="white"/>
                </g>
                <defs>
                    <filter id="filter0_d_16_2749" x="0.599976" y="0" width="84" height="84" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                        <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                        <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                        <feOffset dy="8"/>
                        <feGaussianBlur stdDeviation="6"/>
                        <feColorMatrix type="matrix" values="0 0 0 0 0.0352941 0 0 0 0 0.117647 0 0 0 0 0.258824 0 0 0 0.1 0"/>
                        <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_16_2749"/>
                        <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_16_2749" result="shape"/>
                    </filter>
                    <linearGradient id="paint0_linear_16_2749" x1="72.6" y1="64" x2="2.26195" y2="47.147" gradientUnits="userSpaceOnUse">
                        <stop stop-color="#EFB008"/>
                        <stop offset="1" stop-color="#D83232"/>
                    </linearGradient>
                </defs>
            </svg>
        </div>

    </div>
    <div x-show="openQR" x-cloak class="fixed top-0 left-0 w-screen h-screen bg-black bg-opacity-50 flex justify-center items-center z-50">
        <div @click.outside="openQR=false" class="w-screen md:w-full md:max-w-md max-w-full py-4 rounded-lg bg-white">
            <div class="w-full flex items-center justify-center">
                {{ QrCode::size(150)->generate(route('owner.point', ['data' => encrypt(['scanBarcode' => true, 'id_user' => auth()->user()->id])])) }}
            </div>
        </div>
    </div>
</div>


