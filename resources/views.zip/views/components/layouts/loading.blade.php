<div>
    <style>
        .body-loading {
            top: 0;
            left:0;
            padding: 0;
            display: flex;
            position:fixed;
            width:100%;
            height:100%;
            justify-content: center;
            align-items: center;
            height: 100vh;
            z-index:500;
            background-color: rgba(255, 255, 255, 0.8);
            overflow:hidden;
            }

            .loading-container {
            display: flex;
            justify-content: center;
            align-items: center;
            }

            .loading-image {
            width: 40px; /* Sesuaikan ukuran gambar loading */
            height: 40px; /* Sesuaikan ukuran gambar loading */
            animation: spin 1s linear infinite;
            }

            @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
            }
    </style>
    <div class="body-loading">
        <div>
            <div class="loading-container">
                <img src="{{ asset('src/icons/loading.svg') }}" alt="Loading..." class="loading-image">
            </div>
            <div style="font-weight: 400;" class="mt-[14px] text-[16px]">
                Mohon menunggu, sedang memporses
            </div>
        </div>
    </div>
</div>
