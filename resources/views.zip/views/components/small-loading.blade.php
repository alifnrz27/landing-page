<div>
    <style>
        .body-small-loading {
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index:500;
            background-color: rgba(255, 255, 255, 0.8);
            overflow:hidden;
            }

            .small-loading-container {
            display: flex;
            justify-content: center;
            align-items: center;
            }

            .small-loading-image {
            width: 40px; /* Sesuaikan ukuran gambar loading */
            height: 40px; /* Sesuaikan ukuran gambar loading */
            animation: spin 1s linear infinite;
            }

            @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
            }
    </style>
    <div class="body-small-loading">
        <div>
            <div class="small-loading-container">
                <img src="{{ asset('src/icons/loading.svg') }}" alt="Loading..." class="small-loading-image">
            </div>
        </div>
    </div>
</div>
