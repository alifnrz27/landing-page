@extends('layouts.app')

@section('content')

    <x-layouts.owner.navbar/>

@endsection
