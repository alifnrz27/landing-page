@extends('layouts.app')

@section('content')

    <livewire:customer.point />

@endsection
