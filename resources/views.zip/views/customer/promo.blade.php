@extends('layouts.app')

@section('content')

    <livewire:customer.promo />

@endsection
