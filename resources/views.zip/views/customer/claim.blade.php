@extends('layouts.app')

@section('content')

    <livewire:customer.claim />

@endsection
