@extends('layouts.app')

@section('content')

    <livewire:customer.dashboard />

@endsection
