@extends('layouts.app')

@section('content')

    <livewire:customer.profile />

@endsection
