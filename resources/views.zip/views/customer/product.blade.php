@extends('layouts.app')

@section('content')

    <livewire:customer.product />

@endsection
