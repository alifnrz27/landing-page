<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PDF</title>
</head>
<body>
    <div style="padding-right: 0.75rem; display: flex; align-items: center; justify-content: center;">
        <div style="margin-left: 35%; width: 50%; position: relative; margin-left: 10px;">
            <div style="font-weight: 700; display: flex; font-size: 24px; justify-content: space-between;">
                <div style="width: 100%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%;" class="text-dark-primary">
                    Detail List Customer
                </div>
            </div>
        </div>
    </div>

    <div style="width: 100%; padding-right: 12px; padding-left: 5px;">
        <table style="width: 100%; border-collapse: collapse; border: 1px solid #000;">
            <thead>
                <tr>
                    <th style="border: 1px solid #000;">Nama</th>
                    <th style="border: 1px solid #000;">Telepon</th>
                    <th style="border: 1px solid #000;">Email</th>
                    <th style="border: 1px solid #000;">Alamat</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($customers as $index => $customer)
                <tr>
                    <td style="border: 1px solid #000; padding-left:4px; padding-right:4px">{{ $customer->name }}</td>
                    <td style="border: 1px solid #000; padding-left:4px; padding-right:4px">{{ $customer->phone_number }}</td>
                    <td style="border: 1px solid #000; padding-left:4px; padding-right:4px">{{ $customer->email }}</td>
                    @if ($customer->address->isNotEmpty())
                        <td style="border: 1px solid #000; padding-left:4px; padding-right:4px">{{ $customer->address->first()->detail . "  " . $customer->address->first()->urban_village . " " . $customer->address->first()->subdistrict . " " . $customer->address->first()->city . " " . $customer->address->first()->province . " (" . $customer->address->first()->postal_code . ")" }}</td>
                    @else
                        <td style="border: 1px solid #000; padding-left:4px; padding-right:4px">No Address Available</td>
                    @endif
                </tr>
                @endforeach
            </tbody>
        </table>

    </div>
</body>
</html>
