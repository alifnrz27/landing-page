@extends('layouts.app')

@section('content')

    <x-layouts.owner.navbar/>
    <div class="w-screen flex justify-center bg-white min-h-screen">
        <div style="margin-top:95px" class="absolute w-full md:flex px-12 text-black bg-white justify-between">
            <div class="w-full md:w-3/5 pr-0 md:pr-24">
                <div>
                    <div class="w-full lg:w-[550px] mb-10">
                        <div style="font-weight: 700;" class="text-black text-[24px] mb-2">
                            Dashboard
                        </div>
                        <div style="font-weight: 400;" class="text-[16px] text-dark-primary">
                            In this page you can see, monitor, analysis information.
                        </div>
                    </div>

                    <div class="w-full lg:flex lg:gap-4">
                        <div class="w-full lg:w-4/12 border-2 rounded-sm my-2">
                            <div class="p-3">
                                <div class="flex mb-2">
                                    <div class="w-6 h-6 bg-[#E5EDFA] rounded-full flex items-center justify-center mr-1">
                                        <img src="{{ asset('src/icons/bxs_coupon.svg') }}" />
                                    </div>
                                    <div style="font-weight: 400;" class="text-[16px] text-gray-500 truncate">
                                        Voucher
                                    </div>
                                </div>

                                <div>
                                    <div style="font-weight: 700;" class="text-[32px] text-dark-primary">
                                        {{ count($expiredVouchers) + count($ongoingVouchers) + count($activeVouchers) }}
                                    </div>
                                </div>
                            </div>
                            <div class="p-3 border-t-2">
                                <div class="flex items-center mb-2">
                                    <div class="w-[6px] h-[6px] bg-[#2C9854] rounded-full mr-1">
                                    </div>
                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary truncate">
                                        {{ count($activeVouchers) }} Active
                                    </div>
                                </div>
                                <div class="flex items-center mb-2">
                                    <div class="w-[6px] h-[6px] bg-[#FF8933] rounded-full mr-1">
                                    </div>
                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary truncate">
                                        {{count($ongoingVouchers)}} On scheduling
                                    </div>
                                </div>
                                <div class="flex items-center">
                                    <div class="w-[6px] h-[6px] bg-[#B1B1B1] rounded-full mr-1">
                                    </div>
                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary truncate">
                                        {{count($expiredVouchers)}} Not active
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="w-full lg:w-4/12 border-2 rounded-sm my-2">
                            <div class="p-3">
                                <div class="flex mb-2">
                                    <div class="w-6 h-6 bg-[#FAE4E4] rounded-full flex items-center justify-center mr-1">
                                        <img src="{{ asset('src/icons/mdi_present.svg') }}" />
                                    </div>
                                    <div style="font-weight: 400;" class="text-[16px] text-gray-500 truncate">
                                        Gift
                                    </div>
                                </div>

                                <div>
                                    <div style="font-weight: 700;" class="text-[32px] text-dark-primary">
                                        {{ count($expiredGifts) + count($ongoingGifts) + count($activeGifts) }}
                                    </div>
                                </div>
                            </div>
                            <div class="p-3 border-t-2">
                                <div class="flex items-center mb-2">
                                    <div class="w-[6px] h-[6px] bg-[#2C9854] rounded-full mr-1">
                                    </div>
                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary truncate">
                                        {{count($activeGifts)}} Active
                                    </div>
                                </div>
                                <div class="flex items-center mb-2">
                                    <div class="w-[6px] h-[6px] bg-[#FF8933] rounded-full mr-1">
                                    </div>
                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary truncate">
                                        {{ count($ongoingGifts) }} On scheduling
                                    </div>
                                </div>
                                <div class="flex items-center">
                                    <div class="w-[6px] h-[6px] bg-[#B1B1B1] rounded-full mr-1">
                                    </div>
                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary truncate">
                                        {{ count($expiredGifts) }} Not active
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="w-full lg:w-4/12 border-2 rounded-sm my-2">
                            <div class="p-3">
                                <div class="flex mb-2">
                                    <div class="w-6 h-6 bg-[#DDF1E2] rounded-full flex items-center justify-center mr-1">
                                        <img src="{{ asset('src/icons/iconamoon_discount-fill.svg') }}" />
                                    </div>
                                    <div style="font-weight: 400;" class="text-[16px] text-gray-500 truncate">
                                        Promo
                                    </div>
                                </div>

                                <div>
                                    <div style="font-weight: 700;" class="text-[32px] text-dark-primary">
                                        {{ count($expiredPromotions) + count($ongoingPromotions) + count($activePromotions) }}
                                    </div>
                                </div>
                            </div>
                            <div class="p-3 border-t-2">
                                <div class="flex items-center mb-2">
                                    <div class="w-[6px] h-[6px] bg-[#2C9854] rounded-full mr-1">
                                    </div>
                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary truncate">
                                        {{count($activePromotions)}} Active
                                    </div>
                                </div>
                                <div class="flex items-center mb-2">
                                    <div class="w-[6px] h-[6px] bg-[#FF8933] rounded-full mr-1">
                                    </div>
                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary truncate">
                                        {{count($ongoingPromotions)}} On scheduling
                                    </div>
                                </div>
                                <div class="flex items-center">
                                    <div class="w-[6px] h-[6px] bg-[#B1B1B1] rounded-full mr-1">
                                    </div>
                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary truncate">
                                        {{count($expiredPromotions)}} Not active
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mt-8">
                        <div style="font-weight: 700;" class="h-8 flex items-center text-[24px] text-dark-primary mb-5">
                            The number of sales nominal points
                        </div>
                        <select onchange="updateDisplayDashboard()" id="filter-by">
                            <option value="3">3 months ago</option>
                            <option value="6">6 month ago</option>
                            <option value="12">1 year ago</option>
                        </select>
                        <div>
                            <canvas id="mixedChartID"></canvas>
                        </div>
                    </div>

                </div>
            </div>
            <div class="w-full md:w-2/5">
                <div>
                    <div style="font-weight: 700;" class="text-black text-[24px] mb-[20px]">
                        Gift
                    </div>
                    <div class="p-5 border rounded-sm w-full">
                        <div class="p-5 bg-[#F5F7F9] rounded-md lg:flex items-center justify-between">
                            <div class="flex items-start">
                                <div class="mr-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path d="M20.97 6.20158L12.72 1.68752C12.4996 1.56572 12.2518 1.50183 12 1.50183C11.7482 1.50183 11.5004 1.56572 11.28 1.68752L3.03 6.20345C2.7944 6.33237 2.59772 6.52217 2.46052 6.75304C2.32331 6.98391 2.25061 7.24739 2.25 7.51595V16.4822C2.25061 16.7508 2.32331 17.0142 2.46052 17.2451C2.59772 17.476 2.7944 17.6658 3.03 17.7947L11.28 22.3106C11.5004 22.4324 11.7482 22.4963 12 22.4963C12.2518 22.4963 12.4996 22.4324 12.72 22.3106L20.97 17.7947C21.2056 17.6658 21.4023 17.476 21.5395 17.2451C21.6767 17.0142 21.7494 16.7508 21.75 16.4822V7.51689C21.7499 7.24785 21.6774 6.98379 21.5402 6.75238C21.403 6.52096 21.206 6.33072 20.97 6.20158ZM12 3.00002L19.5328 7.12502L16.7409 8.6522L9.20813 4.5272L12 3.00002ZM12 11.25L4.46719 7.12502L7.64625 5.38408L15.1791 9.50908L12 11.25ZM20.25 16.486L12.75 20.5913V12.5466L15.75 10.905V14.25C15.75 14.4489 15.829 14.6397 15.9697 14.7803C16.1103 14.921 16.3011 15 16.5 15C16.6989 15 16.8897 14.921 17.0303 14.7803C17.171 14.6397 17.25 14.4489 17.25 14.25V10.0838L20.25 8.4422V16.4822V16.486Z" fill="#FE5C5C"/>
                                    </svg>
                                </div>
                                <div>
                                    <div style="font-weight: 600;" class="h-5 flex items-center text-[16px] text-dark-primary">
                                        {{count($undeliveredGifts)}} Gifts need to be sent
                                    </div>
                                    <div style="font-weight: 400;line-height: 20px;" class="text-[14px] text-[#6A6A75] hidden xl:block">
                                        Double check the gifts that need to be sent to the customer's address. Then, update the delivery status.
                                    </div>
                                </div>
                            </div>
                            <div style="font-weight: 600;" class="text-primary h-[44px] flex items-center justify-center">
                                <div onclick="redirectTo('{{route('owner.claim')}}')" class="w-[120px] flex items-center justify-center no-select cursor-pointer">
                                    See All
                                </div>
                            </div>
                        </div>
                        <div class="mt-[10px]">
                            @foreach($undeliveredGifts as $gift)
                            <div class="flex py-3 justify-between items-center border-b">
                                <div class="flex items-center">
                                    <div class="mr-3">
                                        <div class="h-[40px] w-[40px] flex items-center justify-center bg-[#FAE4E4] rounded-full">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                <path d="M7.55016 1.60843C5.97516 1.6001 4.44183 3.11677 5.14183 5.0001H2.50016C2.05814 5.0001 1.63421 5.17569 1.32165 5.48825C1.00909 5.80082 0.833496 6.22474 0.833496 6.66677V8.33343C0.833496 8.55445 0.921293 8.76641 1.07757 8.92269C1.23385 9.07897 1.44582 9.16677 1.66683 9.16677H9.16683V6.66677H10.8335V9.16677H18.3335C18.5545 9.16677 18.7665 9.07897 18.9228 8.92269C19.079 8.76641 19.1668 8.55445 19.1668 8.33343V6.66677C19.1668 6.22474 18.9912 5.80082 18.6787 5.48825C18.3661 5.17569 17.9422 5.0001 17.5002 5.0001H14.8585C15.8335 2.2751 12.1668 0.350099 10.4752 2.7001L10.0002 3.33343L9.52516 2.68343C9.00016 1.94177 8.27516 1.61677 7.55016 1.60843ZM7.50016 3.33343C8.24183 3.33343 8.61683 4.23343 8.09183 4.75843C7.56683 5.28343 6.66683 4.90843 6.66683 4.16677C6.66683 3.94575 6.75463 3.73379 6.91091 3.57751C7.06719 3.42123 7.27915 3.33343 7.50016 3.33343ZM12.5002 3.33343C13.2418 3.33343 13.6168 4.23343 13.0918 4.75843C12.5668 5.28343 11.6668 4.90843 11.6668 4.16677C11.6668 3.94575 11.7546 3.73379 11.9109 3.57751C12.0672 3.42123 12.2792 3.33343 12.5002 3.33343ZM1.66683 10.0001V16.6668C1.66683 17.1088 1.84242 17.5327 2.15498 17.8453C2.46755 18.1578 2.89147 18.3334 3.3335 18.3334H16.6668C17.1089 18.3334 17.5328 18.1578 17.8453 17.8453C18.1579 17.5327 18.3335 17.1088 18.3335 16.6668V10.0001H10.8335V16.6668H9.16683V10.0001H1.66683Z" fill="#FE5C5C"/>
                                            </svg>
                                        </div>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600;" class="h-5 flex items-center text-[16px] text-dark-primary mb-[2px]">
                                            {{$gift->code}}
                                        </div>
                                        <div class="h-5 hidden lg:flex items-center text-[16px] text-[#6A6A75]">
                                            Ditukar {{changeDateFormat($gift->use_date)}}
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div class="px-2 py-1 border rounded-full hidden lg:flex items-center">
                                        <div class="h-[6px] w-[6px] bg-[#FE5C5C] rounded-full">
                                        </div>
                                        <div class='h-5 flex items-center text-[14px] text-dark-primary ml-1'>
                                            Belum dikirim
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
                <div>
                    <div class="flex justify-between items-center">
                        <div style="font-weight: 700;" class="text-black text-[24px] mb-[32px]">
                            List of sales
                        </div>
                        <div>
                            <select onchange="getListSales()" id="filter-sales">
                                <option value="12">1 year ago</option>
                                <option value="6">6 month ago</option>
                                <option value="3">3 month ago</option>
                                <option value="1">1 month ago</option>
                            </select>
                        </div>
                    </div>

                    <script>
                        function getListSales(){
                            var csrfToken = $('meta[name="csrf-token"]').attr('content');
                            var formData = {
                                month: $("#filter-sales").val(),
                            };

                            $.ajax({
                                type: "GET",
                                url: '{{ env('APP_URL').'/owner/get-sales/' }}' + $("#filter-sales").val(),
                                headers: {
                                    'X-CSRF-TOKEN': csrfToken
                                },
                                contentType: "application/json; charset=utf-8",
                                success: function(response) {
                                    var listContainer = document.getElementById('list-all-sales');
                                        listContainer.innerHTML = '';

                                        // Iterate through the response data and create HTML elements
                                        response.data.forEach(function (user, index) {
                                            var listItem = document.createElement('div');
                                            listItem.className = 'flex border-b-2';

                                            // Build the HTML structure based on your template
                                            listItem.innerHTML = `
                                                <div class="w-[78px] h-[78px] flex justify-center items-center text-center text-dark-primary">
                                                    ${index + 1}
                                                </div>
                                                <div class="w-full py-4 px-1 md:px-1 lg:px-3 flex items-center justify-between">
                                                    <div class="w-4/5 flex">
                                                        <div class-"w-full">
                                                            <div style="font-weight: 600;background-color:#${generateRandomHexColor()};-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;" class="w-[44px] h-[44px] rounded-full text-[13px] text-center flex justify-center items-center text-white hover:cursor-pointer">
                                                                ${generateInitials(user.name)}
                                                            </div>
                                                        </div>
                                                        <div class="w-full h-[44px] ml-2 flex justify-between">
                                                            <div class="max-w-[85px] md:max-w-[100px] lg:max-w-[200px] xl:max-w-[270px]">
                                                                <div class="w-full text-[18px] truncate text-dark-primary">
                                                                    ${user.name}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="font-weight: 400;" class="w-[88px] h-[28px] text-[14px] px-2 py-1 border-2 border-gray-500 rounded-[39px] flex items-center justify-center">
                                                        <div class=" flex items-center justify-center">
                                                            <div class="mr-1 w-[20px] h-[20px]">
                                                                <img class="w-[20px] h-[20px]" src="{{ asset('src/icons/ri_copper-coin-fill.svg') }}" alt="he" />
                                                            </div>
                                                            <div style="font-weight: 400;font-size: 12px;" class="truncate max-w-[30px] lg:max-w-[50px] text-dark-primary points">
                                                                ${user.points} pts
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            `;

                                            // Append the new list item to the container
                                            listContainer.appendChild(listItem);
                                        });
                                },
                                error: function(error) {
                                    console.log(error)
                                }
                            });
                        }

                        // Function to generate random hex color
                        function generateRandomHexColor() {
                            return Math.floor(Math.random()*16777215).toString(16);
                        }

                        // Function to generate initials
                        function generateInitials(name) {
                            return name.split(' ').map(word => word[0]).join('').toUpperCase();
                        }
                    </script>
                    <div class="border-2 p-6 rounded-sm">
                        <div id="list-all-sales">
                            @foreach ($sales as $index => $user)
                            <div class="flex border-b-2">
                                <div class="w-[78px] h-[78px] flex justify-center items-center text-center text-dark-primary">
                                    {{$index+1}}
                                </div>
                                <div class="w-full py-4 px-1 md:px-1 lg:px-3 flex items-center justify-between">
                                    <div class="w-4/5 flex">
                                        <div class-"w-full">
                                            <div style="font-weight: 600;background-color:#{{generateRandomHexColor()}};-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;" class="w-[44px] h-[44px] rounded-full text-[13px] text-center flex justify-center items-center text-white hover:cursor-pointer">
                                                {{generateInitials($user['name'])}}
                                            </div>
                                        </div>
                                        <div class="w-full h-[44px] ml-2 flex justify-between">
                                            <div class="max-w-[85px] md:max-w-[100px] lg:max-w-[200px] xl:max-w-[270px]">
                                                <div class="w-full text-[18px] truncate text-dark-primary">
                                                    {{$user['name']}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="font-weight: 400;" class="w-[88px] h-[28px] text-[14px] px-2 py-1 border-2 border-gray-500 rounded-[39px] flex items-center justify-center">
                                        <div class=" flex items-center justify-center">
                                            <div class="mr-1 w-[20px] h-[20px]">
                                                <img class="w-[20px] h-[20px]" src="{{ asset('src/icons/ri_copper-coin-fill.svg') }}" alt="he" />
                                            </div>
                                            <div style="font-weight: 400;font-size: 12px;" class="truncate max-w-[30px] lg:max-w-[50px] text-dark-primary">
                                                {{$user['points']}} pts
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src=
    "https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js">
        </script>
        <script src=
    "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.1.2/chart.umd.js">
        </script>

    <script>
        getChartData()
        var myChart;

        function getChartData(){
                // filter_by: $("#chartBy").val(),
                var filter_by = $("#filter-by").val()
            $.ajax({
                    type: "GET",
                    url: '{{ env('APP_URL').'/owner/get-chart/' }}' + 3,
                    contentType: "application/json; charset=utf-8",
                    success: function(response) {
                        displayDashboard(response.months, response.nominal, response.points)
                    },
                    error: function(error) {
                        alert('error')
                    }
                });
        }

        function updateDisplayDashboard(labels, data1, data2){
            // filter_by: $("#chartBy").val(),
            var filter_by = $("#filter-by").val()
            var mychart = document.getElementById("mixedChartID").getContext("2d");
            this.myChart.destroy();
            $.ajax({
                    type: "GET",
                    url: '{{ env('APP_URL').'/owner/get-chart/' }}' + filter_by,
                    contentType: "application/json; charset=utf-8",
                    success: function(response) {
                        displayDashboard(response.months, response.nominal, response.points)
                    },
                    error: function(error) {
                        alert('error')
                    }
                });
    }

        function displayDashboard(labels, data1, data2){
            var mychart = document.getElementById("mixedChartID").getContext("2d");
            this.myChart = new Chart(mychart, {
            type: 'bar',
            title: {
                text: "The number of sales points"
            },
            data: {
                datasets: [{
                    label: 'Nominal',
                    data: data1,
                    type: 'bar',
                    borderColor: "blue",
                    borderWidth: 2,
                    yAxisID: 'yAxis1' // Setelah menambahkan ini, dataset ini akan menggunakan yAxis1
                }, {
                    label: 'Points',
                    data: data2,
                    type: 'line',
                    borderColor: "green",
                    yAxisID: 'yAxis2' // Setelah menambahkan ini, dataset ini akan menggunakan yAxis2
                }],
                labels: labels
            },
            options: {
                scales: {
                    yAxis1: {
                        type: 'linear',
                        position: 'left',
                        ticks: {
                            callback: function (value, index, values) {
                                return value / 1000 + 'K'; // Format label sumbu y untuk dataset pertama
                            }
                        }
                    },
                    yAxis2: {
                        type: 'linear',
                        position: 'right',
                        ticks: {
                            callback: function (value, index, values) {
                                return value; // Format label sumbu y untuk dataset kedua
                            }
                        }
                    }
                }
            }
        });
        }
    </script>


@endsection
