@extends('layouts.app')

@section('content')

    <x-layouts.owner.navbar/>
    <div class="w-screen flex justify-center bg-white min-h-screen">
        <div style="margin-top:95px" class="absolute w-full md:flex text-black bg-white justify-between">
            <livewire:owner.users />
        </div>
    </div>

@endsection
