<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PDF</title>
</head>
<body>
    <div style="padding-right: 0.75rem; display: flex; align-items: center; justify-content: center;">
        <div style="margin-left: 35%; width: 50%; position: relative; margin-left: 10px;">
            <div style="font-weight: 700; display: flex; font-size: 24px; justify-content: space-between;">
                <div style="width: 100%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%;" class="text-dark-primary">
                    {{$detailCustomer->name}}
                </div>
            </div>
            <div style="font-weight: 600; margin-top: 2px; margin-left: 2px; font-size: 18px; color: #777777; text-overflow: ellipsis; overflow: hidden; white-space: nowrap; max-width: 100%;" class="text-gray-500">
                {{$detailCustomer->phone_number}}
            </div>
        </div>
    </div>

    <div style="width: 100%; padding-right: 12px; padding-left: 5px;">
        <div style="width: 100%; display: flex; justify-content: space-between;">
            <div style="font-weight: 600; font-size: 18px; width: 25%; color: #1E293B;">Riyawat poin</div>
        </div>

        <div style="width: 100%; margin-top: 10px;">
            @foreach ($points as $index=>$point)
            <div style="width: 100%; display: flex; align-items: center; justify-content: space-between; padding: 10px 20px; {{ $index%2 == 1 ? 'background-color: #F5F7F9;' : '' }}">
                <div style="float: left; width: 75%;">
                    <div style="float: left; width: 30%;font-weight: 600; max-width: 130px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        <div style="font-weight: 600; font-size: 16px; margin-bottom: 1px; {{$index%2 == 1 ? 'color: #333' : 'color: #333; background-color: #fff'}}">
                            {{date("d M Y H:i", strtotime($point['created_at']))}}
                        </div>
                        @if($points[$index]['points'] != null)
                        <div style="font-weight: 400; font-size: 16px; {{$index%2 == 1 ? 'color: #888' : 'color: #888; background-color: #fff'}};">
                            @if($points[$index]['points']['store'] != null)
                            {{ $points[$index]['points']['store']['name'] }}
                            @else
                            Pemilik Utama
                            @endif
                        </div>
                        @endif
                    </div>

                    <div style="width: 65%;margin-left: 25%;">
                        <div style="font-weight: 400;" class="line-clamp-2 mx-4 text-[16px] max-w-[500px] {{$index%2 == 1 ? 'text-dark-primary' : 'text-dark-primary'}}">
                            {{$point['description']}}

                        </div>
                        @if($point['points'] != null)
                        <div style="font-weight: 400;" class="line-clamp-2 mx-4 text-[16px] max-w-[500px] {{$index%2 == 1 ? 'text-dark-primary' : 'text-dark-primary'}}">
                            @if($point['points'] != null)
                            {{ $point['points']['nominal'] }}
                            @else
                            -
                            @endif
                        </div>
                        @endif
                    </div>
                </div>
                <div style="margin-left: 500px; width: 20%;">
                    <div style="font-weight: 400; margin-top: -15px; background-color: white; border: 2px solid #6B7280; border-radius: 39px; padding: 2px 8px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                        <div style="display: flex; align-items: center; justify-content: center;">
                            <div style="font-weight: 400; font-size: 12px;text-align:center">
                                {{ $point['point'] }}pts
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</body>
</html>
