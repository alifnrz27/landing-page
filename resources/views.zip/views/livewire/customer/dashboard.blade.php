<div>
    <div class="w-screen h-screen bg-[#E8EAED] flex justify-center items-center" x-data="{
            howToRedeem:false,
            dashboard:true,
            inbox:false,
            detailInbox:false,
            allInbox:true,
            promoInbox:false,
            voucherInbox:false,
        }" x-init="
        $wire.on('showInbox', value => {
            inbox = value;
            dashboard = !value;
        });
        $wire.on('showDetailInbox', value => {
            inbox = !value;
            detailInbox = value;
        });

        ">
        <div x-cloak x-show="dashboard" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white overflow-auto hide-scrollbar">
            <div class="flex-1 overflow-y-auto hide-scrollbar pb-44 relative">
                <div class="absolute">
                    <img src="{{ asset('src/images/bg-profile.png') }}" alt="">
                </div>
                <div class="p-5 flex items-center justify-between relative">
                    <div class="flex items-center gap-2">
                        <div class="w-6 h-6 rounded-full flex justify-center items-center bg-white">
                            <img class="w-full rounded-full" src="@if(auth()->user()->image_path) {{ asset('storage/' . auth()->user()->image_path) }} @else {{ asset('src/images/profile.png') }} @endif" alt="">
                        </div>
                        <div style="line-height: 22px" class="text-[#FFFFFF] text-[14px] font-medium max-w-[150px] truncate">
                            {{ auth()->user()->name }}
                        </div>
                    </div>
                    <div class="flex items-center gap-2">
                        <div @click="howToRedeem=true;dashboard=false" style="line-height: 20px" class="text-white text-[10px] cursor-pointer no-select lg:text-[14px] flex items-center justify-center px-3 py-2 rounded-full border-white border font-bold">
                            How to redeem
                        </div>
                        <div class=" cursor-pointer" wire:click="showInbox">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19.3399 14.49L18.3399 12.83C18.1299 12.46 17.9399 11.76 17.9399 11.35V8.82C17.9399 6.47 16.5599 4.44 14.5699 3.49C14.0499 2.57 13.0899 2 11.9899 2C10.8999 2 9.91994 2.59 9.39994 3.52C7.44994 4.49 6.09994 6.5 6.09994 8.82V11.35C6.09994 11.76 5.90994 12.46 5.69994 12.82L4.68994 14.49C4.28994 15.16 4.19994 15.9 4.44994 16.58C4.68994 17.25 5.25994 17.77 5.99994 18.02C7.93994 18.68 9.97994 19 12.0199 19C14.0599 19 16.0999 18.68 18.0399 18.03C18.7399 17.8 19.2799 17.27 19.5399 16.58C19.7999 15.89 19.7299 15.13 19.3399 14.49Z" fill="white"/>
                                <path d="M14.8301 20.01C14.4101 21.17 13.3001 22 12.0001 22C11.2101 22 10.4301 21.68 9.88005 21.11C9.56005 20.81 9.32005 20.41 9.18005 20C9.31005 20.02 9.44005 20.03 9.58005 20.05C9.81005 20.08 10.0501 20.11 10.2901 20.13C10.8601 20.18 11.4401 20.21 12.0201 20.21C12.5901 20.21 13.1601 20.18 13.7201 20.13C13.9301 20.11 14.1401 20.1 14.3401 20.07C14.5001 20.05 14.6601 20.03 14.8301 20.01Z" fill="white"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="px-8 w-full relative ">
                    <div class="relative bg-[#0F1A2A] rounded-3xl">
                        <div onclick="redirectTo('{{ route('point') }}')" class="relative cursor-pointer no-select sm:mb-[2%] md:mb-[7%]">
                            <div class="absolute top-0 left-0 w-full">
                                <img src="{{ asset('src/images/bg-dashboard.png') }}" alt="">
                            </div>
                            <div class="relative p-5 flex flex-col justify-center">
                                <div style="line-height: 14.52px" class="text-[#64748B] text-[12px] font-bold">
                                    TOTAL POINT
                                </div>
                                <div class="flex items-center gap-1 mt-3">
                                    <div>
                                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_108_1669)">
                                            <path d="M31.9559 17.1998H26.2402C21.2475 17.1998 17.2002 21.2472 17.2002 26.2398V31.9555C25.0801 31.3712 31.3716 25.0797 31.9559 17.1998Z" fill="#EFB008"/>
                                            <path d="M14.8003 31.9555V26.2398C14.8003 21.2472 10.7529 17.1998 5.76023 17.1998H0.0445557C0.628823 25.0797 6.92031 31.3712 14.8003 31.9555Z" fill="#EFB008"/>
                                            <path d="M31.9559 14.7998C31.3716 6.91988 25.0801 0.628396 17.2002 0.0441284V5.7598C17.2002 10.7525 21.2475 14.7998 26.2402 14.7998H31.9559Z" fill="#EFB008"/>
                                            <path d="M14.8003 0.0441284C6.92031 0.628396 0.628823 6.91988 0.0445557 14.7998H5.76023C10.7529 14.7998 14.8003 10.7525 14.8003 5.7598V0.0441284Z" fill="#EFB008"/>
                                            <path d="M10.8665 15.9998C13.0845 14.8916 14.8921 13.084 16.0002 10.866C17.1085 13.084 18.916 14.8916 21.1341 15.9998C18.916 17.108 17.1085 18.9156 16.0002 21.1336C14.8921 18.9156 13.0845 17.108 10.8665 15.9998Z" fill="#FFDE81"/>
                                            </g>
                                            <defs>
                                            <clipPath id="clip0_108_1669">
                                            <rect width="32" height="32" fill="white"/>
                                            </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div style="line-height: 36px" class="text-[#976400] text-[24px] font-bold">
                                        {{ auth()->user()->total_point }}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div onclick="redirectTo('{{ route('claim') }}')" class="relative px-3 pb-3 flex no-select cursor-pointer items-center justify-between">
                            <div style="line-height: 14.52px" class="text-white font-bold text-[12px]">
                                Redeem Your Point
                            </div>
                            <div>
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8.91003 19.92L15.43 13.4C16.2 12.63 16.2 11.37 15.43 10.6L8.91003 4.07999" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white relative rounded-3xl mt-7">

                    <div class="w-full px-10 pt-6">
                        <div class="w-full flex justify-between items-center mb-3">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary">
                                Latest product
                            </div>
                            <div onclick="redirectTo('{{ route('product') }}')" style="font-weight: 500;line-height:22px" class="flex text-[#64748B] items-center justify-between gap-1 p-3 text-[14px] no-select cursor-pointer">
                                <div>
                                    See all
                                </div>
                                <div>
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8.91003 19.92L15.43 13.4C16.2 12.63 16.2 11.37 15.43 10.6L8.91003 4.08" stroke="#64748B" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="scrollable-element" class="w-full px-10 mt-3" data-carousel="slide" @touchstart="startX = $event.touches[0].clientX"
                        @touchmove="onTouchMove"
                        @touchend="onTouchEnd" x-data="{
                        startX: null, endX: null,swipeThreshold: 50,
                        data_carousel_item:0,
                        canScroll: true,
                        totalItems:{{ count($products) }},
                        currentItem:1,
                        hideCarouselItems() {
                            const carouselItems = document.querySelectorAll('[data-carousel-item]');
                            const carouselSlide = document.querySelectorAll('[data-carousel-slide-to]');
                            carouselItems.forEach(item => {
                                item.classList.add('hidden');
                            });
                            carouselSlide.forEach(item => {
                                item.classList.remove('bg-[#D83232]');
                                item.classList.add('bg-gray-300');
                            });
                        },
                        showItem(element) {
                            if (element instanceof Element) {
                                const slideTo = element.getAttribute('data-carousel-slide-to');
                                if (slideTo !== null) {
                                    this.hideCarouselItems();
                                    element.classList.remove('bg-gray-300');
                                    element.classList.add('bg-[#D83232]');
                                    const elementsWithCarouselItemZero = document.querySelectorAll('[data-carousel-item=\''+slideTo+'\']');
                                    this.currentItem = parseInt(slideTo)+1;
                                    this.canScroll = false;
                                    this.sleep(200).then(() => {
                                        this.canScroll = true;
                                    });
                                    elementsWithCarouselItemZero.forEach((element) => {
                                        element.classList.remove('hidden');
                                    });
                                }
                            }
                        },
                        sleep(ms) {
                            return new Promise(resolve => setTimeout(resolve, ms));
                        },

                        onTouchMove(event) {
                            if (this.canScroll) {
                                this.endX = event.touches[0].clientX;
                                const deltaX = this.endX - this.startX;

                                // Check if the swipe is significant enough
                                if (Math.abs(deltaX) >= this.swipeThreshold) {
                                if (deltaX < 0 && this.currentItem < this.totalItems) {
                                    this.hideCarouselItems();
                                    this.currentItem += 1;
                                    const element = document.querySelector('[data-carousel-slide-to=\'' + (this.currentItem-1) + '\']');
                                    element.classList.remove('bg-gray-300');
                                    element.classList.add('bg-[#D83232]');
                                    const elementsWithCarouselItemZero = document.querySelectorAll('[data-carousel-item=\''+(this.currentItem-1)+'\']');
                                    elementsWithCarouselItemZero.forEach((element) => {
                                        element.classList.remove('hidden');
                                    });
                                    this.canScroll = false;

                                    this.sleep(200).then(() => {
                                        this.canScroll = true;
                                    });
                                } else if (deltaX > 0 && this.currentItem > 1) {
                                    this.hideCarouselItems();
                                    this.currentItem -= 1;
                                    const element = document.querySelector('[data-carousel-slide-to=\'' + (this.currentItem-1) + '\']');
                                    element.classList.remove('bg-gray-300');
                                    element.classList.add('bg-[#D83232]');
                                    const elementsWithCarouselItemZero = document.querySelectorAll('[data-carousel-item=\''+(this.currentItem-1)+'\']');
                                    elementsWithCarouselItemZero.forEach((element) => {
                                        element.classList.remove('hidden');
                                    });

                                    this.canScroll = false;

                                    this.sleep(200).then(() => {
                                        this.canScroll = true;
                                    });
                                }


                                }
                            }
                            },

                            onTouchEnd() {
                            // Reset touch event values
                            this.startX = null;
                            this.endX = null;
                            },

                        scrollHandler() {
                            if (this.canScroll) {
                                if(event.deltaY > 0 || event.deltaX < 0){
                                    if(this.currentItem > 1){
                                        this.hideCarouselItems();
                                        this.currentItem -= 1;
                                        const element = document.querySelector('[data-carousel-slide-to=\'' + (this.currentItem-1) + '\']');
                                        element.classList.remove('bg-gray-300');
                                        element.classList.add('bg-[#D83232]');
                                        const elementsWithCarouselItemZero = document.querySelectorAll('[data-carousel-item=\''+(this.currentItem-1)+'\']');
                                        elementsWithCarouselItemZero.forEach((element) => {
                                            element.classList.remove('hidden');
                                        });
                                    }
                                }else{
                                    if(this.currentItem < this.totalItems){
                                        this.hideCarouselItems();
                                        this.currentItem += 1;
                                        const element = document.querySelector('[data-carousel-slide-to=\'' + (this.currentItem-1) + '\']');
                                        element.classList.remove('bg-gray-300');
                                        element.classList.add('bg-[#D83232]');
                                        const elementsWithCarouselItemZero = document.querySelectorAll('[data-carousel-item=\''+(this.currentItem-1)+'\']');
                                        elementsWithCarouselItemZero.forEach((element) => {
                                            element.classList.remove('hidden');
                                        });

                                    }
                                }
                                this.canScroll = false;

                                this.sleep(200).then(() => {
                                    this.canScroll = true;
                                });
                            }
                        }
                        }" x-on:wheel="scrollHandler()">
                        <!-- Carousel wrapper -->
                        <div class="w-full flex rounded-sm overflow-hidden my-3">
                            @if (count($products) == 0)
                                <div class="w-full h-20 flex items-center justify-center text-[20px] text-dark-primary no-select">
                                    Product not available
                                </div>
                            @else
                            @foreach ($products as $index => $product)
                                <div class="w-full cursor-pointer no-select {{ $index > 0 ? 'hidden' : '' }}" data-carousel-item="{{ $index }}">
                                    <div onclick="redirectTo('{{route('merchant', ['data' => encrypt(['product_from_dashboard' => true, 'id' => $product->id])])}}')" @if($product->thumbnail_path)  @endif class="relative w-full rounded-xl flex items-center @if($product->thumbnail_path) h-full  @else h-[163px] p-5 {{ $index %2 == 0 ? 'bg-[#3688EF]' : 'bg-[#2C9854]' }}  @endif overflow-hidden">
                                        @if($product->thumbnail_path)
                                        <img src="{{ asset('storage/'.$product->thumbnail_path) }}" class="w-full h-full left-0 rounded-2xl" alt="">
                                        @endif
                                        <div style="background: linear-gradient(to right, #FFDE81, rgba(255, 222, 129, 0));" class="z-50 flex top-0 left-0 w-full h-full absolute">
                                            <div class="max-w-[200px] flex flex-col justify-center gap-2 pl-5">
                                                <div style="font-weight: 600;line-height:22px;overflow: hidden;display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 3;" class="flex items-center text-[#000000] text-[18px] mb-1 line-clamp-3">
                                                    {{$product->title}}
                                                </div>
                                                <div style="line-height:12px" class="px-4 py-2 bg-[#D83232] rounded-full text-white text-[10px] font-medium">
                                                    Code: {{ $product->code }}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                                        </div>
                                    </div>
                                </div>
                            @endforeach
                            @endif
                        </div>
                        <!-- Slider indicators -->
                        <div class="z-30 flex mb-3 p-2 items-center justify-center">
                            @foreach ($products as $index => $promo)
                                <button type="button" class="w-2 h-2 mx-1 rounded-full bg-[#D83232] " aria-current="true" aria-label="Slide {{ $index+1 }}" @click="showItem($event.target)" data-carousel-slide-to="{{$index}}"></button>
                            @endforeach
                        </div>
                    </div>

                    <div class="w-full px-10">
                        <div class="w-full flex justify-between items-center mb-3">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary">
                                Latest Promo
                            </div>
                            <div onclick="redirectTo('{{ route('promo') }}')" style="font-weight: 500;line-height:22px" class="flex text-[#64748B] items-center justify-between gap-1 p-3 text-[14px] no-select cursor-pointer">
                                <div>
                                    See all
                                </div>
                                <div>
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8.91003 19.92L15.43 13.4C16.2 12.63 16.2 11.37 15.43 10.6L8.91003 4.08" stroke="#64748B" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="w-full px-10 mt-3 ">
                        <div class="max-w-full overflow-auto flex gap-6 hide-scrollbar" >
                            @if (count($promotions) == 0)
                                <div class="w-full h-20 flex items-center justify-center text-[20px] text-dark-primary no-select">
                                    Promo not available
                                </div>
                            @else
                            @foreach ($promotions as $promo)
                            <div onclick="redirectTo('{{route('merchant', ['data' => encrypt(['from_promo_dashboard' => true, 'id' => $promo->id])])}}')" class="w-[200px] rounded-2xl shadow-lg">
                                <div class="w-[200px]">
                                    @if($promo->thumbnail_path)
                                    <img src="{{ asset('storage/'.$promo->thumbnail_path) }}" class="w-[200px] rounded-t-2xl" alt="">
                                    @else
                                    <div class="w-[200px] h-[100px] rounded-t-2xl bg-gray-500">

                                    </div>
                                    @endif
                                </div>
                                <div class="p-3 flex flex-col gap-2">
                                    <div style="line-height: 20px" class="line-clamp-2 h-[42px] font-normal text-[15px]">
                                        {{ $promo->title }}
                                    </div>
                                    <div style="line-height: 13px" class="text-[#6A7481] text-[11px] font-normal">
                                        {{ $promo->brand->company_name }}
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            @endif
                        </div>
                    </div>

                    <div class="w-full px-10 mt-3">
                        <div class="w-full flex justify-between items-center mb-3">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary">
                                Branch
                            </div>
                            <div onclick="redirectTo('{{ route('merchant') }}')" style="font-weight: 500;line-height:22px" class="flex text-[#64748B] items-center justify-between gap-1 p-3 text-[14px] no-select cursor-pointer">
                                <div>
                                    See all
                                </div>
                                <div>
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8.91003 19.92L15.43 13.4C16.2 12.63 16.2 11.37 15.43 10.6L8.91003 4.08" stroke="#64748B" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="w-full flex flex-wrap justify-between px-8 mt-3">
                        @foreach ($merchants as $index => $merchant)
                            @if($index == 6)
                            @break
                            @endif
                            <div class="w-1/3 text-center mb-4 cursor-pointer px-2">
                                <div class="h-[120px] relative flex items-center justify-center m-auto rounded-lg mb-2" style="position: relative; background-image: url('{{ 'storage/' . $merchant->store_image }}'); background-size: cover; background-position: center; background-repeat: no-repeat;">
                                    <div class="relative w-full h-full inset-0 rounded-lg" style=" background-color: rgb(0 0 0 / var(--tw-bg-opacity));--tw-bg-opacity: 0.3;">
                                        <div class="text-white text-[16px] absolute bottom-3 left-0 flex flex-col items-start max-w-full px-2">
                                            <div style="line-height: 20px" class="text-white font-bold text-[14px] truncate max-w-full">
                                                {{ $merchant->city }}
                                            </div>
                                            <div style="line-height: 20px" class="text-white font-medium text-[12px] truncate max-w-full">
                                                {{ $merchant->count }} Branchs
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            <x-layouts.customer.navbar :currentPage="$currentPage" />
        </div>

        <div x-cloak x-show="inbox" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
            <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar relative">
                <div class="relative">
                    <div class="py-5 bg-white">
                        <div class="relative flex justify-center no-select px-8">
                            <div style="line-height: 26px;font-weight:400;" class="text-[16px] mb-2">
                                Inbox
                            </div>
                            <div @click="inbox=false;dashboard=true" class="absolute left-5 top-1 cursor-pointer">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                                </svg>
                            </div>
                        </div>
                        <div class="relative px-14 mt-7">
                            <div class="flex items-center justify-between no-select">
                                <div @click="allInbox=true;promoInbox=false;voucherInbox=false;" :class="allInbox ? 'font-semibold text-[#D92D20]' : 'font-normal text-[#49454F]'" class="text-[15px] cursor-pointer relative pb-2 " style="line-height: 20px">
                                    <div x-show="allInbox" class="absolute bottom-0 w-full border-2 rounded-t-lg h-[1px] border-[#D92D20]">

                                    </div>
                                    All
                                </div>
                                <div @click="allInbox=false;promoInbox=true;voucherInbox=false;" :class="promoInbox ? 'font-semibold text-[#D92D20]' : 'font-normal text-[#49454F]'" class="text-[15px] cursor-pointer relative pb-2" style="line-height: 20px">
                                    <div x-show="promoInbox" class="absolute bottom-0 w-full border-2 rounded-t-lg h-[1px] border-[#D92D20]">

                                    </div>
                                    Promo
                                </div>
                                <div @click="allInbox=false;promoInbox=false;voucherInbox=true;" :class="voucherInbox ? 'font-semibold text-[#D92D20]' : 'font-normal text-[#49454F]'" class="text-[15px] cursor-pointer relative pb-2" style="line-height: 20px">
                                    <div x-show="voucherInbox" class="absolute bottom-0 w-full border-2 rounded-t-lg h-[1px] border-[#D92D20]">

                                    </div>
                                    Voucher
                                </div>
                            </div>
                        </div>

                        <div x-show="allInbox" class="">
                            @foreach ($allInbox as $inbox)
                            <div wire:click="detailInbox('{{ $inbox['type_inbox'] }}', {{ $inbox['id'] }})" class="flex items-center gap-2 px-5 py-2 cursor-pointer no-select">
                                <div class="h-[64px] w-3/12 flex items-center justify-center">
                                    <img src="{{ asset('storage/' . $inbox['thumbnail_path']) }}" height="64" class="rounded-xl" alt="">
                                </div>
                                <div    class="w-9/12 flex flex-col gap-1">
                                    <div class="text-[#8C0000] text-[12px] font-bold" style="line-height: 14.52px">
                                        {{ $inbox['type_inbox'] == 'promotion' ? "Promo" : 'Voucher' }}
                                    </div>
                                    <div class="text-[14px] font-medium line-clamp-2" style="line-height:22px">
                                        There is new {{ $inbox['type_inbox'] == 'promotion' ? "promo" : 'voucher' }} {{ $inbox['title'] }}
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>

                        <div x-show="promoInbox" class="">
                            @foreach ($promoInbox as $promo)
                            <div wire:click="detailInbox('promotion', {{ $promo->id }})" class="flex items-center gap-2 px-5 py-2 cursor-pointer no-select">
                                <div class="h-[64px] w-3/12 flex items-center justify-center">
                                    <img src="{{ asset('storage/' . $promo->thumbnail_path) }}" height="64" class="rounded-xl" alt="">
                                </div>
                                <div class="w-9/12 flex flex-col gap-1">
                                    <div class="text-[#8C0000] text-[12px] font-bold" style="line-height: 14.52px">
                                        Promo
                                    </div>
                                    <div class="text-[14px] font-medium line-clamp-2" style="line-height:22px">
                                        New promo available {{ $promo->title }}
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>

                        <div x-show="voucherInbox" class="">
                            @foreach ($voucherInbox as $voucher)
                            <div wire:click="detailInbox('voucher', {{ $voucher->id }})" class="flex items-center gap-2 px-5 py-2 cursor-pointer no-select">
                                <div class="h-[64px] w-3/12 flex items-center justify-center">
                                    <img src="{{ asset('storage/'.$voucher->thumbnail_path) }}" height="64" class="rounded-xl" alt="">
                                </div>
                                <div class="w-9/12 flex flex-col gap-1">
                                    <div class="text-[#8C0000] text-[12px] font-bold" style="line-height: 14.52px">
                                        Voucher
                                    </div>
                                    <div class="text-[14px] font-medium line-clamp-2" style="line-height:22px">
                                        New voucher available {{ $voucher->title }}
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>


                </div>
            </div>
        </div>

        <div x-cloak x-show="detailInbox" class="w-screen md:w-full md:max-w-md max-w-full relative overflow-auto hide-scrollbar h-screen flex flex-col bg-white ">
            <div class="w-full absolute bottom-0 h-full">
                <div class=" relative">
                    <div class="relative h-full">
                        <div class="py-3 bg-white h-full">
                            <div class="relative flex justify-center no-select px-8">
                                <div style="line-height: 26px;font-weight:400;" class="text-[16px] mb-2">
                                    Inbox Detail
                                </div>
                                <div @click="inbox=true;detailInbox=false" class="absolute left-5 top-1 cursor-pointer">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="relative">
                    <div>
                        <?php
                        $thumbnailPath = isset($detailInbox['thumbnail_path']) ? $detailInbox['thumbnail_path'] : '';
                        ?>
                        <img src="{{ asset('storage/' . $thumbnailPath) }}" class="w-full" alt="">
                    </div>
                    <div class="mt-6 px-8">
                        <div class="text-[#976400] text-[15px] font-bold" style="line-height:14.52px">
                            {{ isset($detailInbox['type_inbox']) ? $detailInbox['type_inbox'] == 'promotion' ? "Promo" : 'Voucher' : '' }}
                        </div>
                        <div class="mt-3 text-[16px] font-semibold" style="line-height: 20px">
                            {{ isset($detailInbox['title']) ? $detailInbox['title'] : '' }}
                        </div>
                        <div class="mt-3 text-[13px] font-normal" style="line-height: 20px">
                            {{ isset($detailInbox['start_date']) ? changeDateFormat($detailInbox['start_date']) : '' }}
                        </div>
                        <div class="mt-6 text-[15px] font-normal" style="line-height: 22px">
                            {{ isset($detailInbox['description']) ? $detailInbox['description'] : '' }}
                        </div>
                    </div>
                </div>
                <div class="text-[16px] w-screen md:w-full md:max-w-md max-w-full bg-white py-3 px-6 flex items-center justify-center font-bold fixed bottom-0" style="line-height: 24px">
                    <div @if(isset($detailInbox['type_inbox'])) @if($detailInbox['type_inbox'] == 'promotion') onclick="redirectTo('{{route('merchant', ['data' => encrypt(['from_promo_dashboard' => true, 'id' => $detailInbox['id']])])}}')" @else onclick="redirectTo('{{route('claim', ['data' => encrypt(['from_voucher_dashboard' => true, 'id' => $detailInbox['id']])])}}')" @endif @endif class="border rounded-lg w-full flex items-center justify-center py-4 border-[#CBD4E1] no-select cursor-pointer">
                        See detail
                    </div>
                </div>
            </div>
        </div>

        <div x-cloak x-show="howToRedeem" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
            <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar relative">
                <div class="relative">
                    <div class="py-5 bg-white">
                        <div class="relative flex justify-center no-select px-8">
                            <div style="line-height: 26px;font-weight:400;" class="text-[16px] mb-2">
                                How to redeem
                            </div>
                            <div @click="howToRedeem=false;dashboard=true" class="absolute left-5 top-1 cursor-pointer">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                                </svg>
                            </div>
                        </div>
                        <div class="absolute left-0 max-h-screen overflow-hidden">
                            <img src="{{ asset('src/images/bg-promo.png') }}" alt="">
                        </div>
                        <div class="relative mt-[50px] px-7">
                            <div style="line-height: 36px" class="text-white text-[24px] font-bold">
                                Redeem your voucher <br> with 3 easy steps
                            </div>
                            <div class="mt-7 bg-[#F6F8FC] rounded-2xl p-7">
                                <div class="w-full relative">
                                    <div class="absolute left-5 top-0">
                                        <svg width="1" height="289" viewBox="0 0 1 289" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <line x1="0.5" y1="2.18557e-08" x2="0.499987" y2="289" stroke="#CBD4E1" stroke-dasharray="5 5"/>
                                        </svg>
                                    </div>
                                    <div class="flex items-start relative gap-3">
                                        <div>
                                            <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <rect width="44" height="44" rx="22" fill="white"/>
                                                <path d="M31.9201 26.75C31.5901 29.41 29.4101 31.59 26.7501 31.92C25.1401 32.12 23.6401 31.68 22.4701 30.82C21.8001 30.33 21.9601 29.29 22.7601 29.05C25.7701 28.14 28.1401 25.76 29.0601 22.75C29.3001 21.96 30.3401 21.8 30.8301 22.46C31.6801 23.64 32.1201 25.14 31.9201 26.75Z" fill="#EFB008"/>
                                                <path d="M19.99 12C15.58 12 12 15.58 12 19.99C12 24.4 15.58 27.98 19.99 27.98C24.4 27.98 27.98 24.4 27.98 19.99C27.97 15.58 24.4 12 19.99 12ZM19.05 18.87L21.46 19.71C22.33 20.02 22.75 20.63 22.75 21.57C22.75 22.65 21.89 23.54 20.84 23.54H20.75V23.59C20.75 24 20.41 24.34 20 24.34C19.59 24.34 19.25 24 19.25 23.59V23.53C18.14 23.48 17.25 22.55 17.25 21.39C17.25 20.98 17.59 20.64 18 20.64C18.41 20.64 18.75 20.98 18.75 21.39C18.75 21.75 19.01 22.04 19.33 22.04H20.83C21.06 22.04 21.24 21.83 21.24 21.57C21.24 21.22 21.18 21.2 20.95 21.12L18.54 20.28C17.68 19.98 17.25 19.37 17.25 18.42C17.25 17.34 18.11 16.45 19.16 16.45H19.25V16.41C19.25 16 19.59 15.66 20 15.66C20.41 15.66 20.75 16 20.75 16.41V16.47C21.86 16.52 22.75 17.45 22.75 18.61C22.75 19.02 22.41 19.36 22 19.36C21.59 19.36 21.25 19.02 21.25 18.61C21.25 18.25 20.99 17.96 20.67 17.96H19.17C18.94 17.96 18.76 18.17 18.76 18.43C18.75 18.77 18.81 18.79 19.05 18.87Z" fill="#EFB008"/>
                                            </svg>
                                        </div>
                                        <div class="flex flex-col gap-2">
                                            <div style="line-height: 20px" class="text-[16px] font-semibold line-clamp-2">
                                                Collect as many points as possible
                                            </div>
                                            <div style="line-height: 20px" class="text-[#64748B] line-clamp-2 text-[12px] font-normal">
                                                Nec eleifend nullam quam viverra elit ullamcorper vestibulum pretium.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex items-start relative gap-3 mt-12">
                                        <div>
                                            <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <rect width="44" height="44" rx="22" fill="white"/>
                                                <path d="M31.3 20.84C31.69 20.84 32 20.53 32 20.14V19.21C32 15.11 30.75 13.86 26.65 13.86H17.35C13.25 13.86 12 15.11 12 19.21V19.68C12 20.07 12.31 20.38 12.7 20.38C13.6 20.38 14.33 21.11 14.33 22.01C14.33 22.91 13.6 23.63 12.7 23.63C12.31 23.63 12 23.94 12 24.33V24.8C12 28.9 13.25 30.15 17.35 30.15H26.65C30.75 30.15 32 28.9 32 24.8C32 24.41 31.69 24.1 31.3 24.1C30.4 24.1 29.67 23.37 29.67 22.47C29.67 21.57 30.4 20.84 31.3 20.84ZM19 18.88C19.55 18.88 20 19.33 20 19.88C20 20.43 19.56 20.88 19 20.88C18.45 20.88 18 20.43 18 19.88C18 19.33 18.44 18.88 19 18.88ZM25 25.88C24.44 25.88 23.99 25.43 23.99 24.88C23.99 24.33 24.44 23.88 24.99 23.88C25.54 23.88 25.99 24.33 25.99 24.88C25.99 25.43 25.56 25.88 25 25.88ZM25.9 19.48L19.17 26.21C19.02 26.36 18.83 26.43 18.64 26.43C18.45 26.43 18.26 26.36 18.11 26.21C17.82 25.92 17.82 25.44 18.11 25.15L24.84 18.42C25.13 18.13 25.61 18.13 25.9 18.42C26.19 18.71 26.19 19.19 25.9 19.48Z" fill="#EFB008"/>
                                            </svg>
                                        </div>
                                        <div class="flex flex-col gap-2">
                                            <div style="line-height: 20px" class="text-[16px] font-semibold line-clamp-2">
                                                Exchange points into vouchers
                                            </div>
                                            <div style="line-height: 20px" class="text-[#64748B] text-[12px] line-clamp-2 font-normal">
                                                Nec eleifend nullam quam viverra elit ullamcorper vestibulum pretium.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex items-start relative gap-3 mt-12">
                                        <div>
                                            <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <rect width="44" height="44" rx="22" fill="white"/>
                                                <path d="M12 19.75C11.59 19.75 11.25 19.41 11.25 19V16.5C11.25 13.6 13.61 11.25 16.5 11.25H19C19.41 11.25 19.75 11.59 19.75 12C19.75 12.41 19.41 12.75 19 12.75H16.5C14.43 12.75 12.75 14.43 12.75 16.5V19C12.75 19.41 12.41 19.75 12 19.75Z" fill="#EFB008"/>
                                                <path d="M32 19.75C31.59 19.75 31.25 19.41 31.25 19V16.5C31.25 14.43 29.57 12.75 27.5 12.75H25C24.59 12.75 24.25 12.41 24.25 12C24.25 11.59 24.59 11.25 25 11.25H27.5C30.39 11.25 32.75 13.6 32.75 16.5V19C32.75 19.41 32.41 19.75 32 19.75Z" fill="#EFB008"/>
                                                <path d="M27.5 32.75H26C25.59 32.75 25.25 32.41 25.25 32C25.25 31.59 25.59 31.25 26 31.25H27.5C29.57 31.25 31.25 29.57 31.25 27.5V26C31.25 25.59 31.59 25.25 32 25.25C32.41 25.25 32.75 25.59 32.75 26V27.5C32.75 30.4 30.39 32.75 27.5 32.75Z" fill="#EFB008"/>
                                                <path d="M19 32.75H16.5C13.61 32.75 11.25 30.4 11.25 27.5V25C11.25 24.59 11.59 24.25 12 24.25C12.41 24.25 12.75 24.59 12.75 25V27.5C12.75 29.57 14.43 31.25 16.5 31.25H19C19.41 31.25 19.75 31.59 19.75 32C19.75 32.41 19.41 32.75 19 32.75Z" fill="#EFB008"/>
                                                <path d="M19 15.25H17C15.86 15.25 15.25 15.85 15.25 17V19C15.25 20.15 15.86 20.75 17 20.75H19C20.14 20.75 20.75 20.15 20.75 19V17C20.75 15.85 20.14 15.25 19 15.25Z" fill="#EFB008"/>
                                                <path d="M27 15.25H25C23.86 15.25 23.25 15.85 23.25 17V19C23.25 20.15 23.86 20.75 25 20.75H27C28.14 20.75 28.75 20.15 28.75 19V17C28.75 15.85 28.14 15.25 27 15.25Z" fill="#EFB008"/>
                                                <path d="M19 23.25H17C15.86 23.25 15.25 23.85 15.25 25V27C15.25 28.15 15.86 28.75 17 28.75H19C20.14 28.75 20.75 28.15 20.75 27V25C20.75 23.85 20.14 23.25 19 23.25Z" fill="#EFB008"/>
                                                <path d="M27 23.25H25C23.86 23.25 23.25 23.85 23.25 25V27C23.25 28.15 23.86 28.75 25 28.75H27C28.14 28.75 28.75 28.15 28.75 27V25C28.75 23.85 28.14 23.25 27 23.25Z" fill="#EFB008"/>
                                            </svg>
                                        </div>
                                        <div class="flex flex-col gap-2">
                                            <div style="line-height: 20px" class="text-[16px] font-semibold line-clamp-2">
                                                Use voucher code or scan
                                            </div>
                                            <div style="line-height: 20px" class="text-[#64748B] text-[12px] line-clamp-2 font-normal">
                                                Nec eleifend nullam quam viverra elit ullamcorper vestibulum pretium.
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div onclick="redirectTo('{{ route('claim') }}')" style="line-height:24px" class="mt-7 w-full py-4 no-select cursor-pointer flex items-center justify-center font-bold text-[16px] bg-white rounded-xl text-[#D83232]">
                                Start Redeem
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
        <script>
            function showMoreActiveClaim(){
                document.getElementById('claim-4').classList.remove('hidden')
                document.getElementById('claim-5').classList.remove('hidden')
                document.getElementById('show-more').classList.add('hidden')
            }
        </script>
    </div>
</div>


