<div class="w-screen h-screen bg-[#E8EAED] flex justify-center items-center">
    <div class="w-screen md:w-full md:max-w-md max-w-full h-screen max-h-screen overflow-auto bg-white flex flex-col">
        <div class="flex-none">
            <div class="w-full flex p-5">
                <div onclick="redirectTo('{{ route('dashboard') }}')" class="flex items-center no-select cursor-pointer">
                    <div class="mr-1">
                        <div class="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21">
                            <path class="fill-primary" d="M8.45306 6.63482C8.65228 6.83014 8.65228 7.15435 8.45697 7.35357L6.08588 9.73248H15.121C15.3984 9.73248 15.6249 9.95904 15.6249 10.2403C15.6249 10.5215 15.3984 10.7481 15.121 10.7481H6.08588L8.46088 13.127C8.65619 13.3262 8.65228 13.6465 8.45697 13.8458C8.25775 14.0411 7.94134 14.0411 7.74213 13.8419L4.52338 10.5997C4.48041 10.5528 4.44525 10.502 4.41791 10.4395C4.39056 10.377 4.37885 10.3106 4.37885 10.2442C4.37885 10.1114 4.42963 9.98639 4.52338 9.88873L7.74213 6.64654C7.93353 6.44342 8.25384 6.43951 8.45306 6.63482Z"/>
                            </svg>
                        </div>
                    </div>
                    <div style="font-weight: 600;" class="text-primary text-[16px]">
                        Back
                    </div>
                </div>
            </div>
        </div>

        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar">
            <div class="p-5 flex items-center">
                <div class="w-full border bg-white rounded-lg border-[#EDEDED] bg-none p-5 truncate flex flex-col items-center">
                    <div class="w-full justify-center items-center p-1">
                        <div class="flex justify-center items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="33" viewBox="0 0 32 33" fill="none">
                                <path d="M16.0067 29.5773C8.64267 29.5773 2.67334 23.608 2.67334 16.244C2.67334 8.87998 8.64267 2.91064 16.0067 2.91064C23.3707 2.91064 29.34 8.87998 29.34 16.244C29.34 23.608 23.3707 29.5773 16.0067 29.5773ZM16.0067 10.5866L10.3493 16.244L16.0067 21.9013L21.6627 16.244L16.0067 10.5866Z" fill="#FFA858"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M16.0068 8.70092L23.5481 16.244L16.0068 23.787L8.46372 16.244L16.0068 8.70092ZM4.00667 16.244C4.00667 22.8716 9.37905 28.244 16.0067 28.244C22.6343 28.244 28.0067 22.8716 28.0067 16.244C28.0067 9.61636 22.6343 4.24398 16.0067 4.24398C9.37905 4.24398 4.00667 9.61636 4.00667 16.244ZM10.3493 16.244L16.0067 10.5866L21.6627 16.244L16.0067 21.9013L10.3493 16.244ZM2.67334 16.244C2.67334 23.608 8.64267 29.5773 16.0067 29.5773C23.3707 29.5773 29.34 23.608 29.34 16.244C29.34 8.87998 23.3707 2.91064 16.0067 2.91064C8.64267 2.91064 2.67334 8.87998 2.67334 16.244Z" fill="#DF812B"/>
                            </svg>
                        </div>
                    </div>
                    <div style="font-weight: 700;" class="text-[24px] mt-[2px] no-select text-dark-primary">
                        {{ auth()->user()->total_point }} poin
                    </div>
                    <div style="font-weight: 400;" class="text-[16px] mt-[2px] text-[#6A6A75]">
                        Total points earned
                    </div>
                </div>
            </div>

            <div style="font-weight: 600;" class="w-full h-11 mt-6 px-5 text-[18px] text-dark-primary flex items-center">
                Point history
            </div>

            <div class="my-3 px-5">
                @foreach ($historyPoints as $history)
                    <div class="w-full py-3 flex justify-between border-b">
                        <div>
                            <div style="font-weight: 600;" class="text-[16px] h-5 flex items-center text-dark-primary">
                                {{$history->description}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#B1B1B1] h-5 flex items-center">
                                {{ changeDateFormat($history->created_at) }}
                            </div>
                        </div>
                        <div class="px-2 py-1 flex items-center">
                            <div class="mr-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                                    <path d="M10.0042 18.5758C5.40173 18.5758 1.6709 14.845 1.6709 10.2425C1.6709 5.64001 5.40173 1.90918 10.0042 1.90918C14.6067 1.90918 18.3376 5.64001 18.3376 10.2425C18.3376 14.845 14.6067 18.5758 10.0042 18.5758ZM10.0042 6.70668L6.4684 10.2425L10.0042 13.7783L13.5392 10.2425L10.0042 6.70668Z" fill="#FFA858"/>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M10.0043 5.5281L14.7176 10.2425L10.0043 14.9569L5.28989 10.2425L10.0043 5.5281ZM2.50423 10.2425C2.50423 14.3848 5.86197 17.7425 10.0042 17.7425C14.1465 17.7425 17.5042 14.3848 17.5042 10.2425C17.5042 6.10025 14.1465 2.74251 10.0042 2.74251C5.86197 2.74251 2.50423 6.10025 2.50423 10.2425ZM6.4684 10.2425L10.0042 6.70668L13.5392 10.2425L10.0042 13.7783L6.4684 10.2425ZM1.6709 10.2425C1.6709 14.845 5.40173 18.5758 10.0042 18.5758C14.6067 18.5758 18.3376 14.845 18.3376 10.2425C18.3376 5.64001 14.6067 1.90918 10.0042 1.90918C5.40173 1.90918 1.6709 5.64001 1.6709 10.2425Z" fill="#DF812B"/>
                                </svg>
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] {{ $history->is_income_point ? 'text-[#2C9854]' : 'text-[#FE5C5C]'}}">
                                {{ $history->is_income_point ? '+' : '-'}}{{ $history->point }} pts
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="w-full no-select flex justify-center items-center">
                @if($showButtonMore)
                <div wire:click="addMore" class="flex p-3 justify-center items-center cursor-pointer">
                    <div class="mr-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
                            <path d="M10.5 11.7283L15.4609 6.76343C15.8281 6.39624 16.4219 6.39624 16.7852 6.76343C17.1484 7.13062 17.1484 7.72437 16.7852 8.09155L11.1641 13.7166C10.8086 14.072 10.2383 14.0798 9.87109 13.7439L4.21094 8.09546C4.02734 7.91187 3.9375 7.66968 3.9375 7.4314C3.9375 7.19312 4.02734 6.95093 4.21094 6.76733C4.57812 6.40015 5.17187 6.40015 5.53516 6.76733L10.5 11.7283Z" fill="#3688EF"/>
                        </svg>
                    </div>
                    <div style="font-weight: 600;" class="text-[16px] text-primary">
                        More
                    </div>
                </div>
                @endif
            </div>
        </div>
    </div>
</div>
