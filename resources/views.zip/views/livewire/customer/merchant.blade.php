<div class="w-screen h-screen bg-[#E8EAED] flex justify-center items-center" x-data="{
    openMerchants:true,
    openCityStore:false,
    openDetailMerchants:false,
    openDetailStore:false,
    openDetailClaim:false,
    openDetailPromo:false,
    openDetailProduct:false,
    openListStores:false,
    voucherLists:false,
    giftLists:false,
    promoLists:false,
    productLists:false,
    loading:false,
    moreVoucherButton:true,
    moreGiftButton:true,
    morePromotionButton:true,
    moreProductButton:true,
    smallLoading:false,
    exchangeConfirm:false,
    readMore:false,
    openListClaimStores:false,
    openListPromoStores:false,
    openListProductStores:false,
    idMerchant: {{ $idMerchant ? $idMerchant : '0' }},
    fromPromoStore: {{ $from_promo_store ? $from_promo_store : 'false' }},
    fromDashboard: {{ $from_dashboard ? $from_dashboard : 'false' }},
    fromPromoDetail: {{ $from_promo_detail ? $from_promo_detail : 'false' }},
    fromPromoDashboard: {{ $from_promo_dashboard ? $from_promo_dashboard : 'false' }},
    productFromDashboard : {{ $product_from_dashboard ? $product_from_dashboard : 'false' }},
    fromProductDetail : {{ $from_product_detail ? $from_product_detail : 'false' }},
    }"
    x-init="
        if(fromPromoStore){
            openMerchants = false;
            openDetailMerchants = false;
            openDetailStore = true;
            voucherLists = false;
            giftLists = false;
            promoLists = true;
            loading = false;
            scrollToTop();
        }
        if(productFromDashboard || fromProductDetail){

            openMerchants = false;
            openDetailMerchants = false;
            openDetailStore = false;
            openDetailProduct=true;
            loading = false;
            scrollToTop();
        }
        if(fromDashboard || fromPromoDetail || fromPromoDashboard){
            openMerchants = false;
            openDetailMerchants = false;
            openDetailStore = false;
            openDetailPromo=true;
            loading = false;
            scrollToTop();
        }
        $wire.on('showMoreButtonVoucher', value => {
            moreVoucherButton = value;
            smallLoading = !value;
        });
        $wire.on('showDetailClaim', value => {
            openDetailClaim=value;
            openDetailStore = false;
            loading=false;
        });
        $wire.on('showDetailPromo', value => {
            openDetailPromo=value;
            openDetailStore = false;
            loading=false;
        });
        $wire.on('showDetailProduct', value => {
            openDetailProduct=value;
            openDetailStore = false;
            loading=false;
        });
        $wire.on('showExchangeConfirm', value => {
            exchangeConfirm=value;
            loading=false;
        });
        $wire.on('showMoreButtonGift', value => {
            moreGiftButton = value;
            smallLoading = !value;
        });
        $wire.on('showMoreButtonProduct', value => {
            moreProductButton = value;
            smallLoading = !value;
        });
        $wire.on('showMoreButtonPromotion', value => {
            morePromotionButton = value;
            smallLoading = !value;
        });
        $wire.on('showMerchant', value => {
            openMerchants = !value;
            openDetailMerchants = value;
            loading = false;
            scrollToTop();
        });
        $wire.on('showStore', value => {
            openCityStore = !value;
            openDetailStore = value;
            voucherLists = value;
            giftLists = false;
            promoLists = false;
            productLists = false;
            loading = false;
            scrollToTop();
        });
        $wire.on('showCityStore', value => {
            openMerchants = !value;
            openCityStore = value;
            loading = false;
            scrollToTop();
        });

    " x-ref="scrollContainer">
    <div x-show="loading">
        <x-layouts.loading/>
    </div>

    <div x-cloak x-show="openMerchants" class="w-screen md:w-full md:max-w-md max-w-full h-screen bg-white  max-h-screen overflow-auto flex flex-col ">
        <div class="flex-none">
            <div class="w-full flex p-5">
                <div @if($from_promo) onclick="redirectTo('{{ route('promo') }}')" @else onclick="redirectTo('{{ route('dashboard') }}')" @endif class="flex items-center no-select cursor-pointer">
                    <div class="mr-1">
                        <div class="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21">
                            <path class="fill-primary " d="M8.45306 6.63482C8.65228 6.83014 8.65228 7.15435 8.45697 7.35357L6.08588 9.73248H15.121C15.3984 9.73248 15.6249 9.95904 15.6249 10.2403C15.6249 10.5215 15.3984 10.7481 15.121 10.7481H6.08588L8.46088 13.127C8.65619 13.3262 8.65228 13.6465 8.45697 13.8458C8.25775 14.0411 7.94134 14.0411 7.74213 13.8419L4.52338 10.5997C4.48041 10.5528 4.44525 10.502 4.41791 10.4395C4.39056 10.377 4.37885 10.3106 4.37885 10.2442C4.37885 10.1114 4.42963 9.98639 4.52338 9.88873L7.74213 6.64654C7.93353 6.44342 8.25384 6.43951 8.45306 6.63482Z"/>
                            </svg>
                        </div>
                    </div>
                    <div style="font-weight: 600;" class="text-primary  text-[16px]">
                        Back
                    </div>
                </div>
            </div>
        </div>

        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar" x-ref="scrollContainer">
            <div class="mt-4 px-5 pb-5">
                <div class="w-full">
                    <div style="font-weight: 600;" class="mb-2 text-[20px] text-dark-primary ">
                        Merchants available
                    </div>
                    <div style="font-weight: 400;" class="text-[16px] text-[#6A6A75] ">
                        Find merchants closest to you
                    </div>
                </div>
            </div>

            <div class="w-full flex flex-wrap px-5 mt-6">
                @foreach ($merchants as $data)
                    <div wire:click="openCity('{{ $data->city }}')" @click="loading=true" class="w-4/12 text-center mb-4 cursor-pointer">
                        <div class="h-[120px] w-[100px] relative flex items-center justify-center m-auto rounded-lg mb-2" style="position: relative; background-image: url('{{ 'storage/' . $data->store_image }}'); background-size: cover; background-position: center; background-repeat: no-repeat;">

                        </div>
                        <div style="font-weight: 400;" class="text-[16px] mb-[2px] text-dark-primary truncate">
                            {{ $data->city }}
                        </div>
                        <div style="font-weight: 400;" class="text-[16px] mb-[2px] text-dark-primary ">
                            {{ $data->count }} Branches
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>

    <div x-cloak x-show="openCityStore" class="w-screen md:w-full md:max-w-md max-w-full h-screen bg-white  max-h-screen overflow-auto flex flex-col ">
        <div class="flex-none">
            <div class="w-full flex p-5">
                <div @click="openCityStore=false;openMerchants=true;" class="flex items-center no-select cursor-pointer">
                    <div class="mr-1">
                        <div class="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21">
                            <path class="fill-primary " d="M8.45306 6.63482C8.65228 6.83014 8.65228 7.15435 8.45697 7.35357L6.08588 9.73248H15.121C15.3984 9.73248 15.6249 9.95904 15.6249 10.2403C15.6249 10.5215 15.3984 10.7481 15.121 10.7481H6.08588L8.46088 13.127C8.65619 13.3262 8.65228 13.6465 8.45697 13.8458C8.25775 14.0411 7.94134 14.0411 7.74213 13.8419L4.52338 10.5997C4.48041 10.5528 4.44525 10.502 4.41791 10.4395C4.39056 10.377 4.37885 10.3106 4.37885 10.2442C4.37885 10.1114 4.42963 9.98639 4.52338 9.88873L7.74213 6.64654C7.93353 6.44342 8.25384 6.43951 8.45306 6.63482Z"/>
                            </svg>
                        </div>
                    </div>
                    <div style="font-weight: 600;" class="text-primary  text-[16px]">
                        Back
                    </div>
                </div>
            </div>
        </div>

        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar" x-ref="scrollContainer">
            <div class="mt-4 px-5 pb-5">
                <div class="w-full">
                    <div style="font-weight: 600;" class="mb-2 text-[20px] text-dark-primary ">
                        Merchants available
                    </div>
                    <div style="font-weight: 400;" class="text-[16px] text-[#6A6A75] ">
                        Find merchants who work with us & enjoy attractive offers
                    </div>
                </div>
            </div>

            <div class="w-full flex flex-wrap px-5 mt-6">
                @foreach ($merchantCity as $data)
                    <div wire:click="openMerchant({{ $data->id }})" @click="loading=true" class="w-4/12 text-center mb-4 cursor-pointer">
                        <div class="w-[92px] h-[92px] flex items-center justify-center text-white m-auto bg-cover bg-center bg-no-repeat rounded-full mb-2" style="background-color: #{{ generateRandomHexColor() }}">
                            <div class="text[16px]">
                                {{ generateInitials($data->name) }}
                            </div>
                        </div>
                        <div style="font-weight: 400;" class="text-[16px] mb-[2px] text-dark-primary ">
                            {{ $data->name }}
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>

    <div x-cloak x-show="openDetailStore" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        @if($detailStore)
        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar relative bg-white">
            <div class="absolute">
                <img src="{{ asset('src/images/bg-profile.png') }}" alt="">
            </div>
            <div class="relative py-5">
                <div class="relative flex justify-center no-select">
                    <div style="line-height: 26px;font-weight:400;" class="text-[16px] text-white">
                        {{$detailStore->name}}
                    </div>
                    <div @if($from_promo_store) @click="redirectTo('{{ route('promo') }}')" @else wire:click="closeStore" @endif  class="absolute left-3 top-1 cursor-pointer">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="white"/>
                        </svg>
                    </div>
                </div>

                <div class="bg-white rounded-t-2xl pt-1 mt-12 pb-52 relative">
                    <div class="w-full h-12 flex items-center justify-between mt-5 max-w-full overflow-auto hide-scrollbar">
                        <div @click="voucherLists=true;giftLists=false;promoLists=false;productLists=false"  class="w-4/12 px-6 no-select cursor-pointer h-full flex items-center justify-center text-[16px] border-r-[1px]">
                            <div :class="voucherLists ? 'text-dark-primary font-bold border-b-[#DA0713] border-b-4' : 'text-[#6A6A75] font-light border-none'" class=" py-2">
                                Voucher
                            </div>
                        </div>
                        <div  @click="voucherLists=false;giftLists=true;promoLists=false;productLists=false" class="w-4/12 px-6 py-2 no-select cursor-pointer flex items-center justify-center text-[16px] h-full border-r-[1px]">
                            <div :class="giftLists ? 'text-dark-primary font-bold border-b-[#DA0713] border-b-4' : 'text-[#6A6A75] font-light border-none'" class=" py-2">
                                Gift
                            </div>
                        </div>
                        <div @click="voucherLists=false;giftLists=false;promoLists=true;productLists=false" class="w-4/12 px-6 py-2 no-select cursor-pointer h-full flex items-center justify-center text-[16px] border-r-[1px]">
                            <div :class="promoLists ? 'text-dark-primary font-bold border-b-[#DA0713] border-b-4' : 'text-[#6A6A75] font-light border-none'" class=" py-2">
                                Promo
                            </div>
                        </div>
                        <div @click="voucherLists=false;giftLists=false;promoLists=false;productLists=true" class="w-4/12 px-6 py-2 no-select cursor-pointer h-full flex items-center justify-center text-[16px]">
                            <div :class="productLists ? 'text-dark-primary font-bold border-b-[#DA0713] border-b-4' : 'text-[#6A6A75] font-light border-none'" class=" py-2">
                                Product
                            </div>
                        </div>
                    </div>

                    <div class="w-full p-5">
                        <div x-show="voucherLists">
                            @foreach ($vouchers as $voucher)
                            <?php
                                $precentageStock = intval((count($voucher->claimmed) / $voucher->stock) * 100);
                            ?>
                            <div class=" bg-white shadow-lg rounded-xl  mt-6 cursor-pointer relative" wire:click="showDetailClaim({{$voucher->id}})" @click="loading=true">
                                @if($voucher->thumbnail_path)
                                <img src="{{ asset('storage/'. $voucher->thumbnail_path) }}" class= "w-[100%] h-full rounded-xl" alt="Image">
                                @else
                                <div class="relative flex p-5 items-center bg-[#2C9854] overflow-hidden rounded-xl">
                                    <div class="mr-[18px]">
                                        <svg width="46" height="49" viewBox="0 0 46 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_328_4498)">
                                                <path d="M42.1875 39.3087L27.7025 47.3482C27.0076 47.7339 25.8705 47.7339 25.1757 47.3482L10.6906 39.3087C10.3432 39.1159 10.1695 38.8616 10.1695 38.6075H10.0156V20.6479H42.7087V38.6075C42.7087 38.8616 42.535 39.1159 42.1875 39.3087Z" fill="#FE5C5C"/>
                                                <path d="M42.7081 20.6478V38.6073C42.7081 38.8615 42.5344 39.1157 42.187 39.3086L27.7019 47.3481C27.3406 47.5486 26.8598 47.6441 26.3837 47.6359C26.3949 38.6428 26.6506 29.6383 26.3711 20.6477L42.7081 20.6478Z" fill="#FC8B8B"/>
                                                <path d="M25.1751 29.3887L10.6901 21.3491C9.99522 20.9634 9.99522 20.3324 10.6901 19.9467L25.1751 11.9072C25.87 11.5215 27.0071 11.5215 27.7019 11.9072L42.187 19.9467C42.8819 20.3324 42.8819 20.9635 42.187 21.3492L27.702 29.3887C27.0071 29.7744 25.87 29.7744 25.1751 29.3887Z" fill="#FFA9BA"/>
                                                <path d="M36.271 16.4045C36.2703 16.4895 36.2467 16.5727 36.2026 16.6454C36.1586 16.7181 36.0958 16.7775 36.0208 16.8175L18.6653 26.0688C18.6414 26.0815 18.6164 26.0922 18.5907 26.1006L18.532 26.1334V43.3984C18.532 43.4807 18.5106 43.5616 18.4697 43.633C18.4289 43.7044 18.3701 43.764 18.2992 43.8057C18.2283 43.8475 18.1477 43.87 18.0655 43.871C17.9832 43.8721 17.9021 43.8516 17.8301 43.8117L14.922 42.1976C14.8482 42.1567 14.7868 42.0968 14.744 42.0241C14.7013 41.9514 14.6787 41.8687 14.6787 41.7843V24.9835C14.6788 24.6952 14.7436 24.4106 14.8683 24.1507C14.9931 23.8908 15.1746 23.6622 15.3994 23.4818L15.4166 23.4684C15.4547 23.4386 15.4908 23.4124 15.528 23.3873C15.5832 23.3498 15.6402 23.3152 15.699 23.2835L32.5474 14.3025C32.617 14.2654 32.6948 14.2463 32.7737 14.2469C32.8526 14.2476 32.9301 14.268 32.999 14.3063L36.0278 15.9873C36.1021 16.0286 36.1639 16.0891 36.2067 16.1625C36.2495 16.2359 36.2717 16.3195 36.271 16.4045ZM37.8715 23.7135C37.7615 23.5881 37.6357 23.4776 37.4972 23.3847C37.4881 23.3785 37.479 23.3723 37.4683 23.3653C37.4233 23.336 37.3771 23.3086 37.3298 23.2833L20.4814 14.3024C20.4118 14.2653 20.334 14.2462 20.2551 14.2468C20.1762 14.2475 20.0988 14.2679 20.0298 14.3063L17.001 15.9873C16.9267 16.0285 16.8648 16.089 16.822 16.1624C16.7792 16.2359 16.757 16.3195 16.7577 16.4045C16.7584 16.4895 16.782 16.5727 16.8261 16.6454C16.8702 16.7181 16.933 16.7776 17.0081 16.8175L34.3636 26.0688C34.3877 26.0816 34.4127 26.0923 34.4382 26.1007L34.4968 26.1335V43.3985C34.4968 43.4808 34.5183 43.5616 34.5591 43.6331C34.6 43.7045 34.6587 43.764 34.7296 43.8058C34.8005 43.8475 34.8811 43.87 34.9634 43.8711C35.0457 43.8721 35.1268 43.8517 35.1987 43.8118L38.1069 42.1977C38.1806 42.1567 38.242 42.0968 38.2848 42.0242C38.3276 41.9515 38.3501 41.8687 38.3501 41.7844V24.9835C38.3499 24.5161 38.1798 24.0648 37.8715 23.7135Z" fill="#3688EF"/>
                                                <path d="M32.2361 20.982C32.2361 22.1679 30.7816 23.0285 28.7777 23.0285C27.9604 23.0285 27.2347 22.8852 26.6617 22.6353C26.5885 22.6035 26.5092 22.5883 26.4295 22.5906C26.3498 22.593 26.2715 22.6129 26.2004 22.649C25.6031 22.9504 24.8111 23.1261 23.9067 23.1261C21.9028 23.1261 20.4482 22.2654 20.4482 21.0795C20.4482 20.4825 20.817 19.968 21.4389 19.6041C21.6839 19.4608 21.7868 19.1549 21.6655 18.8983C21.2222 17.9609 21.2364 17.0814 21.7801 16.5377C22.0617 16.2561 22.4473 16.1073 22.8954 16.1073C23.2102 16.1073 23.5521 16.1817 23.9033 16.3214C24.0382 16.3752 24.1889 16.3738 24.3228 16.3174C24.4567 16.2611 24.5631 16.1543 24.619 16.0202C24.98 15.1586 25.5772 14.6279 26.2934 14.6279C26.9973 14.6279 27.5865 15.1406 27.9493 15.9764C28.0697 16.2538 28.3875 16.3862 28.667 16.2708C29.034 16.1194 29.3916 16.0384 29.7199 16.0384C30.2859 16.0384 30.6388 16.2724 30.8352 16.4688C31.3696 17.0032 31.3926 17.8621 30.9722 18.7816C30.8543 19.0395 30.9589 19.3448 31.2058 19.4843C31.8515 19.8491 32.2361 20.3725 32.2361 20.982Z" fill="#2F6BB7"/>
                                            </g>
                                            <circle cx="40.8979" cy="11.7502" r="1.71429" fill="#FF8933"/>
                                            <path d="M11.4777 3.74029C12.0165 3.25521 12.8612 3.74291 12.7105 4.452C12.643 4.76912 12.7875 5.09357 13.0683 5.25567C13.6961 5.61814 13.4933 6.57222 12.7723 6.648C12.4499 6.68189 12.186 6.91954 12.1186 7.23665C11.9678 7.94575 10.9978 8.0477 10.7029 7.38544C10.5711 7.08927 10.2635 6.91169 9.94106 6.94558C9.22009 7.02135 8.82336 6.13029 9.36209 5.64521C9.60302 5.42828 9.67686 5.08088 9.545 4.78471C9.25014 4.12244 9.975 3.46978 10.6028 3.83224C10.8836 3.99434 11.2368 3.95722 11.4777 3.74029Z" fill="#80D5EF"/>
                                            <circle cx="28.1635" cy="1.95428" r="1.71429" fill="white"/>
                                            <path d="M3.66431 30.9826C3.70225 30.2587 4.64441 30.0062 5.03924 30.6142C5.21581 30.8861 5.54739 31.0134 5.86054 30.9295C6.56077 30.7419 7.09201 31.5599 6.6358 32.1233C6.43177 32.3752 6.41318 32.7299 6.58975 33.0018C6.98458 33.6098 6.37075 34.3678 5.69396 34.108C5.39129 33.9918 5.04823 34.0838 4.84421 34.3357C4.38799 34.8991 3.47738 34.5495 3.51532 33.8256C3.53229 33.5018 3.33885 33.204 3.03619 33.0878C2.3594 32.828 2.41045 31.8539 3.11068 31.6663C3.42384 31.5824 3.64735 31.3064 3.66431 30.9826Z" fill="#ABEAB9"/>
                                            <defs>
                                                <clipPath id="clip0_328_4498">
                                                    <rect width="37.2245" height="37.2245" fill="white" transform="translate(7.83691 11.0154)"/>
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600;" class="h-6 flex items-center text-white text-[20px] mb-1">
                                            Claim image
                                        </div>
                                        <div style="font-weight: 400;" class="h-5 text-white text-[16px]">
                                            Claim now!
                                        </div>
                                    </div>
                                    <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                                    </div>
                                </div>
                                @endif

                                <div class="absolute px-2 w-full top-[40%] md:top-[45%] lg:top-[48%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{$detailStore->name}}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ readableDaysLeft($voucher->end_date) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="p-3 bg-white rounded-b-lg ">
                                    <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] mt-5 h-[68px] text-dark-primary flex items-center">
                                        {{$voucher->title}}
                                    </div>
                                    <div class="w-full">
                                        <div class="relative h-[4px] bg-gray-200 mb-1">
                                            <div class="absolute top-0 h-[4px] @if($precentageStock > 70) bg-red-500 @elseif($precentageStock > 30) bg-yellow-500 @else bg-[#2C9854] @endif" style="width: {{ $precentageStock }}%;"></div>
                                        </div>
                                        <div class="flex justify-between items-center">
                                            <div style="line-height: 13px" class="text-[#202124] font-normal text-[11px]">
                                                Stock left
                                            </div>
                                            <div style="line-height: 13px" class="text-[10px] font-normal @if($precentageStock > 70) text-red-500 @elseif($precentageStock > 30) text-yellow-500 @else text-[#2C9854] @endif">
                                                {{ $voucher->stock - count($voucher->claimmed) }} voucher left
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex justify-between items-center mt-6">
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_15_1368)">
                                                    <path d="M16.4779 8.59992H13.6201C11.1237 8.59992 9.1001 10.6236 9.1001 13.1199V15.9778C13.0401 15.6856 16.1858 12.5399 16.4779 8.59992Z" fill="#EFB008"/>
                                                    <path d="M7.90007 15.9778V13.1199C7.90007 10.6236 5.87639 8.59992 3.38006 8.59992H0.522217C0.81435 12.5399 3.9601 15.6856 7.90007 15.9778Z" fill="#EFB008"/>
                                                    <path d="M16.4779 7.39992C16.1858 3.45995 13.0401 0.314206 9.1001 0.0220718V2.87991C9.1001 5.37624 11.1237 7.39992 13.6201 7.39992H16.4779Z" fill="#EFB008"/>
                                                    <path d="M7.90007 0.0220718C3.9601 0.314206 0.81435 3.45995 0.522217 7.39992H3.38006C5.87639 7.39992 7.90007 5.37624 7.90007 2.87991V0.0220718Z" fill="#EFB008"/>
                                                    <path d="M5.93323 7.99992C7.04223 7.4458 7.94603 6.542 8.50011 5.433C9.05423 6.542 9.95799 7.4458 11.067 7.99992C9.95799 8.554 9.05423 9.4578 8.50011 10.5668C7.94603 9.4578 7.04223 8.554 5.93323 7.99992Z" fill="#FFDE81"/>
                                                    </g>
                                                    <defs>
                                                    <clipPath id="clip0_15_1368">
                                                    <rect width="16" height="16" fill="white" transform="translate(0.5)"/>
                                                    </clipPath>
                                                    </defs>
                                                </svg>
                                            </div>
                                            <div style="line-height: 22px" class="text-[#976400] font-semibold text-[18px]">
                                                {{ $voucher->exchange_rate }} Point
                                            </div>
                                        </div>
                                        <div style="line-height: 20px" class="bg-[#D83232] rounded-full px-7 py-2 flex items-center justify-center text-white font-bold text-[14px]">
                                            Redeem
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            <div class="w-full mt-[16px] flex justify-center items-center">
                                <div>
                                    @if($showAddMoreButtonVouchers)
                                    <div x-show="moreVoucherButton" @click="moreVoucherButton = false; smallLoading = true" wire:click="addMoreVoucher" class="p-3 flex items-center cursor-pointer no-select">
                                        <div class="mr-1">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
                                                <path d="M10.5 11.7283L15.4609 6.76343C15.8281 6.39624 16.4219 6.39624 16.7852 6.76343C17.1484 7.13062 17.1484 7.72437 16.7852 8.09155L11.1641 13.7166C10.8086 14.072 10.2383 14.0798 9.87109 13.7439L4.21094 8.09546C4.02734 7.91187 3.9375 7.66968 3.9375 7.4314C3.9375 7.19312 4.02734 6.95093 4.21094 6.76733C4.57812 6.40015 5.17187 6.40015 5.53516 6.76733L10.5 11.7283Z" fill="#3688EF"/>
                                            </svg>
                                        </div>
                                        <div style="font-weight: 600;" class="h-5 flex items-center text-primary text-[16px]">
                                            More
                                        </div>
                                    </div>
                                    @endif

                                </div>
                            </div>
                        </div>

                        <div x-show="giftLists">
                            @foreach ($gifts as $gift)
                            <?php
                                $precentageStock = intval((count($gift->claimmed) / $gift->stock) * 100);
                            ?>
                            <div class=" bg-white shadow-lg rounded-xl  mt-6 cursor-pointer relative" wire:click="showDetailClaim({{$gift->id}})" @click="loading=true">
                                @if($gift->thumbnail_path)
                                <img src="{{ asset('storage/'. $gift->thumbnail_path) }}" class= "w-[100%] h-full rounded-xl" alt="Image">
                                @else
                                <div class="relative flex p-5 items-center bg-[#2C9854] overflow-hidden rounded-xl">
                                    <div class="mr-[18px]">
                                        <svg width="46" height="49" viewBox="0 0 46 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_328_4498)">
                                                <path d="M42.1875 39.3087L27.7025 47.3482C27.0076 47.7339 25.8705 47.7339 25.1757 47.3482L10.6906 39.3087C10.3432 39.1159 10.1695 38.8616 10.1695 38.6075H10.0156V20.6479H42.7087V38.6075C42.7087 38.8616 42.535 39.1159 42.1875 39.3087Z" fill="#FE5C5C"/>
                                                <path d="M42.7081 20.6478V38.6073C42.7081 38.8615 42.5344 39.1157 42.187 39.3086L27.7019 47.3481C27.3406 47.5486 26.8598 47.6441 26.3837 47.6359C26.3949 38.6428 26.6506 29.6383 26.3711 20.6477L42.7081 20.6478Z" fill="#FC8B8B"/>
                                                <path d="M25.1751 29.3887L10.6901 21.3491C9.99522 20.9634 9.99522 20.3324 10.6901 19.9467L25.1751 11.9072C25.87 11.5215 27.0071 11.5215 27.7019 11.9072L42.187 19.9467C42.8819 20.3324 42.8819 20.9635 42.187 21.3492L27.702 29.3887C27.0071 29.7744 25.87 29.7744 25.1751 29.3887Z" fill="#FFA9BA"/>
                                                <path d="M36.271 16.4045C36.2703 16.4895 36.2467 16.5727 36.2026 16.6454C36.1586 16.7181 36.0958 16.7775 36.0208 16.8175L18.6653 26.0688C18.6414 26.0815 18.6164 26.0922 18.5907 26.1006L18.532 26.1334V43.3984C18.532 43.4807 18.5106 43.5616 18.4697 43.633C18.4289 43.7044 18.3701 43.764 18.2992 43.8057C18.2283 43.8475 18.1477 43.87 18.0655 43.871C17.9832 43.8721 17.9021 43.8516 17.8301 43.8117L14.922 42.1976C14.8482 42.1567 14.7868 42.0968 14.744 42.0241C14.7013 41.9514 14.6787 41.8687 14.6787 41.7843V24.9835C14.6788 24.6952 14.7436 24.4106 14.8683 24.1507C14.9931 23.8908 15.1746 23.6622 15.3994 23.4818L15.4166 23.4684C15.4547 23.4386 15.4908 23.4124 15.528 23.3873C15.5832 23.3498 15.6402 23.3152 15.699 23.2835L32.5474 14.3025C32.617 14.2654 32.6948 14.2463 32.7737 14.2469C32.8526 14.2476 32.9301 14.268 32.999 14.3063L36.0278 15.9873C36.1021 16.0286 36.1639 16.0891 36.2067 16.1625C36.2495 16.2359 36.2717 16.3195 36.271 16.4045ZM37.8715 23.7135C37.7615 23.5881 37.6357 23.4776 37.4972 23.3847C37.4881 23.3785 37.479 23.3723 37.4683 23.3653C37.4233 23.336 37.3771 23.3086 37.3298 23.2833L20.4814 14.3024C20.4118 14.2653 20.334 14.2462 20.2551 14.2468C20.1762 14.2475 20.0988 14.2679 20.0298 14.3063L17.001 15.9873C16.9267 16.0285 16.8648 16.089 16.822 16.1624C16.7792 16.2359 16.757 16.3195 16.7577 16.4045C16.7584 16.4895 16.782 16.5727 16.8261 16.6454C16.8702 16.7181 16.933 16.7776 17.0081 16.8175L34.3636 26.0688C34.3877 26.0816 34.4127 26.0923 34.4382 26.1007L34.4968 26.1335V43.3985C34.4968 43.4808 34.5183 43.5616 34.5591 43.6331C34.6 43.7045 34.6587 43.764 34.7296 43.8058C34.8005 43.8475 34.8811 43.87 34.9634 43.8711C35.0457 43.8721 35.1268 43.8517 35.1987 43.8118L38.1069 42.1977C38.1806 42.1567 38.242 42.0968 38.2848 42.0242C38.3276 41.9515 38.3501 41.8687 38.3501 41.7844V24.9835C38.3499 24.5161 38.1798 24.0648 37.8715 23.7135Z" fill="#3688EF"/>
                                                <path d="M32.2361 20.982C32.2361 22.1679 30.7816 23.0285 28.7777 23.0285C27.9604 23.0285 27.2347 22.8852 26.6617 22.6353C26.5885 22.6035 26.5092 22.5883 26.4295 22.5906C26.3498 22.593 26.2715 22.6129 26.2004 22.649C25.6031 22.9504 24.8111 23.1261 23.9067 23.1261C21.9028 23.1261 20.4482 22.2654 20.4482 21.0795C20.4482 20.4825 20.817 19.968 21.4389 19.6041C21.6839 19.4608 21.7868 19.1549 21.6655 18.8983C21.2222 17.9609 21.2364 17.0814 21.7801 16.5377C22.0617 16.2561 22.4473 16.1073 22.8954 16.1073C23.2102 16.1073 23.5521 16.1817 23.9033 16.3214C24.0382 16.3752 24.1889 16.3738 24.3228 16.3174C24.4567 16.2611 24.5631 16.1543 24.619 16.0202C24.98 15.1586 25.5772 14.6279 26.2934 14.6279C26.9973 14.6279 27.5865 15.1406 27.9493 15.9764C28.0697 16.2538 28.3875 16.3862 28.667 16.2708C29.034 16.1194 29.3916 16.0384 29.7199 16.0384C30.2859 16.0384 30.6388 16.2724 30.8352 16.4688C31.3696 17.0032 31.3926 17.8621 30.9722 18.7816C30.8543 19.0395 30.9589 19.3448 31.2058 19.4843C31.8515 19.8491 32.2361 20.3725 32.2361 20.982Z" fill="#2F6BB7"/>
                                            </g>
                                            <circle cx="40.8979" cy="11.7502" r="1.71429" fill="#FF8933"/>
                                            <path d="M11.4777 3.74029C12.0165 3.25521 12.8612 3.74291 12.7105 4.452C12.643 4.76912 12.7875 5.09357 13.0683 5.25567C13.6961 5.61814 13.4933 6.57222 12.7723 6.648C12.4499 6.68189 12.186 6.91954 12.1186 7.23665C11.9678 7.94575 10.9978 8.0477 10.7029 7.38544C10.5711 7.08927 10.2635 6.91169 9.94106 6.94558C9.22009 7.02135 8.82336 6.13029 9.36209 5.64521C9.60302 5.42828 9.67686 5.08088 9.545 4.78471C9.25014 4.12244 9.975 3.46978 10.6028 3.83224C10.8836 3.99434 11.2368 3.95722 11.4777 3.74029Z" fill="#80D5EF"/>
                                            <circle cx="28.1635" cy="1.95428" r="1.71429" fill="white"/>
                                            <path d="M3.66431 30.9826C3.70225 30.2587 4.64441 30.0062 5.03924 30.6142C5.21581 30.8861 5.54739 31.0134 5.86054 30.9295C6.56077 30.7419 7.09201 31.5599 6.6358 32.1233C6.43177 32.3752 6.41318 32.7299 6.58975 33.0018C6.98458 33.6098 6.37075 34.3678 5.69396 34.108C5.39129 33.9918 5.04823 34.0838 4.84421 34.3357C4.38799 34.8991 3.47738 34.5495 3.51532 33.8256C3.53229 33.5018 3.33885 33.204 3.03619 33.0878C2.3594 32.828 2.41045 31.8539 3.11068 31.6663C3.42384 31.5824 3.64735 31.3064 3.66431 30.9826Z" fill="#ABEAB9"/>
                                            <defs>
                                                <clipPath id="clip0_328_4498">
                                                    <rect width="37.2245" height="37.2245" fill="white" transform="translate(7.83691 11.0154)"/>
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600;" class="h-6 flex items-center text-white text-[20px] mb-1">
                                            Claim image
                                        </div>
                                        <div style="font-weight: 400;" class="h-5 text-white text-[16px]">
                                            Claim now!
                                        </div>
                                    </div>
                                    <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                                    </div>
                                </div>
                                @endif

                                <div class="absolute px-2 w-full top-[40%] md:top-[45%] lg:top-[48%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{$detailStore->name}}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ readableDaysLeft($gift->end_date) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="p-3 bg-white rounded-b-lg ">
                                    <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] mt-5 h-[68px] text-dark-primary flex items-center">
                                        {{$gift->title}}
                                    </div>
                                    <div class="w-full">
                                        <div class="relative h-[4px] bg-gray-200 mb-1">
                                            <div class="absolute top-0 h-[4px] @if($precentageStock > 70) bg-red-500 @elseif($precentageStock > 30) bg-yellow-500 @else bg-[#2C9854] @endif" style="width: {{ $precentageStock }}%;"></div>
                                        </div>
                                        <div class="flex justify-between items-center">
                                            <div style="line-height: 13px" class="text-[#202124] font-normal text-[11px]">
                                                Stock left
                                            </div>
                                            <div style="line-height: 13px" class="text-[10px] font-normal @if($precentageStock > 70) text-red-500 @elseif($precentageStock > 30) text-yellow-500 @else text-[#2C9854] @endif">
                                                {{ $gift->stock - count($gift->claimmed) }} gift left
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex justify-between items-center mt-6">
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_15_1368)">
                                                    <path d="M16.4779 8.59992H13.6201C11.1237 8.59992 9.1001 10.6236 9.1001 13.1199V15.9778C13.0401 15.6856 16.1858 12.5399 16.4779 8.59992Z" fill="#EFB008"/>
                                                    <path d="M7.90007 15.9778V13.1199C7.90007 10.6236 5.87639 8.59992 3.38006 8.59992H0.522217C0.81435 12.5399 3.9601 15.6856 7.90007 15.9778Z" fill="#EFB008"/>
                                                    <path d="M16.4779 7.39992C16.1858 3.45995 13.0401 0.314206 9.1001 0.0220718V2.87991C9.1001 5.37624 11.1237 7.39992 13.6201 7.39992H16.4779Z" fill="#EFB008"/>
                                                    <path d="M7.90007 0.0220718C3.9601 0.314206 0.81435 3.45995 0.522217 7.39992H3.38006C5.87639 7.39992 7.90007 5.37624 7.90007 2.87991V0.0220718Z" fill="#EFB008"/>
                                                    <path d="M5.93323 7.99992C7.04223 7.4458 7.94603 6.542 8.50011 5.433C9.05423 6.542 9.95799 7.4458 11.067 7.99992C9.95799 8.554 9.05423 9.4578 8.50011 10.5668C7.94603 9.4578 7.04223 8.554 5.93323 7.99992Z" fill="#FFDE81"/>
                                                    </g>
                                                    <defs>
                                                    <clipPath id="clip0_15_1368">
                                                    <rect width="16" height="16" fill="white" transform="translate(0.5)"/>
                                                    </clipPath>
                                                    </defs>
                                                </svg>
                                            </div>
                                            <div style="line-height: 22px" class="text-[#976400] font-semibold text-[18px]">
                                                {{ $gift->exchange_rate }} Point
                                            </div>
                                        </div>
                                        <div  style="line-height: 20px" class="bg-[#D83232] rounded-full px-7 py-2 flex items-center justify-center text-white font-bold text-[14px]">
                                            Redeem
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            <div class="w-full mt-[16px] flex justify-center items-center">
                                <div>
                                    @if($showAddMoreButtonGifts)
                                    <div x-show="moreGiftButton" @click="moreGiftButton = false; smallLoading = true" wire:click="addMoreGift" class="p-3 flex items-center  cursor-pointer no-select">
                                        <div class="mr-1">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
                                                <path d="M10.5 11.7283L15.4609 6.76343C15.8281 6.39624 16.4219 6.39624 16.7852 6.76343C17.1484 7.13062 17.1484 7.72437 16.7852 8.09155L11.1641 13.7166C10.8086 14.072 10.2383 14.0798 9.87109 13.7439L4.21094 8.09546C4.02734 7.91187 3.9375 7.66968 3.9375 7.4314C3.9375 7.19312 4.02734 6.95093 4.21094 6.76733C4.57812 6.40015 5.17187 6.40015 5.53516 6.76733L10.5 11.7283Z" fill="#3688EF"/>
                                            </svg>
                                        </div>
                                        <div style="font-weight: 600;" class="h-5 flex items-center text-primary text-[16px]">
                                            More
                                        </div>
                                    </div>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div x-show="promoLists">
                            @foreach ($promotions as $promo)
                            <div class=" bg-white shadow-lg rounded-xl  mt-6 cursor-pointer relative" wire:click="showDetailPromo({{$promo->id}})" @click="loading=true">
                                @if($promo->thumbnail_path)
                                <img src="{{ asset('storage/'. $promo->thumbnail_path) }}" class= "w-[100%] h-full rounded-xl" alt="Image">
                                @else
                                <div class="relative flex p-5 items-center bg-[#2C9854] overflow-hidden rounded-xl">
                                    <div class="mr-[18px]">
                                        <svg width="46" height="49" viewBox="0 0 46 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_328_4498)">
                                                <path d="M42.1875 39.3087L27.7025 47.3482C27.0076 47.7339 25.8705 47.7339 25.1757 47.3482L10.6906 39.3087C10.3432 39.1159 10.1695 38.8616 10.1695 38.6075H10.0156V20.6479H42.7087V38.6075C42.7087 38.8616 42.535 39.1159 42.1875 39.3087Z" fill="#FE5C5C"/>
                                                <path d="M42.7081 20.6478V38.6073C42.7081 38.8615 42.5344 39.1157 42.187 39.3086L27.7019 47.3481C27.3406 47.5486 26.8598 47.6441 26.3837 47.6359C26.3949 38.6428 26.6506 29.6383 26.3711 20.6477L42.7081 20.6478Z" fill="#FC8B8B"/>
                                                <path d="M25.1751 29.3887L10.6901 21.3491C9.99522 20.9634 9.99522 20.3324 10.6901 19.9467L25.1751 11.9072C25.87 11.5215 27.0071 11.5215 27.7019 11.9072L42.187 19.9467C42.8819 20.3324 42.8819 20.9635 42.187 21.3492L27.702 29.3887C27.0071 29.7744 25.87 29.7744 25.1751 29.3887Z" fill="#FFA9BA"/>
                                                <path d="M36.271 16.4045C36.2703 16.4895 36.2467 16.5727 36.2026 16.6454C36.1586 16.7181 36.0958 16.7775 36.0208 16.8175L18.6653 26.0688C18.6414 26.0815 18.6164 26.0922 18.5907 26.1006L18.532 26.1334V43.3984C18.532 43.4807 18.5106 43.5616 18.4697 43.633C18.4289 43.7044 18.3701 43.764 18.2992 43.8057C18.2283 43.8475 18.1477 43.87 18.0655 43.871C17.9832 43.8721 17.9021 43.8516 17.8301 43.8117L14.922 42.1976C14.8482 42.1567 14.7868 42.0968 14.744 42.0241C14.7013 41.9514 14.6787 41.8687 14.6787 41.7843V24.9835C14.6788 24.6952 14.7436 24.4106 14.8683 24.1507C14.9931 23.8908 15.1746 23.6622 15.3994 23.4818L15.4166 23.4684C15.4547 23.4386 15.4908 23.4124 15.528 23.3873C15.5832 23.3498 15.6402 23.3152 15.699 23.2835L32.5474 14.3025C32.617 14.2654 32.6948 14.2463 32.7737 14.2469C32.8526 14.2476 32.9301 14.268 32.999 14.3063L36.0278 15.9873C36.1021 16.0286 36.1639 16.0891 36.2067 16.1625C36.2495 16.2359 36.2717 16.3195 36.271 16.4045ZM37.8715 23.7135C37.7615 23.5881 37.6357 23.4776 37.4972 23.3847C37.4881 23.3785 37.479 23.3723 37.4683 23.3653C37.4233 23.336 37.3771 23.3086 37.3298 23.2833L20.4814 14.3024C20.4118 14.2653 20.334 14.2462 20.2551 14.2468C20.1762 14.2475 20.0988 14.2679 20.0298 14.3063L17.001 15.9873C16.9267 16.0285 16.8648 16.089 16.822 16.1624C16.7792 16.2359 16.757 16.3195 16.7577 16.4045C16.7584 16.4895 16.782 16.5727 16.8261 16.6454C16.8702 16.7181 16.933 16.7776 17.0081 16.8175L34.3636 26.0688C34.3877 26.0816 34.4127 26.0923 34.4382 26.1007L34.4968 26.1335V43.3985C34.4968 43.4808 34.5183 43.5616 34.5591 43.6331C34.6 43.7045 34.6587 43.764 34.7296 43.8058C34.8005 43.8475 34.8811 43.87 34.9634 43.8711C35.0457 43.8721 35.1268 43.8517 35.1987 43.8118L38.1069 42.1977C38.1806 42.1567 38.242 42.0968 38.2848 42.0242C38.3276 41.9515 38.3501 41.8687 38.3501 41.7844V24.9835C38.3499 24.5161 38.1798 24.0648 37.8715 23.7135Z" fill="#3688EF"/>
                                                <path d="M32.2361 20.982C32.2361 22.1679 30.7816 23.0285 28.7777 23.0285C27.9604 23.0285 27.2347 22.8852 26.6617 22.6353C26.5885 22.6035 26.5092 22.5883 26.4295 22.5906C26.3498 22.593 26.2715 22.6129 26.2004 22.649C25.6031 22.9504 24.8111 23.1261 23.9067 23.1261C21.9028 23.1261 20.4482 22.2654 20.4482 21.0795C20.4482 20.4825 20.817 19.968 21.4389 19.6041C21.6839 19.4608 21.7868 19.1549 21.6655 18.8983C21.2222 17.9609 21.2364 17.0814 21.7801 16.5377C22.0617 16.2561 22.4473 16.1073 22.8954 16.1073C23.2102 16.1073 23.5521 16.1817 23.9033 16.3214C24.0382 16.3752 24.1889 16.3738 24.3228 16.3174C24.4567 16.2611 24.5631 16.1543 24.619 16.0202C24.98 15.1586 25.5772 14.6279 26.2934 14.6279C26.9973 14.6279 27.5865 15.1406 27.9493 15.9764C28.0697 16.2538 28.3875 16.3862 28.667 16.2708C29.034 16.1194 29.3916 16.0384 29.7199 16.0384C30.2859 16.0384 30.6388 16.2724 30.8352 16.4688C31.3696 17.0032 31.3926 17.8621 30.9722 18.7816C30.8543 19.0395 30.9589 19.3448 31.2058 19.4843C31.8515 19.8491 32.2361 20.3725 32.2361 20.982Z" fill="#2F6BB7"/>
                                            </g>
                                            <circle cx="40.8979" cy="11.7502" r="1.71429" fill="#FF8933"/>
                                            <path d="M11.4777 3.74029C12.0165 3.25521 12.8612 3.74291 12.7105 4.452C12.643 4.76912 12.7875 5.09357 13.0683 5.25567C13.6961 5.61814 13.4933 6.57222 12.7723 6.648C12.4499 6.68189 12.186 6.91954 12.1186 7.23665C11.9678 7.94575 10.9978 8.0477 10.7029 7.38544C10.5711 7.08927 10.2635 6.91169 9.94106 6.94558C9.22009 7.02135 8.82336 6.13029 9.36209 5.64521C9.60302 5.42828 9.67686 5.08088 9.545 4.78471C9.25014 4.12244 9.975 3.46978 10.6028 3.83224C10.8836 3.99434 11.2368 3.95722 11.4777 3.74029Z" fill="#80D5EF"/>
                                            <circle cx="28.1635" cy="1.95428" r="1.71429" fill="white"/>
                                            <path d="M3.66431 30.9826C3.70225 30.2587 4.64441 30.0062 5.03924 30.6142C5.21581 30.8861 5.54739 31.0134 5.86054 30.9295C6.56077 30.7419 7.09201 31.5599 6.6358 32.1233C6.43177 32.3752 6.41318 32.7299 6.58975 33.0018C6.98458 33.6098 6.37075 34.3678 5.69396 34.108C5.39129 33.9918 5.04823 34.0838 4.84421 34.3357C4.38799 34.8991 3.47738 34.5495 3.51532 33.8256C3.53229 33.5018 3.33885 33.204 3.03619 33.0878C2.3594 32.828 2.41045 31.8539 3.11068 31.6663C3.42384 31.5824 3.64735 31.3064 3.66431 30.9826Z" fill="#ABEAB9"/>
                                            <defs>
                                                <clipPath id="clip0_328_4498">
                                                    <rect width="37.2245" height="37.2245" fill="white" transform="translate(7.83691 11.0154)"/>
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600;" class="h-6 flex items-center text-white text-[20px] mb-1">
                                            Claim image
                                        </div>
                                        <div style="font-weight: 400;" class="h-5 text-white text-[16px]">
                                            Claim now!
                                        </div>
                                    </div>
                                    <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                                    </div>
                                </div>
                                @endif

                                <div class="absolute px-2 w-full top-[52%] md:top-[577%] lg:top-[60%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{$detailStore->name}}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ readableDaysLeft($promo->end_date) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="p-3 bg-white rounded-b-lg ">
                                    <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] mt-5 h-[68px] text-dark-primary flex items-center">
                                        {{$promo->title}}
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            <div class="w-full mt-[16px] flex justify-center items-center">
                                <div>
                                    @if($showAddMoreButtonPromotions)
                                    <div x-show="morePromotionButton" @click="morePromotionButton = false; smallLoading = true" wire:click="addMorePromotion" class="p-3 flex items-center cursor-pointer no-select">
                                        <div class="mr-1">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
                                                <path d="M10.5 11.7283L15.4609 6.76343C15.8281 6.39624 16.4219 6.39624 16.7852 6.76343C17.1484 7.13062 17.1484 7.72437 16.7852 8.09155L11.1641 13.7166C10.8086 14.072 10.2383 14.0798 9.87109 13.7439L4.21094 8.09546C4.02734 7.91187 3.9375 7.66968 3.9375 7.4314C3.9375 7.19312 4.02734 6.95093 4.21094 6.76733C4.57812 6.40015 5.17187 6.40015 5.53516 6.76733L10.5 11.7283Z" fill="#3688EF"/>
                                            </svg>
                                        </div>
                                        <div style="font-weight: 600;" class="h-5 flex items-center text-primary text-[16px]">
                                            More
                                        </div>
                                    </div>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div x-show="productLists">
                            @foreach ($products as $product)
                            <div class=" bg-white shadow-lg rounded-xl  mt-6 cursor-pointer relative" wire:click="showDetailProduct({{$product->id}})" @click="loading=true">
                                @if($product->thumbnail_path)
                                <img src="{{ asset('storage/'. $product->thumbnail_path) }}" class= "w-[100%] h-full rounded-xl" alt="Image">
                                @else
                                <div class="relative flex p-5 items-center bg-[#2C9854] overflow-hidden rounded-xl">
                                    <div class="mr-[18px]">
                                        <svg width="46" height="49" viewBox="0 0 46 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_328_4498)">
                                                <path d="M42.1875 39.3087L27.7025 47.3482C27.0076 47.7339 25.8705 47.7339 25.1757 47.3482L10.6906 39.3087C10.3432 39.1159 10.1695 38.8616 10.1695 38.6075H10.0156V20.6479H42.7087V38.6075C42.7087 38.8616 42.535 39.1159 42.1875 39.3087Z" fill="#FE5C5C"/>
                                                <path d="M42.7081 20.6478V38.6073C42.7081 38.8615 42.5344 39.1157 42.187 39.3086L27.7019 47.3481C27.3406 47.5486 26.8598 47.6441 26.3837 47.6359C26.3949 38.6428 26.6506 29.6383 26.3711 20.6477L42.7081 20.6478Z" fill="#FC8B8B"/>
                                                <path d="M25.1751 29.3887L10.6901 21.3491C9.99522 20.9634 9.99522 20.3324 10.6901 19.9467L25.1751 11.9072C25.87 11.5215 27.0071 11.5215 27.7019 11.9072L42.187 19.9467C42.8819 20.3324 42.8819 20.9635 42.187 21.3492L27.702 29.3887C27.0071 29.7744 25.87 29.7744 25.1751 29.3887Z" fill="#FFA9BA"/>
                                                <path d="M36.271 16.4045C36.2703 16.4895 36.2467 16.5727 36.2026 16.6454C36.1586 16.7181 36.0958 16.7775 36.0208 16.8175L18.6653 26.0688C18.6414 26.0815 18.6164 26.0922 18.5907 26.1006L18.532 26.1334V43.3984C18.532 43.4807 18.5106 43.5616 18.4697 43.633C18.4289 43.7044 18.3701 43.764 18.2992 43.8057C18.2283 43.8475 18.1477 43.87 18.0655 43.871C17.9832 43.8721 17.9021 43.8516 17.8301 43.8117L14.922 42.1976C14.8482 42.1567 14.7868 42.0968 14.744 42.0241C14.7013 41.9514 14.6787 41.8687 14.6787 41.7843V24.9835C14.6788 24.6952 14.7436 24.4106 14.8683 24.1507C14.9931 23.8908 15.1746 23.6622 15.3994 23.4818L15.4166 23.4684C15.4547 23.4386 15.4908 23.4124 15.528 23.3873C15.5832 23.3498 15.6402 23.3152 15.699 23.2835L32.5474 14.3025C32.617 14.2654 32.6948 14.2463 32.7737 14.2469C32.8526 14.2476 32.9301 14.268 32.999 14.3063L36.0278 15.9873C36.1021 16.0286 36.1639 16.0891 36.2067 16.1625C36.2495 16.2359 36.2717 16.3195 36.271 16.4045ZM37.8715 23.7135C37.7615 23.5881 37.6357 23.4776 37.4972 23.3847C37.4881 23.3785 37.479 23.3723 37.4683 23.3653C37.4233 23.336 37.3771 23.3086 37.3298 23.2833L20.4814 14.3024C20.4118 14.2653 20.334 14.2462 20.2551 14.2468C20.1762 14.2475 20.0988 14.2679 20.0298 14.3063L17.001 15.9873C16.9267 16.0285 16.8648 16.089 16.822 16.1624C16.7792 16.2359 16.757 16.3195 16.7577 16.4045C16.7584 16.4895 16.782 16.5727 16.8261 16.6454C16.8702 16.7181 16.933 16.7776 17.0081 16.8175L34.3636 26.0688C34.3877 26.0816 34.4127 26.0923 34.4382 26.1007L34.4968 26.1335V43.3985C34.4968 43.4808 34.5183 43.5616 34.5591 43.6331C34.6 43.7045 34.6587 43.764 34.7296 43.8058C34.8005 43.8475 34.8811 43.87 34.9634 43.8711C35.0457 43.8721 35.1268 43.8517 35.1987 43.8118L38.1069 42.1977C38.1806 42.1567 38.242 42.0968 38.2848 42.0242C38.3276 41.9515 38.3501 41.8687 38.3501 41.7844V24.9835C38.3499 24.5161 38.1798 24.0648 37.8715 23.7135Z" fill="#3688EF"/>
                                                <path d="M32.2361 20.982C32.2361 22.1679 30.7816 23.0285 28.7777 23.0285C27.9604 23.0285 27.2347 22.8852 26.6617 22.6353C26.5885 22.6035 26.5092 22.5883 26.4295 22.5906C26.3498 22.593 26.2715 22.6129 26.2004 22.649C25.6031 22.9504 24.8111 23.1261 23.9067 23.1261C21.9028 23.1261 20.4482 22.2654 20.4482 21.0795C20.4482 20.4825 20.817 19.968 21.4389 19.6041C21.6839 19.4608 21.7868 19.1549 21.6655 18.8983C21.2222 17.9609 21.2364 17.0814 21.7801 16.5377C22.0617 16.2561 22.4473 16.1073 22.8954 16.1073C23.2102 16.1073 23.5521 16.1817 23.9033 16.3214C24.0382 16.3752 24.1889 16.3738 24.3228 16.3174C24.4567 16.2611 24.5631 16.1543 24.619 16.0202C24.98 15.1586 25.5772 14.6279 26.2934 14.6279C26.9973 14.6279 27.5865 15.1406 27.9493 15.9764C28.0697 16.2538 28.3875 16.3862 28.667 16.2708C29.034 16.1194 29.3916 16.0384 29.7199 16.0384C30.2859 16.0384 30.6388 16.2724 30.8352 16.4688C31.3696 17.0032 31.3926 17.8621 30.9722 18.7816C30.8543 19.0395 30.9589 19.3448 31.2058 19.4843C31.8515 19.8491 32.2361 20.3725 32.2361 20.982Z" fill="#2F6BB7"/>
                                            </g>
                                            <circle cx="40.8979" cy="11.7502" r="1.71429" fill="#FF8933"/>
                                            <path d="M11.4777 3.74029C12.0165 3.25521 12.8612 3.74291 12.7105 4.452C12.643 4.76912 12.7875 5.09357 13.0683 5.25567C13.6961 5.61814 13.4933 6.57222 12.7723 6.648C12.4499 6.68189 12.186 6.91954 12.1186 7.23665C11.9678 7.94575 10.9978 8.0477 10.7029 7.38544C10.5711 7.08927 10.2635 6.91169 9.94106 6.94558C9.22009 7.02135 8.82336 6.13029 9.36209 5.64521C9.60302 5.42828 9.67686 5.08088 9.545 4.78471C9.25014 4.12244 9.975 3.46978 10.6028 3.83224C10.8836 3.99434 11.2368 3.95722 11.4777 3.74029Z" fill="#80D5EF"/>
                                            <circle cx="28.1635" cy="1.95428" r="1.71429" fill="white"/>
                                            <path d="M3.66431 30.9826C3.70225 30.2587 4.64441 30.0062 5.03924 30.6142C5.21581 30.8861 5.54739 31.0134 5.86054 30.9295C6.56077 30.7419 7.09201 31.5599 6.6358 32.1233C6.43177 32.3752 6.41318 32.7299 6.58975 33.0018C6.98458 33.6098 6.37075 34.3678 5.69396 34.108C5.39129 33.9918 5.04823 34.0838 4.84421 34.3357C4.38799 34.8991 3.47738 34.5495 3.51532 33.8256C3.53229 33.5018 3.33885 33.204 3.03619 33.0878C2.3594 32.828 2.41045 31.8539 3.11068 31.6663C3.42384 31.5824 3.64735 31.3064 3.66431 30.9826Z" fill="#ABEAB9"/>
                                            <defs>
                                                <clipPath id="clip0_328_4498">
                                                    <rect width="37.2245" height="37.2245" fill="white" transform="translate(7.83691 11.0154)"/>
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600;" class="h-6 flex items-center text-white text-[20px] mb-1">
                                            Product image
                                        </div>
                                        <div style="font-weight: 400;" class="h-5 text-white text-[16px]">
                                            Claim now!
                                        </div>
                                    </div>
                                    <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                                    </div>
                                </div>
                                @endif

                                <div class="absolute px-2 w-full top-[52%] md:top-[577%] lg:top-[60%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{$detailStore->name}}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ readableDaysLeft($product->end_date) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="p-3 bg-white rounded-b-lg ">
                                    <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] mt-5 h-[68px] text-dark-primary flex items-center">
                                        {{$product->title}}
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            <div class="w-full mt-[16px] flex justify-center items-center">
                                <div>
                                    @if($showAddMoreButtonProducts)
                                    <div x-show="moreProductButton" @click="moreProductButton = false; smallLoading = true" wire:click="addMoreProduct" class="p-3 flex items-center cursor-pointer no-select">
                                        <div class="mr-1">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
                                                <path d="M10.5 11.7283L15.4609 6.76343C15.8281 6.39624 16.4219 6.39624 16.7852 6.76343C17.1484 7.13062 17.1484 7.72437 16.7852 8.09155L11.1641 13.7166C10.8086 14.072 10.2383 14.0798 9.87109 13.7439L4.21094 8.09546C4.02734 7.91187 3.9375 7.66968 3.9375 7.4314C3.9375 7.19312 4.02734 6.95093 4.21094 6.76733C4.57812 6.40015 5.17187 6.40015 5.53516 6.76733L10.5 11.7283Z" fill="#3688EF"/>
                                            </svg>
                                        </div>
                                        <div style="font-weight: 600;" class="h-5 flex items-center text-primary text-[16px]">
                                            More
                                        </div>
                                    </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="openDetailClaim" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        @if($detailClaim)
        <div class="flex-1 overflow-y-auto hide-scrollbar relative">
            <div class="relative mt-5">
                <div style="position: relative" class="flex flex-col min-h-screen overflow-hidden">
                    <div class="flex-1">
                        <div class="px-8">
                            <div class="relative flex justify-center no-select">
                                <div style="line-height: 26px;font-weight:400;" class="text-[16px]">
                                    Detail {{ $detailClaim->claim_type_id == 1 ? 'Voucher' : 'Gift' }}
                                </div>
                                <div @click="openDetailStore=true;openDetailClaim=false;exchangeConfirm=false"  class="absolute left-0 top-1 cursor-pointer">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                                    </svg>
                                </div>
                            </div>
                            <div class="relative mt-5">
                                @if($detailClaim->thumbnail_path)
                                <img src="{{ asset('storage/'. $detailClaim->thumbnail_path) }}" class="w-full rounded-lg shadow-lg" alt="">
                                @else
                                <div class="w-full flex items-center justify-center h-[135px] bg-[#EAEFF3]  rounded-lg shadow-lg">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="71" height="70" viewBox="0 0 71 70" fill="none">
                                        <path d="M15.0833 61.25C13.4792 61.25 12.1054 60.6783 10.9621 59.535C9.81875 58.3917 9.24806 57.0189 9.25 55.4167V14.5833C9.25 12.9792 9.82167 11.6054 10.965 10.4621C12.1083 9.31875 13.4811 8.74806 15.0833 8.75H55.9167C57.5208 8.75 58.8946 9.32167 60.0379 10.465C61.1813 11.6083 61.752 12.9811 61.75 14.5833V55.4167C61.75 57.0208 61.1783 58.3946 60.035 59.5379C58.8917 60.6813 57.5189 61.252 55.9167 61.25H15.0833ZM18 49.5833H53L42.0625 35L33.3125 46.6667L26.75 37.9167L18 49.5833Z" fill="#D6DADF"/>
                                    </svg>
                                </div>
                                @endif
                                <div class="absolute px-2 w-full top-[38%] md:top-[45%] lg:top-[47%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{$detailStore->name}}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                Until {{changeDateFormat($detailClaim->end_date)}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="p-3 max-w-full">
                                    <div class="px-3 mt-3 border-b">
                                        <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] h-[48px] flex items-center">
                                            {{$detailClaim->title}}
                                        </div>
                                    </div>
                                    <div class="mt-2 flex flex-col gap-2">
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Valid until
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] font-normal">
                                                {{ changeDateFormat($detailClaim->end_date) }}
                                            </div>
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Stock left
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] {{ $detailClaim->stock - count($detailClaim->claimmed) < 10 ? 'text-[#DA0713]' : 'text-[#2C9854]' }} font-normal">
                                                {{ $detailClaim->stock - count($detailClaim->claimmed) }} Voucher lagi
                                            </div>
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Change limit
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] font-normal">
                                                @if($detailClaim->limit == 0) Unlimited @else {{ $detailClaim->limit }}X redeem @endif/person
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="relative">
                            <img src="{{ asset('src/images/bg-profile.png') }}" class="w-full h-[150px]" alt="">
                            <div  style="top: 30px" class="absolute w-full">
                                <div class=" px-5">
                                    <div @click="openListClaimStores=true" class="flex bg-white p-3 mb-4 border border-white   rounded-lg shadow-lg w-full justify-between items-center no-select cursor-pointer">
                                        <div class="flex items-center">
                                            <div class="flex items-center justify-center mr-2">
                                                <img src="{{ asset('src/images/cabang.png') }}" class="w-[32px] h-[32px]" alt="">
                                            </div>
                                            <div class="max-w-[300px]">
                                                <div style="font-weight:600;line-height:20px" class="mb-1 flex items-center text-[16px] text-[#DA0814] truncate">
                                                    {{ $detailClaim->brand->company_name }}
                                                </div>
                                                <div style="font-weight: 400;" class="h-5 flex items-center text-[#6A6A75]  text-[14px] truncate">
                                                    Can be purchased at {{ count($detailClaim->claimStores) }} branches store
                                                </div>
                                            </div>
                                        </div>
                                        <div class="h-5 w-5 flex items-center justify-center">
                                            <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M11.9883 10L7.02344 5.03906C6.65625 4.67188 6.65625 4.07812 7.02344 3.71484C7.39062 3.35156 7.98438 3.35156 8.35156 3.71484L13.9766 9.33594C14.332 9.69141 14.3398 10.2617 14.0039 10.6289L8.35547 16.2891C8.17188 16.4727 7.92969 16.5625 7.69141 16.5625C7.45313 16.5625 7.21094 16.4727 7.02734 16.2891C6.66016 15.9219 6.66016 15.3281 7.02734 14.9648L11.9883 10Z" fill="#DA0814"/>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="px-8 pt-9 lg:pt-7 rounded-t-2xl -mt-[15px] relative bg-white">
                            <div style="line-height: 20px" class="text-[16px] font-semibold mb-4">
                                How to use voucher
                            </div>
                            <div style="line-height: 20px" class="text-[13px] font-normal mb-3">
                                {{$detailClaim->description}}
                            </div>
                        </div>
                    </div>
                    <div style="box-shadow: 0 30px 30px 30px rgba(0, 0, 0, 0.1);" class="bg-white  relative px-5 pt-3 pb-7 flex items-center justify-center justify-between shadow-lg">
                        <div class="flex justify-center flex-col gap-1">
                            <div style="line-height:20px" class="text-[12px] font-normal">
                                Point
                            </div>
                            <div class="flex gap-1 items-center">
                                <div>
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_15_1722)">
                                        <path d="M15.9779 8.59991H13.1201C10.6237 8.59991 8.6001 10.6236 8.6001 13.1199V15.9778C12.5401 15.6856 15.6858 12.5399 15.9779 8.59991Z" fill="#EFB008"/>
                                        <path d="M7.40007 15.9778V13.1199C7.40007 10.6236 5.37639 8.59991 2.88006 8.59991H0.0222168C0.31435 12.5399 3.4601 15.6856 7.40007 15.9778Z" fill="#EFB008"/>
                                        <path d="M15.9779 7.39994C15.6858 3.45997 12.5401 0.314228 8.6001 0.0220947V2.87993C8.6001 5.37626 10.6237 7.39994 13.1201 7.39994H15.9779Z" fill="#EFB008"/>
                                        <path d="M7.40007 0.0220947C3.4601 0.314228 0.31435 3.45997 0.0222168 7.39994H2.88006C5.37639 7.39994 7.40007 5.37626 7.40007 2.87993V0.0220947Z" fill="#EFB008"/>
                                        <path d="M5.43323 7.9999C6.54223 7.44578 7.44603 6.54198 8.00011 5.43298C8.55423 6.54198 9.45799 7.44578 10.567 7.9999C9.45799 8.55398 8.55423 9.45778 8.00011 10.5668C7.44603 9.45778 6.54223 8.55398 5.43323 7.9999Z" fill="#FFDE81"/>
                                        </g>
                                        <defs>
                                        <clipPath id="clip0_15_1722">
                                        <rect width="16" height="16" fill="white"/>
                                        </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div style="line-height: 22px" class="text-[18px] font-semibold text-[#976400]">
                                    <span style="line-height: 22px" class="font-semibold text-[18px]">{{$detailClaim->exchange_rate}}</span> Poin
                                </div>
                            </div>
                        </div>
                        <div style="line-height: 24px" @click="exchangeConfirm=true" class=" no-select cursor-pointer rounded-2xl py-3 w-[151px] text-white bg-[#DA0713] flex items-center justify-center font-bold text-[14px]">
                            Redeem
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="openDetailPromo" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        @if($detailPromo)
        <div class="flex-1 overflow-y-auto hide-scrollbar relative">
            <div class="relative mt-5">
                <div style="position: relative" class="flex flex-col min-h-screen overflow-hidden">
                    <div class="flex-1">
                        <div class="px-8">
                            <div class="relative flex justify-center no-select">
                                <div style="line-height: 26px;font-weight:400;" class="text-[16px]">
                                    Promo Detail
                                </div>
                                <div @if($from_promo_dashboard) @click="redirectTo('{{ route('dashboard') }}')" @elseif($from_promo_detail) @click="redirectTo('{{ route('promo') }}')" @else @click="openDetailStore=true;openDetailPromo=false;exchangeConfirm=false" @endif  class="absolute left-0 top-1 cursor-pointer">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                                    </svg>
                                </div>
                            </div>
                            <div class="relative mt-5">
                                @if($detailPromo->thumbnail_path)
                                <img src="{{ asset('storage/'. $detailPromo->thumbnail_path) }}" class="w-full rounded-lg shadow-lg" alt="">
                                @else
                                <div class="w-full flex items-center justify-center h-[135px] bg-[#EAEFF3]  rounded-lg shadow-lg">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="71" height="70" viewBox="0 0 71 70" fill="none">
                                        <path d="M15.0833 61.25C13.4792 61.25 12.1054 60.6783 10.9621 59.535C9.81875 58.3917 9.24806 57.0189 9.25 55.4167V14.5833C9.25 12.9792 9.82167 11.6054 10.965 10.4621C12.1083 9.31875 13.4811 8.74806 15.0833 8.75H55.9167C57.5208 8.75 58.8946 9.32167 60.0379 10.465C61.1813 11.6083 61.752 12.9811 61.75 14.5833V55.4167C61.75 57.0208 61.1783 58.3946 60.035 59.5379C58.8917 60.6813 57.5189 61.252 55.9167 61.25H15.0833ZM18 49.5833H53L42.0625 35L33.3125 46.6667L26.75 37.9167L18 49.5833Z" fill="#D6DADF"/>
                                    </svg>
                                </div>
                                @endif

                                <div class="absolute px-2 w-full top-[55%] md:top-[60%] lg:top-[65%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{isset($detailStore->name) ? $detailStore->name : $brand->company_name}}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                Until {{changeDateFormat($detailPromo->end_date)}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="p-3 max-w-full">
                                    <div class="px-3 mt-3">
                                        <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] h-[48px] flex items-center">
                                            {{$detailPromo->title}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="relative">
                            <img src="{{ asset('src/images/bg-profile.png') }}" class="w-full h-[150px]" alt="">
                            <div  style="top: 30px" class="absolute w-full">
                                <div class=" px-5">
                                    <div @click="openListPromoStores=true" class="flex bg-white p-3 mb-4 border border-white   rounded-lg shadow-lg w-full justify-between items-center no-select cursor-pointer">
                                        <div class="flex items-center">
                                            <div class="flex items-center justify-center mr-2">
                                                <img src="{{ asset('src/images/cabang.png') }}" class="w-[32px] h-[32px]" alt="">
                                            </div>
                                            <div class="max-w-[300px]">
                                                <div style="font-weight:600;line-height:20px" class="mb-1 flex items-center text-[16px] text-[#DA0814] truncate">
                                                    {{ $detailPromo->brand->company_name }}
                                                </div>
                                                <div style="font-weight: 400;" class="h-5 flex items-center text-[#6A6A75]  text-[14px] truncate">
                                                    Can be purchased at {{ count($detailPromo->promotionStores) }} branches store
                                                </div>
                                            </div>
                                        </div>
                                        <div class="h-5 w-5 flex items-center justify-center">
                                            <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M11.9883 10L7.02344 5.03906C6.65625 4.67188 6.65625 4.07812 7.02344 3.71484C7.39062 3.35156 7.98438 3.35156 8.35156 3.71484L13.9766 9.33594C14.332 9.69141 14.3398 10.2617 14.0039 10.6289L8.35547 16.2891C8.17188 16.4727 7.92969 16.5625 7.69141 16.5625C7.45313 16.5625 7.21094 16.4727 7.02734 16.2891C6.66016 15.9219 6.66016 15.3281 7.02734 14.9648L11.9883 10Z" fill="#DA0814"/>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="px-8 pt-9 lg:pt-7 rounded-t-2xl -mt-[15px] relative bg-white">
                            <div style="line-height: 20px" class="text-[16px] font-semibold mb-4">
                                Promo terms & conditions
                            </div>
                            <div style="line-height: 20px" class="text-[13px] font-normal mb-3">
                                {{$detailPromo->description}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="openDetailProduct" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        @if($detailProduct)
        <div class="flex-1 overflow-y-auto hide-scrollbar relative">
            <div class="relative mt-5">
                <div style="position: relative" class="flex flex-col min-h-screen overflow-hidden">
                    <div class="flex-1">
                        <div class="px-8">
                            <div class="relative flex justify-center no-select">
                                <div style="line-height: 26px;font-weight:400;" class="text-[16px]">
                                    Product Detail
                                </div>
                                <div @if($product_from_dashboard) @click="redirectTo('{{ route('dashboard') }}')" @elseif($from_product_detail) @click="redirectTo('{{ route('product') }}')" @else @click="openDetailStore=true;openDetailProduct=false;exchangeConfirm=false" @endif  class="absolute left-0 top-1 cursor-pointer">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                                    </svg>
                                </div>
                            </div>
                            <div class="relative mt-5">
                                @if($detailProduct->thumbnail_path)
                                <img src="{{ asset('storage/'. $detailProduct->thumbnail_path) }}" class="w-full rounded-lg shadow-lg" alt="">
                                @else
                                <div class="w-full flex items-center justify-center h-[135px] bg-[#EAEFF3]  rounded-lg shadow-lg">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="71" height="70" viewBox="0 0 71 70" fill="none">
                                        <path d="M15.0833 61.25C13.4792 61.25 12.1054 60.6783 10.9621 59.535C9.81875 58.3917 9.24806 57.0189 9.25 55.4167V14.5833C9.25 12.9792 9.82167 11.6054 10.965 10.4621C12.1083 9.31875 13.4811 8.74806 15.0833 8.75H55.9167C57.5208 8.75 58.8946 9.32167 60.0379 10.465C61.1813 11.6083 61.752 12.9811 61.75 14.5833V55.4167C61.75 57.0208 61.1783 58.3946 60.035 59.5379C58.8917 60.6813 57.5189 61.252 55.9167 61.25H15.0833ZM18 49.5833H53L42.0625 35L33.3125 46.6667L26.75 37.9167L18 49.5833Z" fill="#D6DADF"/>
                                    </svg>
                                </div>
                                @endif
                                <div class="absolute px-2 w-full top-[35%] md:top-[44%] lg:top-[53%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{isset($detailStore->name) ? $detailStore->name : $brand->company_name}}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                Until {{changeDateFormat($detailProduct->end_date)}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="p-3 max-w-full">
                                    <div class="px-3 mt-3 border-b">
                                        <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] h-[48px] flex items-center">
                                            {{$detailProduct->title}}
                                        </div>
                                    </div>
                                    <div class="mt-2 flex flex-col gap-2">
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Start from
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] font-normal">
                                                Rp {{ number_format($detailProduct->price, 0, ',', '.') }}
                                            </div>
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Valid until
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] font-normal">
                                                {{ changeDateFormat($detailProduct->end_date) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="relative">
                            <img src="{{ asset('src/images/bg-profile.png') }}" class="w-full h-[150px]" alt="">
                            <div  style="top: 30px" class="absolute w-full">
                                <div class=" px-5">
                                    <div @click="openListProductStores=true" class="flex bg-white p-3 mb-4 border border-white   rounded-lg shadow-lg w-full justify-between items-center no-select cursor-pointer">
                                        <div class="flex items-center">
                                            <div class="flex items-center justify-center mr-2">
                                                <img src="{{ asset('src/images/cabang.png') }}" class="w-[32px] h-[32px]" alt="">
                                            </div>
                                            <div class="max-w-[300px]">
                                                <div style="font-weight:600;line-height:20px" class="mb-1 flex items-center text-[16px] text-[#DA0814] truncate">
                                                    {{ $detailProduct->brand->company_name }}
                                                </div>
                                                <div style="font-weight: 400;" class="h-5 flex items-center text-[#6A6A75]  text-[14px] truncate">
                                                    Can be purchased at {{ count($detailProduct->productStores) }} branches  store
                                                </div>
                                            </div>
                                        </div>
                                        <div class="h-5 w-5 flex items-center justify-center">
                                            <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M11.9883 10L7.02344 5.03906C6.65625 4.67188 6.65625 4.07812 7.02344 3.71484C7.39062 3.35156 7.98438 3.35156 8.35156 3.71484L13.9766 9.33594C14.332 9.69141 14.3398 10.2617 14.0039 10.6289L8.35547 16.2891C8.17188 16.4727 7.92969 16.5625 7.69141 16.5625C7.45313 16.5625 7.21094 16.4727 7.02734 16.2891C6.66016 15.9219 6.66016 15.3281 7.02734 14.9648L11.9883 10Z" fill="#DA0814"/>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="px-8 pt-9 lg:pt-7 rounded-t-2xl -mt-[15px] relative bg-white">
                            <div style="line-height: 20px" class="text-[16px] font-semibold mb-4">
                                Product Description
                            </div>
                            <div style="line-height: 20px" class="text-[13px] font-normal mb-3">
                                {{$detailProduct->description}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>

    {{-- <div x-cloak x-show="openDetailClaim" class="w-screen md:w-full md:max-w-md max-w-full h-screen bg-white  max-h-screen overflow-auto flex flex-col ">
        @if($detailClaim)

        <div class="flex-none">
            <div class="w-full flex p-5">
                <div @click="openDetailStore=true;openDetailClaim=false;exchangeConfirm=false" class="flex items-center no-select cursor-pointer">
                    <div class="mr-1">
                        <div class="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21">
                            <path class="fill-primary " d="M8.45306 6.63482C8.65228 6.83014 8.65228 7.15435 8.45697 7.35357L6.08588 9.73248H15.121C15.3984 9.73248 15.6249 9.95904 15.6249 10.2403C15.6249 10.5215 15.3984 10.7481 15.121 10.7481H6.08588L8.46088 13.127C8.65619 13.3262 8.65228 13.6465 8.45697 13.8458C8.25775 14.0411 7.94134 14.0411 7.74213 13.8419L4.52338 10.5997C4.48041 10.5528 4.44525 10.502 4.41791 10.4395C4.39056 10.377 4.37885 10.3106 4.37885 10.2442C4.37885 10.1114 4.42963 9.98639 4.52338 9.88873L7.74213 6.64654C7.93353 6.44342 8.25384 6.43951 8.45306 6.63482Z"/>
                            </svg>
                        </div>
                    </div>
                    <div style="font-weight: 600;" class="text-primary  text-[16px]">
                        Kembali
                    </div>
                </div>
            </div>
        </div>

        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar bg-white  ">
            <div class="w-full p-5">
                <div class="w-full  rounded-sm mb-5">
                    <div class="relative">
                        @if ($detailClaim->thumbnail_path)
                        <img src="{{ asset('storage/' . $detailClaim->thumbnail_path) }}" class= "w-[100%] h-full mt-6" alt="Image">
                        @else
                        <div class="w-full flex items-center justify-center h-[135px] bg-[#EAEFF3]">
                            <svg xmlns="http://www.w3.org/2000/svg" width="71" height="70" viewBox="0 0 71 70" fill="none">
                                <path d="M15.0833 61.25C13.4792 61.25 12.1054 60.6783 10.9621 59.535C9.81875 58.3917 9.24806 57.0189 9.25 55.4167V14.5833C9.25 12.9792 9.82167 11.6054 10.965 10.4621C12.1083 9.31875 13.4811 8.74806 15.0833 8.75H55.9167C57.5208 8.75 58.8946 9.32167 60.0379 10.465C61.1813 11.6083 61.752 12.9811 61.75 14.5833V55.4167C61.75 57.0208 61.1783 58.3946 60.035 59.5379C58.8917 60.6813 57.5189 61.252 55.9167 61.25H15.0833ZM18 49.5833H53L42.0625 35L33.3125 46.6667L26.75 37.9167L18 49.5833Z" fill="#D6DADF"/>
                            </svg>
                        </div>
                        @endif
                        <div class="absolute top-0 h-10 p-2 bg-white  flex items-center rounded-br-2xl">
                            <div class="w-6 h-6 rounded-full bg-[#E5EDFA] flex items-center justify-center mr-[6px]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
                                    <path d="M10.5 2.74023H1.5C1.36739 2.74023 1.24021 2.79291 1.14645 2.88668C1.05268 2.98045 1 3.10763 1 3.24023V5.24023H1.4465C1.9445 5.24023 2.4065 5.58073 2.4865 6.07223C2.51087 6.21575 2.50363 6.36286 2.46528 6.50329C2.42693 6.64372 2.3584 6.7741 2.26447 6.88531C2.17054 6.99652 2.05347 7.0859 1.92143 7.1472C1.7894 7.2085 1.64557 7.24025 1.5 7.24023H1V9.24023C1 9.37284 1.05268 9.50002 1.14645 9.59379C1.24021 9.68756 1.36739 9.74023 1.5 9.74023H10.5C10.6326 9.74023 10.7598 9.68756 10.8536 9.59379C10.9473 9.50002 11 9.37284 11 9.24023V7.24023H10.5C10.3544 7.24025 10.2106 7.2085 10.0786 7.1472C9.94653 7.0859 9.82946 6.99652 9.73553 6.88531C9.6416 6.7741 9.57307 6.64372 9.53472 6.50329C9.49637 6.36286 9.48913 6.21575 9.5135 6.07223C9.5935 5.58073 10.0555 5.24023 10.5535 5.24023H11V3.24023C11 3.10763 10.9473 2.98045 10.8536 2.88668C10.7598 2.79291 10.6326 2.74023 10.5 2.74023ZM5.5 8.74023H4.5V7.74023H5.5V8.74023ZM5.5 6.74023H4.5V5.74023H5.5V6.74023ZM5.5 4.74023H4.5V3.74023H5.5V4.74023Z" fill="#3688EF"/>
                                </svg>
                            </div>
                            <div style="font-weight: 400;" class="h-5 flex items-center ">
                                Voucher
                            </div>
                        </div>
                        <div class="p-3 max-w-full">
                            <div style="font-weight: 600;" class="w-full h-6 flex items-center text-[20px] text-dark-primary ">
                                {{ $detailClaim->title }}
                            </div>
                            <div style="font-weight: 400;" :class="readMore ? '' : 'line-clamp-2'" class="text-[14px] text-[#6A6A75]   mt-[2px]">
                                {{ $detailClaim->description }}
                            </div>
                            <div x-show="!readMore" @click="readMore=true" class="w-full flex items-center justify-center p-3 no-select cursor-pointer">
                                <div style="font-weight: 400;" class="text-primary  tect-[14px] h-5 flex items-center mr-1">
                                    Baca lebih lanjut
                                </div>
                                <div class="h-5 w-5 flex items-center justify-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <path d="M10 11.4883L14.9609 6.52344C15.3281 6.15625 15.9219 6.15625 16.2852 6.52344C16.6484 6.89062 16.6484 7.48438 16.2852 7.85156L10.6641 13.4766C10.3086 13.832 9.73828 13.8398 9.37109 13.5039L3.71094 7.85547C3.52734 7.67188 3.4375 7.42969 3.4375 7.19141C3.4375 6.95313 3.52734 6.71094 3.71094 6.52734C4.07812 6.16016 4.67187 6.16016 5.03516 6.52734L10 11.4883Z" fill="#3688EF"/>
                                    </svg>
                                </div>
                            </div>
                            <div x-show="readMore" @click="readMore=false" class="w-full flex items-center justify-center p-3 no-select cursor-pointer">
                                <div style="font-weight: 400;" class="text-primary  tect-[14px] h-5 flex items-center mr-1">
                                    Baca lebih sedikit
                                </div>
                                <div class="h-5 w-5 flex items-center justify-center rotate-180">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <path d="M10 11.4883L14.9609 6.52344C15.3281 6.15625 15.9219 6.15625 16.2852 6.52344C16.6484 6.89062 16.6484 7.48438 16.2852 7.85156L10.6641 13.4766C10.3086 13.832 9.73828 13.8398 9.37109 13.5039L3.71094 7.85547C3.52734 7.67188 3.4375 7.42969 3.4375 7.19141C3.4375 6.95313 3.52734 6.71094 3.71094 6.52734C4.07812 6.16016 4.67187 6.16016 5.03516 6.52734L10 11.4883Z" fill="#3688EF"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="p-3 border border-white  ">
                        <div class="w-full flex justify-between items-center mb-5">
                            <div style="font-weight: 400;" class="h-5 flex items-center text-[16px] text-[#6A6A75]  ">
                                Tanggal beredar
                            </div>
                            <div style="font-weight: 400;" class="h-5 flex items-center text-[16px] text-dark-primary  truncate">
                                {{ changeDateFormat($detailClaim->start_date) }} - {{ changeDateFormat($detailClaim->end_date) }}
                            </div>
                        </div>

                        <div class="w-full flex justify-between items-center mb-5">
                            <div style="font-weight: 400;" class="h-5 flex items-center text-[16px] text-[#6A6A75]  ">
                                Kuota tersisa
                            </div>
                            <div style="font-weight: 400;" class="h-5 flex items-center text-[16px] text-dark-primary  truncate">
                                {{ 60-count($detailClaim->claimmed) }}
                            </div>
                        </div>

                        <div class="w-full flex justify-between items-center mb-5">
                            <div style="font-weight: 400;" class="h-5 flex items-center text-[16px] text-[#6A6A75]  ">
                                Masa berlaku
                            </div>
                            <div style="font-weight: 400;" class="h-5 flex items-center text-[16px] text-dark-primary  truncate">
                                {{$detailClaim->validity_duration}} hari
                            </div>
                        </div>

                        <div class="w-full flex justify-between items-center">
                            <div style="font-weight: 400;" class="h-5 flex items-center text-[16px] text-[#6A6A75]  ">
                                Nilai tukar
                            </div>
                            <div class="flex border border-white   rounded-full max-w-[100px] px-2 py-1 truncate">
                                <div class="mr-1 w-5 h-5 flex items-center justify-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <path d="M10.0042 18.3359C5.40166 18.3359 1.67083 14.605 1.67083 10.0025C1.67083 5.40002 5.40166 1.66919 10.0042 1.66919C14.6067 1.66919 18.3375 5.40002 18.3375 10.0025C18.3375 14.605 14.6067 18.3359 10.0042 18.3359ZM10.0042 6.46669L6.46833 10.0025L10.0042 13.5384L13.5392 10.0025L10.0042 6.46669Z" fill="#FFA858"/>
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M10.0041 5.28811L14.7174 10.0025L10.0041 14.7169L5.28973 10.0025L10.0041 5.28811ZM2.50407 10.0025C2.50407 14.1448 5.86181 17.5025 10.0041 17.5025C14.1463 17.5025 17.5041 14.1448 17.5041 10.0025C17.5041 5.86026 14.1463 2.50252 10.0041 2.50252C5.86181 2.50252 2.50407 5.86026 2.50407 10.0025ZM6.46824 10.0025L10.0041 6.46669L13.5391 10.0025L10.0041 13.5384L6.46824 10.0025ZM1.67074 10.0025C1.67074 14.605 5.40157 18.3359 10.0041 18.3359C14.6066 18.3359 18.3374 14.605 18.3374 10.0025C18.3374 5.40002 14.6066 1.66919 10.0041 1.66919C5.40157 1.66919 1.67074 5.40002 1.67074 10.0025Z" fill="#DF812B"/>
                                    </svg>
                                </div>
                                <div style="font-weight: 400;" class="h-5 text-[14px] text-dark-primary  flex items-center justify-center">
                                    {{$detailClaim->exchange_rate}} pts
                                </div>
                            </div>
                        </div>
                    </div>

                    <div @click="exchangeConfirm=true" class="p-3 bg-primary mt-4 rounded-sm cursor-pointer no-select">
                        <div class="w-full h-5  bg-primary flex items-center justify-center text-white">
                            Tukar Penawaran Ini
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div> --}}

    {{-- <div x-cloak x-show="openDetailPromo" class="w-screen md:w-full md:max-w-md max-w-full h-screen bg-white  max-h-screen overflow-auto flex flex-col ">
        @if($detailPromo)

        <div class="flex-none">
            <div class="w-full flex p-5">
                <div @if($from_dashboard) @click="redirectTo('{{ route('dashboard') }}')" @elseif($from_promo_detail) @click="redirectTo('{{ route('promo') }}')" @else @click="openDetailStore=true;openDetailPromo=false;exchangeConfirm=false" @endif class="flex items-center no-select cursor-pointer">
                    <div class="mr-1">
                        <div class="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21">
                            <path class="fill-primary " d="M8.45306 6.63482C8.65228 6.83014 8.65228 7.15435 8.45697 7.35357L6.08588 9.73248H15.121C15.3984 9.73248 15.6249 9.95904 15.6249 10.2403C15.6249 10.5215 15.3984 10.7481 15.121 10.7481H6.08588L8.46088 13.127C8.65619 13.3262 8.65228 13.6465 8.45697 13.8458C8.25775 14.0411 7.94134 14.0411 7.74213 13.8419L4.52338 10.5997C4.48041 10.5528 4.44525 10.502 4.41791 10.4395C4.39056 10.377 4.37885 10.3106 4.37885 10.2442C4.37885 10.1114 4.42963 9.98639 4.52338 9.88873L7.74213 6.64654C7.93353 6.44342 8.25384 6.43951 8.45306 6.63482Z"/>
                            </svg>
                        </div>
                    </div>
                    <div style="font-weight: 600;" class="text-primary  text-[16px]">
                        Kembali
                    </div>
                </div>
            </div>
        </div>

        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar bg-white  ">
            <div class="w-full px-5">
                <div class="w-full  rounded-sm ">
                    <div class="my-4 h-6 flex items-center text-[20px] text-dark-primary  mb-5">
                        {{ $detailPromo->title }}
                    </div>
                    @if ($detailPromo->thumbnail_path)
                    <img src="{{ asset('storage/' . $detailPromo->thumbnail_path) }}" class= "w-[100%] h-full mt-6" alt="Image">
                    @else
                    <div class="relative flex p-5 h-[100px] items-center bg-[#2C9854] overflow-hidden mb-4">
                        <div class="mr-[18px]">
                            <svg width="46" height="49" viewBox="0 0 46 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_328_4498)">
                                    <path d="M42.1875 39.3087L27.7025 47.3482C27.0076 47.7339 25.8705 47.7339 25.1757 47.3482L10.6906 39.3087C10.3432 39.1159 10.1695 38.8616 10.1695 38.6075H10.0156V20.6479H42.7087V38.6075C42.7087 38.8616 42.535 39.1159 42.1875 39.3087Z" fill="#FE5C5C"/>
                                    <path d="M42.7081 20.6478V38.6073C42.7081 38.8615 42.5344 39.1157 42.187 39.3086L27.7019 47.3481C27.3406 47.5486 26.8598 47.6441 26.3837 47.6359C26.3949 38.6428 26.6506 29.6383 26.3711 20.6477L42.7081 20.6478Z" fill="#FC8B8B"/>
                                    <path d="M25.1751 29.3887L10.6901 21.3491C9.99522 20.9634 9.99522 20.3324 10.6901 19.9467L25.1751 11.9072C25.87 11.5215 27.0071 11.5215 27.7019 11.9072L42.187 19.9467C42.8819 20.3324 42.8819 20.9635 42.187 21.3492L27.702 29.3887C27.0071 29.7744 25.87 29.7744 25.1751 29.3887Z" fill="#FFA9BA"/>
                                    <path d="M36.271 16.4045C36.2703 16.4895 36.2467 16.5727 36.2026 16.6454C36.1586 16.7181 36.0958 16.7775 36.0208 16.8175L18.6653 26.0688C18.6414 26.0815 18.6164 26.0922 18.5907 26.1006L18.532 26.1334V43.3984C18.532 43.4807 18.5106 43.5616 18.4697 43.633C18.4289 43.7044 18.3701 43.764 18.2992 43.8057C18.2283 43.8475 18.1477 43.87 18.0655 43.871C17.9832 43.8721 17.9021 43.8516 17.8301 43.8117L14.922 42.1976C14.8482 42.1567 14.7868 42.0968 14.744 42.0241C14.7013 41.9514 14.6787 41.8687 14.6787 41.7843V24.9835C14.6788 24.6952 14.7436 24.4106 14.8683 24.1507C14.9931 23.8908 15.1746 23.6622 15.3994 23.4818L15.4166 23.4684C15.4547 23.4386 15.4908 23.4124 15.528 23.3873C15.5832 23.3498 15.6402 23.3152 15.699 23.2835L32.5474 14.3025C32.617 14.2654 32.6948 14.2463 32.7737 14.2469C32.8526 14.2476 32.9301 14.268 32.999 14.3063L36.0278 15.9873C36.1021 16.0286 36.1639 16.0891 36.2067 16.1625C36.2495 16.2359 36.2717 16.3195 36.271 16.4045ZM37.8715 23.7135C37.7615 23.5881 37.6357 23.4776 37.4972 23.3847C37.4881 23.3785 37.479 23.3723 37.4683 23.3653C37.4233 23.336 37.3771 23.3086 37.3298 23.2833L20.4814 14.3024C20.4118 14.2653 20.334 14.2462 20.2551 14.2468C20.1762 14.2475 20.0988 14.2679 20.0298 14.3063L17.001 15.9873C16.9267 16.0285 16.8648 16.089 16.822 16.1624C16.7792 16.2359 16.757 16.3195 16.7577 16.4045C16.7584 16.4895 16.782 16.5727 16.8261 16.6454C16.8702 16.7181 16.933 16.7776 17.0081 16.8175L34.3636 26.0688C34.3877 26.0816 34.4127 26.0923 34.4382 26.1007L34.4968 26.1335V43.3985C34.4968 43.4808 34.5183 43.5616 34.5591 43.6331C34.6 43.7045 34.6587 43.764 34.7296 43.8058C34.8005 43.8475 34.8811 43.87 34.9634 43.8711C35.0457 43.8721 35.1268 43.8517 35.1987 43.8118L38.1069 42.1977C38.1806 42.1567 38.242 42.0968 38.2848 42.0242C38.3276 41.9515 38.3501 41.8687 38.3501 41.7844V24.9835C38.3499 24.5161 38.1798 24.0648 37.8715 23.7135Z" fill="#3688EF"/>
                                    <path d="M32.2361 20.982C32.2361 22.1679 30.7816 23.0285 28.7777 23.0285C27.9604 23.0285 27.2347 22.8852 26.6617 22.6353C26.5885 22.6035 26.5092 22.5883 26.4295 22.5906C26.3498 22.593 26.2715 22.6129 26.2004 22.649C25.6031 22.9504 24.8111 23.1261 23.9067 23.1261C21.9028 23.1261 20.4482 22.2654 20.4482 21.0795C20.4482 20.4825 20.817 19.968 21.4389 19.6041C21.6839 19.4608 21.7868 19.1549 21.6655 18.8983C21.2222 17.9609 21.2364 17.0814 21.7801 16.5377C22.0617 16.2561 22.4473 16.1073 22.8954 16.1073C23.2102 16.1073 23.5521 16.1817 23.9033 16.3214C24.0382 16.3752 24.1889 16.3738 24.3228 16.3174C24.4567 16.2611 24.5631 16.1543 24.619 16.0202C24.98 15.1586 25.5772 14.6279 26.2934 14.6279C26.9973 14.6279 27.5865 15.1406 27.9493 15.9764C28.0697 16.2538 28.3875 16.3862 28.667 16.2708C29.034 16.1194 29.3916 16.0384 29.7199 16.0384C30.2859 16.0384 30.6388 16.2724 30.8352 16.4688C31.3696 17.0032 31.3926 17.8621 30.9722 18.7816C30.8543 19.0395 30.9589 19.3448 31.2058 19.4843C31.8515 19.8491 32.2361 20.3725 32.2361 20.982Z" fill="#2F6BB7"/>
                                </g>
                                <circle cx="40.8979" cy="11.7502" r="1.71429" fill="#FF8933"/>
                                <path d="M11.4777 3.74029C12.0165 3.25521 12.8612 3.74291 12.7105 4.452C12.643 4.76912 12.7875 5.09357 13.0683 5.25567C13.6961 5.61814 13.4933 6.57222 12.7723 6.648C12.4499 6.68189 12.186 6.91954 12.1186 7.23665C11.9678 7.94575 10.9978 8.0477 10.7029 7.38544C10.5711 7.08927 10.2635 6.91169 9.94106 6.94558C9.22009 7.02135 8.82336 6.13029 9.36209 5.64521C9.60302 5.42828 9.67686 5.08088 9.545 4.78471C9.25014 4.12244 9.975 3.46978 10.6028 3.83224C10.8836 3.99434 11.2368 3.95722 11.4777 3.74029Z" fill="#80D5EF"/>
                                <circle cx="28.1635" cy="1.95428" r="1.71429" fill="white"/>
                                <path d="M3.66431 30.9826C3.70225 30.2587 4.64441 30.0062 5.03924 30.6142C5.21581 30.8861 5.54739 31.0134 5.86054 30.9295C6.56077 30.7419 7.09201 31.5599 6.6358 32.1233C6.43177 32.3752 6.41318 32.7299 6.58975 33.0018C6.98458 33.6098 6.37075 34.3678 5.69396 34.108C5.39129 33.9918 5.04823 34.0838 4.84421 34.3357C4.38799 34.8991 3.47738 34.5495 3.51532 33.8256C3.53229 33.5018 3.33885 33.204 3.03619 33.0878C2.3594 32.828 2.41045 31.8539 3.11068 31.6663C3.42384 31.5824 3.64735 31.3064 3.66431 30.9826Z" fill="#ABEAB9"/>
                                <defs>
                                    <clipPath id="clip0_328_4498">
                                        <rect width="37.2245" height="37.2245" fill="white" transform="translate(7.83691 11.0154)"/>
                                    </clipPath>
                                </defs>
                            </svg>
                        </div>
                        <div>
                            <div style="font-weight: 600;" class="h-6 flex items-center text-white text-[20px] mb-1">
                                Promo image
                            </div>
                            <div style="font-weight: 400;" class="h-5 text-white text-[16px]">
                                Klaim sekarang!
                            </div>
                        </div>
                        <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                        </div>
                    </div>
                    @endif

                    <div class="flex items-center justify-start mb-[44px]">
                        <div class="mr-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                                <path d="M16.5625 3.98999H15V4.92749C15 5.09937 14.8594 5.23999 14.6875 5.23999H14.0625C13.8906 5.23999 13.75 5.09937 13.75 4.92749V3.98999H6.25V4.92749C6.25 5.09937 6.10938 5.23999 5.9375 5.23999H5.3125C5.14062 5.23999 5 5.09937 5 4.92749V3.98999H3.4375C2.57812 3.98999 1.875 4.69312 1.875 5.55249V16.1775C1.875 17.0369 2.57812 17.74 3.4375 17.74H16.5625C17.4219 17.74 18.125 17.0369 18.125 16.1775V5.55249C18.125 4.69312 17.4219 3.98999 16.5625 3.98999ZM16.875 15.7087C16.875 16.1384 16.5234 16.49 16.0938 16.49H3.90625C3.47656 16.49 3.125 16.1384 3.125 15.7087V8.67749C3.125 8.50562 3.26562 8.36499 3.4375 8.36499H16.5625C16.7344 8.36499 16.875 8.50562 16.875 8.67749V15.7087ZM6.25 3.05249C6.25 2.88062 6.10938 2.73999 5.9375 2.73999H5.3125C5.14062 2.73999 5 2.88062 5 3.05249V3.98999H6.25V3.05249ZM15 3.05249C15 2.88062 14.8594 2.73999 14.6875 2.73999H14.0625C13.8906 2.73999 13.75 2.88062 13.75 3.05249V3.98999H15V3.05249Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                        <div class="flex items-center h-5 text-[#6A6A75]  ">
                            Berlaku sampai {{changeDateFormat($detailPromo->end_date)}}
                        </div>
                    </div>
                </div>

                <div class="py-3 px-5 mb-6">
                    <div style="font-weight: 600;" class="h-6 flex items-center text-[18px] text-dark-primary ">
                        Penukaran dapat dilakukan di cabang :
                    </div>
                    @foreach ($detailPromo->promotionStores as $store)
                        <div class="w-full py-3 flex border-b">
                            <div class="mr-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                                    <g clip-path="url(#clip0_488_1632)">
                                        <path d="M15.75 4.73994C15.7499 4.0304 15.5486 3.33543 15.1693 2.73576C14.79 2.13609 14.2484 1.65632 13.6074 1.35219C12.9663 1.04806 12.2521 0.932037 11.5478 1.01761C10.8434 1.10317 10.1778 1.38682 9.62818 1.83559C9.07859 2.28437 8.66759 2.87986 8.44293 3.5529C8.21828 4.22593 8.18917 4.9489 8.359 5.63781C8.52884 6.32673 8.89063 6.95333 9.40237 7.44483C9.91411 7.93633 10.5548 8.27256 11.25 8.41447V21.6881C11.2501 21.8873 11.2898 22.0846 11.3667 22.2684L11.8388 23.3934C11.8546 23.4223 11.8779 23.4465 11.9063 23.4633C11.9346 23.4801 11.967 23.489 12 23.489C12.033 23.489 12.0654 23.4801 12.0937 23.4633C12.1221 23.4465 12.1454 23.4223 12.1613 23.3934L12.6333 22.2684C12.7102 22.0846 12.7499 21.8873 12.75 21.6881V8.41447C13.5964 8.24053 14.357 7.78007 14.9035 7.11071C15.4499 6.44135 15.7489 5.60405 15.75 4.73994ZM13.125 4.73994C12.9025 4.73994 12.685 4.67396 12.5 4.55034C12.315 4.42673 12.1708 4.25103 12.0856 4.04546C12.0005 3.83989 11.9782 3.61369 12.0216 3.39546C12.065 3.17723 12.1722 2.97678 12.3295 2.81944C12.4868 2.66211 12.6873 2.55496 12.9055 2.51156C13.1238 2.46815 13.35 2.49043 13.5555 2.57558C13.7611 2.66072 13.9368 2.80492 14.0604 2.98992C14.184 3.17493 14.25 3.39244 14.25 3.61494C14.25 3.91331 14.1315 4.19946 13.9205 4.41044C13.7095 4.62141 13.4234 4.73994 13.125 4.73994Z" fill="#FE5C5C"/>
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_488_1632">
                                            <rect width="24" height="24" fill="white" transform="translate(0 0.23999)"/>
                                        </clipPath>
                                    </defs>
                                </svg>
                            </div>
                            <div>
                                <div style='font-weight: 600;' class="mb-2 h-5 flex items-center text-[16px] text-dark-primary ">
                                    {{$store->store->name}}
                                </div>
                                <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]   line-clamp-2">
                                    {{$store->store->address}}, {{$store->store->urban_village}}, {{$store->store->subdistrict}}, {{ $store->store->city }}, {{$store->store->province}} ({{$store->store->postal_code}})
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>

                <div class="px-5 mb-5">
                    <div style="font-weight: 600;" class="h-6 text-[18px] text-dark-primary  flex items-center mb-2">
                        Syarat & Ketentuan
                    </div>
                    <div style="font-weight: 400;" class="text-[16px] text-[#6A6A75]  ">
                        {{ $detailPromo->description }}
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div> --}}

    {{-- <div x-cloak x-show="openDetailProduct" class="w-screen md:w-full md:max-w-md max-w-full h-screen bg-white  max-h-screen overflow-auto flex flex-col ">
        @if($detailProduct)

        <div class="flex-none">
            <div class="w-full flex p-5">
                <div @if($from_dashboard) @click="redirectTo('{{ route('dashboard') }}')" @elseif($from_promo_detail) @click="redirectTo('{{ route('promo') }}')" @else @click="openDetailStore=true;openDetailProduct=false;exchangeConfirm=false" @endif class="flex items-center no-select cursor-pointer">
                    <div class="mr-1">
                        <div class="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21">
                            <path class="fill-primary " d="M8.45306 6.63482C8.65228 6.83014 8.65228 7.15435 8.45697 7.35357L6.08588 9.73248H15.121C15.3984 9.73248 15.6249 9.95904 15.6249 10.2403C15.6249 10.5215 15.3984 10.7481 15.121 10.7481H6.08588L8.46088 13.127C8.65619 13.3262 8.65228 13.6465 8.45697 13.8458C8.25775 14.0411 7.94134 14.0411 7.74213 13.8419L4.52338 10.5997C4.48041 10.5528 4.44525 10.502 4.41791 10.4395C4.39056 10.377 4.37885 10.3106 4.37885 10.2442C4.37885 10.1114 4.42963 9.98639 4.52338 9.88873L7.74213 6.64654C7.93353 6.44342 8.25384 6.43951 8.45306 6.63482Z"/>
                            </svg>
                        </div>
                    </div>
                    <div style="font-weight: 600;" class="text-primary  text-[16px]">
                        Kembali
                    </div>
                </div>
            </div>
        </div>

        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar bg-white  ">
            <div class="w-full px-5">
                <div class="w-full  rounded-sm ">
                    <div class="my-4 h-6 flex items-center text-[20px] text-dark-primary  mb-5">
                        {{ $detailProduct->title }}
                    </div>
                    @if ($detailProduct->thumbnail_path)
                    <img src="{{ asset('storage/' . $detailProduct->thumbnail_path) }}" class= "w-[100%] h-full mt-6" alt="Image">
                    @else
                    <div class="relative flex p-5 h-[100px] items-center bg-[#2C9854] overflow-hidden mb-4">
                        <div class="mr-[18px]">
                            <svg width="46" height="49" viewBox="0 0 46 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_328_4498)">
                                    <path d="M42.1875 39.3087L27.7025 47.3482C27.0076 47.7339 25.8705 47.7339 25.1757 47.3482L10.6906 39.3087C10.3432 39.1159 10.1695 38.8616 10.1695 38.6075H10.0156V20.6479H42.7087V38.6075C42.7087 38.8616 42.535 39.1159 42.1875 39.3087Z" fill="#FE5C5C"/>
                                    <path d="M42.7081 20.6478V38.6073C42.7081 38.8615 42.5344 39.1157 42.187 39.3086L27.7019 47.3481C27.3406 47.5486 26.8598 47.6441 26.3837 47.6359C26.3949 38.6428 26.6506 29.6383 26.3711 20.6477L42.7081 20.6478Z" fill="#FC8B8B"/>
                                    <path d="M25.1751 29.3887L10.6901 21.3491C9.99522 20.9634 9.99522 20.3324 10.6901 19.9467L25.1751 11.9072C25.87 11.5215 27.0071 11.5215 27.7019 11.9072L42.187 19.9467C42.8819 20.3324 42.8819 20.9635 42.187 21.3492L27.702 29.3887C27.0071 29.7744 25.87 29.7744 25.1751 29.3887Z" fill="#FFA9BA"/>
                                    <path d="M36.271 16.4045C36.2703 16.4895 36.2467 16.5727 36.2026 16.6454C36.1586 16.7181 36.0958 16.7775 36.0208 16.8175L18.6653 26.0688C18.6414 26.0815 18.6164 26.0922 18.5907 26.1006L18.532 26.1334V43.3984C18.532 43.4807 18.5106 43.5616 18.4697 43.633C18.4289 43.7044 18.3701 43.764 18.2992 43.8057C18.2283 43.8475 18.1477 43.87 18.0655 43.871C17.9832 43.8721 17.9021 43.8516 17.8301 43.8117L14.922 42.1976C14.8482 42.1567 14.7868 42.0968 14.744 42.0241C14.7013 41.9514 14.6787 41.8687 14.6787 41.7843V24.9835C14.6788 24.6952 14.7436 24.4106 14.8683 24.1507C14.9931 23.8908 15.1746 23.6622 15.3994 23.4818L15.4166 23.4684C15.4547 23.4386 15.4908 23.4124 15.528 23.3873C15.5832 23.3498 15.6402 23.3152 15.699 23.2835L32.5474 14.3025C32.617 14.2654 32.6948 14.2463 32.7737 14.2469C32.8526 14.2476 32.9301 14.268 32.999 14.3063L36.0278 15.9873C36.1021 16.0286 36.1639 16.0891 36.2067 16.1625C36.2495 16.2359 36.2717 16.3195 36.271 16.4045ZM37.8715 23.7135C37.7615 23.5881 37.6357 23.4776 37.4972 23.3847C37.4881 23.3785 37.479 23.3723 37.4683 23.3653C37.4233 23.336 37.3771 23.3086 37.3298 23.2833L20.4814 14.3024C20.4118 14.2653 20.334 14.2462 20.2551 14.2468C20.1762 14.2475 20.0988 14.2679 20.0298 14.3063L17.001 15.9873C16.9267 16.0285 16.8648 16.089 16.822 16.1624C16.7792 16.2359 16.757 16.3195 16.7577 16.4045C16.7584 16.4895 16.782 16.5727 16.8261 16.6454C16.8702 16.7181 16.933 16.7776 17.0081 16.8175L34.3636 26.0688C34.3877 26.0816 34.4127 26.0923 34.4382 26.1007L34.4968 26.1335V43.3985C34.4968 43.4808 34.5183 43.5616 34.5591 43.6331C34.6 43.7045 34.6587 43.764 34.7296 43.8058C34.8005 43.8475 34.8811 43.87 34.9634 43.8711C35.0457 43.8721 35.1268 43.8517 35.1987 43.8118L38.1069 42.1977C38.1806 42.1567 38.242 42.0968 38.2848 42.0242C38.3276 41.9515 38.3501 41.8687 38.3501 41.7844V24.9835C38.3499 24.5161 38.1798 24.0648 37.8715 23.7135Z" fill="#3688EF"/>
                                    <path d="M32.2361 20.982C32.2361 22.1679 30.7816 23.0285 28.7777 23.0285C27.9604 23.0285 27.2347 22.8852 26.6617 22.6353C26.5885 22.6035 26.5092 22.5883 26.4295 22.5906C26.3498 22.593 26.2715 22.6129 26.2004 22.649C25.6031 22.9504 24.8111 23.1261 23.9067 23.1261C21.9028 23.1261 20.4482 22.2654 20.4482 21.0795C20.4482 20.4825 20.817 19.968 21.4389 19.6041C21.6839 19.4608 21.7868 19.1549 21.6655 18.8983C21.2222 17.9609 21.2364 17.0814 21.7801 16.5377C22.0617 16.2561 22.4473 16.1073 22.8954 16.1073C23.2102 16.1073 23.5521 16.1817 23.9033 16.3214C24.0382 16.3752 24.1889 16.3738 24.3228 16.3174C24.4567 16.2611 24.5631 16.1543 24.619 16.0202C24.98 15.1586 25.5772 14.6279 26.2934 14.6279C26.9973 14.6279 27.5865 15.1406 27.9493 15.9764C28.0697 16.2538 28.3875 16.3862 28.667 16.2708C29.034 16.1194 29.3916 16.0384 29.7199 16.0384C30.2859 16.0384 30.6388 16.2724 30.8352 16.4688C31.3696 17.0032 31.3926 17.8621 30.9722 18.7816C30.8543 19.0395 30.9589 19.3448 31.2058 19.4843C31.8515 19.8491 32.2361 20.3725 32.2361 20.982Z" fill="#2F6BB7"/>
                                </g>
                                <circle cx="40.8979" cy="11.7502" r="1.71429" fill="#FF8933"/>
                                <path d="M11.4777 3.74029C12.0165 3.25521 12.8612 3.74291 12.7105 4.452C12.643 4.76912 12.7875 5.09357 13.0683 5.25567C13.6961 5.61814 13.4933 6.57222 12.7723 6.648C12.4499 6.68189 12.186 6.91954 12.1186 7.23665C11.9678 7.94575 10.9978 8.0477 10.7029 7.38544C10.5711 7.08927 10.2635 6.91169 9.94106 6.94558C9.22009 7.02135 8.82336 6.13029 9.36209 5.64521C9.60302 5.42828 9.67686 5.08088 9.545 4.78471C9.25014 4.12244 9.975 3.46978 10.6028 3.83224C10.8836 3.99434 11.2368 3.95722 11.4777 3.74029Z" fill="#80D5EF"/>
                                <circle cx="28.1635" cy="1.95428" r="1.71429" fill="white"/>
                                <path d="M3.66431 30.9826C3.70225 30.2587 4.64441 30.0062 5.03924 30.6142C5.21581 30.8861 5.54739 31.0134 5.86054 30.9295C6.56077 30.7419 7.09201 31.5599 6.6358 32.1233C6.43177 32.3752 6.41318 32.7299 6.58975 33.0018C6.98458 33.6098 6.37075 34.3678 5.69396 34.108C5.39129 33.9918 5.04823 34.0838 4.84421 34.3357C4.38799 34.8991 3.47738 34.5495 3.51532 33.8256C3.53229 33.5018 3.33885 33.204 3.03619 33.0878C2.3594 32.828 2.41045 31.8539 3.11068 31.6663C3.42384 31.5824 3.64735 31.3064 3.66431 30.9826Z" fill="#ABEAB9"/>
                                <defs>
                                    <clipPath id="clip0_328_4498">
                                        <rect width="37.2245" height="37.2245" fill="white" transform="translate(7.83691 11.0154)"/>
                                    </clipPath>
                                </defs>
                            </svg>
                        </div>
                        <div>
                            <div style="font-weight: 600;" class="h-6 flex items-center text-white text-[20px] mb-1">
                                Promo image
                            </div>
                            <div style="font-weight: 400;" class="h-5 text-white text-[16px]">
                                Klaim sekarang!
                            </div>
                        </div>
                        <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                        </div>
                    </div>
                    @endif

                    <div class="flex items-center justify-start mb-[44px]">
                        <div class="mr-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                                <path d="M16.5625 3.98999H15V4.92749C15 5.09937 14.8594 5.23999 14.6875 5.23999H14.0625C13.8906 5.23999 13.75 5.09937 13.75 4.92749V3.98999H6.25V4.92749C6.25 5.09937 6.10938 5.23999 5.9375 5.23999H5.3125C5.14062 5.23999 5 5.09937 5 4.92749V3.98999H3.4375C2.57812 3.98999 1.875 4.69312 1.875 5.55249V16.1775C1.875 17.0369 2.57812 17.74 3.4375 17.74H16.5625C17.4219 17.74 18.125 17.0369 18.125 16.1775V5.55249C18.125 4.69312 17.4219 3.98999 16.5625 3.98999ZM16.875 15.7087C16.875 16.1384 16.5234 16.49 16.0938 16.49H3.90625C3.47656 16.49 3.125 16.1384 3.125 15.7087V8.67749C3.125 8.50562 3.26562 8.36499 3.4375 8.36499H16.5625C16.7344 8.36499 16.875 8.50562 16.875 8.67749V15.7087ZM6.25 3.05249C6.25 2.88062 6.10938 2.73999 5.9375 2.73999H5.3125C5.14062 2.73999 5 2.88062 5 3.05249V3.98999H6.25V3.05249ZM15 3.05249C15 2.88062 14.8594 2.73999 14.6875 2.73999H14.0625C13.8906 2.73999 13.75 2.88062 13.75 3.05249V3.98999H15V3.05249Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                        <div class="flex items-center h-5 text-[#6A6A75]  ">
                            Berlaku sampai {{changeDateFormat($detailProduct->end_date)}}
                        </div>
                    </div>
                </div>

                <div class="py-3 px-5 mb-6">
                    <div style="font-weight: 600;" class="h-6 flex items-center text-[18px] text-dark-primary ">
                        Penukaran dapat dilakukan di cabang :
                    </div>
                    @foreach ($detailProduct->productStores as $store)
                        <div class="w-full py-3 flex border-b">
                            <div class="mr-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                                    <g clip-path="url(#clip0_488_1632)">
                                        <path d="M15.75 4.73994C15.7499 4.0304 15.5486 3.33543 15.1693 2.73576C14.79 2.13609 14.2484 1.65632 13.6074 1.35219C12.9663 1.04806 12.2521 0.932037 11.5478 1.01761C10.8434 1.10317 10.1778 1.38682 9.62818 1.83559C9.07859 2.28437 8.66759 2.87986 8.44293 3.5529C8.21828 4.22593 8.18917 4.9489 8.359 5.63781C8.52884 6.32673 8.89063 6.95333 9.40237 7.44483C9.91411 7.93633 10.5548 8.27256 11.25 8.41447V21.6881C11.2501 21.8873 11.2898 22.0846 11.3667 22.2684L11.8388 23.3934C11.8546 23.4223 11.8779 23.4465 11.9063 23.4633C11.9346 23.4801 11.967 23.489 12 23.489C12.033 23.489 12.0654 23.4801 12.0937 23.4633C12.1221 23.4465 12.1454 23.4223 12.1613 23.3934L12.6333 22.2684C12.7102 22.0846 12.7499 21.8873 12.75 21.6881V8.41447C13.5964 8.24053 14.357 7.78007 14.9035 7.11071C15.4499 6.44135 15.7489 5.60405 15.75 4.73994ZM13.125 4.73994C12.9025 4.73994 12.685 4.67396 12.5 4.55034C12.315 4.42673 12.1708 4.25103 12.0856 4.04546C12.0005 3.83989 11.9782 3.61369 12.0216 3.39546C12.065 3.17723 12.1722 2.97678 12.3295 2.81944C12.4868 2.66211 12.6873 2.55496 12.9055 2.51156C13.1238 2.46815 13.35 2.49043 13.5555 2.57558C13.7611 2.66072 13.9368 2.80492 14.0604 2.98992C14.184 3.17493 14.25 3.39244 14.25 3.61494C14.25 3.91331 14.1315 4.19946 13.9205 4.41044C13.7095 4.62141 13.4234 4.73994 13.125 4.73994Z" fill="#FE5C5C"/>
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_488_1632">
                                            <rect width="24" height="24" fill="white" transform="translate(0 0.23999)"/>
                                        </clipPath>
                                    </defs>
                                </svg>
                            </div>
                            <div>
                                <div style='font-weight: 600;' class="mb-2 h-5 flex items-center text-[16px] text-dark-primary ">
                                    {{$store->store->name}}
                                </div>
                                <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]   line-clamp-2">
                                    {{$store->store->address}}, {{$store->store->urban_village}}, {{$store->store->subdistrict}}, {{ $store->store->city }}, {{$store->store->province}} ({{$store->store->postal_code}})
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>

                <div class="px-5 mb-5">
                    <div style="font-weight: 600;" class="h-6 text-[18px] text-dark-primary  flex items-center mb-2">
                        Syarat & Ketentuan
                    </div>
                    <div style="font-weight: 400;" class="text-[16px] text-[#6A6A75]  ">
                        {{ $detailProduct->description }}
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div> --}}

    <div x-cloak x-show="openListClaimStores" style="z-index: 80" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        @if($detailClaim)
        <div @click.outside="openListClaimStores=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5 max-h-[400px] flex flex-col">
                <div class="flex-none">
                    <div class="w-full flex justify-between items-center mb-[18px]">
                        <div>
                            <div style="font-weight: 600;" class="text-[18px] mb-[2px] text-dark-primary">
                                {{$detailClaim->brand->company_name}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]">
                                Here are the branches you can find
                            </div>
                        </div>
                        <div @click="openListClaimStores=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="flex-1 overflow-y-auto hide-scrollbar">
                @foreach ($detailClaim->claimStores as $claimStore)
                    <div class="w-full py-3 mt-[18px] flex">
                        <div class="mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M15.75 4.50019C15.7499 3.79065 15.5486 3.09568 15.1693 2.49601C14.79 1.89634 14.2484 1.41658 13.6074 1.11245C12.9663 0.808312 12.2521 0.692291 11.5478 0.777859C10.8434 0.863427 10.1778 1.14707 9.62818 1.59585C9.07859 2.04462 8.66759 2.64011 8.44293 3.31315C8.21828 3.98619 8.18917 4.70915 8.359 5.39807C8.52884 6.08699 8.89063 6.71358 9.40237 7.20508C9.91411 7.69659 10.5548 8.03282 11.25 8.17472V21.4483C11.2501 21.6476 11.2898 21.8448 11.3667 22.0286L11.8388 23.1536C11.8546 23.1826 11.8779 23.2067 11.9063 23.2236C11.9346 23.2404 11.967 23.2493 12 23.2493C12.033 23.2493 12.0654 23.2404 12.0937 23.2236C12.1221 23.2067 12.1454 23.1826 12.1613 23.1536L12.6333 22.0286C12.7102 21.8448 12.7499 21.6476 12.75 21.4483V8.17472C13.5964 8.00078 14.357 7.54032 14.9035 6.87096C15.4499 6.20161 15.7489 5.3643 15.75 4.50019ZM13.125 4.50019C12.9025 4.50019 12.685 4.43421 12.5 4.3106C12.315 4.18698 12.1708 4.01128 12.0856 3.80571C12.0005 3.60015 11.9782 3.37395 12.0216 3.15572C12.065 2.93749 12.1722 2.73703 12.3295 2.5797C12.4868 2.42236 12.6873 2.31522 12.9055 2.27181C13.1238 2.2284 13.35 2.25068 13.5555 2.33583C13.7611 2.42098 13.9368 2.56517 14.0604 2.75018C14.184 2.93518 14.25 3.15269 14.25 3.37519C14.25 3.67356 14.1315 3.95971 13.9205 4.17069C13.7095 4.38167 13.4234 4.50019 13.125 4.50019Z" fill="#FE5C5C"/>
                            </svg>
                        </div>
                        <div class="max-w-[330px]">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary mb-2 h-6 flex items-center truncate">
                                {{$claimStore->store->name}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] h-10 items-center line-clamp-2">
                                {{$claimStore->store->address}}, {{$claimStore->store->urban_village}}, {{$claimStore->store->subdistrict}}, {{ $claimStore->store->city }}, {{$claimStore->store->province}} ({{$claimStore->store->postal_code}})
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="openListPromoStores" style="z-index: 80" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        @if($detailPromo)
        <div @click.outside="openListPromoStores=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5 max-h-[400px] flex flex-col">
                <div class="flex-none">
                    <div class="w-full flex justify-between items-center mb-[18px]">
                        <div>
                            <div style="font-weight: 600;" class="text-[18px] mb-[2px] text-dark-primary">
                                {{$detailPromo->brand->company_name}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]">
                                Here are the branches you can find
                            </div>
                        </div>
                        <div @click="openListPromoStores=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="flex-1 overflow-y-auto hide-scrollbar">
                @foreach ($detailPromo->promotionStores as $promoStore)
                    <div class="w-full py-3 mt-[18px] flex">
                        <div class="mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M15.75 4.50019C15.7499 3.79065 15.5486 3.09568 15.1693 2.49601C14.79 1.89634 14.2484 1.41658 13.6074 1.11245C12.9663 0.808312 12.2521 0.692291 11.5478 0.777859C10.8434 0.863427 10.1778 1.14707 9.62818 1.59585C9.07859 2.04462 8.66759 2.64011 8.44293 3.31315C8.21828 3.98619 8.18917 4.70915 8.359 5.39807C8.52884 6.08699 8.89063 6.71358 9.40237 7.20508C9.91411 7.69659 10.5548 8.03282 11.25 8.17472V21.4483C11.2501 21.6476 11.2898 21.8448 11.3667 22.0286L11.8388 23.1536C11.8546 23.1826 11.8779 23.2067 11.9063 23.2236C11.9346 23.2404 11.967 23.2493 12 23.2493C12.033 23.2493 12.0654 23.2404 12.0937 23.2236C12.1221 23.2067 12.1454 23.1826 12.1613 23.1536L12.6333 22.0286C12.7102 21.8448 12.7499 21.6476 12.75 21.4483V8.17472C13.5964 8.00078 14.357 7.54032 14.9035 6.87096C15.4499 6.20161 15.7489 5.3643 15.75 4.50019ZM13.125 4.50019C12.9025 4.50019 12.685 4.43421 12.5 4.3106C12.315 4.18698 12.1708 4.01128 12.0856 3.80571C12.0005 3.60015 11.9782 3.37395 12.0216 3.15572C12.065 2.93749 12.1722 2.73703 12.3295 2.5797C12.4868 2.42236 12.6873 2.31522 12.9055 2.27181C13.1238 2.2284 13.35 2.25068 13.5555 2.33583C13.7611 2.42098 13.9368 2.56517 14.0604 2.75018C14.184 2.93518 14.25 3.15269 14.25 3.37519C14.25 3.67356 14.1315 3.95971 13.9205 4.17069C13.7095 4.38167 13.4234 4.50019 13.125 4.50019Z" fill="#FE5C5C"/>
                            </svg>
                        </div>
                        <div class="max-w-[330px]">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary mb-2 h-6 flex items-center truncate">
                                {{$promoStore->store->name}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] h-10 items-center line-clamp-2">
                                {{$promoStore->store->address}}, {{$promoStore->store->urban_village}}, {{$promoStore->store->subdistrict}}, {{ $promoStore->store->city }}, {{$promoStore->store->province}} ({{$promoStore->store->postal_code}})
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="openListProductStores" style="z-index: 80" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        @if($detailProduct)
        <div @click.outside="openListProductStores=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5 max-h-[400px] flex flex-col">
                <div class="flex-none">
                    <div class="w-full flex justify-between items-center mb-[18px]">
                        <div>
                            <div style="font-weight: 600;" class="text-[18px] mb-[2px] text-dark-primary">
                                {{$detailProduct->brand->company_name}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]">
                                Here are the branches you can find
                            </div>
                        </div>
                        <div @click="openListProductStores=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="flex-1 overflow-y-auto hide-scrollbar">
                @foreach ($detailProduct->productStores as $productStore)
                    <div class="w-full py-3 mt-[18px] flex">
                        <div class="mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M15.75 4.50019C15.7499 3.79065 15.5486 3.09568 15.1693 2.49601C14.79 1.89634 14.2484 1.41658 13.6074 1.11245C12.9663 0.808312 12.2521 0.692291 11.5478 0.777859C10.8434 0.863427 10.1778 1.14707 9.62818 1.59585C9.07859 2.04462 8.66759 2.64011 8.44293 3.31315C8.21828 3.98619 8.18917 4.70915 8.359 5.39807C8.52884 6.08699 8.89063 6.71358 9.40237 7.20508C9.91411 7.69659 10.5548 8.03282 11.25 8.17472V21.4483C11.2501 21.6476 11.2898 21.8448 11.3667 22.0286L11.8388 23.1536C11.8546 23.1826 11.8779 23.2067 11.9063 23.2236C11.9346 23.2404 11.967 23.2493 12 23.2493C12.033 23.2493 12.0654 23.2404 12.0937 23.2236C12.1221 23.2067 12.1454 23.1826 12.1613 23.1536L12.6333 22.0286C12.7102 21.8448 12.7499 21.6476 12.75 21.4483V8.17472C13.5964 8.00078 14.357 7.54032 14.9035 6.87096C15.4499 6.20161 15.7489 5.3643 15.75 4.50019ZM13.125 4.50019C12.9025 4.50019 12.685 4.43421 12.5 4.3106C12.315 4.18698 12.1708 4.01128 12.0856 3.80571C12.0005 3.60015 11.9782 3.37395 12.0216 3.15572C12.065 2.93749 12.1722 2.73703 12.3295 2.5797C12.4868 2.42236 12.6873 2.31522 12.9055 2.27181C13.1238 2.2284 13.35 2.25068 13.5555 2.33583C13.7611 2.42098 13.9368 2.56517 14.0604 2.75018C14.184 2.93518 14.25 3.15269 14.25 3.37519C14.25 3.67356 14.1315 3.95971 13.9205 4.17069C13.7095 4.38167 13.4234 4.50019 13.125 4.50019Z" fill="#FE5C5C"/>
                            </svg>
                        </div>
                        <div class="max-w-[330px]">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary mb-2 h-6 flex items-center truncate">
                                {{$productStore->store->name}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] h-10 items-center line-clamp-2">
                                {{$productStore->store->address}}, {{$productStore->store->urban_village}}, {{$productStore->store->subdistrict}}, {{ $productStore->store->city }}, {{$productStore->store->province}} ({{$productStore->store->postal_code}})
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="exchangeConfirm" style="z-index: 80" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        @if($detailClaim)
        <div @click.outside="exchangeConfirm=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5">
                <div class="w-full flex justify-between items-center mb-[18px]">
                    <div>
                        <div style="font-weight: 600;" class="text-[18px] mb-[2px] text-dark-secondary ">
                            Confirmation
                        </div>
                        <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]  ">
                            Are you sure want to redeem?
                        </div>
                    </div>
                    <div @click="exchangeConfirm=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
                <div class="w-full flex items-center justify-between p-3 border rounded-sm  ">
                    <div class="flex items-center">
                        <div>
                            <div class="w-8 h-8 rounded-full mr-2 {{ ($detailClaim->claim_type_id == 1) ? 'bg-[#E5EDFA]' : 'bg-[#FAE4E4]'}} flex items-center justify-center">
                                @if ($detailClaim->claim_type_id == 1)
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
                                    <path d="M10.5 2.74023H1.5C1.36739 2.74023 1.24021 2.79291 1.14645 2.88668C1.05268 2.98045 1 3.10763 1 3.24023V5.24023H1.4465C1.9445 5.24023 2.4065 5.58073 2.4865 6.07223C2.51087 6.21575 2.50363 6.36286 2.46528 6.50329C2.42693 6.64372 2.3584 6.7741 2.26447 6.88531C2.17054 6.99652 2.05347 7.0859 1.92143 7.1472C1.7894 7.2085 1.64557 7.24025 1.5 7.24023H1V9.24023C1 9.37284 1.05268 9.50002 1.14645 9.59379C1.24021 9.68756 1.36739 9.74023 1.5 9.74023H10.5C10.6326 9.74023 10.7598 9.68756 10.8536 9.59379C10.9473 9.50002 11 9.37284 11 9.24023V7.24023H10.5C10.3544 7.24025 10.2106 7.2085 10.0786 7.1472C9.94653 7.0859 9.82946 6.99652 9.73553 6.88531C9.6416 6.7741 9.57307 6.64372 9.53472 6.50329C9.49637 6.36286 9.48913 6.21575 9.5135 6.07223C9.5935 5.58073 10.0555 5.24023 10.5535 5.24023H11V3.24023C11 3.10763 10.9473 2.98045 10.8536 2.88668C10.7598 2.79291 10.6326 2.74023 10.5 2.74023ZM5.5 8.74023H4.5V7.74023H5.5V8.74023ZM5.5 6.74023H4.5V5.74023H5.5V6.74023ZM5.5 4.74023H4.5V3.74023H5.5V4.74023Z" fill="#3688EF"/>
                                </svg>
                                @else
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="17" viewBox="0 0 16 17" fill="none">
                                    <path d="M6.03996 1.52664C4.77996 1.51997 3.55329 2.73331 4.11329 4.23997H1.99996C1.64634 4.23997 1.3072 4.38045 1.05715 4.6305C0.807102 4.88054 0.666626 5.21968 0.666626 5.57331V6.90664C0.666626 7.08345 0.736864 7.25302 0.861888 7.37804C0.986912 7.50307 1.15648 7.57331 1.33329 7.57331H7.33329V5.57331H8.66663V7.57331H14.6666C14.8434 7.57331 15.013 7.50307 15.138 7.37804C15.2631 7.25302 15.3333 7.08345 15.3333 6.90664V5.57331C15.3333 5.21968 15.1928 4.88054 14.9428 4.6305C14.6927 4.38045 14.3536 4.23997 14 4.23997H11.8866C12.6666 2.05997 9.73329 0.519972 8.37996 2.39997L7.99996 2.90664L7.61996 2.38664C7.19996 1.79331 6.61996 1.53331 6.03996 1.52664ZM5.99996 2.90664C6.59329 2.90664 6.89329 3.62664 6.47329 4.04664C6.05329 4.46664 5.33329 4.16664 5.33329 3.57331C5.33329 3.39649 5.40353 3.22693 5.52855 3.1019C5.65358 2.97688 5.82315 2.90664 5.99996 2.90664ZM9.99996 2.90664C10.5933 2.90664 10.8933 3.62664 10.4733 4.04664C10.0533 4.46664 9.33329 4.16664 9.33329 3.57331C9.33329 3.39649 9.40353 3.22693 9.52855 3.1019C9.65358 2.97688 9.82315 2.90664 9.99996 2.90664ZM1.33329 8.23997V13.5733C1.33329 13.9269 1.47377 14.2661 1.72382 14.5161C1.97387 14.7662 2.313 14.9066 2.66663 14.9066H13.3333C13.6869 14.9066 14.0261 14.7662 14.2761 14.5161C14.5262 14.2661 14.6666 13.9269 14.6666 13.5733V8.23997H8.66663V13.5733H7.33329V8.23997H1.33329Z" fill="#FE5C5C"/>
                                </svg>
                                @endif

                            </div>
                        </div>
                        <div class="max-w-[200px]">
                            <div style="font-weight: 600;" class="text-[16px] text-dark-primary  flex items-center h-5 truncate">
                                {{$detailClaim->title}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-dark-primary  flex items-center h-5">
                                End date {{ readableDaysLeft($detailClaim->end_date) }}
                            </div>
                        </div>
                    </div>
                    <div class="flex border   rounded-full max-w-[100px] px-2 py-1 truncate">
                        <div class="mr-1 w-5 h-5 flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M10.0042 18.3359C5.40166 18.3359 1.67083 14.605 1.67083 10.0025C1.67083 5.40002 5.40166 1.66919 10.0042 1.66919C14.6067 1.66919 18.3375 5.40002 18.3375 10.0025C18.3375 14.605 14.6067 18.3359 10.0042 18.3359ZM10.0042 6.46669L6.46833 10.0025L10.0042 13.5384L13.5392 10.0025L10.0042 6.46669Z" fill="#FFA858"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M10.0041 5.28811L14.7174 10.0025L10.0041 14.7169L5.28973 10.0025L10.0041 5.28811ZM2.50407 10.0025C2.50407 14.1448 5.86181 17.5025 10.0041 17.5025C14.1463 17.5025 17.5041 14.1448 17.5041 10.0025C17.5041 5.86026 14.1463 2.50252 10.0041 2.50252C5.86181 2.50252 2.50407 5.86026 2.50407 10.0025ZM6.46824 10.0025L10.0041 6.46669L13.5391 10.0025L10.0041 13.5384L6.46824 10.0025ZM1.67074 10.0025C1.67074 14.605 5.40157 18.3359 10.0041 18.3359C14.6066 18.3359 18.3374 14.605 18.3374 10.0025C18.3374 5.40002 14.6066 1.66919 10.0041 1.66919C5.40157 1.66919 1.67074 5.40002 1.67074 10.0025Z" fill="#DF812B"/>
                            </svg>
                        </div>
                        <div style="font-weight: 400;" class="h-5 text-[14px] text-dark-primary  flex items-center justify-center">
                            {{$detailClaim->exchange_rate}} pts
                        </div>
                    </div>
                </div>

                <div class="flex rounded-b-sm p-3 w-full mt-10 justify-between items-center">
                    <div @click="exchangeConfirm=false" style="font-weight: 600;" class="text-primary border rounded-sm    no-select cursor-pointer flex items-center justify-center text-[16px] w-6/12 h-[46px]">
                        Cancel
                    </div>
                    <div wire:click="savePoint()" @click="loading=true" style="font-weight: 600;" class="w-6/12 h-[46px] text-[16px] text-white no-select cursor-pointer flex bg-primary ml-3 items-center justify-center rounded-sm">
                        Yes
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>
</div>
