<div class="w-screen h-screen bg-[#E8EAED] flex justify-center items-center" x-data="{
    openProfile:true,
    openForm:false,
    openSubmitConfirm:false,
    openLogoutConfirm:false,
    openAddress:false,
    openActionPopUp:false,
    openDeleteConfirm:false,
    openHelpDesk:false,
    changePassword:false,
    openChangePasswordConfirm:false,
    openChangeProfileConfirm:false,
    editProfile:false,
    openHistory:false,
    loading: false,
    allPointHistory:true,
    allPointHistoryPlus:false,
    allPointHistoryMinus:false,
    fromClaim:{{ $from_claim ? $from_claim : 'false' }},
    changeAddress:{{ $change_address ? $change_address : 'false' }},
    historyFromClaim: {{ $history_from_claim ? $history_from_claim : 'false' }},
    }"
    x-init="
        if(fromClaim){
            openProfile=false,
            openForm=true,
            scrollToTop();
        }
        if(changeAddress){
            openProfile=false,
            openAddress=true,
            scrollToTop();
        }
        if(historyFromClaim){
            openProfile=false,
            openHistory=true,
            scrollToTop();
        }
        $wire.on('showAddressLists', value => {
            openAddress = value;
            openProfile = !value;
            openDeleteConfirm=false;
            loading = false;
            scrollToTop();
        });
        $wire.on('showActionsPopUp', value => {
            openActionPopUp=true;
        });
        $wire.on('openPointHistories', value => {
            openHistory=true;
        });
        $wire.on('openPointHistoriesPlus', value => {
            allPointHistoryPlus=value;
            allPointHistory=!value;
            allPointHistoryMinus=!value;
        });
        $wire.on('openPointHistoriesMinus', value => {
            allPointHistoryPlus=!value;
            allPointHistory=!value;
            allPointHistoryMinus=value;
        });
        $wire.on('closeLoader', value => {
            loading=false;
        });
        $wire.on('showForm', value => {
            openForm=value;
            openSubmitConfirm=false;
            openAddress=!value;
            openActionPopUp=false;
            loading=false;
            scrollToTop();
        });

    " x-ref="scrollContainer">

    <div x-show="loading">
        <x-layouts.loading/>
    </div>

    <div x-cloak x-show="openProfile" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar relative">
            <div class="absolute">
                <img src="{{ asset('src/images/bg-profile.png') }}" alt="">
            </div>
            <div class="relative">
                <div class="py-9 px-8">
                    <div style="line-height: 30px;font-weight:600;" class="text-[36px] text-white flex justify-between items-end no-select">
                        <div class="flex items-center gap-3">
                            <div class="w-[68px] h-[68px] bg-white rounded-full flex items-center justify-center">
                                <img class="w-full rounded-full" src="@if($image_path) {{ asset('storage/' . $image_path) }} @else {{ asset('src/images/profile.png') }} @endif" alt="">
                            </div>
                            <div class="flex flex-col max-w-[110px] md:max-w-[180px] lg:max-w-[220px]">
                                <div style="line-height: 24px" class="font-bold text-[20px] text-white truncate">
                                    {{ auth()->user()->name }}
                                </div>
                                <div class="text-[12px] font-normal text-white truncate" style="line-height: 20px">
                                    {{ auth()->user()->email }}
                                </div>
                                <div class="text-[12px] font-normal text-white truncate" style="line-height: 20px">
                                    {{ auth()->user()->phone_number }}
                                </div>
                            </div>
                        </div>
                        <div style="line-height: 20px" @click="editProfile=true;openProfile=false" class="flex items-center cursor-pointer no-select justify-center text-white text-[14px] font-bold px-3 py-2 rounded-full bg-[#27364B]">
                            Edit
                        </div>
                    </div>
                </div>

                <div class="w-full mt-0 no-select bg-white py-8 px-8 rounded-t-3xl">
                    <div class="text-[16px] font-semibold mb-5">
                        Profil
                    </div>
                    <div wire:click="openAddressLists" @click="loading=true" class="flex justify-between items-center pb-3 border-b cursor-pointer">
                        <div class="flex gap-2 items-center">
                            <div>
                                <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect width="44" height="44" rx="22" fill="#F6F8FC"/>
                                    <g clip-path="url(#clip0_63_19296)">
                                    <path d="M30.62 18.45C29.57 13.83 25.54 11.75 22 11.75C22 11.75 22 11.75 21.99 11.75C18.46 11.75 14.42 13.82 13.37 18.44C12.2 23.6 15.36 27.97 18.22 30.72C19.28 31.74 20.64 32.25 22 32.25C23.36 32.25 24.72 31.74 25.77 30.72C28.63 27.97 31.79 23.61 30.62 18.45ZM22 23.46C20.26 23.46 18.85 22.05 18.85 20.31C18.85 18.57 20.26 17.16 22 17.16C23.74 17.16 25.15 18.57 25.15 20.31C25.15 22.05 23.74 23.46 22 23.46Z" fill="#27364B"/>
                                    </g>
                                    <defs>
                                    <clipPath id="clip0_63_19296">
                                    <rect width="24" height="24" fill="white" transform="translate(10 10)"/>
                                    </clipPath>
                                    </defs>
                                </svg>
                            </div>
                            <div style="line-height:20px;" class="flex flex-col gap-1">
                                <div style="font-weight:600" class="text-[14px]">
                                    Address
                                </div>
                                <div style="font-weight:400" class="text-[12px]">
                                    List of your address
                                </div>
                            </div>
                        </div>
                        <div>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.786 12L7.82815 6.04688C7.38752 5.60625 7.38752 4.89375 7.82815 4.45781C8.26877 4.02188 8.98127 4.02188 9.4219 4.45781L16.1719 11.2031C16.5985 11.6297 16.6078 12.3141 16.2047 12.7547L9.42659 19.5469C9.20627 19.7672 8.91565 19.875 8.62971 19.875C8.34377 19.875 8.05315 19.7672 7.83284 19.5469C7.39221 19.1062 7.39221 18.3938 7.83284 17.9578L13.786 12Z" fill="#1F2D3D"/>
                            </svg>
                        </div>
                    </div>
                    <div wire:click="openPointHistories" @click="loading=true;openProfile=false" class="flex justify-between items-center pb-3 border-b mt-3 cursor-pointer ">
                        <div class="flex gap-2 items-center">
                            <div>
                                <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect width="44" height="44" rx="22" fill="#F6F8FC"/>
                                    <path d="M26.19 12H17.81C14.17 12 12 14.17 12 17.81V26.18C12 29.83 14.17 32 17.81 32H26.18C29.82 32 31.99 29.83 31.99 26.19V17.81C32 14.17 29.83 12 26.19 12ZM25.75 25.75H18.25C17.84 25.75 17.5 25.41 17.5 25C17.5 24.59 17.84 24.25 18.25 24.25H25.75C26.16 24.25 26.5 24.59 26.5 25C26.5 25.41 26.16 25.75 25.75 25.75ZM25.75 19.75H18.25C17.84 19.75 17.5 19.41 17.5 19C17.5 18.59 17.84 18.25 18.25 18.25H25.75C26.16 18.25 26.5 18.59 26.5 19C26.5 19.41 26.16 19.75 25.75 19.75Z" fill="#27364B"/>
                                </svg>
                            </div>
                            <div style="line-height:20px;" class="flex flex-col gap-1">
                                <div style="font-weight:600" class="text-[14px]">
                                    Claim history
                                </div>
                                <div style="font-weight:400" class="text-[12px]">
                                    Check your claim history
                                </div>
                            </div>
                        </div>
                        <div>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.786 12L7.82815 6.04688C7.38752 5.60625 7.38752 4.89375 7.82815 4.45781C8.26877 4.02188 8.98127 4.02188 9.4219 4.45781L16.1719 11.2031C16.5985 11.6297 16.6078 12.3141 16.2047 12.7547L9.42659 19.5469C9.20627 19.7672 8.91565 19.875 8.62971 19.875C8.34377 19.875 8.05315 19.7672 7.83284 19.5469C7.39221 19.1062 7.39221 18.3938 7.83284 17.9578L13.786 12Z" fill="#1F2D3D"/>
                            </svg>
                        </div>
                    </div>
                    <div @click="changePassword=true;openProfile=false" class="flex justify-between items-center pb-3 border-b mt-3 cursor-pointer ">
                        <div class="flex gap-2 items-center">
                            <div>
                                <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect width="44" height="44" rx="22" fill="#F6F8FC"/>
                                    <path d="M28.75 18V20.1C28.31 20.04 27.81 20.01 27.25 20V18C27.25 14.85 26.36 12.75 22 12.75C17.64 12.75 16.75 14.85 16.75 18V20C16.19 20.01 15.69 20.04 15.25 20.1V18C15.25 15.1 15.95 11.25 22 11.25C28.05 11.25 28.75 15.1 28.75 18Z" fill="#27364B"/>
                                    <path d="M28.75 20.1C28.31 20.04 27.81 20.01 27.25 20H16.75C16.19 20.01 15.69 20.04 15.25 20.1C12.7 20.41 12 21.66 12 25V27C12 31 13 32 17 32H27C31 32 32 31 32 27V25C32 21.66 31.3 20.41 28.75 20.1ZM18.71 26.71C18.52 26.89 18.26 27 18 27C17.87 27 17.74 26.97 17.62 26.92C17.49 26.87 17.39 26.8 17.29 26.71C17.11 26.52 17 26.26 17 26C17 25.87 17.03 25.74 17.08 25.62C17.13 25.5 17.2 25.39 17.29 25.29C17.39 25.2 17.49 25.13 17.62 25.08C17.99 24.92 18.43 25.01 18.71 25.29C18.8 25.39 18.87 25.5 18.92 25.62C18.97 25.74 19 25.87 19 26C19 26.26 18.89 26.52 18.71 26.71ZM22.92 26.38C22.87 26.5 22.8 26.61 22.71 26.71C22.52 26.89 22.26 27 22 27C21.73 27 21.48 26.89 21.29 26.71C21.2 26.61 21.13 26.5 21.08 26.38C21.03 26.26 21 26.13 21 26C21 25.73 21.11 25.48 21.29 25.29C21.66 24.92 22.33 24.92 22.71 25.29C22.89 25.48 23 25.73 23 26C23 26.13 22.97 26.26 22.92 26.38ZM26.71 26.71C26.52 26.89 26.26 27 26 27C25.74 27 25.48 26.89 25.29 26.71C25.11 26.52 25 26.27 25 26C25 25.73 25.11 25.48 25.29 25.29C25.67 24.92 26.34 24.92 26.71 25.29C26.75 25.34 26.79 25.39 26.83 25.45C26.87 25.5 26.9 25.56 26.92 25.62C26.95 25.68 26.97 25.74 26.98 25.8C26.99 25.87 27 25.94 27 26C27 26.26 26.89 26.52 26.71 26.71Z" fill="#27364B"/>
                                </svg>
                            </div>
                            <div style="line-height:20px;" class="flex flex-col gap-1">
                                <div style="font-weight:600" class="text-[14px]">
                                    Change Password
                                </div>
                                <div style="font-weight:400" class="text-[12px]">
                                    Want to change password? Click here
                                </div>
                            </div>
                        </div>
                        <div>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.786 12L7.82815 6.04688C7.38752 5.60625 7.38752 4.89375 7.82815 4.45781C8.26877 4.02188 8.98127 4.02188 9.4219 4.45781L16.1719 11.2031C16.5985 11.6297 16.6078 12.3141 16.2047 12.7547L9.42659 19.5469C9.20627 19.7672 8.91565 19.875 8.62971 19.875C8.34377 19.875 8.05315 19.7672 7.83284 19.5469C7.39221 19.1062 7.39221 18.3938 7.83284 17.9578L13.786 12Z" fill="#1F2D3D"/>
                            </svg>
                        </div>
                    </div>
                    <div @click="openHelpDesk=true;openProfile=false" class="flex justify-between items-center pb-3 border-b mt-3 cursor-pointer ">
                        <div class="flex gap-2 items-center">
                            <div>
                                <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect width="44" height="44" rx="22" fill="#F6F8FC"/>
                                    <path d="M27 12.43H17C14 12.43 12 14.43 12 17.43V23.43C12 26.43 14 28.43 17 28.43V30.56C17 31.36 17.89 31.84 18.55 31.39L23 28.43H27C30 28.43 32 26.43 32 23.43V17.43C32 14.43 30 12.43 27 12.43ZM22 24.6C21.58 24.6 21.25 24.26 21.25 23.85C21.25 23.44 21.58 23.1 22 23.1C22.42 23.1 22.75 23.44 22.75 23.85C22.75 24.26 22.42 24.6 22 24.6ZM23.26 20.45C22.87 20.71 22.75 20.88 22.75 21.16V21.37C22.75 21.78 22.41 22.12 22 22.12C21.59 22.12 21.25 21.78 21.25 21.37V21.16C21.25 20 22.1 19.43 22.42 19.21C22.79 18.96 22.91 18.79 22.91 18.53C22.91 18.03 22.5 17.62 22 17.62C21.5 17.62 21.09 18.03 21.09 18.53C21.09 18.94 20.75 19.28 20.34 19.28C19.93 19.28 19.59 18.94 19.59 18.53C19.59 17.2 20.67 16.12 22 16.12C23.33 16.12 24.41 17.2 24.41 18.53C24.41 19.67 23.57 20.24 23.26 20.45Z" fill="#27364B"/>
                                </svg>
                            </div>
                            <div style="line-height:20px;" class="flex flex-col gap-1">
                                <div style="font-weight:600" class="text-[14px]">
                                    Help desk
                                </div>
                                <div style="font-weight:400" class="text-[12px]">
                                    Need help? Contact us via this menu!
                                </div>
                            </div>
                        </div>
                        <div>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.786 12L7.82815 6.04688C7.38752 5.60625 7.38752 4.89375 7.82815 4.45781C8.26877 4.02188 8.98127 4.02188 9.4219 4.45781L16.1719 11.2031C16.5985 11.6297 16.6078 12.3141 16.2047 12.7547L9.42659 19.5469C9.20627 19.7672 8.91565 19.875 8.62971 19.875C8.34377 19.875 8.05315 19.7672 7.83284 19.5469C7.39221 19.1062 7.39221 18.3938 7.83284 17.9578L13.786 12Z" fill="#1F2D3D"/>
                            </svg>
                        </div>
                    </div>
                    <div @click="openLogoutConfirm=true" class="flex justify-between items-center pb-3 border-b mt-3 cursor-pointer ">
                        <div class="flex gap-2 items-center">
                            <div>
                                <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect width="44" height="44" rx="22" fill="#F6F8FC"/>
                                    <path d="M17.88 22.07C17.88 21.66 18.22 21.32 18.63 21.32H24.11V12.86C24.1 12.38 23.72 12 23.24 12C17.35 12 13.24 16.11 13.24 22C13.24 27.89 17.35 32 23.24 32C23.71 32 24.1 31.62 24.1 31.14V22.81H18.63C18.21 22.82 17.88 22.48 17.88 22.07Z" fill="#27364B"/>
                                    <path d="M30.54 21.54L27.7 18.69C27.41 18.4 26.93 18.4 26.64 18.69C26.35 18.98 26.35 19.46 26.64 19.75L28.2 21.31H24.1V22.81H28.19L26.63 24.37C26.34 24.66 26.34 25.14 26.63 25.43C26.78 25.58 26.97 25.65 27.16 25.65C27.35 25.65 27.54 25.58 27.69 25.43L30.53 22.58C30.83 22.3 30.83 21.83 30.54 21.54Z" fill="#27364B"/>
                                </svg>
                            </div>
                            <div style="line-height:20px;" class="flex flex-col gap-1">
                                <div style="font-weight:600" class="text-[14px]">
                                    Logout
                                </div>
                                <div style="font-weight:400" class="text-[12px]">
                                    Want to change account? Click this button to logout
                                </div>
                            </div>
                        </div>
                        <div>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.786 12L7.82815 6.04688C7.38752 5.60625 7.38752 4.89375 7.82815 4.45781C8.26877 4.02188 8.98127 4.02188 9.4219 4.45781L16.1719 11.2031C16.5985 11.6297 16.6078 12.3141 16.2047 12.7547L9.42659 19.5469C9.20627 19.7672 8.91565 19.875 8.62971 19.875C8.34377 19.875 8.05315 19.7672 7.83284 19.5469C7.39221 19.1062 7.39221 18.3938 7.83284 17.9578L13.786 12Z" fill="#1F2D3D"/>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div x-cloak x-show="openHelpDesk" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar relative">
            <div class="relative px-8">
                <div class="py-5 no-select">
                    <div class="relative flex justify-center no-select">
                        <div style="line-height: 26px;font-weight:400;" class="text-[16px]">
                            Help Desk
                        </div>
                        <div @click="openProfile=true;openHelpDesk=false;" class="absolute left-0 top-1 cursor-pointer">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                            </svg>
                        </div>
                    </div>
                    <div class="pt-16 flex flex-col items-center justify-center gap-8">
                        <div>
                            <svg width="250" height="250" viewBox="0 0 250 250" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect x="20" y="20" width="210" height="210" rx="105" fill="#EFB008"/>
                                <path d="M147.917 81.1375H102.083C88.3334 81.1375 79.1667 90.3042 79.1667 104.054V131.554C79.1667 145.304 88.3334 154.471 102.083 154.471V164.233C102.083 167.9 106.163 170.1 109.188 168.038L129.583 154.471H147.917C161.667 154.471 170.833 145.304 170.833 131.554V104.054C170.833 90.3042 161.667 81.1375 147.917 81.1375ZM125 136.917C123.075 136.917 121.563 135.358 121.563 133.479C121.563 131.6 123.075 130.042 125 130.042C126.925 130.042 128.438 131.6 128.438 133.479C128.438 135.358 126.925 136.917 125 136.917ZM130.775 117.896C128.988 119.088 128.438 119.867 128.438 121.15V122.113C128.438 123.992 126.879 125.55 125 125.55C123.121 125.55 121.563 123.992 121.563 122.113V121.15C121.563 115.833 125.458 113.221 126.925 112.213C128.621 111.067 129.171 110.288 129.171 109.096C129.171 106.804 127.292 104.925 125 104.925C122.708 104.925 120.829 106.804 120.829 109.096C120.829 110.975 119.271 112.533 117.392 112.533C115.513 112.533 113.954 110.975 113.954 109.096C113.954 103 118.904 98.05 125 98.05C131.096 98.05 136.046 103 136.046 109.096C136.046 114.321 132.196 116.933 130.775 117.896Z" fill="white"/>
                                <rect x="20" y="20" width="210" height="210" rx="105" stroke="#FFDE81" stroke-width="40"/>
                            </svg>
                        </div>
                        <div style="line-height: 24px" class="text-[16px] font-normal text-[#6A6A75]">
                            Need help? Contact us
                        </div>
                        <div style="line-height: 36px" class="text-[24px] font-bold text-[#976400]">
                            clp.bantuan@gmail.com
                        </div>
                        <a href="https://www.gmail.com" target="_blank">
                            <div style="line-height: 24px" class="border-[#CBD4E1] border rounded-xl px-5 py-4 text-[#27364B] text-[16px] font-bold">
                                Send Email
                            </div>
                        </a>
                    </div>

                </div>


            </div>
        </div>
    </div>

    <div x-cloak x-show="openHistory" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar relative">
            <div class="relative">
                <div class="py-5 bg-white">
                    <div class="relative flex justify-center no-select px-8">
                        <div style="line-height: 26px;font-weight:400;" class="text-[16px] mb-2">
                            History
                        </div>
                        <div @if($history_from_claim) onclick="redirectTo('{{route('claim')}}')" @else @click="openProfile=true;openHistory=false;" @endif class="absolute left-5 top-1 cursor-pointer">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                            </svg>
                        </div>
                    </div>
                    <div class="absolute left-0">
                        <img src="{{ asset('src/images/bg-profile.png') }}" alt="">
                    </div>
                    <div class="relative mt-[50px]">
                        <div class="w-full px-10">
                            <a href="{{ route('claim') }}">
                                <div style=" background: linear-gradient(to right, #FFFFFF, #FFF5D5);" class="p-3 rounded-lg">
                                    <div style="line-height: 14.52px" class="text-[#64748B] text-[12px] font-bold">
                                        Total point
                                    </div>
                                    <div class="flex items-center gap-1 mt-3">
                                        <div>
                                            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <g clip-path="url(#clip0_30_18905)">
                                                <path d="M31.9559 17.1998H26.2402C21.2475 17.1998 17.2002 21.2472 17.2002 26.2398V31.9555C25.0801 31.3712 31.3716 25.0797 31.9559 17.1998Z" fill="#EFB008"/>
                                                <path d="M14.8003 31.9555V26.2398C14.8003 21.2472 10.7529 17.1998 5.76023 17.1998H0.0445557C0.628823 25.0797 6.92031 31.3712 14.8003 31.9555Z" fill="#EFB008"/>
                                                <path d="M31.9559 14.7999C31.3716 6.91994 25.0801 0.628457 17.2002 0.0441895V5.75986C17.2002 10.7525 21.2475 14.7999 26.2402 14.7999H31.9559Z" fill="#EFB008"/>
                                                <path d="M14.8003 0.0441895C6.92031 0.628457 0.628823 6.91994 0.0445557 14.7999H5.76023C10.7529 14.7999 14.8003 10.7525 14.8003 5.75986V0.0441895Z" fill="#EFB008"/>
                                                <path d="M10.8665 15.9998C13.0845 14.8916 14.8921 13.084 16.0002 10.866C17.1085 13.084 18.916 14.8916 21.1341 15.9998C18.916 17.108 17.1085 18.9156 16.0002 21.1336C14.8921 18.9156 13.0845 17.108 10.8665 15.9998Z" fill="#FFDE81"/>
                                                </g>
                                                <defs>
                                                <clipPath id="clip0_30_18905">
                                                <rect width="32" height="32" fill="white"/>
                                                </clipPath>
                                                </defs>
                                            </svg>
                                        </div>
                                        <div style="line-height: 36px" class="text-[24px] text-[#976400] font-bold">
                                            {{ auth()->user()->total_point }}
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="bg-white min-h-screen p-5 mt-[50px] rounded-t-2xl">
                            <div class="flex items-center justify-between lg:gap-3 gap-1">
                                <div style="line-height: 20px;" @click="allPointHistory=true;allPointHistoryPlus=false;allPointHistoryMinus=false" :class="allPointHistory ? 'text-[#D92D20]' : ' font-normal'" class="flex relative h-12 items-center justify-center lg:px-3 px-1 py-1 lg:py-2 text-[12px] lg:text-[16px] cursor-pointer no-select font-bold">
                                    All
                                    <div x-show="allPointHistory" class="h-1 w-[50px] rounded-t-md bg-[#D92D20] absolute bottom-0">

                                    </div>
                                </div>
                                <div style="line-height: 20px;" wire:click="openPointHistoriesPlus" @click="loading=true" :class="allPointHistoryPlus ? 'text-[#D92D20]' : 'font-normal'" class="flex relative h-12 items-center justify-center lg:px-3 px-1 py-1 lg:py-2 text-[12px] lg:text-[16px] cursor-pointer no-select font-bold">
                                    Plus
                                    <div x-show="allPointHistoryPlus" class="h-1 w-[80px] rounded-t-md bg-[#D92D20] absolute bottom-0">

                                    </div>
                                </div>
                                <div style="line-height: 20px;" wire:click="openPointHistoriesMinus" @click="loading=true" :class="allPointHistoryMinus ? 'text-[#D92D20]' : 'font-normal'" class="flex relative h-12 items-center justify-center lg:px-3 px-1 py-1 lg:py-2 text-[12px] lg:text-[16px] cursor-pointer no-select font-bold">
                                    Minus
                                    <div x-show="allPointHistoryMinus" class="h-1 w-[75px] rounded-t-md bg-[#D92D20] absolute bottom-0">

                                    </div>
                                </div>
                            </div>

                            <div x-cloak x-show="allPointHistory">
                                @foreach ($allPointHistories as $index => $pointHistoryAll)
                                <div class="mt-7">
                                    <div style="line-height:16px" class="text-[14px] text-[#64748B] font-bold">
                                        {{ $index }}
                                    </div>
                                    <div class="mt-3 flex flex-col gap-3">
                                        @foreach ($pointHistoryAll as $historyAll)
                                        <div class="border rounded-xl p-5 flex items-center justify-between">
                                            <div>
                                                <div style="line-height: 19px" class="font-semibold text-[12px] max-w-[150px] lg:max-w-[200px] line-clamp-2">
                                                    {{ isset($historyAll->description) ? $historyAll->description : $historyAll['description'] }}
                                                </div>
                                                <div style="line-height: 13px" class="text-[11px] font-normal text-[#6A7481] mt-2">
                                                    {{ changeDateFormat2(isset($historyAll->created_at) ? $historyAll->created_at : $historyAll['created_at']) }}
                                                </div>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <div style="line-height: 19px" class="text-[16px] font-semibold {{ (isset($historyAll->is_income_point) ? $historyAll->is_income_point : $historyAll['is_income_point']) ? 'text-[#00632B]' : 'text-[#B01212]' }}">
                                                    {{ (isset($historyAll->is_income_point) ? $historyAll->is_income_point : $historyAll['is_income_point']) ? '+' : '-' }}{{ isset($historyAll->point) ? $historyAll->point : $historyAll['point'] }}
                                                </div>
                                                <div>
                                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <g clip-path="url(#clip0_30_18936)">
                                                        <path d="M15.9779 8.59998H13.1201C10.6237 8.59998 8.6001 10.6237 8.6001 13.12V15.9778C12.5401 15.6857 15.6858 12.5399 15.9779 8.59998Z" fill="#EFB008"/>
                                                        <path d="M7.40007 15.9778V13.12C7.40007 10.6237 5.37639 8.59998 2.88005 8.59998H0.0222168C0.31435 12.5399 3.46009 15.6857 7.40007 15.9778Z" fill="#EFB008"/>
                                                        <path d="M15.9779 7.39994C15.6858 3.45997 12.5401 0.314228 8.6001 0.0220947V2.87993C8.6001 5.37626 10.6237 7.39994 13.1201 7.39994H15.9779Z" fill="#EFB008"/>
                                                        <path d="M7.40007 0.0220947C3.46009 0.314228 0.31435 3.45997 0.0222168 7.39994H2.88005C5.37639 7.39994 7.40007 5.37626 7.40007 2.87993V0.0220947Z" fill="#EFB008"/>
                                                        <path d="M5.43323 7.9999C6.54223 7.44578 7.44603 6.54198 8.00011 5.43298C8.55423 6.54198 9.45799 7.44578 10.567 7.9999C9.45799 8.55398 8.55423 9.45778 8.00011 10.5668C7.44603 9.45778 6.54223 8.55398 5.43323 7.9999Z" fill="#FFDE81"/>
                                                        </g>
                                                        <defs>
                                                        <clipPath id="clip0_30_18936">
                                                        <rect width="16" height="16" fill="white"/>
                                                        </clipPath>
                                                        </defs>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                                @endforeach
                            </div>
                            <div x-cloak x-show="allPointHistoryPlus">
                                @foreach ($allPointHistoriesPlus as $indexPlus => $pointHistoryPlus)
                                <div class="mt-7">
                                    <div style="line-height:16px" class="text-[14px] text-[#64748B] font-bold">
                                        {{ $indexPlus }}
                                    </div>
                                    <div class="mt-3 flex flex-col gap-3">
                                        @foreach ($pointHistoryPlus as $historyPlus)
                                        <div class="border rounded-xl p-5 flex items-center justify-between">
                                            <div>
                                                <div style="line-height: 19px" class="font-semibold text-[12px] max-w-[150px] lg:max-w-[200px] line-clamp-2">
                                                    {{ isset($historyPlus->description) ? $historyPlus->description : $historyPlus['description'] }}
                                                </div>
                                                <div style="line-height: 13px" class="text-[11px] font-normal text-[#6A7481] mt-2">
                                                    {{ changeDateFormat2(isset($historyPlus->created_at) ? $historyPlus->created_at : $historyPlus['created_at']) }}
                                                </div>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <div style="line-height: 19px" class="text-[16px] font-semibold {{ (isset($historyPlus->is_income_point) ? $historyPlus->is_income_point : $historyPlus['is_income_point']) ? 'text-[#00632B]' : 'text-[#B01212]' }}">
                                                    {{ (isset($historyPlus->is_income_point) ? $historyPlus->is_income_point : $historyPlus['is_income_point']) ? '+' : '-' }}{{ isset($historyPlus->point) ? $historyPlus->point : $historyPlus['point'] }}
                                                </div>
                                                <div>
                                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <g clip-path="url(#clip0_30_18936)">
                                                        <path d="M15.9779 8.59998H13.1201C10.6237 8.59998 8.6001 10.6237 8.6001 13.12V15.9778C12.5401 15.6857 15.6858 12.5399 15.9779 8.59998Z" fill="#EFB008"/>
                                                        <path d="M7.40007 15.9778V13.12C7.40007 10.6237 5.37639 8.59998 2.88005 8.59998H0.0222168C0.31435 12.5399 3.46009 15.6857 7.40007 15.9778Z" fill="#EFB008"/>
                                                        <path d="M15.9779 7.39994C15.6858 3.45997 12.5401 0.314228 8.6001 0.0220947V2.87993C8.6001 5.37626 10.6237 7.39994 13.1201 7.39994H15.9779Z" fill="#EFB008"/>
                                                        <path d="M7.40007 0.0220947C3.46009 0.314228 0.31435 3.45997 0.0222168 7.39994H2.88005C5.37639 7.39994 7.40007 5.37626 7.40007 2.87993V0.0220947Z" fill="#EFB008"/>
                                                        <path d="M5.43323 7.9999C6.54223 7.44578 7.44603 6.54198 8.00011 5.43298C8.55423 6.54198 9.45799 7.44578 10.567 7.9999C9.45799 8.55398 8.55423 9.45778 8.00011 10.5668C7.44603 9.45778 6.54223 8.55398 5.43323 7.9999Z" fill="#FFDE81"/>
                                                        </g>
                                                        <defs>
                                                        <clipPath id="clip0_30_18936">
                                                        <rect width="16" height="16" fill="white"/>
                                                        </clipPath>
                                                        </defs>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                                @endforeach
                            </div>
                            <div x-cloak x-show="allPointHistoryMinus">
                                @foreach ($allPointHistoriesMinus as $indexMinus => $pointHistoryMinus)
                                <div class="mt-7">
                                    <div style="line-height:16px" class="text-[14px] text-[#64748B] font-bold">
                                        {{ $indexMinus }}
                                    </div>
                                    <div class="mt-3 flex flex-col gap-3">
                                        @foreach ($pointHistoryMinus as $historyMinus)
                                        <div class="border rounded-xl p-5 flex items-center justify-between">
                                            <div>
                                                <div style="line-height: 19px" class="font-semibold text-[12px] max-w-[150px] lg:max-w-[200px] line-clamp-2">
                                                    {{ isset($historyMinus->description) ? $historyMinus->description : $historyMinus['description'] }}
                                                </div>
                                                <div style="line-height: 13px" class="text-[11px] font-normal text-[#6A7481] mt-2">
                                                    {{ changeDateFormat2(isset($historyMinus->created_at) ? $historyMinus->created_at : $historyMinus['created_at']) }}
                                                </div>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <div style="line-height: 19px" class="text-[16px] font-semibold {{ (isset($historyMinus->is_income_point) ? $historyMinus->is_income_point : $historyMinus['is_income_point']) ? 'text-[#00632B]' : 'text-[#B01212]' }}">
                                                    {{ (isset($historyMinus->is_income_point) ? $historyMinus->is_income_point : $historyMinus['is_income_point']) ? '+' : '-' }}{{ isset($historyMinus->point) ? $historyMinus->point : $historyMinus['point'] }}
                                                </div>
                                                <div>
                                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <g clip-path="url(#clip0_30_18936)">
                                                        <path d="M15.9779 8.59998H13.1201C10.6237 8.59998 8.6001 10.6237 8.6001 13.12V15.9778C12.5401 15.6857 15.6858 12.5399 15.9779 8.59998Z" fill="#EFB008"/>
                                                        <path d="M7.40007 15.9778V13.12C7.40007 10.6237 5.37639 8.59998 2.88005 8.59998H0.0222168C0.31435 12.5399 3.46009 15.6857 7.40007 15.9778Z" fill="#EFB008"/>
                                                        <path d="M15.9779 7.39994C15.6858 3.45997 12.5401 0.314228 8.6001 0.0220947V2.87993C8.6001 5.37626 10.6237 7.39994 13.1201 7.39994H15.9779Z" fill="#EFB008"/>
                                                        <path d="M7.40007 0.0220947C3.46009 0.314228 0.31435 3.45997 0.0222168 7.39994H2.88005C5.37639 7.39994 7.40007 5.37626 7.40007 2.87993V0.0220947Z" fill="#EFB008"/>
                                                        <path d="M5.43323 7.9999C6.54223 7.44578 7.44603 6.54198 8.00011 5.43298C8.55423 6.54198 9.45799 7.44578 10.567 7.9999C9.45799 8.55398 8.55423 9.45778 8.00011 10.5668C7.44603 9.45778 6.54223 8.55398 5.43323 7.9999Z" fill="#FFDE81"/>
                                                        </g>
                                                        <defs>
                                                        <clipPath id="clip0_30_18936">
                                                        <rect width="16" height="16" fill="white"/>
                                                        </clipPath>
                                                        </defs>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>

    <div x-cloak x-show="changePassword" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        <div class="flex-1 overflow-y-auto hide-scrollbar relative">
            <div class="relative px-8">
                <div class="py-5 min-h-screen relative">
                    <div class="relative flex justify-center no-select">
                        <div style="line-height: 26px;font-weight:400;" class="text-[16px]">
                            Change Password
                        </div>
                        <div @click="openProfile=true;changePassword=false;" class="absolute left-0 top-1 cursor-pointer">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                            </svg>
                        </div>
                    </div>
                    <div style="line-height: 24px"  @click="openChangePasswordConfirm=true" class="absolute cursor-pointer no-select bottom-5 text-[16px]  text-[#757575] rounded-xl py-4 flex items-center justify-center w-full bg-[#F6F8FC] font-bold">
                        Edit Password
                    </div>
                    <div class="mt-10">
                        <div class="flex flex-col gap-3">
                            <div class="text-[#64748B] font-normal text-[14px]">
                               Insert your old password
                            </div>
                            <div class="relative">
                                <input type="password" wire:model.lazy="oldPassword" class="h-[56px] w-full rounded-xl" placeholder="Old pasword" id="">
                                @if(isset($errorMessages['oldPassword']))
                                <div class="absolute text-[12px] ml-3 text-red-500">
                                    {{ $errorMessages['oldPassword'][0] }}
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="mt-10">
                        <div class="flex flex-col gap-3">
                            <div class="text-[#64748B] font-normal text-[14px]">
                                Insert your new password
                            </div>
                            <div class="relative">
                                <input type="password" wire:model.lazy="password" class="h-[56px] w-full rounded-xl" placeholder="New password" id="">
                            </div>
                            <div class="relative">
                                <input type="password" wire:model.lazy="passwordConfirmation" class="h-[56px] w-full rounded-xl" placeholder="Password confirmation" id="">
                                @if(isset($errorMessages['password']))
                                <div class="absolute text-[12px] ml-3 text-red-500">
                                    {{ $errorMessages['password'][0] }}
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                    {{-- <div class="flex justify-center items-center mt-8">
                        <div class="w-full relative">
                            <div class="ml-2 bg-[#FF9B14] h-[150px] rounded-lg">
                                <div class="ml-2 bg-white rounded-lg h-full shadow-lg flex justify-between items-end">
                                    <div class="p-6 flex flex-col justify-between h-full max-w-[150px]">
                                        <div style="font-weight: 400; line-height:16px" class="text-[12px] text-[#6A6A75]">
                                            Password kamu sekarang
                                        </div>
                                        <div style="font-weight: 700;line-height:16px" class="text-[16px] text-[#DA0814]">
                                            ***********{{ auth()->user()->last_digit_password }}
                                        </div>
                                        <a href="https://www.gmail.com" target="_blank">
                                            <div class="px-2 py-1 bg-[#FEF3F2] flex items-center gap-1 w-fit rounded-lg">
                                                <div style="font-weight: 600;line-height:20px" class="text-[#D92D20] text-[8px]">
                                                    @if(auth()->user()->last_change_password )
                                                    <div class="px-2 py-1 bg-[#FEF3F2] flex items-center gap-1 w-fit rounded-lg">
                                                        <div style="font-weight: 600;line-height:20px" class="text-[#D92D20] text-[8px]">
                                                            Diganti {{ auth()->user()->last_change_password ? changeLastChangePassword(auth()->user()->last_change_password) : "" }}
                                                        </div>
                                                    </div>
                                                    @endif
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div>
                                        <img src="{{ asset('src/images/change-password.png') }}" style="width: 110px;height:110px" class=" rounded-br-lg" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="relative mt-8 px-2">
                        <div class="relative">
                            <div style="font-weight: 300; line-height:20px" class="text-[#6A6A75] text-[14px] mb-1">
                                Pasword Baru
                            </div>
                            <div>
                                <input wire:model.lazy="password" placeholder="Ketik password baru kamu di sini" style="font-weight: 400;font-style: italic;line-height:20px" class="w-full outline-slate-500 border-b-slate-600 rounded-lg outline-gray text-[12px]" type="password">
                            </div>
                            @if(isset($errorMessages['password']))
                            <div class="absolute text-[12px] ml-3 text-red-500">
                                {{ $errorMessages['password'][0] }}
                            </div>
                            @endif
                        </div>
                        <div class="mt-5">
                            <div style="font-weight: 300; line-height:20px" class="text-[#6A6A75] text-[14px] mb-1">
                                Konfirmasi Pasword Baru
                            </div>
                            <div>
                                <input wire:model.lazy="passwordConfirmation" placeholder="Ketik ulang password baru kamu di sini" style="font-weight: 400;font-style: italic;line-height:20px" class="w-full outline-slate-500 border-b-slate-600 rounded-lg outline-gray text-[12px]" type="password">
                            </div>
                        </div>
                        <div @click="openChangePasswordConfirm=true" style="font-weight: 700;line-height:24px" class="flex mt-5 justify-center py-3 bg-[#DA0713] rounded-full w-full text-white text-[16px] no-select cursor-pointer">
                            Update Password
                        </div>
                    </div> --}}
                </div>
            </div>
        </div>
    </div>

    <div x-cloak x-show="openChangePasswordConfirm" style="z-index: 80" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        <div @click.outside="openChangePasswordConfirm=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5">
                <div class="w-full flex justify-end items-center mb-[18px]">
                    <div @click="openChangePasswordConfirm=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
                <div class="mt-5 text-center">
                    <div style="font-weight: 600;" class="mb-[2px] text-[16px] text-dark-primary ">
                        Confirm your password
                    </div>
                    <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] ">
                        Are you sure want to change your password?
                    </div>
                </div>
            </div>
            <div class="p-5 flex w-full">
                <div @click="openChangePasswordConfirm=false" style="font-weight: 600;" class="h-[44px] mr-3 w-6/12 flex items-center justify-center text-[16px] text-[#6A6A75]  cursor-pointer">
                    Cancel
                </div>
                <div style="font-weight: 600;" wire:click="changePassword" @click="loading=true;openChangePasswordConfirm=false" class="h-[44px] w-6/12 text-[16px] flex items-center cursor-pointer justify-center rounded-sm text-[#FE5C5C] border border-[#D6DADF]">
                    Yes
                </div>
            </div>
        </div>
    </div>

    <div x-cloak x-show="editProfile" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar relative">
            <div class="relative">
                <div class="py-5 relative">
                    <div class="relative flex justify-center items-center no-select px-8">
                        <div style="line-height: 26px;font-weight:400;" class="text-[16px] mb-2">
                            Edit Profile
                        </div>
                        <div @click="openProfile=true;editProfile=false;" class="absolute left-5 top-1 cursor-pointer">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                            </svg>
                        </div>
                    </div>
                    <div class="absolute">
                        <img src="{{ asset('src/images/bg-profile.png') }}" alt="">
                    </div>
                    <div class="relative">
                        <div class="w-full mt-[150px]">
                            <div class="relative bg-white rounded-t-3xl p-8">
                                <div class="absolute flex justify-center items-center w-full" style="top: -10%;left:0">
                                    <div class="w-[120px] h-[120px] relative flex items-center justify-center bg-white rounded-full shadow-lg">
                                        @if($image_path)
                                        <img src="{{ substr($image_path, 0, 4) != "data" ?  asset('storage/'.$image_path) : $image_path }}" class="rounded-full" alt="">
                                        @else
                                        <img src="{{ asset('src/images/profile.png') }}" class="rounded-full" alt="">
                                        @endif
                                        <input type="file" id="image_path" wire:model="image_path" class="hidden">
                                        <input type="file" id="showProfileImage" class="hidden image" accept="image/png, image/jpeg">
                                        <div class="">
                                            <label for="showProfileImage" class="rounded-full bg-transparent shadow-xl absolute top-0 left-0 w-full h-full flex items-center justify-center -right-2 bottom-1 cursor-pointer">

                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div style="line-height: 27px;font-weight:700" class="text-[15px] text-[#64748B] mt-12">
                                    Personal Info
                                </div>
                                <div class="relative border-x-2 border-2 pt-5 rounded-xl mt-5">
                                    <div class="form-group">
                                        <input type="text" id="name" style="font-weight: 400;" wire:model.lazy="name" class="w-full h-11 p-3 text-[16px] rounded-b-lg" required>
                                        <label for="name" style="font-weight: 400;" class="w-full h-7 p-1 flex items-center text-[#6A6A75] text-[14px]">Name</label>
                                    </div>
                                    @if(isset($errorMessages['name']))
                                    <div class="absolute text-[12px] ml-3 text-red-500">
                                        {{ $errorMessages['name'][0] }}
                                    </div>
                                    @endif
                                </div>
                                <div class="relative border-x-2 border-2 pt-5 rounded-xl mt-5">
                                    <div class="form-group">
                                        <div class="flex items-center">
                                            <input type="text" id="name" style="font-weight: 400;width:40px" wire:model.lazy="day" wire:change="checkDay" class="h-11 p-3 text-[16px] rounded-b-lg" required maxlength="2">/
                                            <input type="text" id="name" style="font-weight: 400;width:40px" wire:model.lazy="month" wire:change="checkMonth" class="h-11 p-3 text-[16px] rounded-b-lg" required maxlength="2">/
                                            <input type="text" id="name" style="font-weight: 400;width:80px" wire:model.lazy="year" wire:change="checkYear" class="h-11 p-3 text-[16px] rounded-b-lg" required maxlength="4">
                                        </div>
                                        <label style="font-weight: 400;color: #9AA0A6;top:10px;font-size: 12px;transform: translateY(-100%) scale(0.8);color: #333;" class="w-full h-7 p-1 flex items-center text-[#6A6A75] text-[14px]">Birth Date</label>
                                    </div>
                                    @if(isset($errorMessages['day']))
                                    <div class="absolute text-[12px] ml-3 text-red-500">
                                        {{ $errorMessages['day'][0] }}
                                    </div>
                                    @elseif(isset($errorMessages['month']))
                                    <div class="absolute text-[12px] ml-3 text-red-500">
                                        {{ $errorMessages['month'][0] }}
                                    </div>
                                    @elseif(isset($errorMessages['year']))
                                    <div class="absolute text-[12px] ml-3 text-red-500">
                                        {{ $errorMessages['year'][0] }}
                                    </div>
                                    @endif
                                </div>
                                <div style="line-height: 27px;font-weight:700" class="text-[15px] text-[#64748B] mt-6">
                                    Contact
                                </div>
                                <div class="relative border-x-2 border-2 pt-5 rounded-xl mt-5">
                                    <div class="form-group">
                                        <input type="email" id="email" style="font-weight: 400;" wire:model.lazy="email" class="w-full h-11 p-3 text-[16px] rounded-b-lg" required>
                                        <label for="email" style="font-weight: 400;" class="w-full h-7 p-1 flex items-center text-[#6A6A75] text-[14px]">Email</label>
                                    </div>
                                    @if(isset($errorMessages['email']))
                                    <div class="absolute text-[12px] ml-3 text-red-500">
                                        {{ $errorMessages['email'][0] }}
                                    </div>
                                    @endif
                                </div>
                                <div class="relative border-x-2 border-2 pt-5 rounded-xl mt-5">
                                    <div class="form-group">
                                        <input type="text" id="phone_number" style="font-weight: 400;" wire:model.lazy="phone_number" class="w-full h-11 p-3 text-[16px] rounded-b-lg" required>
                                        <label for="phone_number" style="font-weight: 400;" class="w-full h-7 p-1 flex items-center text-[#6A6A75] text-[14px]">Phone Number</label>
                                    </div>
                                    @if(isset($errorMessages['phone_number']))
                                    <div class="absolute text-[12px] ml-3 text-red-500">
                                        {{ $errorMessages['phone_number'][0] }}
                                    </div>
                                    @endif
                                </div>
                                <div @click="openChangeProfileConfirm=true" style="font-weight: 700;line-height:24px" class="flex mt-5 justify-center py-3 bg-[#F6F8FC] rounded-xl w-full text-[#757575] text-[16px] no-select cursor-pointer">
                                    Update Profile
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div x-cloak x-show="openChangeProfileConfirm" style="z-index: 80" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        <div @click.outside="openChangeProfileConfirm=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5">
                <div class="w-full flex justify-end items-center mb-[18px]">
                    <div @click="openChangeProfileConfirm=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
                <div class="mt-5 text-center">
                    <div style="font-weight: 600;" class="mb-[2px] text-[16px] text-dark-primary ">
                        Confirm update profile
                    </div>
                    <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] ">
                        Are you sure want to update your profile?
                    </div>
                </div>
            </div>
            <div class="p-5 flex w-full">
                <div @click="openChangeProfileConfirm=false" style="font-weight: 600;" class="h-[44px] mr-3 w-6/12 flex items-center justify-center text-[16px] text-[#6A6A75]  cursor-pointer">
                    Cancel
                </div>
                <div style="font-weight: 600;" wire:click="changeProfile" @click="loading=true;openChangeProfileConfirm=false" class="h-[44px] w-6/12 text-[16px] flex items-center cursor-pointer justify-center rounded-sm text-[#FE5C5C] border border-[#D6DADF]">
                    Yes
                </div>
            </div>
        </div>
    </div>

    <x-layouts.customer.navbar :currentPage="$currentPage" />

    <div x-cloak x-show="openForm" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col max-h-screen overflow-auto hide-scrollbar bg-white  ">
        <div class="flex-none">
            <div class="w-full flex p-5">
                <div @if($from_claim) wire:click="backToClaim" @else wire:click="closeForm" @endif class="flex items-center no-select cursor-pointer">
                    <div class="mr-1">
                        <div class="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21">
                            <path class="fill-primary " d="M8.45306 6.63482C8.65228 6.83014 8.65228 7.15435 8.45697 7.35357L6.08588 9.73248H15.121C15.3984 9.73248 15.6249 9.95904 15.6249 10.2403C15.6249 10.5215 15.3984 10.7481 15.121 10.7481H6.08588L8.46088 13.127C8.65619 13.3262 8.65228 13.6465 8.45697 13.8458C8.25775 14.0411 7.94134 14.0411 7.74213 13.8419L4.52338 10.5997C4.48041 10.5528 4.44525 10.502 4.41791 10.4395C4.39056 10.377 4.37885 10.3106 4.37885 10.2442C4.37885 10.1114 4.42963 9.98639 4.52338 9.88873L7.74213 6.64654C7.93353 6.44342 8.25384 6.43951 8.45306 6.63482Z"/>
                            </svg>
                        </div>
                    </div>
                    <div style="font-weight: 600;" class="text-primary  text-[16px]">
                        Back
                    </div>
                </div>
            </div>
        </div>

        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar" x-ref="scrollContainer">
            <div class="mt-4 px-5 pb-5">
                <div class="w-full">
                    <div style="font-weight: 600;" class="mb-2 text-[20px] text-dark-primary ">
                        Form Address
                    </div>
                    <div style="font-weight: 400;" class="text-[16px] text-[#6A6A75]  ">
                        Fill in the address information for easier and more accurate delivery
                    </div>
                </div>
            </div>

            <div class="px-5">
                <form class="w-full">
                    <div class="w-full flex mb-1">
                        <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]  mr-1">
                            Building Type
                        </div>
                        <div class="text-[#FE5C5C] text-[14px]">
                            *
                        </div>
                    </div>
                    <select wire:model.lazy="building_type_id" class="w-full border cursor-pointer border-[#D6DADF] bg-white   text-dark-primary   rounded-sm p-3">
                        @foreach ($buildingTypes as $type)
                            <option value="{{ $type->id }}" style="font-weight: 400;" class="text-[16px]">
                                {{ $type->name }}
                            </option>
                        @endforeach
                    </select>
                    @error('building_type_id')
                        <p class="relative text-sm text-red-600">{{ $message }}</p>
                    @enderror
                    <div class="w-full flex mb-1 mt-4">
                        <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]  mr-1">
                            Province
                        </div>
                        <div class="text-[#FE5C5C] text-[14px]">
                            *
                        </div>
                    </div>
                    <input type="text" style="font-weight: 400;" wire:model.lazy="province" class="w-full border border-[#D6DADF]  text-dark-primary   bg-white   rounded-sm p-3 text-[16px]" placeholder="Province" />
                    @if(isset($errorMessages['province']))
                        <p class="relative text-sm text-red-600">{{ $errorMessages['province'][0] }}</p>
                    @endif
                    <div class="w-full flex mb-1 mt-4">
                        <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]  mr-1">
                            City / District
                        </div>
                        <div class="text-[#FE5C5C] text-[14px]">
                            *
                        </div>
                    </div>
                    <input type="text" style="font-weight: 400;" wire:model.lazy="city" class="w-full border border-[#D6DADF]  text-dark-primary   bg-white   rounded-sm p-3 text-[16px]" placeholder="City / District" />
                    @if(isset($errorMessages['city']))
                        <p class="relative text-sm text-red-600">{{ $errorMessages['city'][0] }}</p>
                    @endif
                    <div class="w-full flex mb-1 mt-4">
                        <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]  mr-1">
                            Subdistrict
                        </div>
                        <div class="text-[#FE5C5C] text-[14px]">
                            *
                        </div>
                    </div>
                    <input type="text" style="font-weight: 400;" wire:model.lazy="subdistrict" class="w-full border border-[#D6DADF]  text-dark-primary   bg-white   rounded-sm p-3 text-[16px]" placeholder="Subdistrict" />
                    @if(isset($errorMessages['subdistrict']))
                        <p class="relative text-sm text-red-600">{{ $errorMessages['subdistrict'][0] }}</p>
                    @endif
                    <div class="w-full flex mb-1 mt-4">
                        <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]  mr-1">
                            Kelurahan
                        </div>
                        <div class="text-[#FE5C5C] text-[14px]">
                            *
                        </div>
                    </div>
                    <input type="text" style="font-weight: 400;" wire:model.lazy="urban_village" class="w-full border border-[#D6DADF]  text-dark-primary   bg-white   rounded-sm p-3 text-[16px]" placeholder="Kelurahan" />
                    @if(isset($errorMessages['urban_village']))
                        <p class="relative text-sm text-red-600">{{ $errorMessages['urban_village'][0] }}</p>
                    @endif
                    <div class="w-full flex mb-1 mt-4">
                        <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]  mr-1">
                            Detail
                        </div>
                        <div class="text-[#FE5C5C] text-[14px]">
                            *
                        </div>
                    </div>
                    <input type="text" style="font-weight: 400;" wire:model.lazy="detail" class="w-full border border-[#D6DADF]  text-dark-primary   bg-white   rounded-sm p-3 text-[16px]" placeholder="Detail" />
                    @if(isset($errorMessages['detail']))
                        <p class="relative text-sm text-red-600">{{ $errorMessages['detail'][0] }}</p>
                    @endif
                    <div class="w-full flex mb-1 mt-4">
                        <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]  mr-1">
                            Postal code
                        </div>
                        <div class="text-[#FE5C5C] text-[14px]">
                            *
                        </div>
                    </div>
                    <input type="text" style="font-weight: 400;" wire:model.lazy="postal_code" class="w-full border border-[#D6DADF]  text-dark-primary   bg-white   rounded-sm p-3 text-[16px]" placeholder="Postal Code" />
                    @if(isset($errorMessages['postal_code']))
                        <p class="relative text-sm text-red-600">{{ $errorMessages['postal_code'][0] }}</p>
                    @endif
                    <div class="w-full mt-4 flex justify-between p-3 bg-[#F5F7F9] ">
                        <div stle="font-weight: 400;" class="text-[16px] text-[#6A6A75] ">
                            Make it the Primary Address?
                        </div>
                        <input type="checkbox" checked wire:model.lazy="is_primary" class="hidden" id="input-primary" />
                        <label id="is-primary-toggle" for="input-primary">
                            <div id="background-toggle-primary" class="flex h-5 w-9 cursor-pointer items-center rounded-full p-1 {{ $is_primary ? 'bg-primary' : '' }}">
                                <div class="toggle-circle-primary h-4 w-4 rounded-full bg-white transition duration-300 ease-in-out">
                                </div>
                            </div>
                        </label>
                    </div>
                    <div class="flex items-center justify-center my-6">
                        <div wire:click="closeForm" style="font-weight: 600;" class="w-6/12 no-select mr-4 text-center text-[16px] text-dark-primary  border border-[#D6DADF] rounded-sm p-3 cursor-pointer">
                            Cancel
                        </div>
                        <div @click="openSubmitConfirm=true" style="font-weight: 600;" class="w-6/12 no-select text-center bg-primary rounded-sm text-white text-[16px] p-3 cursor-pointer">
                            Save
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div x-cloak x-show="openAddress" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full bg-white h-screen flex flex-col  max-h-screen">
        <div class="flex-none">
            <div class="w-full flex p-5">
                <div @if($change_address) wire:click="backToClaim" @else wire:click="closeAddressLists" @endif class="flex items-center no-select cursor-pointer">
                    <div class="mr-1">
                        <div class="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21">
                            <path class="fill-primary " d="M8.45306 6.63482C8.65228 6.83014 8.65228 7.15435 8.45697 7.35357L6.08588 9.73248H15.121C15.3984 9.73248 15.6249 9.95904 15.6249 10.2403C15.6249 10.5215 15.3984 10.7481 15.121 10.7481H6.08588L8.46088 13.127C8.65619 13.3262 8.65228 13.6465 8.45697 13.8458C8.25775 14.0411 7.94134 14.0411 7.74213 13.8419L4.52338 10.5997C4.48041 10.5528 4.44525 10.502 4.41791 10.4395C4.39056 10.377 4.37885 10.3106 4.37885 10.2442C4.37885 10.1114 4.42963 9.98639 4.52338 9.88873L7.74213 6.64654C7.93353 6.44342 8.25384 6.43951 8.45306 6.63482Z"/>
                            </svg>
                        </div>
                    </div>
                    <div style="font-weight: 600;" class="text-primary  text-[16px]">
                        Back
                    </div>
                </div>
            </div>
        </div>

        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar" x-ref="scrollContainer">
            <div class="mt-4 px-5 pb-5">
                <div class="w-full">
                    <div style="font-weight: 600;" class="mb-2 text-[20px] text-dark-primary ">
                        Address
                    </div>
                    <div style="font-weight: 400;" class="text-[16px] text-[#6A6A75] ">
                        Add or change your shipping address for gift delivery needs
                    </div>
                </div>
            </div>

            <div class="px-5">
                @if(count($addressLists) > 0)
                @foreach ($addressLists as $address)
                <div class="relative">
                    <div class="w-full flex justify-between items-center p-3 border {{ $address->is_primary ? 'border-primary bg-[#EAF2FA]' : 'border-[#EDEDED]' }}   mb-5">
                        <div class="w-full flex">
                            <div class="mr-2 flex items-start">
                                <div>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                                        <path class="fill-gray-400 " d="M11.9999 2.49023C8.27338 2.49023 5.24994 5.29805 5.24994 8.75742C5.24994 13.6324 11.9999 21.9902 11.9999 21.9902C11.9999 21.9902 18.7499 13.6324 18.7499 8.75742C18.7499 5.29805 15.7265 2.49023 11.9999 2.49023ZM11.9999 11.4387C10.7859 11.4387 9.8015 10.4543 9.8015 9.24023C9.8015 8.02617 10.7859 7.0418 11.9999 7.0418C13.214 7.0418 14.1984 8.02617 14.1984 9.24023C14.1984 10.4543 13.214 11.4387 11.9999 11.4387Z"/>
                                    </svg>
                                </div>
                            </div>
                            <div>
                                <div style="font-weight: 600;" class="text-[20px] mb-2 text-dark-primary ">
                                    {{ $address->buildingType->name }}
                                </div>
                                <div style="font-weight: 400;" class="text-[16px] text-[#6A6A75]  line-clamp-3">
                                    {{ $address->detail }}, {{ $address->urban_village }}, {{ $address->subdistrict }}, {{ $address->city }}, {{ $address->province }} ({{ $address->postal_code }})
                                </div>
                            </div>
                        </div>
                        <div class="cursor-pointer" wire:click="openActionsPopUp({{ $address->id }})">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                                <path d="M13.8749 6.61523C13.8749 5.58389 13.0313 4.74023 11.9999 4.74023C10.9686 4.74023 10.1249 5.58389 10.1249 6.61523C10.1249 7.64658 10.9686 8.49023 11.9999 8.49023C13.0313 8.49023 13.8749 7.64658 13.8749 6.61523ZM13.8749 17.8652C13.8749 16.8339 13.0313 15.9902 11.9999 15.9902C10.9686 15.9902 10.1249 16.8339 10.1249 17.8652C10.1249 18.8966 10.9686 19.7402 11.9999 19.7402C13.0313 19.7402 13.8749 18.8966 13.8749 17.8652ZM13.8749 12.2402C13.8749 11.2089 13.0313 10.3652 11.9999 10.3652C10.9686 10.3652 10.1249 11.2089 10.1249 12.2402C10.1249 13.2716 10.9686 14.1152 11.9999 14.1152C13.0313 14.1152 13.8749 13.2716 13.8749 12.2402Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                    </div>
                    @if($address->is_primary)
                    <div class="absolute top-0 right-0 flex items-center justify-center px-1 py-2 bg-primary rounded-bl-md">
                        <div style="font-weight: 400;" class=" text-white h-5 flex items-center text-[14px] justify-center">
                            Primary Address
                        </div>
                    </div>
                    @endif
                </div>
                @endforeach
                @endif
                <div @click="openForm=true;openAddress=false;openActionPopUp=false" class="w-full no-select flex justify-center items-center p-3 bg-none  border border-[#D6DADF]  mb-5 cursor-pointer">
                    <div class="mr-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                            <path d="M14.3945 9.61523H10.6249V5.8457C10.6249 5.50195 10.3437 5.2207 9.99994 5.2207C9.65619 5.2207 9.37494 5.50195 9.37494 5.8457V9.61523H5.60541C5.26166 9.61523 4.98041 9.89648 4.98041 10.2402C4.98041 10.4121 5.05072 10.5684 5.164 10.6816C5.27728 10.7949 5.43353 10.8652 5.60541 10.8652H9.37494V14.6348C9.37494 14.8066 9.44525 14.9629 9.55853 15.0762C9.67181 15.1895 9.82806 15.2598 9.99994 15.2598C10.3437 15.2598 10.6249 14.9785 10.6249 14.6348V10.8652H14.3945C14.7382 10.8652 15.0195 10.584 15.0195 10.2402C15.0195 9.89648 14.7382 9.61523 14.3945 9.61523Z" fill="#3688EF"/>
                        </svg>
                    </div>
                    <div style="font-weight: 600;" class="text-[16px] text-primary">
                        Add new address
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div x-cloak x-show="openActionPopUp" style="z-index: 80" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        <div @click.outside="openActionPopUp=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5">
                <div class="w-full flex justify-between items-center mb-[18px]">
                    <div>
                        <div style="font-weight: 600;" class="text-[18px] mb-[2px] text-dark-secondary ">
                            Setting
                        </div>
                        <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] ">
                            Change or edit your shipping address
                        </div>
                    </div>
                    <div @click="openActionPopUp=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
                <div wire:click="openEditForm" class="w-full flex justify-between items-center my-3 cursor-pointer">
                    <div class="flex items-center">
                        <div class="mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                <path d="M4 23.2798V27.3332C4 27.7065 4.29333 27.9998 4.66667 27.9998H8.72C8.89333 27.9998 9.06667 27.9332 9.18667 27.7998L23.7467 13.2532L18.7467 8.25317L4.2 22.7998C4.06667 22.9332 4 23.0932 4 23.2798ZM27.6133 9.38651C27.7369 9.26316 27.835 9.11664 27.9019 8.95534C27.9688 8.79404 28.0033 8.62113 28.0033 8.44651C28.0033 8.27188 27.9688 8.09897 27.9019 7.93768C27.835 7.77638 27.7369 7.62986 27.6133 7.50651L24.4933 4.38651C24.37 4.2629 24.2235 4.16484 24.0622 4.09793C23.9009 4.03102 23.728 3.99658 23.5533 3.99658C23.3787 3.99658 23.2058 4.03102 23.0445 4.09793C22.8832 4.16484 22.7367 4.2629 22.6133 4.38651L20.1733 6.82651L25.1733 11.8265L27.6133 9.38651Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                        <div class="p-1">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary  mb-[2px]">
                                Edit
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] ">
                                Change address
                            </div>
                        </div>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.7859 12L7.82812 6.04688C7.38749 5.60625 7.38749 4.89375 7.82812 4.45781C8.26874 4.02188 8.98124 4.02188 9.42187 4.45781L16.1719 11.2031C16.5984 11.6297 16.6078 12.3141 16.2047 12.7547L9.42656 19.5469C9.20624 19.7672 8.91562 19.875 8.62968 19.875C8.34374 19.875 8.05312 19.7672 7.83281 19.5469C7.39218 19.1062 7.39218 18.3938 7.83281 17.9578L13.7859 12Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
                <div @click="openDeleteConfirm=true;openActionPopUp=false" class="w-full flex justify-between items-center mt-3 cursor-pointer">
                    <div class="flex items-center">
                        <div class="mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                <path d="M8 25.3393C8 26.8029 9.19988 28 10.6667 28H21.3334C22.8001 28 24 26.8029 24 25.3393V10H8V25.3393ZM26 6H21L19.3259 4H12.6741L11 6H6V8H26V6Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                        <div class="p-1">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary  mb-[2px]">
                                Delete
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] ">
                                Delete address
                            </div>
                        </div>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.7859 12L7.82812 6.04688C7.38749 5.60625 7.38749 4.89375 7.82812 4.45781C8.26874 4.02188 8.98124 4.02188 9.42187 4.45781L16.1719 11.2031C16.5984 11.6297 16.6078 12.3141 16.2047 12.7547L9.42656 19.5469C9.20624 19.7672 8.91562 19.875 8.62968 19.875C8.34374 19.875 8.05312 19.7672 7.83281 19.5469C7.39218 19.1062 7.39218 18.3938 7.83281 17.9578L13.7859 12Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div x-cloak x-show="openDeleteConfirm" style="z-index: 80" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        <div @click.outside="openDeleteConfirm=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5">
                <div class="w-full flex justify-end items-center mb-[18px]">
                    <div @click="openDeleteConfirm=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
                <div class="mt-5 text-center">
                    <div style="font-weight: 600;" class="mb-[2px] text-[16px] text-dark-primary ">
                        Delete confirmation
                    </div>
                    <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] ">
                        Are you sure want to delete your address?
                    </div>
                </div>
            </div>
            <div class="p-5 flex w-full">
                <div @click="openDeleteConfirm=false" style="font-weight: 600;" class="h-[44px] mr-3 w-6/12 flex items-center justify-center text-[16px] text-[#6A6A75]  cursor-pointer">
                    Cancel
                </div>
                <div style="font-weight: 600;" wire:click="deleteAddress" @click="loading=true" class="h-[44px] w-6/12 text-[16px] flex items-center cursor-pointer justify-center rounded-sm text-[#FE5C5C] border border-[#D6DADF]  bg-dark-secondary">
                    Yes
                </div>
            </div>
        </div>
    </div>

    <div x-cloak x-show="openLogoutConfirm" style="z-index: 80" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        <div @click.outside="openLogoutConfirm=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5">
                <div class="w-full flex justify-end items-center mb-[18px]">
                    <div @click="openLogoutConfirm=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
                <div class="mt-5 text-center">
                    <div style="font-weight: 600;" class="mb-[2px] text-[16px] text-dark-primary ">
                        Logout confirmation
                    </div>
                    <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] ">
                        Are you sure want to logout?
                    </div>
                </div>
            </div>
            <div class="p-5 flex w-full">
                <div @click="openLogoutConfirm=false" style="font-weight: 600;" class="h-[44px] mr-3 w-6/12 flex items-center justify-center text-[16px] text-[#6A6A75]  cursor-pointer">
                    Cancel
                </div>
                <form action="{{route('logout')}}" class="w-6/12" method="POST">
                    @csrf
                    <button type="submit" style="font-weight: 600;" class="h-[44px] w-full text-[16px] flex items-center justify-center rounded-sm text-[#FE5C5C] border border-[#D6DADF]   bg-none">
                        Yes
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div x-cloak x-show="openSubmitConfirm" style="z-index: 80" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        <div @click.outside="openSubmitConfirm=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5">
                <div class="w-full flex justify-end items-center mb-[18px]">
                    <div @click="openSubmitConfirm=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
                <div class="mt-5 text-center">
                    <div style="font-weight: 600;" class="mb-[2px] text-[16px] text-dark-primary ">
                        Confirmation
                    </div>
                    <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]  ">
                        Have you filled in the address form correctly?
                    </div>
                </div>
            </div>
            <div class="p-5 flex w-full">
                <div @click="openSubmitConfirm=false" style="font-weight: 600;" class="h-[44px] mr-3 w-6/12 flex items-center justify-center text-[16px] text-[#6A6A75]  cursor-pointer">
                    Cancel
                </div>
                <div @click="loading=true;openSubmitConfirm=false" wire:click="{{ $is_update ? 'updateAddress' : 'submitAddress' }}" style="font-weight: 600;" class="h-[44px] w-6/12 text-[16px] cursor-pointer flex items-center justify-center rounded-sm text-white bg-primary">
                    Yes
                </div>
            </div>
        </div>
    </div>

    <div id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" class="hidden fixed w-screen h-screen top-0 left-0 right-0 bottom-0" style="z-index: 200">
        <div class="absolute top-0 left-0 right-0 bottom-0 flex w-screen h-screen justify-center items-center bg-black bg-opacity-70">
            <div class="modal fade p-10 rounded-lg justify-center items-center w-[500px] h-fit bg-white" style="z-index: 200">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true" class="text-[20px]">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="img-container">
                                <div class="row">
                                    <div class="col-md-8">
                                        <img id="image" class="w-[400px]">
                                    </div>
                                    <div class="col-md-4">
                                        <div class="preview"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="w-full flex gap-2 items-center justify-end mt-5">
                            <button type="button" style=" --tw-bg-opacity: 1;background-color: rgb(248 113 113 / var(--tw-bg-opacity)); color:white;" class="px-3 py-2 bg-red-400 rounded-lg text-white" data-dismiss="modal">Cancel</button>
                            <button type="button" style=" --tw-bg-opacity: 1;background-color: rgb(74 222 128 / var(--tw-bg-opacity)); color:white;" class="px-3 py-2 bg-green-400 rounded-lg text-white" id="crop">Crop</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="{{ asset('src/js/isPrimaryToggle.js') }}"></script>
    <script src="{{ asset('src/js/cropperJS.js') }}"></script>
</div>
