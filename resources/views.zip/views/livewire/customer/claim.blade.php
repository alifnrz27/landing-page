<div class="w-screen h-screen bg-[#E8EAED] flex justify-center items-center" x-data="{
    openClaims:true,
    openDetailClaim:false,
    openDetailExpiredVoucher:false,
    openDetailUsedVoucher:false,
    openDetailActiveVoucher:false,
    exchangeConfirm:false,
    myCollection:false,
    voucherGiftLists:true,
    voucherLists:false,
    giftLists:false,
    openListStores:false,
    openListActiveStores:false,
    openListExpiredStores:false,
    readMore:false,
    isSuccess:false,
    activeVoucher:true,
    usedVoucher:false,
    expiredVoucher:false,
    openRedeemOption: false,
    detailRedeemStore:false,
    openSendHomeConfirm:false,
    loading:false,
    fromProfile:{{ $from_profile ? $from_profile : 'false' }},
    fromDashboard:{{ $from_dashboard ? $from_dashboard : 'false' }},
    fromVoucherDashboard:{{ $from_voucher_dashboard ? $from_voucher_dashboard : 'false' }},
    openActiveClaimmed:{{ $open_active_claimmed ? $open_active_claimmed : 'false' }},
    openExpiredClaimmed:{{ $open_expired_claimmed ? $open_expired_claimmed : 'false' }},
    openUsedClaimmed:{{ $open_used_claimmed ? $open_used_claimmed : 'false' }},
    openClaim:{{ $open_claim ? $open_claim : 'false' }},
    }"
     x-init="
        if(fromProfile){
            openClaims=false;
            openDetailActiveVoucher=true;
        }
        if(fromDashboard){
            openClaims=false;
            myCollection=true;
        }
        if(openActiveClaimmed){
            openClaims=false;
            openDetailActiveVoucher=true;
        }

        if(openExpiredClaimmed){
            openClaims=false;
            openDetailExpiredVoucher=true;
        }

        if(openUsedClaimmed){
            openClaims=false;
            openDetailUsedVoucher=true;
        }

        if(openClaim){
            openClaims=false;
            openDetailClaim=true;
        }

        if(fromVoucherDashboard){
            openClaims=false;
            openDetailClaim=true;
        }

        $wire.on('showExchangeConfirm', value => {
            exchangeConfirm=value;
            loading=false;
        });
        $wire.on('showDetailClaim', value => {
            openDetailClaim=value;
            openClaims = false;
            loading=false;
        });
        $wire.on('showSendHomeConfirm', value => {
            openSendHomeConfirm=value;
            openRedeemOption = false;
        });
        $wire.on('showDetailActiveVoucher', value => {
            openDetailActiveVoucher = value;
            myCollection = false;
            loading = false;
        });
        $wire.on('showDetailExpiredVoucher', value => {
            openDetailExpiredVoucher = value;
            myCollection = false;
            loading = false;
        });
        $wire.on('showDetailUsedVoucher', value => {
            openDetailUsedVoucher = value;
            myCollection = false;
            loading = false;
        });
        $wire.on('showIsSuccess', value => {
            isSuccess = value;
            openClaims=true;
            openDetailClaim=false;
            setTimeout(() => {
                isSuccess = false;
                document.querySelector('#total-point').value = 'halo'
            }, 2000);
        });

    " x-ref="scrollContainer">

    <div x-show="loading">
        <x-layouts.loading/>
    </div>

    <div x-cloak x-show="isSuccess" class="fixed top-0 px-5 py-2 w-screen md:w-full md:max-w-md max-w-full bg-[#2C9854] justify-between items-center  overflow-auto flex">
        <div class="h-5 flex items-center">
            <div>
                🎉
            </div>
            <div style="font-weight: 600;" class="text-[16px] text-white flex items-center">
                Voucher redeemed successfully
            </div>
        </div>
        <div style="font-weight: 400;" class="h-7 py-1 px-2 flex items-center justify-center text-white text-[14px] border border-white rounded-sm">
            Detail
        </div>
    </div>

    <div x-cloak x-show="openClaims" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar relative bg-white">
            <div class="absolute">
                <img src="{{ asset('src/images/bg-profile.png') }}" alt="">
            </div>
            <div class="relative ">
                <div class="py-5 px-8">
                    <div class="flex justify-between items-center">
                        <div style="line-height: 36px;font-weight:700;" class="text-[24px] text-white">
                            Voucher Claim
                        </div>
                        <div onclick="redirectTo('{{route('profile', ['data' => encrypt(['history_from_claim' => true])])}}')" style="line-height: 20px" class="font-bold text-[14px] px-5 py-2 cursor-pointer no-select text-white rounded-full border border-white">
                            Point History
                        </div>
                    </div>
                </div>
                <div class="flex justify-center items-center relative lg:mt-6">
                    <div class="w-full relative">
                        <div class="rounded-lg gap-2 flex item-center p-3">
                            <div class="w-6/12 flex flex-col  justify-center gap-2 p-5 rounded-xl bg-white no-select">
                                <div style="line-height: 14.52px" class="text-[#64748B] text-[12px] font-bold">
                                    TOTAL POINT
                                </div>
                                <div class="flex items-center gap-1">
                                    <div>
                                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_15_1291)">
                                            <path d="M31.9559 17.1998H26.2403C21.2475 17.1998 17.2003 21.2472 17.2003 26.2398V31.9555C25.0802 31.3712 31.3716 25.0797 31.9559 17.1998Z" fill="#EFB008"/>
                                            <path d="M14.8003 31.9555V26.2398C14.8003 21.2472 10.7529 17.1998 5.76023 17.1998H0.0445557C0.628823 25.0797 6.92031 31.3712 14.8003 31.9555Z" fill="#EFB008"/>
                                            <path d="M31.9559 14.7998C31.3716 6.91988 25.0802 0.628396 17.2003 0.0441284V5.7598C17.2003 10.7525 21.2475 14.7998 26.2403 14.7998H31.9559Z" fill="#EFB008"/>
                                            <path d="M14.8003 0.0441284C6.92031 0.628396 0.628823 6.91988 0.0445557 14.7998H5.76023C10.7529 14.7998 14.8003 10.7525 14.8003 5.7598V0.0441284Z" fill="#EFB008"/>
                                            <path d="M10.8664 15.9998C13.0844 14.8916 14.892 13.084 16.0002 10.866C17.1084 13.084 18.9159 14.8916 21.134 15.9998C18.9159 17.108 17.1084 18.9156 16.0002 21.1336C14.892 18.9156 13.0844 17.108 10.8664 15.9998Z" fill="#FFDE81"/>
                                            </g>
                                            <defs>
                                            <clipPath id="clip0_15_1291">
                                            <rect width="32" height="32" fill="white"/>
                                            </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div style="line-height: 36px" class="text-[#976400] font-bold text-[24px]">
                                        {{ $updateTotalPoint > 0 ? $updateTotalPoint : auth()->user()->total_point }}
                                    </div>
                                </div>
                            </div>
                            <div @click="myCollection=true;openClaims=false" wire:click="showMyCollection" class="w-6/12 flex flex-col cursor-pointer no-select justify-center gap-2 p-5 rounded-xl bg-white">
                                <div style="line-height: 14.52px" class="text-[#64748B] text-[12px] font-bold">
                                    MY VOUCHER
                                </div>
                                <div class="flex items-center gap-1">
                                    <div>
                                        <svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M28.9 14.4533C29.42 14.4533 29.8334 14.04 29.8334 13.52V12.28C29.8334 6.81333 28.1667 5.14667 22.7 5.14667H10.3C4.83335 5.14667 3.16669 6.81333 3.16669 12.28V12.9067C3.16669 13.4267 3.58002 13.84 4.10002 13.84C5.30002 13.84 6.27335 14.8133 6.27335 16.0133C6.27335 17.2133 5.30002 18.1733 4.10002 18.1733C3.58002 18.1733 3.16669 18.5867 3.16669 19.1067V19.7333C3.16669 25.2 4.83335 26.8667 10.3 26.8667H22.7C28.1667 26.8667 29.8334 25.2 29.8334 19.7333C29.8334 19.2133 29.42 18.8 28.9 18.8C27.7 18.8 26.7267 17.8267 26.7267 16.6267C26.7267 15.4267 27.7 14.4533 28.9 14.4533ZM12.5 11.84C13.2334 11.84 13.8334 12.44 13.8334 13.1733C13.8334 13.9067 13.2467 14.5067 12.5 14.5067C11.7667 14.5067 11.1667 13.9067 11.1667 13.1733C11.1667 12.44 11.7534 11.84 12.5 11.84ZM20.5 21.1733C19.7534 21.1733 19.1534 20.5733 19.1534 19.84C19.1534 19.1067 19.7534 18.5067 20.4867 18.5067C21.22 18.5067 21.82 19.1067 21.82 19.84C21.82 20.5733 21.2467 21.1733 20.5 21.1733ZM21.7 12.64L12.7267 21.6133C12.5267 21.8133 12.2734 21.9067 12.02 21.9067C11.7667 21.9067 11.5134 21.8133 11.3134 21.6133C10.9267 21.2267 10.9267 20.5867 11.3134 20.2L20.2867 11.2267C20.6734 10.84 21.3134 10.84 21.7 11.2267C22.0867 11.6133 22.0867 12.2533 21.7 12.64Z" fill="#EFB008"/>
                                        </svg>
                                    </div>
                                    <div style="line-height: 36px" class="text-[#976400] font-bold text-[24px]">
                                        {{ $totalClaims }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-t-2xl pt-1 relative">
                    <div class="w-full h-12 flex items-center justify-between mt-5">
                        <div @click="voucherGiftLists=true;voucherLists=false;giftLists=false"  class="w-4/12 px-6 no-select cursor-pointer h-full flex items-center justify-center text-[16px] border-r-[1px]">
                            <div :class="voucherGiftLists ? 'text-dark-primary font-bold border-b-[#DA0713] border-b-4' : 'text-[#6A6A75] font-light border-none'" class=" py-2">
                                All
                            </div>
                        </div>
                        <div @click="voucherGiftLists=false;voucherLists=true;giftLists=false" class="w-4/12 px-6 py-2 no-select cursor-pointer flex items-center justify-center text-[16px] h-full border-r-[1px]">
                            <div :class="voucherLists ? 'text-dark-primary font-bold border-b-[#DA0713] border-b-4' : 'text-[#6A6A75] font-light border-none'" class=" py-2">
                                Voucher
                            </div>
                        </div>
                        <div @click="voucherGiftLists=false;voucherLists=false;giftLists=true" class="w-4/12 px-6 py-2 no-select cursor-pointer h-full flex items-center justify-center text-[16px]">
                            <div :class="giftLists ? 'text-dark-primary font-bold border-b-[#DA0713] border-b-4' : 'text-[#6A6A75] font-light border-none'" class=" py-2">
                                Gift
                            </div>
                        </div>
                    </div>

                    <div class="w-full p-5">
                        <div x-show="voucherGiftLists">
                            @foreach ($vouchersAndGifts as $allVoucherGift)
                            <?php
                                $precentageStock = intval((count($allVoucherGift->claimmed) / $allVoucherGift->stock) * 100);
                            ?>
                            <div class=" bg-white shadow-lg rounded-xl  mt-6 cursor-pointer relative" wire:click="showDetailClaim({{ $allVoucherGift->id }})" @click="loading=true;readMore=false">
                                @if($allVoucherGift->thumbnail_path)
                                <img src="{{ asset('storage/'. $allVoucherGift->thumbnail_path) }}" class= "w-[100%] h-full rounded-xl" alt="Image">
                                @else
                                <div class="relative flex p-5 items-center bg-[#2C9854] overflow-hidden rounded-xl">
                                    <div class="mr-[18px]">
                                        <svg width="46" height="49" viewBox="0 0 46 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_328_4498)">
                                                <path d="M42.1875 39.3087L27.7025 47.3482C27.0076 47.7339 25.8705 47.7339 25.1757 47.3482L10.6906 39.3087C10.3432 39.1159 10.1695 38.8616 10.1695 38.6075H10.0156V20.6479H42.7087V38.6075C42.7087 38.8616 42.535 39.1159 42.1875 39.3087Z" fill="#FE5C5C"/>
                                                <path d="M42.7081 20.6478V38.6073C42.7081 38.8615 42.5344 39.1157 42.187 39.3086L27.7019 47.3481C27.3406 47.5486 26.8598 47.6441 26.3837 47.6359C26.3949 38.6428 26.6506 29.6383 26.3711 20.6477L42.7081 20.6478Z" fill="#FC8B8B"/>
                                                <path d="M25.1751 29.3887L10.6901 21.3491C9.99522 20.9634 9.99522 20.3324 10.6901 19.9467L25.1751 11.9072C25.87 11.5215 27.0071 11.5215 27.7019 11.9072L42.187 19.9467C42.8819 20.3324 42.8819 20.9635 42.187 21.3492L27.702 29.3887C27.0071 29.7744 25.87 29.7744 25.1751 29.3887Z" fill="#FFA9BA"/>
                                                <path d="M36.271 16.4045C36.2703 16.4895 36.2467 16.5727 36.2026 16.6454C36.1586 16.7181 36.0958 16.7775 36.0208 16.8175L18.6653 26.0688C18.6414 26.0815 18.6164 26.0922 18.5907 26.1006L18.532 26.1334V43.3984C18.532 43.4807 18.5106 43.5616 18.4697 43.633C18.4289 43.7044 18.3701 43.764 18.2992 43.8057C18.2283 43.8475 18.1477 43.87 18.0655 43.871C17.9832 43.8721 17.9021 43.8516 17.8301 43.8117L14.922 42.1976C14.8482 42.1567 14.7868 42.0968 14.744 42.0241C14.7013 41.9514 14.6787 41.8687 14.6787 41.7843V24.9835C14.6788 24.6952 14.7436 24.4106 14.8683 24.1507C14.9931 23.8908 15.1746 23.6622 15.3994 23.4818L15.4166 23.4684C15.4547 23.4386 15.4908 23.4124 15.528 23.3873C15.5832 23.3498 15.6402 23.3152 15.699 23.2835L32.5474 14.3025C32.617 14.2654 32.6948 14.2463 32.7737 14.2469C32.8526 14.2476 32.9301 14.268 32.999 14.3063L36.0278 15.9873C36.1021 16.0286 36.1639 16.0891 36.2067 16.1625C36.2495 16.2359 36.2717 16.3195 36.271 16.4045ZM37.8715 23.7135C37.7615 23.5881 37.6357 23.4776 37.4972 23.3847C37.4881 23.3785 37.479 23.3723 37.4683 23.3653C37.4233 23.336 37.3771 23.3086 37.3298 23.2833L20.4814 14.3024C20.4118 14.2653 20.334 14.2462 20.2551 14.2468C20.1762 14.2475 20.0988 14.2679 20.0298 14.3063L17.001 15.9873C16.9267 16.0285 16.8648 16.089 16.822 16.1624C16.7792 16.2359 16.757 16.3195 16.7577 16.4045C16.7584 16.4895 16.782 16.5727 16.8261 16.6454C16.8702 16.7181 16.933 16.7776 17.0081 16.8175L34.3636 26.0688C34.3877 26.0816 34.4127 26.0923 34.4382 26.1007L34.4968 26.1335V43.3985C34.4968 43.4808 34.5183 43.5616 34.5591 43.6331C34.6 43.7045 34.6587 43.764 34.7296 43.8058C34.8005 43.8475 34.8811 43.87 34.9634 43.8711C35.0457 43.8721 35.1268 43.8517 35.1987 43.8118L38.1069 42.1977C38.1806 42.1567 38.242 42.0968 38.2848 42.0242C38.3276 41.9515 38.3501 41.8687 38.3501 41.7844V24.9835C38.3499 24.5161 38.1798 24.0648 37.8715 23.7135Z" fill="#3688EF"/>
                                                <path d="M32.2361 20.982C32.2361 22.1679 30.7816 23.0285 28.7777 23.0285C27.9604 23.0285 27.2347 22.8852 26.6617 22.6353C26.5885 22.6035 26.5092 22.5883 26.4295 22.5906C26.3498 22.593 26.2715 22.6129 26.2004 22.649C25.6031 22.9504 24.8111 23.1261 23.9067 23.1261C21.9028 23.1261 20.4482 22.2654 20.4482 21.0795C20.4482 20.4825 20.817 19.968 21.4389 19.6041C21.6839 19.4608 21.7868 19.1549 21.6655 18.8983C21.2222 17.9609 21.2364 17.0814 21.7801 16.5377C22.0617 16.2561 22.4473 16.1073 22.8954 16.1073C23.2102 16.1073 23.5521 16.1817 23.9033 16.3214C24.0382 16.3752 24.1889 16.3738 24.3228 16.3174C24.4567 16.2611 24.5631 16.1543 24.619 16.0202C24.98 15.1586 25.5772 14.6279 26.2934 14.6279C26.9973 14.6279 27.5865 15.1406 27.9493 15.9764C28.0697 16.2538 28.3875 16.3862 28.667 16.2708C29.034 16.1194 29.3916 16.0384 29.7199 16.0384C30.2859 16.0384 30.6388 16.2724 30.8352 16.4688C31.3696 17.0032 31.3926 17.8621 30.9722 18.7816C30.8543 19.0395 30.9589 19.3448 31.2058 19.4843C31.8515 19.8491 32.2361 20.3725 32.2361 20.982Z" fill="#2F6BB7"/>
                                            </g>
                                            <circle cx="40.8979" cy="11.7502" r="1.71429" fill="#FF8933"/>
                                            <path d="M11.4777 3.74029C12.0165 3.25521 12.8612 3.74291 12.7105 4.452C12.643 4.76912 12.7875 5.09357 13.0683 5.25567C13.6961 5.61814 13.4933 6.57222 12.7723 6.648C12.4499 6.68189 12.186 6.91954 12.1186 7.23665C11.9678 7.94575 10.9978 8.0477 10.7029 7.38544C10.5711 7.08927 10.2635 6.91169 9.94106 6.94558C9.22009 7.02135 8.82336 6.13029 9.36209 5.64521C9.60302 5.42828 9.67686 5.08088 9.545 4.78471C9.25014 4.12244 9.975 3.46978 10.6028 3.83224C10.8836 3.99434 11.2368 3.95722 11.4777 3.74029Z" fill="#80D5EF"/>
                                            <circle cx="28.1635" cy="1.95428" r="1.71429" fill="white"/>
                                            <path d="M3.66431 30.9826C3.70225 30.2587 4.64441 30.0062 5.03924 30.6142C5.21581 30.8861 5.54739 31.0134 5.86054 30.9295C6.56077 30.7419 7.09201 31.5599 6.6358 32.1233C6.43177 32.3752 6.41318 32.7299 6.58975 33.0018C6.98458 33.6098 6.37075 34.3678 5.69396 34.108C5.39129 33.9918 5.04823 34.0838 4.84421 34.3357C4.38799 34.8991 3.47738 34.5495 3.51532 33.8256C3.53229 33.5018 3.33885 33.204 3.03619 33.0878C2.3594 32.828 2.41045 31.8539 3.11068 31.6663C3.42384 31.5824 3.64735 31.3064 3.66431 30.9826Z" fill="#ABEAB9"/>
                                            <defs>
                                                <clipPath id="clip0_328_4498">
                                                    <rect width="37.2245" height="37.2245" fill="white" transform="translate(7.83691 11.0154)"/>
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600;" class="h-6 flex items-center text-white text-[20px] mb-1">
                                            Claim image
                                        </div>
                                        <div style="font-weight: 400;" class="h-5 text-white text-[16px]">
                                            Claim now!
                                        </div>
                                    </div>
                                    <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                                    </div>
                                </div>
                                @endif

                                <div class="absolute px-2 w-full top-[40%] md:top-[45%] lg:top-[48%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ $allVoucherGift->brand->company_name }}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ readableDaysLeft($allVoucherGift->end_date) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="p-3 bg-white rounded-b-lg ">
                                    <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] mt-5 h-[68px] text-dark-primary flex items-center">
                                        {{$allVoucherGift->title}}
                                    </div>
                                    <div class="w-full">
                                        <div class="relative h-[4px] bg-gray-200 mb-1">
                                            <div class="absolute top-0 h-[4px] @if($precentageStock > 70) bg-red-500 @elseif($precentageStock > 30) bg-yellow-500 @else bg-[#2C9854] @endif" style="width: {{ $precentageStock }}%;"></div>
                                        </div>
                                        <div class="flex justify-between items-center">
                                            <div style="line-height: 13px" class="text-[#202124] font-normal text-[11px]">
                                                Stock left
                                            </div>
                                            <div style="line-height: 13px" class="text-[10px] font-normal @if($precentageStock > 70) text-red-500 @elseif($precentageStock > 30) text-yellow-500 @else text-[#2C9854] @endif">
                                                {{ $allVoucherGift->stock - count($allVoucherGift->claimmed) }} voucher left
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex justify-between items-center mt-6">
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_15_1368)">
                                                    <path d="M16.4779 8.59992H13.6201C11.1237 8.59992 9.1001 10.6236 9.1001 13.1199V15.9778C13.0401 15.6856 16.1858 12.5399 16.4779 8.59992Z" fill="#EFB008"/>
                                                    <path d="M7.90007 15.9778V13.1199C7.90007 10.6236 5.87639 8.59992 3.38006 8.59992H0.522217C0.81435 12.5399 3.9601 15.6856 7.90007 15.9778Z" fill="#EFB008"/>
                                                    <path d="M16.4779 7.39992C16.1858 3.45995 13.0401 0.314206 9.1001 0.0220718V2.87991C9.1001 5.37624 11.1237 7.39992 13.6201 7.39992H16.4779Z" fill="#EFB008"/>
                                                    <path d="M7.90007 0.0220718C3.9601 0.314206 0.81435 3.45995 0.522217 7.39992H3.38006C5.87639 7.39992 7.90007 5.37624 7.90007 2.87991V0.0220718Z" fill="#EFB008"/>
                                                    <path d="M5.93323 7.99992C7.04223 7.4458 7.94603 6.542 8.50011 5.433C9.05423 6.542 9.95799 7.4458 11.067 7.99992C9.95799 8.554 9.05423 9.4578 8.50011 10.5668C7.94603 9.4578 7.04223 8.554 5.93323 7.99992Z" fill="#FFDE81"/>
                                                    </g>
                                                    <defs>
                                                    <clipPath id="clip0_15_1368">
                                                    <rect width="16" height="16" fill="white" transform="translate(0.5)"/>
                                                    </clipPath>
                                                    </defs>
                                                </svg>
                                            </div>
                                            <div style="line-height: 22px" class="text-[#976400] font-semibold text-[18px]">
                                                {{ $allVoucherGift->exchange_rate }} Point
                                            </div>
                                        </div>
                                        <div style="line-height: 20px" class="bg-[#D83232] rounded-full px-7 py-2 flex items-center justify-center text-white font-bold text-[14px]">
                                            Redeem
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>

                        <div x-show="voucherLists">
                            @foreach ($vouchers as $voucher)
                            <?php
                                $precentageStock = intval((count($voucher->claimmed) / $voucher->stock) * 100);
                            ?>
                            <div class=" bg-white shadow-lg rounded-xl  mt-6 cursor-pointer relative" wire:click="showDetailClaim({{ $voucher->id }})" @click="loading=true;readMore=false">
                                @if($voucher->thumbnail_path)
                                <img src="{{ asset('storage/'. $voucher->thumbnail_path) }}" class= "w-[100%] h-full rounded-xl" alt="Image">
                                @else
                                <div class="relative flex p-5 items-center bg-[#2C9854] overflow-hidden rounded-xl">
                                    <div class="mr-[18px]">
                                        <svg width="46" height="49" viewBox="0 0 46 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_328_4498)">
                                                <path d="M42.1875 39.3087L27.7025 47.3482C27.0076 47.7339 25.8705 47.7339 25.1757 47.3482L10.6906 39.3087C10.3432 39.1159 10.1695 38.8616 10.1695 38.6075H10.0156V20.6479H42.7087V38.6075C42.7087 38.8616 42.535 39.1159 42.1875 39.3087Z" fill="#FE5C5C"/>
                                                <path d="M42.7081 20.6478V38.6073C42.7081 38.8615 42.5344 39.1157 42.187 39.3086L27.7019 47.3481C27.3406 47.5486 26.8598 47.6441 26.3837 47.6359C26.3949 38.6428 26.6506 29.6383 26.3711 20.6477L42.7081 20.6478Z" fill="#FC8B8B"/>
                                                <path d="M25.1751 29.3887L10.6901 21.3491C9.99522 20.9634 9.99522 20.3324 10.6901 19.9467L25.1751 11.9072C25.87 11.5215 27.0071 11.5215 27.7019 11.9072L42.187 19.9467C42.8819 20.3324 42.8819 20.9635 42.187 21.3492L27.702 29.3887C27.0071 29.7744 25.87 29.7744 25.1751 29.3887Z" fill="#FFA9BA"/>
                                                <path d="M36.271 16.4045C36.2703 16.4895 36.2467 16.5727 36.2026 16.6454C36.1586 16.7181 36.0958 16.7775 36.0208 16.8175L18.6653 26.0688C18.6414 26.0815 18.6164 26.0922 18.5907 26.1006L18.532 26.1334V43.3984C18.532 43.4807 18.5106 43.5616 18.4697 43.633C18.4289 43.7044 18.3701 43.764 18.2992 43.8057C18.2283 43.8475 18.1477 43.87 18.0655 43.871C17.9832 43.8721 17.9021 43.8516 17.8301 43.8117L14.922 42.1976C14.8482 42.1567 14.7868 42.0968 14.744 42.0241C14.7013 41.9514 14.6787 41.8687 14.6787 41.7843V24.9835C14.6788 24.6952 14.7436 24.4106 14.8683 24.1507C14.9931 23.8908 15.1746 23.6622 15.3994 23.4818L15.4166 23.4684C15.4547 23.4386 15.4908 23.4124 15.528 23.3873C15.5832 23.3498 15.6402 23.3152 15.699 23.2835L32.5474 14.3025C32.617 14.2654 32.6948 14.2463 32.7737 14.2469C32.8526 14.2476 32.9301 14.268 32.999 14.3063L36.0278 15.9873C36.1021 16.0286 36.1639 16.0891 36.2067 16.1625C36.2495 16.2359 36.2717 16.3195 36.271 16.4045ZM37.8715 23.7135C37.7615 23.5881 37.6357 23.4776 37.4972 23.3847C37.4881 23.3785 37.479 23.3723 37.4683 23.3653C37.4233 23.336 37.3771 23.3086 37.3298 23.2833L20.4814 14.3024C20.4118 14.2653 20.334 14.2462 20.2551 14.2468C20.1762 14.2475 20.0988 14.2679 20.0298 14.3063L17.001 15.9873C16.9267 16.0285 16.8648 16.089 16.822 16.1624C16.7792 16.2359 16.757 16.3195 16.7577 16.4045C16.7584 16.4895 16.782 16.5727 16.8261 16.6454C16.8702 16.7181 16.933 16.7776 17.0081 16.8175L34.3636 26.0688C34.3877 26.0816 34.4127 26.0923 34.4382 26.1007L34.4968 26.1335V43.3985C34.4968 43.4808 34.5183 43.5616 34.5591 43.6331C34.6 43.7045 34.6587 43.764 34.7296 43.8058C34.8005 43.8475 34.8811 43.87 34.9634 43.8711C35.0457 43.8721 35.1268 43.8517 35.1987 43.8118L38.1069 42.1977C38.1806 42.1567 38.242 42.0968 38.2848 42.0242C38.3276 41.9515 38.3501 41.8687 38.3501 41.7844V24.9835C38.3499 24.5161 38.1798 24.0648 37.8715 23.7135Z" fill="#3688EF"/>
                                                <path d="M32.2361 20.982C32.2361 22.1679 30.7816 23.0285 28.7777 23.0285C27.9604 23.0285 27.2347 22.8852 26.6617 22.6353C26.5885 22.6035 26.5092 22.5883 26.4295 22.5906C26.3498 22.593 26.2715 22.6129 26.2004 22.649C25.6031 22.9504 24.8111 23.1261 23.9067 23.1261C21.9028 23.1261 20.4482 22.2654 20.4482 21.0795C20.4482 20.4825 20.817 19.968 21.4389 19.6041C21.6839 19.4608 21.7868 19.1549 21.6655 18.8983C21.2222 17.9609 21.2364 17.0814 21.7801 16.5377C22.0617 16.2561 22.4473 16.1073 22.8954 16.1073C23.2102 16.1073 23.5521 16.1817 23.9033 16.3214C24.0382 16.3752 24.1889 16.3738 24.3228 16.3174C24.4567 16.2611 24.5631 16.1543 24.619 16.0202C24.98 15.1586 25.5772 14.6279 26.2934 14.6279C26.9973 14.6279 27.5865 15.1406 27.9493 15.9764C28.0697 16.2538 28.3875 16.3862 28.667 16.2708C29.034 16.1194 29.3916 16.0384 29.7199 16.0384C30.2859 16.0384 30.6388 16.2724 30.8352 16.4688C31.3696 17.0032 31.3926 17.8621 30.9722 18.7816C30.8543 19.0395 30.9589 19.3448 31.2058 19.4843C31.8515 19.8491 32.2361 20.3725 32.2361 20.982Z" fill="#2F6BB7"/>
                                            </g>
                                            <circle cx="40.8979" cy="11.7502" r="1.71429" fill="#FF8933"/>
                                            <path d="M11.4777 3.74029C12.0165 3.25521 12.8612 3.74291 12.7105 4.452C12.643 4.76912 12.7875 5.09357 13.0683 5.25567C13.6961 5.61814 13.4933 6.57222 12.7723 6.648C12.4499 6.68189 12.186 6.91954 12.1186 7.23665C11.9678 7.94575 10.9978 8.0477 10.7029 7.38544C10.5711 7.08927 10.2635 6.91169 9.94106 6.94558C9.22009 7.02135 8.82336 6.13029 9.36209 5.64521C9.60302 5.42828 9.67686 5.08088 9.545 4.78471C9.25014 4.12244 9.975 3.46978 10.6028 3.83224C10.8836 3.99434 11.2368 3.95722 11.4777 3.74029Z" fill="#80D5EF"/>
                                            <circle cx="28.1635" cy="1.95428" r="1.71429" fill="white"/>
                                            <path d="M3.66431 30.9826C3.70225 30.2587 4.64441 30.0062 5.03924 30.6142C5.21581 30.8861 5.54739 31.0134 5.86054 30.9295C6.56077 30.7419 7.09201 31.5599 6.6358 32.1233C6.43177 32.3752 6.41318 32.7299 6.58975 33.0018C6.98458 33.6098 6.37075 34.3678 5.69396 34.108C5.39129 33.9918 5.04823 34.0838 4.84421 34.3357C4.38799 34.8991 3.47738 34.5495 3.51532 33.8256C3.53229 33.5018 3.33885 33.204 3.03619 33.0878C2.3594 32.828 2.41045 31.8539 3.11068 31.6663C3.42384 31.5824 3.64735 31.3064 3.66431 30.9826Z" fill="#ABEAB9"/>
                                            <defs>
                                                <clipPath id="clip0_328_4498">
                                                    <rect width="37.2245" height="37.2245" fill="white" transform="translate(7.83691 11.0154)"/>
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600;" class="h-6 flex items-center text-white text-[20px] mb-1">
                                            Claim image
                                        </div>
                                        <div style="font-weight: 400;" class="h-5 text-white text-[16px]">
                                            Claim now!
                                        </div>
                                    </div>
                                    <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                                    </div>
                                </div>
                                @endif

                                <div class="absolute px-2 w-full top-[40%] md:top-[45%] lg:top-[48%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ $voucher->brand->company_name }}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ readableDaysLeft($voucher->end_date) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="p-3 bg-white rounded-b-lg ">
                                    <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] mt-5 h-[68px] text-dark-primary flex items-center">
                                        {{$voucher->title}}
                                    </div>
                                    <div class="w-full">
                                        <div class="relative h-[4px] bg-gray-200 mb-1">
                                            <div class="absolute top-0 h-[4px] @if($precentageStock > 70) bg-red-500 @elseif($precentageStock > 30) bg-yellow-500 @else bg-[#2C9854] @endif" style="width: {{ $precentageStock }}%;"></div>
                                        </div>
                                        <div class="flex justify-between items-center">
                                            <div style="line-height: 13px" class="text-[#202124] font-normal text-[11px]">
                                                Stock left
                                            </div>
                                            <div style="line-height: 13px" class="text-[10px] font-normal @if($precentageStock > 70) text-red-500 @elseif($precentageStock > 30) text-yellow-500 @else text-[#2C9854] @endif">
                                                {{ $voucher->stock - count($voucher->claimmed) }} voucher left
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex justify-between items-center mt-6">
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_15_1368)">
                                                    <path d="M16.4779 8.59992H13.6201C11.1237 8.59992 9.1001 10.6236 9.1001 13.1199V15.9778C13.0401 15.6856 16.1858 12.5399 16.4779 8.59992Z" fill="#EFB008"/>
                                                    <path d="M7.90007 15.9778V13.1199C7.90007 10.6236 5.87639 8.59992 3.38006 8.59992H0.522217C0.81435 12.5399 3.9601 15.6856 7.90007 15.9778Z" fill="#EFB008"/>
                                                    <path d="M16.4779 7.39992C16.1858 3.45995 13.0401 0.314206 9.1001 0.0220718V2.87991C9.1001 5.37624 11.1237 7.39992 13.6201 7.39992H16.4779Z" fill="#EFB008"/>
                                                    <path d="M7.90007 0.0220718C3.9601 0.314206 0.81435 3.45995 0.522217 7.39992H3.38006C5.87639 7.39992 7.90007 5.37624 7.90007 2.87991V0.0220718Z" fill="#EFB008"/>
                                                    <path d="M5.93323 7.99992C7.04223 7.4458 7.94603 6.542 8.50011 5.433C9.05423 6.542 9.95799 7.4458 11.067 7.99992C9.95799 8.554 9.05423 9.4578 8.50011 10.5668C7.94603 9.4578 7.04223 8.554 5.93323 7.99992Z" fill="#FFDE81"/>
                                                    </g>
                                                    <defs>
                                                    <clipPath id="clip0_15_1368">
                                                    <rect width="16" height="16" fill="white" transform="translate(0.5)"/>
                                                    </clipPath>
                                                    </defs>
                                                </svg>
                                            </div>
                                            <div style="line-height: 22px" class="text-[#976400] font-semibold text-[18px]">
                                                {{ $voucher->exchange_rate }} Point
                                            </div>
                                        </div>
                                        <div  style="line-height: 20px" class="bg-[#D83232] rounded-full px-7 py-2 flex items-center justify-center text-white font-bold text-[14px]">
                                            Redeem
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>

                        <div x-show="giftLists">
                            @foreach ($gifts as $gift)
                            <?php
                                $precentageStock = intval((count($gift->claimmed) / $gift->stock) * 100);
                            ?>
                            <div class=" bg-white shadow-lg rounded-xl mt-6 cursor-pointer relative" wire:click="showDetailClaim({{ $gift->id }})" @click="loading=true;readMore=false">
                                @if($gift->thumbnail_path)
                                <img src="{{ asset('storage/'. $gift->thumbnail_path) }}" class= "w-[100%] h-full rounded-xl" alt="Image">
                                @else
                                <div class="relative flex p-5 items-center bg-[#2C9854] overflow-hidden rounded-t-xl">
                                    <div class="mr-[18px]">
                                        <svg width="46" height="49" viewBox="0 0 46 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_328_4498)">
                                                <path d="M42.1875 39.3087L27.7025 47.3482C27.0076 47.7339 25.8705 47.7339 25.1757 47.3482L10.6906 39.3087C10.3432 39.1159 10.1695 38.8616 10.1695 38.6075H10.0156V20.6479H42.7087V38.6075C42.7087 38.8616 42.535 39.1159 42.1875 39.3087Z" fill="#FE5C5C"/>
                                                <path d="M42.7081 20.6478V38.6073C42.7081 38.8615 42.5344 39.1157 42.187 39.3086L27.7019 47.3481C27.3406 47.5486 26.8598 47.6441 26.3837 47.6359C26.3949 38.6428 26.6506 29.6383 26.3711 20.6477L42.7081 20.6478Z" fill="#FC8B8B"/>
                                                <path d="M25.1751 29.3887L10.6901 21.3491C9.99522 20.9634 9.99522 20.3324 10.6901 19.9467L25.1751 11.9072C25.87 11.5215 27.0071 11.5215 27.7019 11.9072L42.187 19.9467C42.8819 20.3324 42.8819 20.9635 42.187 21.3492L27.702 29.3887C27.0071 29.7744 25.87 29.7744 25.1751 29.3887Z" fill="#FFA9BA"/>
                                                <path d="M36.271 16.4045C36.2703 16.4895 36.2467 16.5727 36.2026 16.6454C36.1586 16.7181 36.0958 16.7775 36.0208 16.8175L18.6653 26.0688C18.6414 26.0815 18.6164 26.0922 18.5907 26.1006L18.532 26.1334V43.3984C18.532 43.4807 18.5106 43.5616 18.4697 43.633C18.4289 43.7044 18.3701 43.764 18.2992 43.8057C18.2283 43.8475 18.1477 43.87 18.0655 43.871C17.9832 43.8721 17.9021 43.8516 17.8301 43.8117L14.922 42.1976C14.8482 42.1567 14.7868 42.0968 14.744 42.0241C14.7013 41.9514 14.6787 41.8687 14.6787 41.7843V24.9835C14.6788 24.6952 14.7436 24.4106 14.8683 24.1507C14.9931 23.8908 15.1746 23.6622 15.3994 23.4818L15.4166 23.4684C15.4547 23.4386 15.4908 23.4124 15.528 23.3873C15.5832 23.3498 15.6402 23.3152 15.699 23.2835L32.5474 14.3025C32.617 14.2654 32.6948 14.2463 32.7737 14.2469C32.8526 14.2476 32.9301 14.268 32.999 14.3063L36.0278 15.9873C36.1021 16.0286 36.1639 16.0891 36.2067 16.1625C36.2495 16.2359 36.2717 16.3195 36.271 16.4045ZM37.8715 23.7135C37.7615 23.5881 37.6357 23.4776 37.4972 23.3847C37.4881 23.3785 37.479 23.3723 37.4683 23.3653C37.4233 23.336 37.3771 23.3086 37.3298 23.2833L20.4814 14.3024C20.4118 14.2653 20.334 14.2462 20.2551 14.2468C20.1762 14.2475 20.0988 14.2679 20.0298 14.3063L17.001 15.9873C16.9267 16.0285 16.8648 16.089 16.822 16.1624C16.7792 16.2359 16.757 16.3195 16.7577 16.4045C16.7584 16.4895 16.782 16.5727 16.8261 16.6454C16.8702 16.7181 16.933 16.7776 17.0081 16.8175L34.3636 26.0688C34.3877 26.0816 34.4127 26.0923 34.4382 26.1007L34.4968 26.1335V43.3985C34.4968 43.4808 34.5183 43.5616 34.5591 43.6331C34.6 43.7045 34.6587 43.764 34.7296 43.8058C34.8005 43.8475 34.8811 43.87 34.9634 43.8711C35.0457 43.8721 35.1268 43.8517 35.1987 43.8118L38.1069 42.1977C38.1806 42.1567 38.242 42.0968 38.2848 42.0242C38.3276 41.9515 38.3501 41.8687 38.3501 41.7844V24.9835C38.3499 24.5161 38.1798 24.0648 37.8715 23.7135Z" fill="#3688EF"/>
                                                <path d="M32.2361 20.982C32.2361 22.1679 30.7816 23.0285 28.7777 23.0285C27.9604 23.0285 27.2347 22.8852 26.6617 22.6353C26.5885 22.6035 26.5092 22.5883 26.4295 22.5906C26.3498 22.593 26.2715 22.6129 26.2004 22.649C25.6031 22.9504 24.8111 23.1261 23.9067 23.1261C21.9028 23.1261 20.4482 22.2654 20.4482 21.0795C20.4482 20.4825 20.817 19.968 21.4389 19.6041C21.6839 19.4608 21.7868 19.1549 21.6655 18.8983C21.2222 17.9609 21.2364 17.0814 21.7801 16.5377C22.0617 16.2561 22.4473 16.1073 22.8954 16.1073C23.2102 16.1073 23.5521 16.1817 23.9033 16.3214C24.0382 16.3752 24.1889 16.3738 24.3228 16.3174C24.4567 16.2611 24.5631 16.1543 24.619 16.0202C24.98 15.1586 25.5772 14.6279 26.2934 14.6279C26.9973 14.6279 27.5865 15.1406 27.9493 15.9764C28.0697 16.2538 28.3875 16.3862 28.667 16.2708C29.034 16.1194 29.3916 16.0384 29.7199 16.0384C30.2859 16.0384 30.6388 16.2724 30.8352 16.4688C31.3696 17.0032 31.3926 17.8621 30.9722 18.7816C30.8543 19.0395 30.9589 19.3448 31.2058 19.4843C31.8515 19.8491 32.2361 20.3725 32.2361 20.982Z" fill="#2F6BB7"/>
                                            </g>
                                            <circle cx="40.8979" cy="11.7502" r="1.71429" fill="#FF8933"/>
                                            <path d="M11.4777 3.74029C12.0165 3.25521 12.8612 3.74291 12.7105 4.452C12.643 4.76912 12.7875 5.09357 13.0683 5.25567C13.6961 5.61814 13.4933 6.57222 12.7723 6.648C12.4499 6.68189 12.186 6.91954 12.1186 7.23665C11.9678 7.94575 10.9978 8.0477 10.7029 7.38544C10.5711 7.08927 10.2635 6.91169 9.94106 6.94558C9.22009 7.02135 8.82336 6.13029 9.36209 5.64521C9.60302 5.42828 9.67686 5.08088 9.545 4.78471C9.25014 4.12244 9.975 3.46978 10.6028 3.83224C10.8836 3.99434 11.2368 3.95722 11.4777 3.74029Z" fill="#80D5EF"/>
                                            <circle cx="28.1635" cy="1.95428" r="1.71429" fill="white"/>
                                            <path d="M3.66431 30.9826C3.70225 30.2587 4.64441 30.0062 5.03924 30.6142C5.21581 30.8861 5.54739 31.0134 5.86054 30.9295C6.56077 30.7419 7.09201 31.5599 6.6358 32.1233C6.43177 32.3752 6.41318 32.7299 6.58975 33.0018C6.98458 33.6098 6.37075 34.3678 5.69396 34.108C5.39129 33.9918 5.04823 34.0838 4.84421 34.3357C4.38799 34.8991 3.47738 34.5495 3.51532 33.8256C3.53229 33.5018 3.33885 33.204 3.03619 33.0878C2.3594 32.828 2.41045 31.8539 3.11068 31.6663C3.42384 31.5824 3.64735 31.3064 3.66431 30.9826Z" fill="#ABEAB9"/>
                                            <defs>
                                                <clipPath id="clip0_328_4498">
                                                    <rect width="37.2245" height="37.2245" fill="white" transform="translate(7.83691 11.0154)"/>
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600;" class="h-6 flex items-center text-white text-[20px] mb-1">
                                            Claim image
                                        </div>
                                        <div style="font-weight: 400;" class="h-5 text-white text-[16px]">
                                            Claim now!
                                        </div>
                                    </div>
                                    <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                                    </div>
                                </div>
                                @endif

                                <div class="absolute px-2 w-full top-[40%] md:top-[45%] lg:top-[48%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ $gift->brand->company_name }}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ readableDaysLeft($gift->end_date) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="p-3 bg-white rounded-xl ">
                                    <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] mt-5 h-[68px] text-dark-primary flex items-center">
                                        {{$gift->title}}
                                    </div>
                                    <div class="w-full">
                                        <div class="relative h-[4px] bg-gray-200 mb-1">
                                            <div class="absolute top-0 h-[4px] @if($precentageStock > 70) bg-red-500 @elseif($precentageStock > 30) bg-yellow-500 @else bg-[#2C9854] @endif" style="width: {{ $precentageStock }}%;"></div>
                                        </div>
                                        <div class="flex justify-between items-center">
                                            <div style="line-height: 13px" class="text-[#202124] font-normal text-[11px]">
                                                Stock left
                                            </div>
                                            <div style="line-height: 13px" class="text-[10px] font-normal @if($precentageStock > 70) text-red-500 @elseif($precentageStock > 30) text-yellow-500 @else text-[#2C9854] @endif">
                                                {{ $gift->stock - count($gift->claimmed) }} gift left
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex justify-between items-center mt-6">
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_15_1368)">
                                                    <path d="M16.4779 8.59992H13.6201C11.1237 8.59992 9.1001 10.6236 9.1001 13.1199V15.9778C13.0401 15.6856 16.1858 12.5399 16.4779 8.59992Z" fill="#EFB008"/>
                                                    <path d="M7.90007 15.9778V13.1199C7.90007 10.6236 5.87639 8.59992 3.38006 8.59992H0.522217C0.81435 12.5399 3.9601 15.6856 7.90007 15.9778Z" fill="#EFB008"/>
                                                    <path d="M16.4779 7.39992C16.1858 3.45995 13.0401 0.314206 9.1001 0.0220718V2.87991C9.1001 5.37624 11.1237 7.39992 13.6201 7.39992H16.4779Z" fill="#EFB008"/>
                                                    <path d="M7.90007 0.0220718C3.9601 0.314206 0.81435 3.45995 0.522217 7.39992H3.38006C5.87639 7.39992 7.90007 5.37624 7.90007 2.87991V0.0220718Z" fill="#EFB008"/>
                                                    <path d="M5.93323 7.99992C7.04223 7.4458 7.94603 6.542 8.50011 5.433C9.05423 6.542 9.95799 7.4458 11.067 7.99992C9.95799 8.554 9.05423 9.4578 8.50011 10.5668C7.94603 9.4578 7.04223 8.554 5.93323 7.99992Z" fill="#FFDE81"/>
                                                    </g>
                                                    <defs>
                                                    <clipPath id="clip0_15_1368">
                                                    <rect width="16" height="16" fill="white" transform="translate(0.5)"/>
                                                    </clipPath>
                                                    </defs>
                                                </svg>
                                            </div>
                                            <div style="line-height: 22px" class="text-[#976400] font-semibold text-[18px]">
                                                {{ $gift->exchange_rate }} Point
                                            </div>
                                        </div>
                                        <div  style="line-height: 20px" class="bg-[#D83232] rounded-full px-7 py-2 flex items-center justify-center text-white font-bold text-[14px]">
                                            Redeem
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div x-cloak x-show="myCollection" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar relative bg-white">
            <div class="absolute">
                <img src="{{ asset('src/images/bg-profile.png') }}" alt="">
            </div>

            <div class="relative ">
                <div class="relative flex justify-center no-select mt-3">
                    <div style="line-height: 26px;font-weight:400;" class="text-[16px] text-white">
                        Collect Voucher & Gift
                    </div>
                    <div @if($from_dashboard) wire:click="backToDashboard" @else @click="myCollection=false;openClaims=true" @endif  class="absolute left-5 top-1 cursor-pointer">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="white"/>
                        </svg>
                    </div>
                </div>

                <div class="bg-white rounded-t-2xl pt-1 relative mt-10">
                    <div class="w-full h-12 flex items-center justify-between mt-5">
                        <div @click="activeVoucher=true;expiredVoucher=false;usedVoucher=false"  class="w-4/12 px-6 no-select cursor-pointer h-full flex items-center justify-center text-[16px] border-r-[1px]">
                            <div :class="activeVoucher ? 'text-dark-primary font-bold border-b-[#DA0713] border-b-4' : 'text-[#6A6A75] font-light border-none'" class=" py-2">
                                Active
                            </div>
                        </div>
                        <div @click="activeVoucher=false;expiredVoucher=false;usedVoucher=true" class="w-4/12 px-6 py-2 no-select cursor-pointer flex items-center justify-center text-[16px] h-full border-r-[1px]">
                            <div :class="usedVoucher ? 'text-dark-primary font-bold border-b-[#DA0713] border-b-4' : 'text-[#6A6A75] font-light border-none'" class=" py-2">
                                Used
                            </div>
                        </div>
                        <div  @click="activeVoucher=false;expiredVoucher=true;usedVoucher=false" class="w-4/12 px-6 py-2 no-select cursor-pointer h-full flex items-center justify-center text-[16px]">
                            <div :class="expiredVoucher ? 'text-dark-primary font-bold border-b-[#DA0713] border-b-4' : 'text-[#6A6A75] font-light border-none'" class=" py-2">
                                Expired
                            </div>
                        </div>
                    </div>

                    <div class="w-full p-5 min-h-screen">
                        <div x-show="activeVoucher">
                            @foreach ($activeVoucher as $active)
                            <div class=" bg-white shadow-lg rounded-xl  mt-6 cursor-pointer relative" @click="loading=true" wire:click="openDetailActiveVoucher({{ $active['id'] }})">
                                @if($active['claim']['thumbnail_path'])
                                <img src="{{ asset('storage/'. $active['claim']['thumbnail_path']) }}" class="w-[100%] h-full rounded-xl" alt="">
                                @else
                                <div class="relative flex p-5 items-center bg-[#2C9854] overflow-hidden rounded-xl">
                                    <div class="mr-[18px]">
                                        <svg width="46" height="49" viewBox="0 0 46 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_328_4498)">
                                                <path d="M42.1875 39.3087L27.7025 47.3482C27.0076 47.7339 25.8705 47.7339 25.1757 47.3482L10.6906 39.3087C10.3432 39.1159 10.1695 38.8616 10.1695 38.6075H10.0156V20.6479H42.7087V38.6075C42.7087 38.8616 42.535 39.1159 42.1875 39.3087Z" fill="#FE5C5C"/>
                                                <path d="M42.7081 20.6478V38.6073C42.7081 38.8615 42.5344 39.1157 42.187 39.3086L27.7019 47.3481C27.3406 47.5486 26.8598 47.6441 26.3837 47.6359C26.3949 38.6428 26.6506 29.6383 26.3711 20.6477L42.7081 20.6478Z" fill="#FC8B8B"/>
                                                <path d="M25.1751 29.3887L10.6901 21.3491C9.99522 20.9634 9.99522 20.3324 10.6901 19.9467L25.1751 11.9072C25.87 11.5215 27.0071 11.5215 27.7019 11.9072L42.187 19.9467C42.8819 20.3324 42.8819 20.9635 42.187 21.3492L27.702 29.3887C27.0071 29.7744 25.87 29.7744 25.1751 29.3887Z" fill="#FFA9BA"/>
                                                <path d="M36.271 16.4045C36.2703 16.4895 36.2467 16.5727 36.2026 16.6454C36.1586 16.7181 36.0958 16.7775 36.0208 16.8175L18.6653 26.0688C18.6414 26.0815 18.6164 26.0922 18.5907 26.1006L18.532 26.1334V43.3984C18.532 43.4807 18.5106 43.5616 18.4697 43.633C18.4289 43.7044 18.3701 43.764 18.2992 43.8057C18.2283 43.8475 18.1477 43.87 18.0655 43.871C17.9832 43.8721 17.9021 43.8516 17.8301 43.8117L14.922 42.1976C14.8482 42.1567 14.7868 42.0968 14.744 42.0241C14.7013 41.9514 14.6787 41.8687 14.6787 41.7843V24.9835C14.6788 24.6952 14.7436 24.4106 14.8683 24.1507C14.9931 23.8908 15.1746 23.6622 15.3994 23.4818L15.4166 23.4684C15.4547 23.4386 15.4908 23.4124 15.528 23.3873C15.5832 23.3498 15.6402 23.3152 15.699 23.2835L32.5474 14.3025C32.617 14.2654 32.6948 14.2463 32.7737 14.2469C32.8526 14.2476 32.9301 14.268 32.999 14.3063L36.0278 15.9873C36.1021 16.0286 36.1639 16.0891 36.2067 16.1625C36.2495 16.2359 36.2717 16.3195 36.271 16.4045ZM37.8715 23.7135C37.7615 23.5881 37.6357 23.4776 37.4972 23.3847C37.4881 23.3785 37.479 23.3723 37.4683 23.3653C37.4233 23.336 37.3771 23.3086 37.3298 23.2833L20.4814 14.3024C20.4118 14.2653 20.334 14.2462 20.2551 14.2468C20.1762 14.2475 20.0988 14.2679 20.0298 14.3063L17.001 15.9873C16.9267 16.0285 16.8648 16.089 16.822 16.1624C16.7792 16.2359 16.757 16.3195 16.7577 16.4045C16.7584 16.4895 16.782 16.5727 16.8261 16.6454C16.8702 16.7181 16.933 16.7776 17.0081 16.8175L34.3636 26.0688C34.3877 26.0816 34.4127 26.0923 34.4382 26.1007L34.4968 26.1335V43.3985C34.4968 43.4808 34.5183 43.5616 34.5591 43.6331C34.6 43.7045 34.6587 43.764 34.7296 43.8058C34.8005 43.8475 34.8811 43.87 34.9634 43.8711C35.0457 43.8721 35.1268 43.8517 35.1987 43.8118L38.1069 42.1977C38.1806 42.1567 38.242 42.0968 38.2848 42.0242C38.3276 41.9515 38.3501 41.8687 38.3501 41.7844V24.9835C38.3499 24.5161 38.1798 24.0648 37.8715 23.7135Z" fill="#3688EF"/>
                                                <path d="M32.2361 20.982C32.2361 22.1679 30.7816 23.0285 28.7777 23.0285C27.9604 23.0285 27.2347 22.8852 26.6617 22.6353C26.5885 22.6035 26.5092 22.5883 26.4295 22.5906C26.3498 22.593 26.2715 22.6129 26.2004 22.649C25.6031 22.9504 24.8111 23.1261 23.9067 23.1261C21.9028 23.1261 20.4482 22.2654 20.4482 21.0795C20.4482 20.4825 20.817 19.968 21.4389 19.6041C21.6839 19.4608 21.7868 19.1549 21.6655 18.8983C21.2222 17.9609 21.2364 17.0814 21.7801 16.5377C22.0617 16.2561 22.4473 16.1073 22.8954 16.1073C23.2102 16.1073 23.5521 16.1817 23.9033 16.3214C24.0382 16.3752 24.1889 16.3738 24.3228 16.3174C24.4567 16.2611 24.5631 16.1543 24.619 16.0202C24.98 15.1586 25.5772 14.6279 26.2934 14.6279C26.9973 14.6279 27.5865 15.1406 27.9493 15.9764C28.0697 16.2538 28.3875 16.3862 28.667 16.2708C29.034 16.1194 29.3916 16.0384 29.7199 16.0384C30.2859 16.0384 30.6388 16.2724 30.8352 16.4688C31.3696 17.0032 31.3926 17.8621 30.9722 18.7816C30.8543 19.0395 30.9589 19.3448 31.2058 19.4843C31.8515 19.8491 32.2361 20.3725 32.2361 20.982Z" fill="#2F6BB7"/>
                                            </g>
                                            <circle cx="40.8979" cy="11.7502" r="1.71429" fill="#FF8933"/>
                                            <path d="M11.4777 3.74029C12.0165 3.25521 12.8612 3.74291 12.7105 4.452C12.643 4.76912 12.7875 5.09357 13.0683 5.25567C13.6961 5.61814 13.4933 6.57222 12.7723 6.648C12.4499 6.68189 12.186 6.91954 12.1186 7.23665C11.9678 7.94575 10.9978 8.0477 10.7029 7.38544C10.5711 7.08927 10.2635 6.91169 9.94106 6.94558C9.22009 7.02135 8.82336 6.13029 9.36209 5.64521C9.60302 5.42828 9.67686 5.08088 9.545 4.78471C9.25014 4.12244 9.975 3.46978 10.6028 3.83224C10.8836 3.99434 11.2368 3.95722 11.4777 3.74029Z" fill="#80D5EF"/>
                                            <circle cx="28.1635" cy="1.95428" r="1.71429" fill="white"/>
                                            <path d="M3.66431 30.9826C3.70225 30.2587 4.64441 30.0062 5.03924 30.6142C5.21581 30.8861 5.54739 31.0134 5.86054 30.9295C6.56077 30.7419 7.09201 31.5599 6.6358 32.1233C6.43177 32.3752 6.41318 32.7299 6.58975 33.0018C6.98458 33.6098 6.37075 34.3678 5.69396 34.108C5.39129 33.9918 5.04823 34.0838 4.84421 34.3357C4.38799 34.8991 3.47738 34.5495 3.51532 33.8256C3.53229 33.5018 3.33885 33.204 3.03619 33.0878C2.3594 32.828 2.41045 31.8539 3.11068 31.6663C3.42384 31.5824 3.64735 31.3064 3.66431 30.9826Z" fill="#ABEAB9"/>
                                            <defs>
                                                <clipPath id="clip0_328_4498">
                                                    <rect width="37.2245" height="37.2245" fill="white" transform="translate(7.83691 11.0154)"/>
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600;" class="h-6 flex items-center text-white text-[20px] mb-1">
                                            Claim image
                                        </div>
                                        <div style="font-weight: 400;" class="h-5 text-white text-[16px]">
                                            Claim now!
                                        </div>
                                    </div>
                                    <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                                    </div>
                                </div>
                                @endif

                                <div class="absolute px-2 w-full top-[50%] md:top-[60%] lg:top-[60%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ $active['claim']['brand']['company_name'] }}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                @if($active['claim']['change_type_id'] == 1)
                                                Valid until {{ readableDaysLeft($active['valid_until']) }}
                                                @else
                                                Unlimited
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="p-3 bg-white rounded-b-lg ">
                                    <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] mt-5 h-[68px] text-dark-primary flex items-center">
                                        {{$active['claim']['title']}}
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>

                        <div x-show="usedVoucher">
                            @foreach ($usedVoucher as $voucher)
                            <div class=" bg-white shadow-lg rounded-xl  mt-6 cursor-pointer relative" @click="loading=true" wire:click="openDetailUsedVoucher({{ $voucher['id'] }})">
                                @if($voucher['claim']['thumbnail_path'])
                                <img src="{{ asset('storage/'. $voucher['claim']['thumbnail_path']) }}" class="w-[100%] h-full rounded-xl" alt="">
                                @else
                                <div class="relative flex p-5 items-center bg-[#2C9854] overflow-hidden rounded-xl">
                                    <div class="mr-[18px]">
                                        <svg width="46" height="49" viewBox="0 0 46 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_328_4498)">
                                                <path d="M42.1875 39.3087L27.7025 47.3482C27.0076 47.7339 25.8705 47.7339 25.1757 47.3482L10.6906 39.3087C10.3432 39.1159 10.1695 38.8616 10.1695 38.6075H10.0156V20.6479H42.7087V38.6075C42.7087 38.8616 42.535 39.1159 42.1875 39.3087Z" fill="#FE5C5C"/>
                                                <path d="M42.7081 20.6478V38.6073C42.7081 38.8615 42.5344 39.1157 42.187 39.3086L27.7019 47.3481C27.3406 47.5486 26.8598 47.6441 26.3837 47.6359C26.3949 38.6428 26.6506 29.6383 26.3711 20.6477L42.7081 20.6478Z" fill="#FC8B8B"/>
                                                <path d="M25.1751 29.3887L10.6901 21.3491C9.99522 20.9634 9.99522 20.3324 10.6901 19.9467L25.1751 11.9072C25.87 11.5215 27.0071 11.5215 27.7019 11.9072L42.187 19.9467C42.8819 20.3324 42.8819 20.9635 42.187 21.3492L27.702 29.3887C27.0071 29.7744 25.87 29.7744 25.1751 29.3887Z" fill="#FFA9BA"/>
                                                <path d="M36.271 16.4045C36.2703 16.4895 36.2467 16.5727 36.2026 16.6454C36.1586 16.7181 36.0958 16.7775 36.0208 16.8175L18.6653 26.0688C18.6414 26.0815 18.6164 26.0922 18.5907 26.1006L18.532 26.1334V43.3984C18.532 43.4807 18.5106 43.5616 18.4697 43.633C18.4289 43.7044 18.3701 43.764 18.2992 43.8057C18.2283 43.8475 18.1477 43.87 18.0655 43.871C17.9832 43.8721 17.9021 43.8516 17.8301 43.8117L14.922 42.1976C14.8482 42.1567 14.7868 42.0968 14.744 42.0241C14.7013 41.9514 14.6787 41.8687 14.6787 41.7843V24.9835C14.6788 24.6952 14.7436 24.4106 14.8683 24.1507C14.9931 23.8908 15.1746 23.6622 15.3994 23.4818L15.4166 23.4684C15.4547 23.4386 15.4908 23.4124 15.528 23.3873C15.5832 23.3498 15.6402 23.3152 15.699 23.2835L32.5474 14.3025C32.617 14.2654 32.6948 14.2463 32.7737 14.2469C32.8526 14.2476 32.9301 14.268 32.999 14.3063L36.0278 15.9873C36.1021 16.0286 36.1639 16.0891 36.2067 16.1625C36.2495 16.2359 36.2717 16.3195 36.271 16.4045ZM37.8715 23.7135C37.7615 23.5881 37.6357 23.4776 37.4972 23.3847C37.4881 23.3785 37.479 23.3723 37.4683 23.3653C37.4233 23.336 37.3771 23.3086 37.3298 23.2833L20.4814 14.3024C20.4118 14.2653 20.334 14.2462 20.2551 14.2468C20.1762 14.2475 20.0988 14.2679 20.0298 14.3063L17.001 15.9873C16.9267 16.0285 16.8648 16.089 16.822 16.1624C16.7792 16.2359 16.757 16.3195 16.7577 16.4045C16.7584 16.4895 16.782 16.5727 16.8261 16.6454C16.8702 16.7181 16.933 16.7776 17.0081 16.8175L34.3636 26.0688C34.3877 26.0816 34.4127 26.0923 34.4382 26.1007L34.4968 26.1335V43.3985C34.4968 43.4808 34.5183 43.5616 34.5591 43.6331C34.6 43.7045 34.6587 43.764 34.7296 43.8058C34.8005 43.8475 34.8811 43.87 34.9634 43.8711C35.0457 43.8721 35.1268 43.8517 35.1987 43.8118L38.1069 42.1977C38.1806 42.1567 38.242 42.0968 38.2848 42.0242C38.3276 41.9515 38.3501 41.8687 38.3501 41.7844V24.9835C38.3499 24.5161 38.1798 24.0648 37.8715 23.7135Z" fill="#3688EF"/>
                                                <path d="M32.2361 20.982C32.2361 22.1679 30.7816 23.0285 28.7777 23.0285C27.9604 23.0285 27.2347 22.8852 26.6617 22.6353C26.5885 22.6035 26.5092 22.5883 26.4295 22.5906C26.3498 22.593 26.2715 22.6129 26.2004 22.649C25.6031 22.9504 24.8111 23.1261 23.9067 23.1261C21.9028 23.1261 20.4482 22.2654 20.4482 21.0795C20.4482 20.4825 20.817 19.968 21.4389 19.6041C21.6839 19.4608 21.7868 19.1549 21.6655 18.8983C21.2222 17.9609 21.2364 17.0814 21.7801 16.5377C22.0617 16.2561 22.4473 16.1073 22.8954 16.1073C23.2102 16.1073 23.5521 16.1817 23.9033 16.3214C24.0382 16.3752 24.1889 16.3738 24.3228 16.3174C24.4567 16.2611 24.5631 16.1543 24.619 16.0202C24.98 15.1586 25.5772 14.6279 26.2934 14.6279C26.9973 14.6279 27.5865 15.1406 27.9493 15.9764C28.0697 16.2538 28.3875 16.3862 28.667 16.2708C29.034 16.1194 29.3916 16.0384 29.7199 16.0384C30.2859 16.0384 30.6388 16.2724 30.8352 16.4688C31.3696 17.0032 31.3926 17.8621 30.9722 18.7816C30.8543 19.0395 30.9589 19.3448 31.2058 19.4843C31.8515 19.8491 32.2361 20.3725 32.2361 20.982Z" fill="#2F6BB7"/>
                                            </g>
                                            <circle cx="40.8979" cy="11.7502" r="1.71429" fill="#FF8933"/>
                                            <path d="M11.4777 3.74029C12.0165 3.25521 12.8612 3.74291 12.7105 4.452C12.643 4.76912 12.7875 5.09357 13.0683 5.25567C13.6961 5.61814 13.4933 6.57222 12.7723 6.648C12.4499 6.68189 12.186 6.91954 12.1186 7.23665C11.9678 7.94575 10.9978 8.0477 10.7029 7.38544C10.5711 7.08927 10.2635 6.91169 9.94106 6.94558C9.22009 7.02135 8.82336 6.13029 9.36209 5.64521C9.60302 5.42828 9.67686 5.08088 9.545 4.78471C9.25014 4.12244 9.975 3.46978 10.6028 3.83224C10.8836 3.99434 11.2368 3.95722 11.4777 3.74029Z" fill="#80D5EF"/>
                                            <circle cx="28.1635" cy="1.95428" r="1.71429" fill="white"/>
                                            <path d="M3.66431 30.9826C3.70225 30.2587 4.64441 30.0062 5.03924 30.6142C5.21581 30.8861 5.54739 31.0134 5.86054 30.9295C6.56077 30.7419 7.09201 31.5599 6.6358 32.1233C6.43177 32.3752 6.41318 32.7299 6.58975 33.0018C6.98458 33.6098 6.37075 34.3678 5.69396 34.108C5.39129 33.9918 5.04823 34.0838 4.84421 34.3357C4.38799 34.8991 3.47738 34.5495 3.51532 33.8256C3.53229 33.5018 3.33885 33.204 3.03619 33.0878C2.3594 32.828 2.41045 31.8539 3.11068 31.6663C3.42384 31.5824 3.64735 31.3064 3.66431 30.9826Z" fill="#ABEAB9"/>
                                            <defs>
                                                <clipPath id="clip0_328_4498">
                                                    <rect width="37.2245" height="37.2245" fill="white" transform="translate(7.83691 11.0154)"/>
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600;" class="h-6 flex items-center text-white text-[20px] mb-1">
                                            Claim already used
                                        </div>
                                    </div>
                                    <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                                    </div>
                                </div>
                                @endif

                                <div class="absolute px-2 w-full top-[50%] md:top-[60%] lg:top-[60%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{$voucher['claim']['brand']['company_name']}}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ date("d M Y", strtotime($voucher['use_date'])) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="p-3 bg-white rounded-b-lg ">
                                    <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] mt-5 h-[68px] text-dark-primary flex items-center">
                                        {{ $voucher['claim']['title'] }}
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>

                        <div x-show="expiredVoucher">
                            @foreach ($expiredVoucher as $voucher)
                            <div class=" bg-white shadow-lg rounded-xl mt-6 cursor-pointer relative" @click="loading=true" wire:click="openDetailExpiredVoucher({{ $voucher['id'] }})">
                                @if($voucher['claim']['thumbnail_path'])
                                <img src="{{ asset('storage/'. $voucher['claim']['thumbnail_path']) }}" class="w-[100%] h-full rounded-xl" alt="">
                                @else
                                <div class="relative flex p-5 items-center bg-[#2C9854] overflow-hidden rounded-t-xl">
                                    <div class="mr-[18px]">
                                        <svg width="46" height="49" viewBox="0 0 46 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_328_4498)">
                                                <path d="M42.1875 39.3087L27.7025 47.3482C27.0076 47.7339 25.8705 47.7339 25.1757 47.3482L10.6906 39.3087C10.3432 39.1159 10.1695 38.8616 10.1695 38.6075H10.0156V20.6479H42.7087V38.6075C42.7087 38.8616 42.535 39.1159 42.1875 39.3087Z" fill="#FE5C5C"/>
                                                <path d="M42.7081 20.6478V38.6073C42.7081 38.8615 42.5344 39.1157 42.187 39.3086L27.7019 47.3481C27.3406 47.5486 26.8598 47.6441 26.3837 47.6359C26.3949 38.6428 26.6506 29.6383 26.3711 20.6477L42.7081 20.6478Z" fill="#FC8B8B"/>
                                                <path d="M25.1751 29.3887L10.6901 21.3491C9.99522 20.9634 9.99522 20.3324 10.6901 19.9467L25.1751 11.9072C25.87 11.5215 27.0071 11.5215 27.7019 11.9072L42.187 19.9467C42.8819 20.3324 42.8819 20.9635 42.187 21.3492L27.702 29.3887C27.0071 29.7744 25.87 29.7744 25.1751 29.3887Z" fill="#FFA9BA"/>
                                                <path d="M36.271 16.4045C36.2703 16.4895 36.2467 16.5727 36.2026 16.6454C36.1586 16.7181 36.0958 16.7775 36.0208 16.8175L18.6653 26.0688C18.6414 26.0815 18.6164 26.0922 18.5907 26.1006L18.532 26.1334V43.3984C18.532 43.4807 18.5106 43.5616 18.4697 43.633C18.4289 43.7044 18.3701 43.764 18.2992 43.8057C18.2283 43.8475 18.1477 43.87 18.0655 43.871C17.9832 43.8721 17.9021 43.8516 17.8301 43.8117L14.922 42.1976C14.8482 42.1567 14.7868 42.0968 14.744 42.0241C14.7013 41.9514 14.6787 41.8687 14.6787 41.7843V24.9835C14.6788 24.6952 14.7436 24.4106 14.8683 24.1507C14.9931 23.8908 15.1746 23.6622 15.3994 23.4818L15.4166 23.4684C15.4547 23.4386 15.4908 23.4124 15.528 23.3873C15.5832 23.3498 15.6402 23.3152 15.699 23.2835L32.5474 14.3025C32.617 14.2654 32.6948 14.2463 32.7737 14.2469C32.8526 14.2476 32.9301 14.268 32.999 14.3063L36.0278 15.9873C36.1021 16.0286 36.1639 16.0891 36.2067 16.1625C36.2495 16.2359 36.2717 16.3195 36.271 16.4045ZM37.8715 23.7135C37.7615 23.5881 37.6357 23.4776 37.4972 23.3847C37.4881 23.3785 37.479 23.3723 37.4683 23.3653C37.4233 23.336 37.3771 23.3086 37.3298 23.2833L20.4814 14.3024C20.4118 14.2653 20.334 14.2462 20.2551 14.2468C20.1762 14.2475 20.0988 14.2679 20.0298 14.3063L17.001 15.9873C16.9267 16.0285 16.8648 16.089 16.822 16.1624C16.7792 16.2359 16.757 16.3195 16.7577 16.4045C16.7584 16.4895 16.782 16.5727 16.8261 16.6454C16.8702 16.7181 16.933 16.7776 17.0081 16.8175L34.3636 26.0688C34.3877 26.0816 34.4127 26.0923 34.4382 26.1007L34.4968 26.1335V43.3985C34.4968 43.4808 34.5183 43.5616 34.5591 43.6331C34.6 43.7045 34.6587 43.764 34.7296 43.8058C34.8005 43.8475 34.8811 43.87 34.9634 43.8711C35.0457 43.8721 35.1268 43.8517 35.1987 43.8118L38.1069 42.1977C38.1806 42.1567 38.242 42.0968 38.2848 42.0242C38.3276 41.9515 38.3501 41.8687 38.3501 41.7844V24.9835C38.3499 24.5161 38.1798 24.0648 37.8715 23.7135Z" fill="#3688EF"/>
                                                <path d="M32.2361 20.982C32.2361 22.1679 30.7816 23.0285 28.7777 23.0285C27.9604 23.0285 27.2347 22.8852 26.6617 22.6353C26.5885 22.6035 26.5092 22.5883 26.4295 22.5906C26.3498 22.593 26.2715 22.6129 26.2004 22.649C25.6031 22.9504 24.8111 23.1261 23.9067 23.1261C21.9028 23.1261 20.4482 22.2654 20.4482 21.0795C20.4482 20.4825 20.817 19.968 21.4389 19.6041C21.6839 19.4608 21.7868 19.1549 21.6655 18.8983C21.2222 17.9609 21.2364 17.0814 21.7801 16.5377C22.0617 16.2561 22.4473 16.1073 22.8954 16.1073C23.2102 16.1073 23.5521 16.1817 23.9033 16.3214C24.0382 16.3752 24.1889 16.3738 24.3228 16.3174C24.4567 16.2611 24.5631 16.1543 24.619 16.0202C24.98 15.1586 25.5772 14.6279 26.2934 14.6279C26.9973 14.6279 27.5865 15.1406 27.9493 15.9764C28.0697 16.2538 28.3875 16.3862 28.667 16.2708C29.034 16.1194 29.3916 16.0384 29.7199 16.0384C30.2859 16.0384 30.6388 16.2724 30.8352 16.4688C31.3696 17.0032 31.3926 17.8621 30.9722 18.7816C30.8543 19.0395 30.9589 19.3448 31.2058 19.4843C31.8515 19.8491 32.2361 20.3725 32.2361 20.982Z" fill="#2F6BB7"/>
                                            </g>
                                            <circle cx="40.8979" cy="11.7502" r="1.71429" fill="#FF8933"/>
                                            <path d="M11.4777 3.74029C12.0165 3.25521 12.8612 3.74291 12.7105 4.452C12.643 4.76912 12.7875 5.09357 13.0683 5.25567C13.6961 5.61814 13.4933 6.57222 12.7723 6.648C12.4499 6.68189 12.186 6.91954 12.1186 7.23665C11.9678 7.94575 10.9978 8.0477 10.7029 7.38544C10.5711 7.08927 10.2635 6.91169 9.94106 6.94558C9.22009 7.02135 8.82336 6.13029 9.36209 5.64521C9.60302 5.42828 9.67686 5.08088 9.545 4.78471C9.25014 4.12244 9.975 3.46978 10.6028 3.83224C10.8836 3.99434 11.2368 3.95722 11.4777 3.74029Z" fill="#80D5EF"/>
                                            <circle cx="28.1635" cy="1.95428" r="1.71429" fill="white"/>
                                            <path d="M3.66431 30.9826C3.70225 30.2587 4.64441 30.0062 5.03924 30.6142C5.21581 30.8861 5.54739 31.0134 5.86054 30.9295C6.56077 30.7419 7.09201 31.5599 6.6358 32.1233C6.43177 32.3752 6.41318 32.7299 6.58975 33.0018C6.98458 33.6098 6.37075 34.3678 5.69396 34.108C5.39129 33.9918 5.04823 34.0838 4.84421 34.3357C4.38799 34.8991 3.47738 34.5495 3.51532 33.8256C3.53229 33.5018 3.33885 33.204 3.03619 33.0878C2.3594 32.828 2.41045 31.8539 3.11068 31.6663C3.42384 31.5824 3.64735 31.3064 3.66431 30.9826Z" fill="#ABEAB9"/>
                                            <defs>
                                                <clipPath id="clip0_328_4498">
                                                    <rect width="37.2245" height="37.2245" fill="white" transform="translate(7.83691 11.0154)"/>
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600;" class="h-6 flex items-center text-white text-[20px] mb-1">
                                            Claim expired
                                        </div>
                                    </div>
                                    <div class="absolute w-[152px] h-[152px] bg-[#DDF1E2] opacity-10 rounded-full -left-19 left-[-78px]">

                                    </div>
                                </div>
                                @endif

                                <div class="absolute px-2 w-full top-[50%] md:top-[60%] lg:top-[60%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{$voucher['claim']['brand']['company_name']}}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                Expired since {{ date("d M Y", strtotime($voucher['valid_until'])) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="p-3 bg-white rounded-xl ">
                                    <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] mt-5 h-[68px] text-dark-primary flex items-center">
                                        {{$voucher['claim']['title']}}
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
{{--
    <div x-cloak x-show ="myCollection" class="w-screen md:w-full md:max-w-md max-w-full h-screen bg-white  max-h-screen overflow-auto flex flex-col">
        <div class="flex-none">
            <div class="w-full flex p-5">
                <div @if($from_dashboard) wire:click="backToDashboard" @else @click="myCollection=false;openClaims=true" @endif class="flex items-center no-select cursor-pointer">
                    <div class="mr-1">
                        <div class="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21">
                            <path class="fill-primary " d="M8.45306 6.63482C8.65228 6.83014 8.65228 7.15435 8.45697 7.35357L6.08588 9.73248H15.121C15.3984 9.73248 15.6249 9.95904 15.6249 10.2403C15.6249 10.5215 15.3984 10.7481 15.121 10.7481H6.08588L8.46088 13.127C8.65619 13.3262 8.65228 13.6465 8.45697 13.8458C8.25775 14.0411 7.94134 14.0411 7.74213 13.8419L4.52338 10.5997C4.48041 10.5528 4.44525 10.502 4.41791 10.4395C4.39056 10.377 4.37885 10.3106 4.37885 10.2442C4.37885 10.1114 4.42963 9.98639 4.52338 9.88873L7.74213 6.64654C7.93353 6.44342 8.25384 6.43951 8.45306 6.63482Z"/>
                            </svg>
                        </div>
                    </div>
                    <div style="font-weight: 600;" class="text-primary text-[16px]">
                        Kembali
                    </div>
                </div>
            </div>
        </div>

        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar bg-[#F5F7F9] " x-ref="scrollContainer">
            <div class="w-full border-b-2 bg-white ">
                <div class="w-full px-5">
                    <div class="py-4">
                        <div class="w-full">
                            <div style="font-weight: 600;" class="mb-2 text-[20px] text-dark-primary">
                                Koleksi Voucher & Hadiah
                            </div>
                        </div>
                    </div>
                    <div class="w-full flex mt-5 py-5">
                        <div style="font-weight: 400;" @click="activeVoucher=true;expiredVoucher=false;usedVoucher=false" :class="activeVoucher ? 'bg-[#EAF2FA] border-primary text-primary' : 'bg-none border-gray-500 text-dark-primary'" class="no-select cursor-pointer flex items-center justify-center py-2 px-3 border  rounded-full  text-[14px] mr-3">
                            <div class="h-5 flex items-center justify-center">
                                Aktif
                            </div>
                        </div>
                        <div style="font-weight: 400;" @click="activeVoucher=false;expiredVoucher=false;usedVoucher=true" :class="usedVoucher ? 'bg-[#EAF2FA] border-primary text-primary' : 'bg-none border-gray-500 text-dark-primary'" class="no-select cursor-pointer flex items-center justify-center py-2 px-3 border rounded-full text-[14px] mr-3">
                            <div class="h-5 flex items-center justify-center">
                                Terpakai
                            </div>
                        </div>
                        <div style="font-weight: 400;" @click="activeVoucher=false;expiredVoucher=true;usedVoucher=false" :class="expiredVoucher ? 'bg-[#EAF2FA] border-primary text-primary' : 'bg-none border-gray-500 text-dark-primary'" class="no-select cursor-pointer flex items-center justify-center py-2 px-3 border rounded-full text-[14px] mr-3">
                            <div class="h-5 flex items-center justify-center">
                                Hangus
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="w-full p-5">
                <div x-show="activeVoucher">

                    @foreach ($activeVoucher as $active)
                    <div @click="loading=true" wire:click="openDetailActiveVoucher({{ $active['id'] }})" class="w-full cursor-pointer bg-white  rounded-sm mb-5">
                        <div class="relative border border-[#EDEDED]  rounded-t-sm">
                            @if($active['claim']['thumbnail_path'])
                            <img src="{{ asset('storage/'. $active['claim']['thumbnail_path']) }}" class="w-full  " alt="">
                            @else
                            <div class="w-full flex items-center justify-center h-[102px] bg-[#EAEFF3]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="71" height="70" viewBox="0 0 71 70" fill="none">
                                    <path d="M15.0833 61.25C13.4792 61.25 12.1054 60.6783 10.9621 59.535C9.81875 58.3917 9.24806 57.0189 9.25 55.4167V14.5833C9.25 12.9792 9.82167 11.6054 10.965 10.4621C12.1083 9.31875 13.4811 8.74806 15.0833 8.75H55.9167C57.5208 8.75 58.8946 9.32167 60.0379 10.465C61.1813 11.6083 61.752 12.9811 61.75 14.5833V55.4167C61.75 57.0208 61.1783 58.3946 60.035 59.5379C58.8917 60.6813 57.5189 61.252 55.9167 61.25H15.0833ZM18 49.5833H53L42.0625 35L33.3125 46.6667L26.75 37.9167L18 49.5833Z" fill="#D6DADF"/>
                                </svg>
                            </div>
                            @endif
                            <div class="absolute top-0 h-10 p-2 bg-white  flex items-center rounded-br-2xl">
                                <div class="w-6 h-6 rounded-full  {{ $active['claim']['claim_type_id'] == 1 ? '#E5EDFA' : 'bg-[#FAE4E4]' }} flex items-center justify-center mr-[6px]">
                                    @if($active['claim']['claim_type_id'] == 1)
                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
                                        <path d="M10.5 2.73999H1.5C1.36739 2.73999 1.24021 2.79267 1.14645 2.88644C1.05268 2.98021 1 3.10738 1 3.23999V5.23999H1.4465C1.9445 5.23999 2.4065 5.58049 2.4865 6.07199C2.51087 6.21551 2.50363 6.36262 2.46528 6.50305C2.42693 6.64348 2.3584 6.77385 2.26447 6.88507C2.17054 6.99628 2.05347 7.08566 1.92143 7.14696C1.7894 7.20826 1.64557 7.24001 1.5 7.23999H1V9.23999C1 9.3726 1.05268 9.49978 1.14645 9.59354C1.24021 9.68731 1.36739 9.73999 1.5 9.73999H10.5C10.6326 9.73999 10.7598 9.68731 10.8536 9.59354C10.9473 9.49978 11 9.3726 11 9.23999V7.23999H10.5C10.3544 7.24001 10.2106 7.20826 10.0786 7.14696C9.94653 7.08566 9.82946 6.99628 9.73553 6.88507C9.6416 6.77385 9.57307 6.64348 9.53472 6.50305C9.49637 6.36262 9.48913 6.21551 9.5135 6.07199C9.5935 5.58049 10.0555 5.23999 10.5535 5.23999H11V3.23999C11 3.10738 10.9473 2.98021 10.8536 2.88644C10.7598 2.79267 10.6326 2.73999 10.5 2.73999ZM5.5 8.73999H4.5V7.73999H5.5V8.73999ZM5.5 6.73999H4.5V5.73999H5.5V6.73999ZM5.5 4.73999H4.5V3.73999H5.5V4.73999Z" fill="#3688EF"/>
                                    </svg>
                                    @else
                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
                                        <path d="M4.53 1.2051C3.585 1.2001 2.665 2.1101 3.085 3.2401H1.5C1.23478 3.2401 0.98043 3.34546 0.792893 3.53299C0.605357 3.72053 0.5 3.97488 0.5 4.2401V5.2401C0.5 5.37271 0.552678 5.49988 0.646447 5.59365C0.740215 5.68742 0.867392 5.7401 1 5.7401H5.5V4.2401H6.5V5.7401H11C11.1326 5.7401 11.2598 5.68742 11.3536 5.59365C11.4473 5.49988 11.5 5.37271 11.5 5.2401V4.2401C11.5 3.97488 11.3946 3.72053 11.2071 3.53299C11.0196 3.34546 10.7652 3.2401 10.5 3.2401H8.915C9.5 1.6051 7.3 0.450099 6.285 1.8601L6 2.2401L5.715 1.8501C5.4 1.4051 4.965 1.2101 4.53 1.2051ZM4.5 2.2401C4.945 2.2401 5.17 2.7801 4.855 3.0951C4.54 3.4101 4 3.1851 4 2.7401C4 2.60749 4.05268 2.48031 4.14645 2.38655C4.24021 2.29278 4.36739 2.2401 4.5 2.2401ZM7.5 2.2401C7.945 2.2401 8.17 2.7801 7.855 3.0951C7.54 3.4101 7 3.1851 7 2.7401C7 2.60749 7.05268 2.48031 7.14645 2.38655C7.24021 2.29278 7.36739 2.2401 7.5 2.2401ZM1 6.2401V10.2401C1 10.5053 1.10536 10.7597 1.29289 10.9472C1.48043 11.1347 1.73478 11.2401 2 11.2401H10C10.2652 11.2401 10.5196 11.1347 10.7071 10.9472C10.8946 10.7597 11 10.5053 11 10.2401V6.2401H6.5V10.2401H5.5V6.2401H1Z" fill="#FE5C5C"/>
                                    </svg>
                                    @endif
                                </div>
                                <div style="font-weight: 400;" class="h-5 flex items-center">
                                    {{ isset($active['claim']['claimType']) ?  $active['claim']['claimType']['name'] : $active['claim']['claim_type']['name']}}
                                </div>
                            </div>
                            <div class="p-3 max-w-full">
                                <div style="font-weight: 600;" class="w-full h-5 flex items-center text-[16px] text-dark-primary">
                                    {{$active['claim']['title']}}
                                </div>
                                <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]  mt-[2px] line-clamp-2">
                                    {{$active['claim']['description']}}
                                </div>
                            </div>
                            <div class="w-full flex items-center h-5 px-3 mt-3">
                                <div class="mr-[3px]">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none">
                                        <path d="M8.99219 0.115234C4.50781 0.115234 0.875 3.75586 0.875 8.24023C0.875 12.7246 4.50781 16.3652 8.99219 16.3652C13.4844 16.3652 17.125 12.7246 17.125 8.24023C17.125 3.75586 13.4844 0.115234 8.99219 0.115234ZM9 14.7402C5.41016 14.7402 2.5 11.8301 2.5 8.24023C2.5 4.65039 5.41016 1.74023 9 1.74023C12.5898 1.74023 15.5 4.65039 15.5 8.24023C15.5 11.8301 12.5898 14.7402 9 14.7402Z" fill="#6A6A75"/>
                                        <path d="M9.40625 4.17773H8.1875V9.05273L12.4531 11.6113L13.0625 10.6113L9.40625 8.44336V4.17773Z" fill="#6A6A75"/>
                                    </svg>
                                </div>
                                <div style="font-weight: 400;" class="text-[14px] text-dark-primary">
                                    @if($active['claim']['change_type_id'] == 1)
                                    Berakhir {{ readableDaysLeft($active['valid_until']) }}
                                    @else
                                    Tidak ada batas
                                    @endif
                                </div>
                            </div>
                            <div class="w-full flex items-center h-5 px-3 my-3">
                                <div class="mr-[3px]">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                                        <path d="M2.5 17.7402H4.16667M4.16667 17.7402H15.8333M4.16667 17.7402V8.01357M17.5 17.7402H15.8333M15.8333 17.7402V8.01357M4.16667 8.01357C4.13551 7.99567 4.10494 7.97677 4.075 7.9569L3.625 7.6569C3.30688 7.44471 3.0714 7.12958 2.95806 6.76437C2.84472 6.39916 2.86041 6.00608 3.0025 5.65107L3.7475 3.78773C3.87124 3.47849 4.0848 3.21341 4.36063 3.0267C4.63647 2.83999 4.96192 2.74021 5.295 2.74023H14.705C15.0381 2.74021 15.3635 2.83999 15.6394 3.0267C15.9152 3.21341 16.1288 3.47849 16.2525 3.78773L16.9975 5.65107C17.1396 6.00608 17.1553 6.39916 17.0419 6.76437C16.9286 7.12958 16.6931 7.44471 16.375 7.6569L15.925 7.9569C15.8951 7.97677 15.8645 7.99567 15.8333 8.01357M4.16667 8.01357C4.43587 8.16905 4.7432 8.24614 5.05392 8.23613C5.36464 8.22612 5.66636 8.1294 5.925 7.9569L7.5 6.9069L9.075 7.9569C9.34888 8.13963 9.67075 8.23715 10 8.23715C10.3292 8.23715 10.6511 8.13963 10.925 7.9569L12.5 6.9069L14.075 7.9569C14.3336 8.1294 14.6354 8.22612 14.9461 8.23613C15.2568 8.24614 15.5641 8.16905 15.8333 8.01357" stroke="#6A6A75" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M11.6668 17.7401V13.5734C11.6668 13.1314 11.4912 12.7075 11.1787 12.3949C10.8661 12.0823 10.4422 11.9067 10.0002 11.9067C9.55814 11.9067 9.13421 12.0823 8.82165 12.3949C8.50909 12.7075 8.3335 13.1314 8.3335 13.5734V17.7401" stroke="#6A6A75" stroke-width="1.5"/>
                                    </svg>
                                </div>
                                <div style="font-weight: 400;" class="text-[14px] text-dark-primary">
                                    {{ $active['claim']['brand']['company_name'] }}
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>

                <div x-show="usedVoucher">

                    @foreach ($usedVoucher as $voucher)
                    <div click="loading=true" wire:click="openDetailUsedVoucher({{ $voucher['id'] }})" class="w-full cursor-pointer bg-white  rounded-sm mb-5">
                        <div class="relative border border-[#EDEDED]  rounded-t-sm">
                            @if($voucher['claim']['thumbnail_path'])
                            <img src="{{ asset('storage/'. $voucher['claim']['thumbnail_path']) }}" class="w-full  " alt="">
                            @else
                            <div class="w-full flex items-center justify-center h-[102px] bg-[#EAEFF3]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="71" height="70" viewBox="0 0 71 70" fill="none">
                                    <path d="M15.0833 61.25C13.4792 61.25 12.1054 60.6783 10.9621 59.535C9.81875 58.3917 9.24806 57.0189 9.25 55.4167V14.5833C9.25 12.9792 9.82167 11.6054 10.965 10.4621C12.1083 9.31875 13.4811 8.74806 15.0833 8.75H55.9167C57.5208 8.75 58.8946 9.32167 60.0379 10.465C61.1813 11.6083 61.752 12.9811 61.75 14.5833V55.4167C61.75 57.0208 61.1783 58.3946 60.035 59.5379C58.8917 60.6813 57.5189 61.252 55.9167 61.25H15.0833ZM18 49.5833H53L42.0625 35L33.3125 46.6667L26.75 37.9167L18 49.5833Z" fill="#D6DADF"/>
                                </svg>
                            </div>
                            @endif
                            <div class="absolute top-0 h-10 p-2 bg-white  flex items-center rounded-br-2xl">
                                <div class="w-6 h-6 rounded-full  {{$voucher['claim']['claim_type_id'] == 1 ? '#E5EDFA' : 'bg-[#FAE4E4]' }} flex items-center justify-center mr-[6px]">
                                    @if($voucher['claim']['claim_type_id'] == 1)
                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
                                        <path d="M10.5 2.73999H1.5C1.36739 2.73999 1.24021 2.79267 1.14645 2.88644C1.05268 2.98021 1 3.10738 1 3.23999V5.23999H1.4465C1.9445 5.23999 2.4065 5.58049 2.4865 6.07199C2.51087 6.21551 2.50363 6.36262 2.46528 6.50305C2.42693 6.64348 2.3584 6.77385 2.26447 6.88507C2.17054 6.99628 2.05347 7.08566 1.92143 7.14696C1.7894 7.20826 1.64557 7.24001 1.5 7.23999H1V9.23999C1 9.3726 1.05268 9.49978 1.14645 9.59354C1.24021 9.68731 1.36739 9.73999 1.5 9.73999H10.5C10.6326 9.73999 10.7598 9.68731 10.8536 9.59354C10.9473 9.49978 11 9.3726 11 9.23999V7.23999H10.5C10.3544 7.24001 10.2106 7.20826 10.0786 7.14696C9.94653 7.08566 9.82946 6.99628 9.73553 6.88507C9.6416 6.77385 9.57307 6.64348 9.53472 6.50305C9.49637 6.36262 9.48913 6.21551 9.5135 6.07199C9.5935 5.58049 10.0555 5.23999 10.5535 5.23999H11V3.23999C11 3.10738 10.9473 2.98021 10.8536 2.88644C10.7598 2.79267 10.6326 2.73999 10.5 2.73999ZM5.5 8.73999H4.5V7.73999H5.5V8.73999ZM5.5 6.73999H4.5V5.73999H5.5V6.73999ZM5.5 4.73999H4.5V3.73999H5.5V4.73999Z" fill="#3688EF"/>
                                    </svg>
                                    @else
                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
                                        <path d="M4.53 1.2051C3.585 1.2001 2.665 2.1101 3.085 3.2401H1.5C1.23478 3.2401 0.98043 3.34546 0.792893 3.53299C0.605357 3.72053 0.5 3.97488 0.5 4.2401V5.2401C0.5 5.37271 0.552678 5.49988 0.646447 5.59365C0.740215 5.68742 0.867392 5.7401 1 5.7401H5.5V4.2401H6.5V5.7401H11C11.1326 5.7401 11.2598 5.68742 11.3536 5.59365C11.4473 5.49988 11.5 5.37271 11.5 5.2401V4.2401C11.5 3.97488 11.3946 3.72053 11.2071 3.53299C11.0196 3.34546 10.7652 3.2401 10.5 3.2401H8.915C9.5 1.6051 7.3 0.450099 6.285 1.8601L6 2.2401L5.715 1.8501C5.4 1.4051 4.965 1.2101 4.53 1.2051ZM4.5 2.2401C4.945 2.2401 5.17 2.7801 4.855 3.0951C4.54 3.4101 4 3.1851 4 2.7401C4 2.60749 4.05268 2.48031 4.14645 2.38655C4.24021 2.29278 4.36739 2.2401 4.5 2.2401ZM7.5 2.2401C7.945 2.2401 8.17 2.7801 7.855 3.0951C7.54 3.4101 7 3.1851 7 2.7401C7 2.60749 7.05268 2.48031 7.14645 2.38655C7.24021 2.29278 7.36739 2.2401 7.5 2.2401ZM1 6.2401V10.2401C1 10.5053 1.10536 10.7597 1.29289 10.9472C1.48043 11.1347 1.73478 11.2401 2 11.2401H10C10.2652 11.2401 10.5196 11.1347 10.7071 10.9472C10.8946 10.7597 11 10.5053 11 10.2401V6.2401H6.5V10.2401H5.5V6.2401H1Z" fill="#FE5C5C"/>
                                    </svg>
                                    @endif
                                </div>
                                <div style="font-weight: 400;" class="h-5 flex items-center">
                                    {{ isset($voucher['claim']['claimType']) ?  $voucher['claim']['claimType']['name'] : $voucher['claim']['claim_type']['name']}}
                                </div>
                            </div>
                            <div class="p-3 max-w-full">
                                <div style="font-weight: 600;" class="w-full h-5 flex items-center text-[16px] text-dark-primary">
                                    {{ $voucher['claim']['title'] }}
                                </div>
                                <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]  mt-[2px] line-clamp-2">
                                    {{$voucher['claim']['description']}}
                                </div>
                            </div>
                            <div class="w-full flex items-center h-5 px-3 mt-3">
                                <div class="mr-[3px]">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none">
                                        <path d="M8.99219 0.115234C4.50781 0.115234 0.875 3.75586 0.875 8.24023C0.875 12.7246 4.50781 16.3652 8.99219 16.3652C13.4844 16.3652 17.125 12.7246 17.125 8.24023C17.125 3.75586 13.4844 0.115234 8.99219 0.115234ZM9 14.7402C5.41016 14.7402 2.5 11.8301 2.5 8.24023C2.5 4.65039 5.41016 1.74023 9 1.74023C12.5898 1.74023 15.5 4.65039 15.5 8.24023C15.5 11.8301 12.5898 14.7402 9 14.7402Z" fill="#6A6A75"/>
                                        <path d="M9.40625 4.17773H8.1875V9.05273L12.4531 11.6113L13.0625 10.6113L9.40625 8.44336V4.17773Z" fill="#6A6A75"/>
                                    </svg>
                                </div>
                                <div style="font-weight: 400;" class="text-[14px] text-dark-primary">
                                    Terpakai tanggal {{ date("d M Y", strtotime($voucher['use_date'])) }}
                                </div>
                            </div>
                            <div class="w-full flex items-center h-5 px-3 my-3">
                                <div class="mr-[3px]">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                                        <path d="M2.5 17.7402H4.16667M4.16667 17.7402H15.8333M4.16667 17.7402V8.01357M17.5 17.7402H15.8333M15.8333 17.7402V8.01357M4.16667 8.01357C4.13551 7.99567 4.10494 7.97677 4.075 7.9569L3.625 7.6569C3.30688 7.44471 3.0714 7.12958 2.95806 6.76437C2.84472 6.39916 2.86041 6.00608 3.0025 5.65107L3.7475 3.78773C3.87124 3.47849 4.0848 3.21341 4.36063 3.0267C4.63647 2.83999 4.96192 2.74021 5.295 2.74023H14.705C15.0381 2.74021 15.3635 2.83999 15.6394 3.0267C15.9152 3.21341 16.1288 3.47849 16.2525 3.78773L16.9975 5.65107C17.1396 6.00608 17.1553 6.39916 17.0419 6.76437C16.9286 7.12958 16.6931 7.44471 16.375 7.6569L15.925 7.9569C15.8951 7.97677 15.8645 7.99567 15.8333 8.01357M4.16667 8.01357C4.43587 8.16905 4.7432 8.24614 5.05392 8.23613C5.36464 8.22612 5.66636 8.1294 5.925 7.9569L7.5 6.9069L9.075 7.9569C9.34888 8.13963 9.67075 8.23715 10 8.23715C10.3292 8.23715 10.6511 8.13963 10.925 7.9569L12.5 6.9069L14.075 7.9569C14.3336 8.1294 14.6354 8.22612 14.9461 8.23613C15.2568 8.24614 15.5641 8.16905 15.8333 8.01357" stroke="#6A6A75" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M11.6668 17.7401V13.5734C11.6668 13.1314 11.4912 12.7075 11.1787 12.3949C10.8661 12.0823 10.4422 11.9067 10.0002 11.9067C9.55814 11.9067 9.13421 12.0823 8.82165 12.3949C8.50909 12.7075 8.3335 13.1314 8.3335 13.5734V17.7401" stroke="#6A6A75" stroke-width="1.5"/>
                                    </svg>
                                </div>
                                <div style="font-weight: 400;" class="text-[14px] text-dark-primary">
                                    {{$voucher['claim']['brand']['company_name']}}
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>

                <div x-show="expiredVoucher">
                    @foreach ($expiredVoucher as $voucher)
                    <div @click="loading=true" wire:click="openDetailExpiredVoucher({{ $voucher['id'] }})" class="w-full cursor-pointer bg-white  rounded-sm mb-5">
                        <div class="relative border border-[#EDEDED]  rounded-t-sm">
                            @if($voucher['claim']['thumbnail_path'])
                            <img src="{{ asset('storage/'. $voucher['claim']['thumbnail_path']) }}" class="w-full  " alt="">
                            @else
                            <div class="w-full flex items-center justify-center h-[102px] bg-[#EAEFF3]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="71" height="70" viewBox="0 0 71 70" fill="none">
                                    <path d="M15.0833 61.25C13.4792 61.25 12.1054 60.6783 10.9621 59.535C9.81875 58.3917 9.24806 57.0189 9.25 55.4167V14.5833C9.25 12.9792 9.82167 11.6054 10.965 10.4621C12.1083 9.31875 13.4811 8.74806 15.0833 8.75H55.9167C57.5208 8.75 58.8946 9.32167 60.0379 10.465C61.1813 11.6083 61.752 12.9811 61.75 14.5833V55.4167C61.75 57.0208 61.1783 58.3946 60.035 59.5379C58.8917 60.6813 57.5189 61.252 55.9167 61.25H15.0833ZM18 49.5833H53L42.0625 35L33.3125 46.6667L26.75 37.9167L18 49.5833Z" fill="#D6DADF"/>
                                </svg>
                            </div>
                            @endif
                            <div class="absolute top-0 h-10 p-2 bg-white  flex items-center rounded-br-2xl">
                                <div class="w-6 h-6 rounded-full  {{$voucher['claim']['claim_type_id'] == 1 ? '#E5EDFA' : 'bg-[#FAE4E4]' }} flex items-center justify-center mr-[6px]">
                                    @if($voucher['claim']['claim_type_id'] == 1)
                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
                                        <path d="M10.5 2.73999H1.5C1.36739 2.73999 1.24021 2.79267 1.14645 2.88644C1.05268 2.98021 1 3.10738 1 3.23999V5.23999H1.4465C1.9445 5.23999 2.4065 5.58049 2.4865 6.07199C2.51087 6.21551 2.50363 6.36262 2.46528 6.50305C2.42693 6.64348 2.3584 6.77385 2.26447 6.88507C2.17054 6.99628 2.05347 7.08566 1.92143 7.14696C1.7894 7.20826 1.64557 7.24001 1.5 7.23999H1V9.23999C1 9.3726 1.05268 9.49978 1.14645 9.59354C1.24021 9.68731 1.36739 9.73999 1.5 9.73999H10.5C10.6326 9.73999 10.7598 9.68731 10.8536 9.59354C10.9473 9.49978 11 9.3726 11 9.23999V7.23999H10.5C10.3544 7.24001 10.2106 7.20826 10.0786 7.14696C9.94653 7.08566 9.82946 6.99628 9.73553 6.88507C9.6416 6.77385 9.57307 6.64348 9.53472 6.50305C9.49637 6.36262 9.48913 6.21551 9.5135 6.07199C9.5935 5.58049 10.0555 5.23999 10.5535 5.23999H11V3.23999C11 3.10738 10.9473 2.98021 10.8536 2.88644C10.7598 2.79267 10.6326 2.73999 10.5 2.73999ZM5.5 8.73999H4.5V7.73999H5.5V8.73999ZM5.5 6.73999H4.5V5.73999H5.5V6.73999ZM5.5 4.73999H4.5V3.73999H5.5V4.73999Z" fill="#3688EF"/>
                                    </svg>
                                    @else
                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
                                        <path d="M4.53 1.2051C3.585 1.2001 2.665 2.1101 3.085 3.2401H1.5C1.23478 3.2401 0.98043 3.34546 0.792893 3.53299C0.605357 3.72053 0.5 3.97488 0.5 4.2401V5.2401C0.5 5.37271 0.552678 5.49988 0.646447 5.59365C0.740215 5.68742 0.867392 5.7401 1 5.7401H5.5V4.2401H6.5V5.7401H11C11.1326 5.7401 11.2598 5.68742 11.3536 5.59365C11.4473 5.49988 11.5 5.37271 11.5 5.2401V4.2401C11.5 3.97488 11.3946 3.72053 11.2071 3.53299C11.0196 3.34546 10.7652 3.2401 10.5 3.2401H8.915C9.5 1.6051 7.3 0.450099 6.285 1.8601L6 2.2401L5.715 1.8501C5.4 1.4051 4.965 1.2101 4.53 1.2051ZM4.5 2.2401C4.945 2.2401 5.17 2.7801 4.855 3.0951C4.54 3.4101 4 3.1851 4 2.7401C4 2.60749 4.05268 2.48031 4.14645 2.38655C4.24021 2.29278 4.36739 2.2401 4.5 2.2401ZM7.5 2.2401C7.945 2.2401 8.17 2.7801 7.855 3.0951C7.54 3.4101 7 3.1851 7 2.7401C7 2.60749 7.05268 2.48031 7.14645 2.38655C7.24021 2.29278 7.36739 2.2401 7.5 2.2401ZM1 6.2401V10.2401C1 10.5053 1.10536 10.7597 1.29289 10.9472C1.48043 11.1347 1.73478 11.2401 2 11.2401H10C10.2652 11.2401 10.5196 11.1347 10.7071 10.9472C10.8946 10.7597 11 10.5053 11 10.2401V6.2401H6.5V10.2401H5.5V6.2401H1Z" fill="#FE5C5C"/>
                                    </svg>
                                    @endif
                                </div>
                                <div style="font-weight: 400;" class="h-5 flex items-center">
                                    {{ isset($voucher['claim']['claimType']) ?  $voucher['claim']['claimType']['name'] : $voucher['claim']['claim_type']['name']}}
                                </div>
                            </div>
                            <div class="p-3 max-w-full">
                                <div style="font-weight: 600;" class="w-full h-5 flex items-center text-[16px] text-dark-primary">
                                    {{$voucher['claim']['title']}}
                                </div>
                                <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]  mt-[2px] line-clamp-2">
                                    {{$voucher['claim']['description']}}
                                </div>
                            </div>
                            <div class="w-full flex items-center h-5 px-3 mt-3">
                                <div class="mr-[3px]">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none">
                                        <path d="M8.99219 0.115234C4.50781 0.115234 0.875 3.75586 0.875 8.24023C0.875 12.7246 4.50781 16.3652 8.99219 16.3652C13.4844 16.3652 17.125 12.7246 17.125 8.24023C17.125 3.75586 13.4844 0.115234 8.99219 0.115234ZM9 14.7402C5.41016 14.7402 2.5 11.8301 2.5 8.24023C2.5 4.65039 5.41016 1.74023 9 1.74023C12.5898 1.74023 15.5 4.65039 15.5 8.24023C15.5 11.8301 12.5898 14.7402 9 14.7402Z" fill="#6A6A75"/>
                                        <path d="M9.40625 4.17773H8.1875V9.05273L12.4531 11.6113L13.0625 10.6113L9.40625 8.44336V4.17773Z" fill="#6A6A75"/>
                                    </svg>
                                </div>
                                <div style="font-weight: 400;" class="text-[14px] text-dark-primary">
                                    Hangus sejak {{ date("d M Y", strtotime($voucher['valid_until'])) }}
                                </div>
                            </div>
                            <div class="w-full flex items-center h-5 px-3 my-3">
                                <div class="mr-[3px]">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                                        <path d="M2.5 17.7402H4.16667M4.16667 17.7402H15.8333M4.16667 17.7402V8.01357M17.5 17.7402H15.8333M15.8333 17.7402V8.01357M4.16667 8.01357C4.13551 7.99567 4.10494 7.97677 4.075 7.9569L3.625 7.6569C3.30688 7.44471 3.0714 7.12958 2.95806 6.76437C2.84472 6.39916 2.86041 6.00608 3.0025 5.65107L3.7475 3.78773C3.87124 3.47849 4.0848 3.21341 4.36063 3.0267C4.63647 2.83999 4.96192 2.74021 5.295 2.74023H14.705C15.0381 2.74021 15.3635 2.83999 15.6394 3.0267C15.9152 3.21341 16.1288 3.47849 16.2525 3.78773L16.9975 5.65107C17.1396 6.00608 17.1553 6.39916 17.0419 6.76437C16.9286 7.12958 16.6931 7.44471 16.375 7.6569L15.925 7.9569C15.8951 7.97677 15.8645 7.99567 15.8333 8.01357M4.16667 8.01357C4.43587 8.16905 4.7432 8.24614 5.05392 8.23613C5.36464 8.22612 5.66636 8.1294 5.925 7.9569L7.5 6.9069L9.075 7.9569C9.34888 8.13963 9.67075 8.23715 10 8.23715C10.3292 8.23715 10.6511 8.13963 10.925 7.9569L12.5 6.9069L14.075 7.9569C14.3336 8.1294 14.6354 8.22612 14.9461 8.23613C15.2568 8.24614 15.5641 8.16905 15.8333 8.01357" stroke="#6A6A75" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M11.6668 17.7401V13.5734C11.6668 13.1314 11.4912 12.7075 11.1787 12.3949C10.8661 12.0823 10.4422 11.9067 10.0002 11.9067C9.55814 11.9067 9.13421 12.0823 8.82165 12.3949C8.50909 12.7075 8.3335 13.1314 8.3335 13.5734V17.7401" stroke="#6A6A75" stroke-width="1.5"/>
                                    </svg>
                                </div>
                                <div style="font-weight: 400;" class="text-[14px] text-dark-primary">
                                    {{$voucher['claim']['brand']['company_name']}}
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div> --}}

    <x-layouts.customer.navbar :currentPage="$currentPage" />

    <div x-cloak x-show="openDetailClaim" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        @if($detailClaim)
        <div class="flex-1 overflow-y-auto hide-scrollbar relative">
            <div class="relative mt-5">
                <div style="position: relative" class="flex flex-col min-h-screen overflow-hidden">
                    <div class="flex-1">
                        <div class="px-8">
                            <div class="relative flex justify-center no-select">
                                <div style="line-height: 26px;font-weight:400;" class="text-[16px]">
                                    Voucher Detail
                                </div>
                                <div @if($open_claim) onclick="redirectTo('{{ route('dashboard') }}')" @elseif($from_voucher_dashboard) onclick="redirectTo('{{ route('dashboard') }}')" @else @click="openClaims=true;openDetailClaim=false;exchangeConfirm=false" @endif  class="absolute left-0 top-1 cursor-pointer">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                                    </svg>
                                </div>
                            </div>
                            <div class="relative mt-5">
                                @if($detailClaim->thumbnail_path)
                                <img src="{{ asset('storage/'. $detailClaim->thumbnail_path) }}" class="w-full rounded-lg shadow-lg" alt="">
                                @else
                                <div class="w-full flex items-center justify-center h-[135px] bg-[#EAEFF3]  rounded-lg shadow-lg">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="71" height="70" viewBox="0 0 71 70" fill="none">
                                        <path d="M15.0833 61.25C13.4792 61.25 12.1054 60.6783 10.9621 59.535C9.81875 58.3917 9.24806 57.0189 9.25 55.4167V14.5833C9.25 12.9792 9.82167 11.6054 10.965 10.4621C12.1083 9.31875 13.4811 8.74806 15.0833 8.75H55.9167C57.5208 8.75 58.8946 9.32167 60.0379 10.465C61.1813 11.6083 61.752 12.9811 61.75 14.5833V55.4167C61.75 57.0208 61.1783 58.3946 60.035 59.5379C58.8917 60.6813 57.5189 61.252 55.9167 61.25H15.0833ZM18 49.5833H53L42.0625 35L33.3125 46.6667L26.75 37.9167L18 49.5833Z" fill="#D6DADF"/>
                                    </svg>
                                </div>
                                @endif
                                <div class="absolute px-2 w-full top-[38%] md:top-[45%] lg:top-[47%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{$detailClaim->brand->company_name}}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                Until {{changeDateFormat($detailClaim->end_date)}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="p-3 max-w-full">
                                    <div class="px-3 mt-3 border-b">
                                        <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] h-[48px] flex items-center">
                                            {{$detailClaim->title}}
                                        </div>
                                    </div>
                                    <div class="mt-2 flex flex-col gap-2">
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Valid Until
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] font-normal">
                                                {{ changeDateFormat($detailClaim->end_date) }}
                                            </div>
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Stock left
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] {{ $detailClaim->stock - count($detailClaim->claimmed) < 10 ? 'text-[#DA0713]' : 'text-[#2C9854]' }} font-normal">
                                                {{ $detailClaim->stock - count($detailClaim->claimmed) }} Voucher lagi
                                            </div>
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Change limit
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] font-normal">
                                                @if($detailClaim->limit == 0) Unlimited @else {{ $detailClaim->limit }}X redeem @endif/person
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="relative">
                            <img src="{{ asset('src/images/bg-profile.png') }}" class="w-full h-[150px]" alt="">
                            <div  style="top: 30px" class="absolute w-full">
                                <div class=" px-5">
                                    <div @click="openListStores=true" class="flex bg-white p-3 mb-4 border border-white   rounded-lg shadow-lg w-full justify-between items-center no-select cursor-pointer">
                                        <div class="flex items-center">
                                            <div class="flex items-center justify-center mr-2">
                                                <img src="{{ asset('src/images/cabang.png') }}" class="w-[32px] h-[32px]" alt="">
                                            </div>
                                            <div class="max-w-[300px]">
                                                <div style="font-weight:600;line-height:20px" class="mb-1 flex items-center text-[16px] text-[#DA0814] truncate">
                                                    {{ $detailClaim->brand->company_name }}
                                                </div>
                                                <div style="font-weight: 400;" class="h-5 flex items-center text-[#6A6A75]  text-[14px] truncate">
                                                    Can be purchased at {{ count($detailClaim->claimStores) }} branches store
                                                </div>
                                            </div>
                                        </div>
                                        <div class="h-5 w-5 flex items-center justify-center">
                                            <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M11.9883 10L7.02344 5.03906C6.65625 4.67188 6.65625 4.07812 7.02344 3.71484C7.39062 3.35156 7.98438 3.35156 8.35156 3.71484L13.9766 9.33594C14.332 9.69141 14.3398 10.2617 14.0039 10.6289L8.35547 16.2891C8.17188 16.4727 7.92969 16.5625 7.69141 16.5625C7.45313 16.5625 7.21094 16.4727 7.02734 16.2891C6.66016 15.9219 6.66016 15.3281 7.02734 14.9648L11.9883 10Z" fill="#DA0814"/>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="px-8 pt-9 lg:pt-7 rounded-t-2xl -mt-[15px] relative bg-white">
                            <div style="line-height: 20px" class="text-[16px] font-semibold mb-4">
                                How to use voucher
                            </div>
                            <div style="line-height: 20px" class="text-[13px] font-normal mb-3">
                                {{$detailClaim->description}}
                            </div>
                        </div>
                    </div>
                    <div style="box-shadow: 0 30px 30px 30px rgba(0, 0, 0, 0.1);" class="bg-white  relative px-5 pt-3 pb-7 flex items-center justify-center justify-between shadow-lg">
                        <div class="flex justify-center flex-col gap-1">
                            <div style="line-height:20px" class="text-[12px] font-normal">
                                Point
                            </div>
                            <div class="flex gap-1 items-center">
                                <div>
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_15_1722)">
                                        <path d="M15.9779 8.59991H13.1201C10.6237 8.59991 8.6001 10.6236 8.6001 13.1199V15.9778C12.5401 15.6856 15.6858 12.5399 15.9779 8.59991Z" fill="#EFB008"/>
                                        <path d="M7.40007 15.9778V13.1199C7.40007 10.6236 5.37639 8.59991 2.88006 8.59991H0.0222168C0.31435 12.5399 3.4601 15.6856 7.40007 15.9778Z" fill="#EFB008"/>
                                        <path d="M15.9779 7.39994C15.6858 3.45997 12.5401 0.314228 8.6001 0.0220947V2.87993C8.6001 5.37626 10.6237 7.39994 13.1201 7.39994H15.9779Z" fill="#EFB008"/>
                                        <path d="M7.40007 0.0220947C3.4601 0.314228 0.31435 3.45997 0.0222168 7.39994H2.88006C5.37639 7.39994 7.40007 5.37626 7.40007 2.87993V0.0220947Z" fill="#EFB008"/>
                                        <path d="M5.43323 7.9999C6.54223 7.44578 7.44603 6.54198 8.00011 5.43298C8.55423 6.54198 9.45799 7.44578 10.567 7.9999C9.45799 8.55398 8.55423 9.45778 8.00011 10.5668C7.44603 9.45778 6.54223 8.55398 5.43323 7.9999Z" fill="#FFDE81"/>
                                        </g>
                                        <defs>
                                        <clipPath id="clip0_15_1722">
                                        <rect width="16" height="16" fill="white"/>
                                        </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div style="line-height: 22px" class="text-[18px] font-semibold text-[#976400]">
                                    <span style="line-height: 22px" class="font-semibold text-[18px]">{{$detailClaim->exchange_rate}}</span> Point
                                </div>
                            </div>
                        </div>
                        <div style="line-height: 24px" @click="exchangeConfirm=true" class=" no-select cursor-pointer rounded-2xl py-3 w-[151px] text-white bg-[#DA0713] flex items-center justify-center font-bold text-[14px]">
                            Redeem
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="exchangeConfirm" style="z-index: 80" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        @if($detailClaim)
        <div @click.outside="exchangeConfirm=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5">
                <div class="w-full flex justify-between items-center mb-[18px]">
                    <div>
                        <div style="font-weight: 600;" class="text-[18px] mb-[2px] text-dark-secondary">
                            Confirmation
                        </div>
                        <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] ">
                            Are you sure want to redeem it?
                        </div>
                    </div>
                    <div @click="exchangeConfirm=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
                <div class="w-full flex items-center justify-between p-3 border rounded-sm  ">
                    <div class="flex items-center">
                        <div>
                            <div class="w-8 h-8 rounded-full mr-2 {{ ($detailClaim->claim_type_id == 1) ? 'bg-[#E5EDFA]' : 'bg-[#FAE4E4]'}} flex items-center justify-center">
                                @if ($detailClaim->claim_type_id == 1)
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
                                    <path d="M10.5 2.74023H1.5C1.36739 2.74023 1.24021 2.79291 1.14645 2.88668C1.05268 2.98045 1 3.10763 1 3.24023V5.24023H1.4465C1.9445 5.24023 2.4065 5.58073 2.4865 6.07223C2.51087 6.21575 2.50363 6.36286 2.46528 6.50329C2.42693 6.64372 2.3584 6.7741 2.26447 6.88531C2.17054 6.99652 2.05347 7.0859 1.92143 7.1472C1.7894 7.2085 1.64557 7.24025 1.5 7.24023H1V9.24023C1 9.37284 1.05268 9.50002 1.14645 9.59379C1.24021 9.68756 1.36739 9.74023 1.5 9.74023H10.5C10.6326 9.74023 10.7598 9.68756 10.8536 9.59379C10.9473 9.50002 11 9.37284 11 9.24023V7.24023H10.5C10.3544 7.24025 10.2106 7.2085 10.0786 7.1472C9.94653 7.0859 9.82946 6.99652 9.73553 6.88531C9.6416 6.7741 9.57307 6.64372 9.53472 6.50329C9.49637 6.36286 9.48913 6.21575 9.5135 6.07223C9.5935 5.58073 10.0555 5.24023 10.5535 5.24023H11V3.24023C11 3.10763 10.9473 2.98045 10.8536 2.88668C10.7598 2.79291 10.6326 2.74023 10.5 2.74023ZM5.5 8.74023H4.5V7.74023H5.5V8.74023ZM5.5 6.74023H4.5V5.74023H5.5V6.74023ZM5.5 4.74023H4.5V3.74023H5.5V4.74023Z" fill="#3688EF"/>
                                </svg>
                                @else
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="17" viewBox="0 0 16 17" fill="none">
                                    <path d="M6.03996 1.52664C4.77996 1.51997 3.55329 2.73331 4.11329 4.23997H1.99996C1.64634 4.23997 1.3072 4.38045 1.05715 4.6305C0.807102 4.88054 0.666626 5.21968 0.666626 5.57331V6.90664C0.666626 7.08345 0.736864 7.25302 0.861888 7.37804C0.986912 7.50307 1.15648 7.57331 1.33329 7.57331H7.33329V5.57331H8.66663V7.57331H14.6666C14.8434 7.57331 15.013 7.50307 15.138 7.37804C15.2631 7.25302 15.3333 7.08345 15.3333 6.90664V5.57331C15.3333 5.21968 15.1928 4.88054 14.9428 4.6305C14.6927 4.38045 14.3536 4.23997 14 4.23997H11.8866C12.6666 2.05997 9.73329 0.519972 8.37996 2.39997L7.99996 2.90664L7.61996 2.38664C7.19996 1.79331 6.61996 1.53331 6.03996 1.52664ZM5.99996 2.90664C6.59329 2.90664 6.89329 3.62664 6.47329 4.04664C6.05329 4.46664 5.33329 4.16664 5.33329 3.57331C5.33329 3.39649 5.40353 3.22693 5.52855 3.1019C5.65358 2.97688 5.82315 2.90664 5.99996 2.90664ZM9.99996 2.90664C10.5933 2.90664 10.8933 3.62664 10.4733 4.04664C10.0533 4.46664 9.33329 4.16664 9.33329 3.57331C9.33329 3.39649 9.40353 3.22693 9.52855 3.1019C9.65358 2.97688 9.82315 2.90664 9.99996 2.90664ZM1.33329 8.23997V13.5733C1.33329 13.9269 1.47377 14.2661 1.72382 14.5161C1.97387 14.7662 2.313 14.9066 2.66663 14.9066H13.3333C13.6869 14.9066 14.0261 14.7662 14.2761 14.5161C14.5262 14.2661 14.6666 13.9269 14.6666 13.5733V8.23997H8.66663V13.5733H7.33329V8.23997H1.33329Z" fill="#FE5C5C"/>
                                </svg>
                                @endif

                            </div>
                        </div>
                        <div class="max-w-[200px]">
                            <div style="font-weight: 600;" class="text-[16px] text-dark-primary flex items-center h-5 truncate">
                                {{$detailClaim->title}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-dark-primary flex items-center h-5">
                                End date {{ readableDaysLeft($detailClaim->end_date) }}
                            </div>
                        </div>
                    </div>
                    <div class="flex border   rounded-full max-w-[100px] px-2 py-1 truncate">
                        <div class="mr-1 w-5 h-5 flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M10.0042 18.3359C5.40166 18.3359 1.67083 14.605 1.67083 10.0025C1.67083 5.40002 5.40166 1.66919 10.0042 1.66919C14.6067 1.66919 18.3375 5.40002 18.3375 10.0025C18.3375 14.605 14.6067 18.3359 10.0042 18.3359ZM10.0042 6.46669L6.46833 10.0025L10.0042 13.5384L13.5392 10.0025L10.0042 6.46669Z" fill="#FFA858"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M10.0041 5.28811L14.7174 10.0025L10.0041 14.7169L5.28973 10.0025L10.0041 5.28811ZM2.50407 10.0025C2.50407 14.1448 5.86181 17.5025 10.0041 17.5025C14.1463 17.5025 17.5041 14.1448 17.5041 10.0025C17.5041 5.86026 14.1463 2.50252 10.0041 2.50252C5.86181 2.50252 2.50407 5.86026 2.50407 10.0025ZM6.46824 10.0025L10.0041 6.46669L13.5391 10.0025L10.0041 13.5384L6.46824 10.0025ZM1.67074 10.0025C1.67074 14.605 5.40157 18.3359 10.0041 18.3359C14.6066 18.3359 18.3374 14.605 18.3374 10.0025C18.3374 5.40002 14.6066 1.66919 10.0041 1.66919C5.40157 1.66919 1.67074 5.40002 1.67074 10.0025Z" fill="#DF812B"/>
                            </svg>
                        </div>
                        <div style="font-weight: 400;" class="h-5 text-[14px] text-dark-primary flex items-center justify-center">
                            {{$detailClaim->exchange_rate}} pts
                        </div>
                    </div>
                </div>

                <div class="flex rounded-b-sm p-3 w-full mt-10 justify-between items-center">
                    <div @click="exchangeConfirm=false" style="font-weight: 600;" class="text-primary border rounded-sm   no-select cursor-pointer flex items-center justify-center text-[16px] w-6/12 h-[46px]">
                        Cancel
                    </div>
                    <div wire:click="savePoint()" @click="loading=true" style="font-weight: 600;" class="w-6/12 h-[46px] text-[16px] text-white no-select cursor-pointer flex bg-primary ml-3 items-center justify-center rounded-sm">
                        Yes
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="openListStores" style="z-index: 80" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        @if($detailClaim)
        <div @click.outside="openListStores=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5 max-h-[400px] flex flex-col">
                <div class="flex-none">
                    <div class="w-full flex justify-between items-center mb-[18px]">
                        <div>
                            <div style="font-weight: 600;" class="text-[18px] mb-[2px] text-dark-primary">
                                {{$detailClaim->brand->company_name}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]">
                                Here are the branches you can find
                            </div>
                        </div>
                        <div @click="openListStores=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="flex-1 overflow-y-auto hide-scrollbar">
                @foreach ($detailClaim->claimStores as $claimStore)
                    <div class="w-full py-3 mt-[18px] flex">
                        <div class="mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M15.75 4.50019C15.7499 3.79065 15.5486 3.09568 15.1693 2.49601C14.79 1.89634 14.2484 1.41658 13.6074 1.11245C12.9663 0.808312 12.2521 0.692291 11.5478 0.777859C10.8434 0.863427 10.1778 1.14707 9.62818 1.59585C9.07859 2.04462 8.66759 2.64011 8.44293 3.31315C8.21828 3.98619 8.18917 4.70915 8.359 5.39807C8.52884 6.08699 8.89063 6.71358 9.40237 7.20508C9.91411 7.69659 10.5548 8.03282 11.25 8.17472V21.4483C11.2501 21.6476 11.2898 21.8448 11.3667 22.0286L11.8388 23.1536C11.8546 23.1826 11.8779 23.2067 11.9063 23.2236C11.9346 23.2404 11.967 23.2493 12 23.2493C12.033 23.2493 12.0654 23.2404 12.0937 23.2236C12.1221 23.2067 12.1454 23.1826 12.1613 23.1536L12.6333 22.0286C12.7102 21.8448 12.7499 21.6476 12.75 21.4483V8.17472C13.5964 8.00078 14.357 7.54032 14.9035 6.87096C15.4499 6.20161 15.7489 5.3643 15.75 4.50019ZM13.125 4.50019C12.9025 4.50019 12.685 4.43421 12.5 4.3106C12.315 4.18698 12.1708 4.01128 12.0856 3.80571C12.0005 3.60015 11.9782 3.37395 12.0216 3.15572C12.065 2.93749 12.1722 2.73703 12.3295 2.5797C12.4868 2.42236 12.6873 2.31522 12.9055 2.27181C13.1238 2.2284 13.35 2.25068 13.5555 2.33583C13.7611 2.42098 13.9368 2.56517 14.0604 2.75018C14.184 2.93518 14.25 3.15269 14.25 3.37519C14.25 3.67356 14.1315 3.95971 13.9205 4.17069C13.7095 4.38167 13.4234 4.50019 13.125 4.50019Z" fill="#FE5C5C"/>
                            </svg>
                        </div>
                        <div class="max-w-[330px]">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary mb-2 h-6 flex items-center truncate">
                                {{$claimStore->store->name}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] h-10 items-center line-clamp-2">
                                {{$claimStore->store->address}}, {{$claimStore->store->urban_village}}, {{$claimStore->store->subdistrict}}, {{ $claimStore->store->city }}, {{$claimStore->store->province}} ({{$claimStore->store->postal_code}})
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="openListActiveStores"style="z-index: 90" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        @if($detailActiveVoucher)
        <div @click.outside="openListActiveStores=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5 max-h-[400px] flex flex-col">
                <div class="flex-none">
                    <div class="w-full flex justify-between items-center mb-[18px]">
                        <div>
                            <div style="font-weight: 600;" class="text-[18px] mb-[2px] text-dark-primary">
                                {{$detailActiveVoucher->claim->brand->company_name}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]">
                                Here are the branches you can find
                            </div>
                        </div>
                        <div @click="openListActiveStores=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="flex-1 overflow-y-auto hide-scrollbar">
                @foreach ($detailActiveVoucher->claim->claimStores as $claimStore)
                    <div class="w-full py-3 mt-[18px] flex">
                        <div class="mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M15.75 4.50019C15.7499 3.79065 15.5486 3.09568 15.1693 2.49601C14.79 1.89634 14.2484 1.41658 13.6074 1.11245C12.9663 0.808312 12.2521 0.692291 11.5478 0.777859C10.8434 0.863427 10.1778 1.14707 9.62818 1.59585C9.07859 2.04462 8.66759 2.64011 8.44293 3.31315C8.21828 3.98619 8.18917 4.70915 8.359 5.39807C8.52884 6.08699 8.89063 6.71358 9.40237 7.20508C9.91411 7.69659 10.5548 8.03282 11.25 8.17472V21.4483C11.2501 21.6476 11.2898 21.8448 11.3667 22.0286L11.8388 23.1536C11.8546 23.1826 11.8779 23.2067 11.9063 23.2236C11.9346 23.2404 11.967 23.2493 12 23.2493C12.033 23.2493 12.0654 23.2404 12.0937 23.2236C12.1221 23.2067 12.1454 23.1826 12.1613 23.1536L12.6333 22.0286C12.7102 21.8448 12.7499 21.6476 12.75 21.4483V8.17472C13.5964 8.00078 14.357 7.54032 14.9035 6.87096C15.4499 6.20161 15.7489 5.3643 15.75 4.50019ZM13.125 4.50019C12.9025 4.50019 12.685 4.43421 12.5 4.3106C12.315 4.18698 12.1708 4.01128 12.0856 3.80571C12.0005 3.60015 11.9782 3.37395 12.0216 3.15572C12.065 2.93749 12.1722 2.73703 12.3295 2.5797C12.4868 2.42236 12.6873 2.31522 12.9055 2.27181C13.1238 2.2284 13.35 2.25068 13.5555 2.33583C13.7611 2.42098 13.9368 2.56517 14.0604 2.75018C14.184 2.93518 14.25 3.15269 14.25 3.37519C14.25 3.67356 14.1315 3.95971 13.9205 4.17069C13.7095 4.38167 13.4234 4.50019 13.125 4.50019Z" fill="#FE5C5C"/>
                            </svg>
                        </div>
                        <div class="max-w-[330px]">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary mb-2 h-6 flex items-center truncate">
                                {{$claimStore->store->name}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] h-10 items-center line-clamp-2">
                                {{$claimStore->store->address}}, {{$claimStore->store->urban_village}}, {{$claimStore->store->subdistrict}}, {{ $claimStore->store->city }}, {{$claimStore->store->province}} ({{$claimStore->store->postal_code}})
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="openListExpiredStores" style="z-index: 90" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        @if($detailExpiredVoucher)
        <div @click.outside="openListExpiredStores=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5 max-h-[400px] flex flex-col">
                <div class="flex-none">
                    <div class="w-full flex justify-between items-center mb-[18px]">
                        <div>
                            <div style="font-weight: 600;" class="text-[18px] mb-[2px] text-dark-primary">
                                {{$detailExpiredVoucher->claim->brand->company_name}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]">
                                Here are the branches you can find
                            </div>
                        </div>
                        <div @click="openListExpiredStores=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="flex-1 overflow-y-auto hide-scrollbar">
                @foreach ($detailExpiredVoucher->claim->claimStores as $claimStore)
                    <div class="w-full py-3 mt-[18px] flex">
                        <div class="mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M15.75 4.50019C15.7499 3.79065 15.5486 3.09568 15.1693 2.49601C14.79 1.89634 14.2484 1.41658 13.6074 1.11245C12.9663 0.808312 12.2521 0.692291 11.5478 0.777859C10.8434 0.863427 10.1778 1.14707 9.62818 1.59585C9.07859 2.04462 8.66759 2.64011 8.44293 3.31315C8.21828 3.98619 8.18917 4.70915 8.359 5.39807C8.52884 6.08699 8.89063 6.71358 9.40237 7.20508C9.91411 7.69659 10.5548 8.03282 11.25 8.17472V21.4483C11.2501 21.6476 11.2898 21.8448 11.3667 22.0286L11.8388 23.1536C11.8546 23.1826 11.8779 23.2067 11.9063 23.2236C11.9346 23.2404 11.967 23.2493 12 23.2493C12.033 23.2493 12.0654 23.2404 12.0937 23.2236C12.1221 23.2067 12.1454 23.1826 12.1613 23.1536L12.6333 22.0286C12.7102 21.8448 12.7499 21.6476 12.75 21.4483V8.17472C13.5964 8.00078 14.357 7.54032 14.9035 6.87096C15.4499 6.20161 15.7489 5.3643 15.75 4.50019ZM13.125 4.50019C12.9025 4.50019 12.685 4.43421 12.5 4.3106C12.315 4.18698 12.1708 4.01128 12.0856 3.80571C12.0005 3.60015 11.9782 3.37395 12.0216 3.15572C12.065 2.93749 12.1722 2.73703 12.3295 2.5797C12.4868 2.42236 12.6873 2.31522 12.9055 2.27181C13.1238 2.2284 13.35 2.25068 13.5555 2.33583C13.7611 2.42098 13.9368 2.56517 14.0604 2.75018C14.184 2.93518 14.25 3.15269 14.25 3.37519C14.25 3.67356 14.1315 3.95971 13.9205 4.17069C13.7095 4.38167 13.4234 4.50019 13.125 4.50019Z" fill="#FE5C5C"/>
                            </svg>
                        </div>
                        <div class="max-w-[330px]">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary mb-2 h-6 flex items-center truncate">
                                {{$claimStore->store->name}}
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] h-10 items-center line-clamp-2">
                                {{$claimStore->store->address}}, {{$claimStore->store->urban_village}}, {{$claimStore->store->subdistrict}}, {{ $claimStore->store->city }}, {{$claimStore->store->province}} ({{$claimStore->store->postal_code}})
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="detailRedeemStore" style="z-index: 100" class="w-screen absolute md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white">
        <div class="flex-none">
            <div class="w-full flex p-5">
                <div @click="detailRedeemStore=false;openDetailActiveVoucher=true" class="flex items-center no-select cursor-pointer">
                    <div class="mr-1">
                        <div class="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21">
                            <path class="fill-primary " d="M8.45306 6.63482C8.65228 6.83014 8.65228 7.15435 8.45697 7.35357L6.08588 9.73248H15.121C15.3984 9.73248 15.6249 9.95904 15.6249 10.2403C15.6249 10.5215 15.3984 10.7481 15.121 10.7481H6.08588L8.46088 13.127C8.65619 13.3262 8.65228 13.6465 8.45697 13.8458C8.25775 14.0411 7.94134 14.0411 7.74213 13.8419L4.52338 10.5997C4.48041 10.5528 4.44525 10.502 4.41791 10.4395C4.39056 10.377 4.37885 10.3106 4.37885 10.2442C4.37885 10.1114 4.42963 9.98639 4.52338 9.88873L7.74213 6.64654C7.93353 6.44342 8.25384 6.43951 8.45306 6.63482Z"/>
                            </svg>
                        </div>
                    </div>
                    <div style="font-weight: 600;" class="text-primary text-[16px]">
                        Back
                    </div>
                </div>
            </div>
        </div>

        <div style="padding-bottom: 160px" class="flex-1 overflow-y-auto hide-scrollbar">
            <div class="p-5 w-full flex items-center justify-center">
                <div class="w-full flex items-center justify-center border border-dotted border-[#EDEDED] h-[135px] p-5 truncate no-select">
                    <div>
                        <div style="font-weight: 400;" class="text-[16px] text-[#6A6A75] h-5 flex items-center justify-center mb-[2px]">
                            Gift code
                        </div>
                        <div style="font-weight: 700;" class="h-8 flex items-center text-dark-primary text-[24px]">
                            @if($detailActiveVoucher)
                            {{$detailActiveVoucher->code}}
                            @endif
                        </div>
                    </div>
                </div>
            </div>

            <div class="w-full mt-6 p-5 mb-5">
                <div style="font-weight: 600;" class="text-[18px] h-6 flex items-center mb-2 text-dark-primary">
                    How to redeem
                </div>
                <div style="font-weight: 400;" class="text-[16px] text-[#6A6A75] ">
                    <div class="flex">
                        <div>
                            1.
                        </div>
                        <div>
                            Come directly to the branch shop. Make sure you come to the branch that applies this offer.
                        </div>
                    </div>
                    <div class="flex">
                        <div>
                            2.
                        </div>
                        <div>
                            Inform the cashier that you want to redeem the offer.
                        </div>
                    </div>
                    <div class="flex">
                        <div>
                            3.
                        </div>
                        <div>
                            Show the code to verify.
                        </div>
                    </div>
                </div>
            </div>

            <div class="px-5">
                <div class="w-full p-3 flex bg-[#F6F2E6]">
                    <div class="mr-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                            <path d="M10.7297 3.9853L2.42815 19.1353C1.90315 20.0822 2.60159 21.24 3.69847 21.24H20.3063C21.3985 21.24 22.0969 20.0822 21.5766 19.1353L13.2703 3.9853C12.7219 2.99155 11.2782 2.99155 10.7297 3.9853ZM12.825 10.2712L12.6563 15.99H11.3438L11.175 10.2712H12.825ZM12 19.1025C11.4985 19.1025 11.1047 18.7228 11.1047 18.24C11.1047 17.7572 11.4985 17.3775 12 17.3775C12.5016 17.3775 12.8953 17.7572 12.8953 18.24C12.8953 18.7228 12.5016 19.1025 12 19.1025Z" fill="#FF8933"/>
                        </svg>
                    </div>
                    <div>
                        <div style="font-weight: 600;" class="h-5 text-[16px] flex items-center mb-[1px]">
                            Be careful
                        </div>
                        <div style="font-weight: 400;" class="text-[14px]">
                            The code is sensitive information. don't give it to anyone.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div x-cloak x-show="openDetailActiveVoucher" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        @if($detailActiveVoucher)
        <div class="flex-1 overflow-y-auto hide-scrollbar relative">
            <div class="relative mt-5">
                <div style="position: relative" class="flex flex-col min-h-screen overflow-hidden">
                    <div class="flex-1">
                        <div class="px-8">
                            <div class="relative flex justify-center no-select">
                                <div style="line-height: 26px;font-weight:400;" class="text-[16px]">
                                    Voucher Detail
                                </div>
                                <div @if($open_active_claimmed) onclick="redirectTo('{{route('dashboard')}}')" @else @click="openDetailActiveVoucher=false;myCollection=true" @endif  class="absolute left-0 top-1 cursor-pointer">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                                    </svg>
                                </div>
                            </div>
                            <div class="relative mt-5">
                                @if($detailActiveVoucher['claim']['thumbnail_path'])
                                <img src="{{ asset('storage/'. $detailActiveVoucher['claim']['thumbnail_path']) }}" class="w-full rounded-lg shadow-lg" alt="">
                                @else
                                <div class="w-full flex items-center justify-center h-[135px] bg-[#EAEFF3]  rounded-lg shadow-lg">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="71" height="70" viewBox="0 0 71 70" fill="none">
                                        <path d="M15.0833 61.25C13.4792 61.25 12.1054 60.6783 10.9621 59.535C9.81875 58.3917 9.24806 57.0189 9.25 55.4167V14.5833C9.25 12.9792 9.82167 11.6054 10.965 10.4621C12.1083 9.31875 13.4811 8.74806 15.0833 8.75H55.9167C57.5208 8.75 58.8946 9.32167 60.0379 10.465C61.1813 11.6083 61.752 12.9811 61.75 14.5833V55.4167C61.75 57.0208 61.1783 58.3946 60.035 59.5379C58.8917 60.6813 57.5189 61.252 55.9167 61.25H15.0833ZM18 49.5833H53L42.0625 35L33.3125 46.6667L26.75 37.9167L18 49.5833Z" fill="#D6DADF"/>
                                    </svg>
                                </div>
                                @endif
                                <div class="absolute px-2 w-full top-[45%] md:top-[52%] lg:top-[55%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ $detailActiveVoucher->claim->brand->company_name }}
                                            </div>
                                        </div>
                                        <div class="flex gap-1 items-center">
                                            <div>
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14.6667 8.00001C14.6667 11.68 11.68 14.6667 8.00001 14.6667C4.32001 14.6667 1.33334 11.68 1.33334 8.00001C1.33334 4.32001 4.32001 1.33334 8.00001 1.33334C11.68 1.33334 14.6667 4.32001 14.6667 8.00001Z" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M10.4733 10.12L8.40666 8.88665C8.04666 8.67332 7.75333 8.15999 7.75333 7.73999V5.00665" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                @if($detailActiveVoucher->claim->change_type_id == 1)
                                                {{ readableDaysLeftActive($detailActiveVoucher->valid_until) }}
                                                @else
                                                    Unlimited
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="p-3 max-w-full">
                                    <div class="px-3 mt-3 border-b">
                                        <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] h-[48px] flex items-center">
                                            {{ $detailActiveVoucher->claim->title }}
                                        </div>
                                    </div>
                                    <div class="mt-2 flex flex-col gap-2">
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Redeem
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] font-normal">
                                                {{ changeDateFormat($detailActiveVoucher->created_at) }}
                                            </div>
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Expired
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] font-normal">
                                                @if($detailActiveVoucher->claim->change_type_id == 1)
                                                {{ readableDaysLeftActive($detailActiveVoucher->valid_until) }}
                                                @else
                                                    Unnlimited
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="relative">
                            <img src="{{ asset('src/images/bg-profile.png') }}" class="w-full h-[150px]" alt="">
                            <div  style="top: 30px" class="absolute w-full">
                                <div class=" px-5">
                                    <div @click="openListActiveStores=true" class="flex bg-white p-3 mb-4 border border-white   rounded-lg shadow-lg w-full justify-between items-center no-select cursor-pointer">
                                        <div class="flex items-center">
                                            <div class="flex items-center justify-center mr-2">
                                                <img src="{{ asset('src/images/cabang.png') }}" class="w-[32px] h-[32px]" alt="">
                                            </div>
                                            <div class="max-w-[300px]">
                                                <div style="font-weight:600;line-height:20px" class="mb-1 flex items-center text-[16px] text-[#DA0814] truncate">
                                                    {{ $detailActiveVoucher->claim->brand->company_name }}
                                                </div>
                                                <div style="font-weight: 400;" class="h-5 flex items-center text-[#6A6A75]  text-[14px] truncate">
                                                    Can be purchased at {{ count($detailActiveVoucher->claim->claimStores) }} branches store
                                                </div>
                                            </div>
                                        </div>
                                        <div class="h-5 w-5 flex items-center justify-center">
                                            <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M11.9883 10L7.02344 5.03906C6.65625 4.67188 6.65625 4.07812 7.02344 3.71484C7.39062 3.35156 7.98438 3.35156 8.35156 3.71484L13.9766 9.33594C14.332 9.69141 14.3398 10.2617 14.0039 10.6289L8.35547 16.2891C8.17188 16.4727 7.92969 16.5625 7.69141 16.5625C7.45313 16.5625 7.21094 16.4727 7.02734 16.2891C6.66016 15.9219 6.66016 15.3281 7.02734 14.9648L11.9883 10Z" fill="#DA0814"/>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="px-8 pt-9 lg:pt-7 pb-32 rounded-t-2xl -mt-[15px] relative bg-white">

                            </div>
                        </div>
                    <div style="box-shadow: 0 30px 30px 30px rgba(0, 0, 0, 0.1);" class="bg-white  relative px-5 pt-3 pb-7 flex items-center justify-center justify-between shadow-lg">
                        <div class="flex justify-center flex-col gap-1">
                            <div style="line-height:20px" class="text-[12px] font-normal">
                                Point
                            </div>
                            <div class="flex gap-1 items-center">
                                <div>
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_15_1722)">
                                        <path d="M15.9779 8.59991H13.1201C10.6237 8.59991 8.6001 10.6236 8.6001 13.1199V15.9778C12.5401 15.6856 15.6858 12.5399 15.9779 8.59991Z" fill="#EFB008"/>
                                        <path d="M7.40007 15.9778V13.1199C7.40007 10.6236 5.37639 8.59991 2.88006 8.59991H0.0222168C0.31435 12.5399 3.4601 15.6856 7.40007 15.9778Z" fill="#EFB008"/>
                                        <path d="M15.9779 7.39994C15.6858 3.45997 12.5401 0.314228 8.6001 0.0220947V2.87993C8.6001 5.37626 10.6237 7.39994 13.1201 7.39994H15.9779Z" fill="#EFB008"/>
                                        <path d="M7.40007 0.0220947C3.4601 0.314228 0.31435 3.45997 0.0222168 7.39994H2.88006C5.37639 7.39994 7.40007 5.37626 7.40007 2.87993V0.0220947Z" fill="#EFB008"/>
                                        <path d="M5.43323 7.9999C6.54223 7.44578 7.44603 6.54198 8.00011 5.43298C8.55423 6.54198 9.45799 7.44578 10.567 7.9999C9.45799 8.55398 8.55423 9.45778 8.00011 10.5668C7.44603 9.45778 6.54223 8.55398 5.43323 7.9999Z" fill="#FFDE81"/>
                                        </g>
                                        <defs>
                                        <clipPath id="clip0_15_1722">
                                        <rect width="16" height="16" fill="white"/>
                                        </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div style="line-height: 22px" class="text-[18px] font-semibold text-[#976400]">
                                    <span style="line-height: 22px" class="font-semibold text-[18px]">{{$detailActiveVoucher->exchange_rate}}</span> Point
                                </div>
                            </div>
                        </div>
                        <div style="line-height: 24px" @click="openRedeemOption=true" class=" no-select cursor-pointer rounded-2xl py-3 w-[151px] text-white bg-[#DA0713] flex items-center justify-center font-bold text-[14px]">
                            Redeem
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="openDetailExpiredVoucher" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        @if($detailExpiredVoucher)
        <div class="flex-1 overflow-y-auto hide-scrollbar relative">
            <div class="relative mt-5">
                <div style="position: relative" class="flex flex-col min-h-screen overflow-hidden">
                    <div class="flex-1">
                        <div class="px-8">
                            <div class="relative flex justify-center no-select">
                                <div style="line-height: 26px;font-weight:400;" class="text-[16px]">
                                    Detail Expired Voucher
                                </div>
                                <div @if($open_expired_claimmed) onclick="redirectTo('{{ route('dashboard') }}')" @else @click="openDetailExpiredVoucher=false;myCollection=true" @endif  class="absolute left-0 top-1 cursor-pointer">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                                    </svg>
                                </div>
                            </div>
                            <div class="relative mt-5">
                                @if($detailExpiredVoucher['claim']['thumbnail_path'])
                                <img src="{{ asset('storage/'. $detailExpiredVoucher['claim']['thumbnail_path']) }}" class="w-full rounded-lg shadow-lg" alt="">
                                @else
                                <div class="w-full flex items-center justify-center h-[135px] bg-[#EAEFF3]  rounded-lg shadow-lg">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="71" height="70" viewBox="0 0 71 70" fill="none">
                                        <path d="M15.0833 61.25C13.4792 61.25 12.1054 60.6783 10.9621 59.535C9.81875 58.3917 9.24806 57.0189 9.25 55.4167V14.5833C9.25 12.9792 9.82167 11.6054 10.965 10.4621C12.1083 9.31875 13.4811 8.74806 15.0833 8.75H55.9167C57.5208 8.75 58.8946 9.32167 60.0379 10.465C61.1813 11.6083 61.752 12.9811 61.75 14.5833V55.4167C61.75 57.0208 61.1783 58.3946 60.035 59.5379C58.8917 60.6813 57.5189 61.252 55.9167 61.25H15.0833ZM18 49.5833H53L42.0625 35L33.3125 46.6667L26.75 37.9167L18 49.5833Z" fill="#D6DADF"/>
                                    </svg>
                                </div>
                                @endif
                                <div class="absolute px-2 w-full top-[55%] md:top-[60%] lg:top-[65%]">
                                    <div class="bg-[#F6F8FC] rounded-xl flex justify-between items-center w-full p-2">
                                        <div class="flex gap-1 items-center">
                                            <div class="w-4 h-4 rounded-full bg-[#D9D9D9]">

                                            </div>
                                            <div style="line-height: 13px" class="text-[#6A6A75] text-[11px] font-normal">
                                                {{ $detailExpiredVoucher->claim->brand->company_name }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="p-3 max-w-full">
                                    <div class="px-3 mt-3 border-b">
                                        <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] h-[48px] flex items-center">
                                            {{ $detailExpiredVoucher->claim->title }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="my-4 mx-5 p-3 bg-[#FAF1F1] flex">
                            <div class="mr-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                                    <path d="M10.7297 3.9853L2.42815 19.1353C1.90315 20.0822 2.60159 21.24 3.69847 21.24H20.3063C21.3985 21.24 22.0969 20.0822 21.5766 19.1353L13.2703 3.9853C12.7219 2.99155 11.2782 2.99155 10.7297 3.9853ZM12.825 10.2712L12.6563 15.99H11.3438L11.175 10.2712H12.825ZM12 19.1025C11.4985 19.1025 11.1047 18.7228 11.1047 18.24C11.1047 17.7572 11.4985 17.3775 12 17.3775C12.5016 17.3775 12.8953 17.7572 12.8953 18.24C12.8953 18.7228 12.5016 19.1025 12 19.1025Z" fill="#FE5C5C"/>
                                </svg>
                            </div>
                            <div>
                                <div style="font-weight: 600;" class="h-5 flex items-center text-[16px] text-dark-primary">
                                    Claim has expired
                                </div>
                                <div style="font-weight: 400;line-height: 20px;" class=" hidden lg:block text-dark-primary text-[14px]">
                                    You can no longer redeem this claim.
                                </div>
                            </div>
                        </div>
                        <div class="relative">
                            <img src="{{ asset('src/images/bg-profile.png') }}" class="w-full h-[150px]" alt="">
                            <div  style="top: 30px" class="absolute w-full">
                                <div class=" px-5">
                                    <div @click="openListExpiredStores=true" class="flex bg-white p-3 mb-4 border border-white   rounded-lg shadow-lg w-full justify-between items-center no-select cursor-pointer">
                                        <div class="flex items-center">
                                            <div class="flex items-center justify-center mr-2">
                                                <img src="{{ asset('src/images/cabang.png') }}" class="w-[32px] h-[32px]" alt="">
                                            </div>
                                            <div class="max-w-[300px]">
                                                <div style="font-weight:600;line-height:20px" class="mb-1 flex items-center text-[16px] text-[#DA0814] truncate">
                                                    {{ $detailExpiredVoucher->claim->brand->company_name }}
                                                </div>
                                                <div style="font-weight: 400;" class="h-5 flex items-center text-[#6A6A75]  text-[14px] truncate">
                                                    Can be purchased at {{ count($detailExpiredVoucher->claim->claimStores) }} branches store
                                                </div>
                                            </div>
                                        </div>
                                        <div class="h-5 w-5 flex items-center justify-center">
                                            <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M11.9883 10L7.02344 5.03906C6.65625 4.67188 6.65625 4.07812 7.02344 3.71484C7.39062 3.35156 7.98438 3.35156 8.35156 3.71484L13.9766 9.33594C14.332 9.69141 14.3398 10.2617 14.0039 10.6289L8.35547 16.2891C8.17188 16.4727 7.92969 16.5625 7.69141 16.5625C7.45313 16.5625 7.21094 16.4727 7.02734 16.2891C6.66016 15.9219 6.66016 15.3281 7.02734 14.9648L11.9883 10Z" fill="#DA0814"/>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="openDetailUsedVoucher" style="z-index: 80" class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white ">
        @if($detailUsedVoucher)
        <div class="flex-1 overflow-y-auto hide-scrollbar relative">
            <div class="relative mt-5">
                <div style="position: relative" class="flex flex-col min-h-screen overflow-hidden">
                    <div class="flex-1">
                        <div class="px-8">
                            <div class="relative flex justify-center no-select">
                                <div style="line-height: 26px;font-weight:400;" class="text-[16px]">
                                    Voucher Detail
                                </div>
                                <div @if($open_used_claimmed) onclick="redirectTo('{{ route('dashboard') }}')" @else @click="openDetailUsedVoucher=false;myCollection=true" @endif  class="absolute left-0 top-1 cursor-pointer">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.825 9L9.425 14.6L8 16L0 8L8 0L9.425 1.4L3.825 7H16V9H3.825Z" fill="black"/>
                                    </svg>
                                </div>
                            </div>
                            <div class="relative mt-5">
                                @if($detailUsedVoucher['claim']['thumbnail_path'])
                                <img src="{{ asset('storage/'. $detailUsedVoucher['claim']['thumbnail_path']) }}" class="w-full rounded-lg shadow-lg" alt="">
                                @else
                                <div class="w-full flex items-center justify-center h-[135px] bg-[#EAEFF3]  rounded-lg shadow-lg">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="71" height="70" viewBox="0 0 71 70" fill="none">
                                        <path d="M15.0833 61.25C13.4792 61.25 12.1054 60.6783 10.9621 59.535C9.81875 58.3917 9.24806 57.0189 9.25 55.4167V14.5833C9.25 12.9792 9.82167 11.6054 10.965 10.4621C12.1083 9.31875 13.4811 8.74806 15.0833 8.75H55.9167C57.5208 8.75 58.8946 9.32167 60.0379 10.465C61.1813 11.6083 61.752 12.9811 61.75 14.5833V55.4167C61.75 57.0208 61.1783 58.3946 60.035 59.5379C58.8917 60.6813 57.5189 61.252 55.9167 61.25H15.0833ZM18 49.5833H53L42.0625 35L33.3125 46.6667L26.75 37.9167L18 49.5833Z" fill="#D6DADF"/>
                                    </svg>
                                </div>
                                @endif
                                <div class="p-3 max-w-full">
                                    <div class="px-3 mt-3 border-b">
                                        <div style="font-weight: 600; line-height: 24px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" class="text-[16px] h-[48px] flex items-center">
                                            {{ $detailUsedVoucher->claim->title }}
                                        </div>
                                    </div>
                                    <div class="mt-2 flex flex-col gap-2">
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Effective Date
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] font-normal">
                                                {{ changeDateFormat($detailUsedVoucher->claim->start_date) }} - {{ changeDateFormat($detailUsedVoucher->claim->end_date) }}
                                            </div>
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Place to exchange claim
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] font-normal">
                                                {{$detailUsedVoucher->in_store ? 'Redeem in store' : 'Send to home'}}
                                            </div>
                                        </div>
                                        @if($detailUsedVoucher->in_store)
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Changed in
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] font-normal">
                                                @if($detailUsedVoucher->store){{$detailUsedVoucher->store->name}}@else {{ $detailUsedVoucher->brand->name }}@endif
                                            </div>
                                        </div>
                                        @endif
                                        <div class="flex items-center justify-between">
                                            <div style="line-height: 16px" class="text-[#6A7481] text-[12px] font-light">
                                                Date used
                                            </div>
                                            <div style="line-height: 20px" class="text-[13px] font-normal">
                                                {{ changeDateFormat($detailUsedVoucher->use_date) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="px-8 pt-9 lg:pt-7 rounded-t-2xl -mt-[15px] relative bg-white">
                            @if(!$detailUsedVoucher->in_store)
                            <div x-data="{
                                copyData(data){
                                    navigator.clipboard.writeText(data);
                                }
                                }" class="flex rounded-b-sm p-3 mb-4 border border-white   rounded-sm w-full justify-between items-center no-select cursor-pointer">
                                <div class="flex items-start">
                                    <div class="h-5 w-5 flex items-center justify-center mr-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17" fill="none">
                                            <path d="M19.4852 11.2283H18.9859V7.86334C18.9859 7.46802 18.8268 7.08826 18.546 6.80811L15.429 3.69843C15.1482 3.41827 14.7675 3.25952 14.3713 3.25952H12.9953V1.76538C12.9953 0.940491 12.3245 0.27124 11.4977 0.27124H3.51016C2.68333 0.27124 2.0125 0.940491 2.0125 1.76538V3.25952H0.265234C0.127949 3.25952 0.015625 3.37158 0.015625 3.50854V4.00659C0.015625 4.14355 0.127949 4.25562 0.265234 4.25562H8.75195C8.88924 4.25562 9.00156 4.36768 9.00156 4.50464V5.00269C9.00156 5.13965 8.88924 5.25171 8.75195 5.25171H1.26367C1.12639 5.25171 1.01406 5.36377 1.01406 5.50073V5.99878C1.01406 6.13574 1.12639 6.2478 1.26367 6.2478H7.75352C7.8908 6.2478 8.00313 6.35986 8.00313 6.49683V6.99487C8.00313 7.13184 7.8908 7.2439 7.75352 7.2439H0.265234C0.127949 7.2439 0.015625 7.35596 0.015625 7.49292V7.99097C0.015625 8.12793 0.127949 8.23999 0.265234 8.23999H6.75508C6.89236 8.23999 7.00469 8.35205 7.00469 8.48901V8.98706C7.00469 9.12402 6.89236 9.23608 6.75508 9.23608H2.0125V13.2205C2.0125 14.8702 3.35415 16.2087 5.00781 16.2087C6.66147 16.2087 8.00313 14.8702 8.00313 13.2205H11.9969C11.9969 14.8702 13.3385 16.2087 14.9922 16.2087C16.6458 16.2087 17.9875 14.8702 17.9875 13.2205H19.4852C19.7597 13.2205 19.9844 12.9963 19.9844 12.7224V11.7263C19.9844 11.4524 19.7597 11.2283 19.4852 11.2283ZM5.00781 14.7146C4.18098 14.7146 3.51016 14.0453 3.51016 13.2205C3.51016 12.3956 4.18098 11.7263 5.00781 11.7263C5.83464 11.7263 6.50547 12.3956 6.50547 13.2205C6.50547 14.0453 5.83464 14.7146 5.00781 14.7146ZM14.9922 14.7146C14.1654 14.7146 13.4945 14.0453 13.4945 13.2205C13.4945 12.3956 14.1654 11.7263 14.9922 11.7263C15.819 11.7263 16.4898 12.3956 16.4898 13.2205C16.4898 14.0453 15.819 14.7146 14.9922 14.7146ZM17.4883 8.23999H12.9953V4.75366H14.3713L17.4883 7.86334V8.23999Z" fill="#B1B1B1"/>
                                        </svg>
                                    </div>
                                    <div class=" max-w-[100px] lg:max-w-[200px]">
                                        <div style="font-weight:600;" class="mb-1 flex items-center text-[16px] text-dark-primary truncate">
                                            {{$detailUsedVoucher->receipt_number}}
                                        </div>
                                        <div style="font-weight: 400;" class= "flex items-center text-[#6A6A75]  text-[14px] truncate">
                                            {{$detailUsedVoucher->expedition}}
                                        </div>
                                    </div>
                                </div>

                                <div @click="copyData(' {{$detailUsedVoucher->receipt_number}} ')" class="h-5 text-primary flex items-center justify-between">
                                    <div class="mr-1">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                                            <path d="M16.875 2.42749H6.875C6.62636 2.42749 6.3879 2.52626 6.21209 2.70208C6.03627 2.87789 5.9375 3.11635 5.9375 3.36499V6.17749H3.125C2.87636 6.17749 2.6379 6.27626 2.46209 6.45208C2.28627 6.62789 2.1875 6.86635 2.1875 7.11499V17.115C2.1875 17.3636 2.28627 17.6021 2.46209 17.7779C2.6379 17.9537 2.87636 18.0525 3.125 18.0525H13.125C13.3736 18.0525 13.6121 17.9537 13.7879 17.7779C13.9637 17.6021 14.0625 17.3636 14.0625 17.115V14.3025H16.875C17.1236 14.3025 17.3621 14.2037 17.5379 14.0279C17.7137 13.8521 17.8125 13.6136 17.8125 13.365V3.36499C17.8125 3.11635 17.7137 2.87789 17.5379 2.70208C17.3621 2.52626 17.1236 2.42749 16.875 2.42749ZM12.1875 16.1775H4.0625V8.05249H12.1875V16.1775ZM15.9375 12.4275H14.0625V7.11499C14.0625 6.86635 13.9637 6.62789 13.7879 6.45208C13.6121 6.27626 13.3736 6.17749 13.125 6.17749H7.8125V4.30249H15.9375V12.4275Z" fill="#3688EF"/>
                                        </svg>
                                    </div>
                                    <div>
                                        Copy
                                    </div>
                                </div>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>

    <div x-cloak x-show="openRedeemOption" style="z-index: 90" class="absolute w-screen h-screen bg-black bg-opacity-50  flex justify-center left-0 items-end">
        <div @click.outside="openRedeemOption=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5">
                <div class="w-full flex justify-between items-center mb-[18px]">
                    <div>
                        <div style="font-weight: 600;" class="text-[18px] mb-[2px] text-dark-secondary">
                            Redeem
                        </div>
                        <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]">
                            Choose the redeem type according to your preferences
                        </div>
                    </div>
                    <div @click="openRedeemOption=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
                @if($detailActiveVoucher)
                @if($detailActiveVoucher->claim->change_system_id == 1 || $detailActiveVoucher->claim->change_system_id == 3)
                <div @click="detailRedeemStore=true;openDetailActiveVoucher=false;openRedeemOption=false;" class="w-full flex justify-between items-center my-3 cursor-pointer">
                    <div class="flex items-center">
                        <div class="mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                <path d="M4 23.2798V27.3332C4 27.7065 4.29333 27.9998 4.66667 27.9998H8.72C8.89333 27.9998 9.06667 27.9332 9.18667 27.7998L23.7467 13.2532L18.7467 8.25317L4.2 22.7998C4.06667 22.9332 4 23.0932 4 23.2798ZM27.6133 9.38651C27.7369 9.26316 27.835 9.11664 27.9019 8.95534C27.9688 8.79404 28.0033 8.62113 28.0033 8.44651C28.0033 8.27188 27.9688 8.09897 27.9019 7.93768C27.835 7.77638 27.7369 7.62986 27.6133 7.50651L24.4933 4.38651C24.37 4.2629 24.2235 4.16484 24.0622 4.09793C23.9009 4.03102 23.728 3.99658 23.5533 3.99658C23.3787 3.99658 23.2058 4.03102 23.0445 4.09793C22.8832 4.16484 22.7367 4.2629 22.6133 4.38651L20.1733 6.82651L25.1733 11.8265L27.6133 9.38651Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                        <div class="p-1">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary mb-[2px]">
                                To Store
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]">
                                See gift code to redeem
                            </div>
                        </div>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.7859 12L7.82812 6.04688C7.38749 5.60625 7.38749 4.89375 7.82812 4.45781C8.26874 4.02188 8.98124 4.02188 9.42187 4.45781L16.1719 11.2031C16.5984 11.6297 16.6078 12.3141 16.2047 12.7547L9.42656 19.5469C9.20624 19.7672 8.91562 19.875 8.62968 19.875C8.34374 19.875 8.05312 19.7672 7.83281 19.5469C7.39218 19.1062 7.39218 18.3938 7.83281 17.9578L13.7859 12Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>

                @endif

                @if($detailActiveVoucher->claim->change_system_id == 2 || $detailActiveVoucher->claim->change_system_id == 3)
                <div wire:click="sendHomeConfirm" class="w-full flex justify-between items-center mt-3 cursor-pointer">
                    <div class="flex items-center">
                        <div class="mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                <path d="M13 28V20H19V28H25.1V16H29L16 4L3 16H6.9V28H13Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                        <div class="p-1">
                            <div style="font-weight: 600;" class="text-[18px] text-dark-primary mb-[2px]">
                                Send to home
                            </div>
                            <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75]">
                                Send gifts to your address
                            </div>
                        </div>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.7859 12L7.82812 6.04688C7.38749 5.60625 7.38749 4.89375 7.82812 4.45781C8.26874 4.02188 8.98124 4.02188 9.42187 4.45781L16.1719 11.2031C16.5984 11.6297 16.6078 12.3141 16.2047 12.7547L9.42656 19.5469C9.20624 19.7672 8.91562 19.875 8.62968 19.875C8.34374 19.875 8.05312 19.7672 7.83281 19.5469C7.39218 19.1062 7.39218 18.3938 7.83281 17.9578L13.7859 12Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
                @endif
                @endif
            </div>
        </div>
    </div>

    <div x-cloak x-show="openSendHomeConfirm" style="z-index: 80" class="absolute left-0 w-screen h-screen bg-black bg-opacity-50  flex justify-center items-end">
        @if($myAddress)
        <div @click.outside="openSendHomeConfirm=false" class="w-screen md:w-full md:max-w-md max-w-full rounded-t-lg bg-white ">
            <div class="p-5">
                <div class="w-full flex justify-between items-center mb-[18px]">
                    <div>
                        <div style="font-weight: 600;" class="text-[18px] mb-[2px] text-dark-secondary">
                            Confirmation
                        </div>
                        <div style="font-weight: 400;" class="text-[14px] text-[#6A6A75] ">
                            Gift will be sent to the following address
                        </div>
                    </div>
                    <div @click="openSendHomeConfirm=false" class="p-1 rounded-full border border-[#EDEDED] cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                        </svg>
                    </div>
                </div>
                <div class="w-full flex items-center justify-between p-3 border rounded-sm  ">
                    <div class="p-3 flex">
                        <div class="mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M12 2.25C8.27344 2.25 5.25 5.05781 5.25 8.51719C5.25 13.3922 12 21.75 12 21.75C12 21.75 18.75 13.3922 18.75 8.51719C18.75 5.05781 15.7266 2.25 12 2.25ZM12 11.1984C10.7859 11.1984 9.80156 10.2141 9.80156 9C9.80156 7.78594 10.7859 6.80156 12 6.80156C13.2141 6.80156 14.1984 7.78594 14.1984 9C14.1984 10.2141 13.2141 11.1984 12 11.1984Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                        <div>
                            <div style="font-weight: 600;" class="text-[20px] h-6 items-center flex mb-1">
                                {{$myAddress->buildingType->name}}
                            </div>
                            <div  style="font-weight: 400; line-height: 20px;" class="text-[16px] no-select text-[#6A6A75]">
                                {{ $myAddress->detail }}, {{ $myAddress->urban_village }}, {{ $myAddress->subdistrict }}, {{ $myAddress->city }}, {{ $myAddress->province }} ({{ $myAddress->postal_code }})
                            </div>
                            <div wire:click="changeAddress()" class="no-select cursor-pointer py-1">
                                <div style="font-weight: 600;" class="h-5 flex items-center text-primary text-[16px]">
                                    Change address
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="flex rounded-b-sm p-3 w-full mt-10 justify-between items-center">
                    <div @click="openSendHomeConfirm=false" style="font-weight: 600;" class="text-primary border rounded-sm   no-select cursor-pointer flex items-center justify-center text-[16px] w-6/12 h-[46px]">
                        Cancel
                    </div>
                    <div wire:click="sendHome()" @click="loading=true" style="font-weight: 600;" class="w-6/12 h-[46px] text-[16px] text-white no-select cursor-pointer flex bg-primary ml-3 items-center justify-center rounded-sm">
                        Yes
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>
</div>
