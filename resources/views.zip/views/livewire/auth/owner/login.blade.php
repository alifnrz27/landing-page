@section('title', 'Sign in to your account')

<div>
    <div class="font-source-sans h-screen flex">
        <div class="w-full hidden lg:block relative overflow-hidden">
            <div class="w-full h-screen relative bg-primary">
                <div class="absolute top-1/2 transform -translate-y-1/2 flex">
                    <img class="block my-auto h-[500px]" src="{{ asset('src/images/login/tape.png') }}" />
                    <div>
                        <div class="w-full max-w-[445px]">
                            <div class="text-[32px] text-white font-bold mb-[12px]">
                                Customer Loyalty
                            </div>
                            <div class="text-white text-[16px]">
                                With easy-to-use features and exclusive benefits, this app will provide your customers with an unforgettable experience.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="absolute bottom-0 right-0">
                    <img class="h-[300px] lg:h-[450px]"  src="{{ asset('src/images/login/page.png') }}" />
                </div>

            </div>
        </div>
        <div class="w-full h-full text-center">
            <div class="flex items-center justify-center h-full">
                <div class="p-3 md:p-0 w-[395px]">
                    <div class="flex mb-5">
                        <x-logo class="w-[28px] mr-1" />
                        <div class="text-[20px]">
                            {{ env('COMPANY_NAME') }}
                        </div>
                    </div>
                    <div class="text-start mb-8">
                        <div class="text-[32px] font-bold mb-2">
                            Welcome
                        </div>
                        <div class="text-[16px] text-gray-500">
                            Welcome to the customer loyalty platform. Enter your username & password to log in
                        </div>
                    </div>
                    <form wire:submit.prevent="authenticate">
                        <div class="mb-6">
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                                    <!-- Add your icon here -->
                                    <img src="{{ asset('src/icons/md-person.svg') }}" />
                                </span>
                                <input wire:model.lazy="username" id="username" name="username" type="text" required placeholder="Username" autofocus autocomplete="off" style="padding-left:38px;border-radius: var(--corner-radius-corner-xs, 2px);" class="appearance-none block w-full h-12 pr-3 py-2 border focus:outline-none focus:ring-primary focus:border-third transition duration-150 ease-in-out sm:text-sm sm:leading-5 @error('username') border-red-300 text-red-900 placeholder-red-300 focus:ring-red @enderror" />
                            </div>

                            @error('username')
                                <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                                    <!-- Add your icon here -->
                                    <img src="{{ asset('src/icons/ios-lock.svg') }}" />
                                </span>
                                <input wire:model.lazy="password" id="input-password" type="password" required placeholder="Password" style="padding-left:38px;border-radius: var(--corner-radius-corner-xs, 2px);" class="appearance-none block w-full h-12 pr-3 py-2 border focus:outline-none focus:border-third focus:ring-primary transition duration-150 ease-in-out sm:text-sm sm:leading-5 @error('password') border-red-300 text-red-900 placeholder-red-300 focus:border-red-300 focus:ring-red @enderror" />
                                <div onclick="seePassword('hide-password', 'view-password', 'input-password')" class="absolute right-4 top-3 cursor-pointer">
                                    <img src="{{asset('src/icons/hide.png')}}" id="hide-password" class="w-[20px] h-[20px]" alt="">
                                    <img src="{{asset('src/icons/view.png')}}" id="view-password" class="w-[20px] h-[20px] hidden" alt="">
                                </div>
                            </div>

                            @error('password')
                                <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="mt-8">
                            <span class="block w-full">
                                <button type="submit" style="background-color:#3688EF;border-radius: var(--corner-radius-corner-xs, 2px);" class="flex justify-center w-full h-[44px] items-center px-4 py-2 text-sm font-medium text-white bg-primary border border-transparent focus:outline-none focus:ring-indigo hover:opacity-60 transition duration-150 ease-in-out">
                                    Login
                                </button>
                            </span>
                            <div class="flex mt-3 justify-center" x-data="{
                                open:false
                            }">
                                <a href="{{ route('forgot-password-view') }}" class="text-primary hover:cursor-pointer hover:opacity-50 duration-150 p-3">Lupa Password?</a>
                                <div x-cloak x-show="open" x-transition class="fixed top-0 left-0  pt-20 w-full min-h-screen bg-black/50 flex justify-center items-center z-10">
                                    <section @click.outside="open=false" class="fixed w-[446px] mb-5 mx-auto my-auto bg-white" style="margin-top: -50px">
                                        <div class="w-full max-h-[650px] overflow-hidden text-center">
                                            <div class="w-full  p-6">
                                                <div style="font-weight: 600;font-size:20px" class="mt-5 mb-2 text-[20px]">
                                                    Forgot Password
                                                </div>
                                                <div style="font-size:16px" class="text-gray-500 mb-6">
                                                    Sorry, there was a problem with your password? Don't worry, we are here to help! Please contact our team at <span class="font-bold">{{ env('ADMIN_EMAIL') }}</span> for assistance in resetting your password. Thank you for your cooperation!
                                                </div>
                                                <p x-on:click="open = false" style="font-weight: 600;" class="text-[16px] text-primary hover:cursor-pointer hover:opacity-50 duration-150">
                                                    Close
                                                </p>
                                            </div>
                                        </div>
                                    </section>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <script src="{{asset('src/js/seePassword.js')}}"></script>
</div>
