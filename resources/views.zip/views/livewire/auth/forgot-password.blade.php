@extends('layouts.app')

@section('content')

<div class="w-screen h-screen bg-[#E8EAED] flex justify-center items-center" x-data="{
    sendResetLink(){
        $wire.sendResetLink();
    }
}">

    {{-- <div x-cloak x-show="isSuccess" class="fixed top-0 px-5 py-2 w-screen md:w-full md:max-w-md max-w-full bg-[#2C9854] justify-between items-center  overflow-auto flex">
        <div class="h-5 flex items-center">
            <div>
                🎉
            </div>
            <div style="font-weight: 600;" class="text-[16px] text-white flex items-center">
                Voucher redeemed successfully
            </div>
        </div>
        <div style="font-weight: 400;" class="h-7 py-1 px-2 flex items-center justify-center text-white text-[14px] border border-white rounded-sm">
            Detail
        </div>
    </div> --}}

    <div class="w-screen md:w-full md:max-w-md max-w-full h-screen flex flex-col bg-white justify-center">
        <div style="padding-bottom: 160px" class="flex-1 flex flex-col justify-center overflow-y-auto hide-scrollbar relative bg-white px-5">
            <div class="relative ">
                <div class="text-[20px] px-2 font-bold">
                    Reset your password
                </div>
                <form action="{{ route('forgot-password') }}" method="POST">
                    @csrf
                    <div class="relative border-2 pt-5 rounded-xl mt-6">
                        <div class="form-group">
                            <input type="text" id="email" style="font-weight: 400;" name="email" class="w-full h-11 p-3 text-[16px] rounded-xl" required>
                            <label for="email" style="font-weight: 400;" class="w-full h-7 p-1 flex items-center text-[#6A6A75] text-[14px]">Email</label>
                        </div>
                    </div>
                    <div class="mt-6">
                        <button type="submit" style="font-weight: 600; background-color:#DA0713;color:white" class="w-full h-[56px] rounded-xl text-center flex justify-center items-center text-[16px] cursor-pointer no-select">
                            Send reset link
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


@endsection
