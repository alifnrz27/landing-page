@section('title', 'Create a new account')

<div class="w-screen h-screen max-h-screen overflow-hidden bg-[#E8EAED] flex justify-center items-center" x-data="{
    startX: null, endX: null,swipeThreshold: 70,
    data_carousel_item:0,
    from_login: {{ $from_login ? $from_login : 'false' }},
    canScroll: true,
    totalItems:4,
    currentItem:1,
    hideCarouselItems() {
        const carouselItems = document.querySelectorAll('[data-carousel-item]');
        carouselItems.forEach(item => {
            item.classList.add('hide');
            item.classList.add('hidden');
        });
    },
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    },

    showItem(element) {
        if (element instanceof Element) {
            const slideTo = element.getAttribute('data-carousel-slide-to');
            if (slideTo !== null) {
                this.hideCarouselItems();
                const elementsWithCarouselItemZero = document.querySelectorAll('[data-carousel-item=\''+slideTo+'\']');
                this.currentItem = parseInt(slideTo)+1;
                this.canScroll = false;
                this.sleep(1000).then(() => {
                    this.canScroll = true;
                });
                elementsWithCarouselItemZero.forEach((element) => {
                    element.classList.remove('hide');
                    element.classList.remove('hidden');
                    element.classList.add('show');
                });
            }
        }
    },

    onTouchMove(event) {
        if (this.canScroll) {
            this.endX = event.touches[0].clientX;
            const deltaX = this.endX - this.startX;

            // Check if the swipe is significant enough
            if (Math.abs(deltaX) >= this.swipeThreshold) {
            if (deltaX < 0 && this.currentItem < this.totalItems) {
                this.hideCarouselItems();
                this.currentItem += 1;
                const elementsWithCarouselItemZero = document.querySelectorAll('[data-carousel-item=\''+(this.currentItem-1)+'\']');
                elementsWithCarouselItemZero.forEach((element) => {
                    element.classList.remove('hide');
                    element.classList.remove('hidden');
                    element.classList.add('show');
                });
                this.canScroll = false;

                this.sleep(1000).then(() => {
                    this.canScroll = true;
                });
            }


            }
        }
        },

        onTouchEnd() {
        // Reset touch event values
        this.startX = null;
        this.endX = null;
        },

    scrollHandler() {
        if (this.canScroll) {
            if(this.currentItem < 4){
                if(event.deltaY > 0 || event.deltaX > 0){
                    if(this.currentItem < this.totalItems){
                        this.hideCarouselItems();
                        this.currentItem += 1;
                        const elementsWithCarouselItemZero = document.querySelectorAll('[data-carousel-item=\''+(this.currentItem-1)+'\']');
                        elementsWithCarouselItemZero.forEach((element) => {
                            element.classList.remove('hide');
                            element.classList.remove('hidden');
                            element.classList.add('show');
                        });

                    }
                }
                this.canScroll = false;

                this.sleep(1000).then(() => {
                    this.canScroll = true;
                });
            }
        }
    },

    register(){
        name = document.getElementById('name').value
        email = document.getElementById('email').value
        phone_number = document.getElementById('phone_number').value
        day = document.getElementById('day').value
        month = document.getElementById('month').value
        year = document.getElementById('year').value
        input_password = document.getElementById('input-password').value
        input_confirmation_password = document.getElementById('input-confirmation-password').value
        $wire.register(name, email, phone_number, day, month, year, input_password, input_confirmation_password)


    }
    }" x-init="
    if(from_login){
        const elementsWithCarouselItemZero = document.querySelectorAll('[data-carousel-item=\'3\']');
        currentItem = parseInt(3)+1;
        hideCarouselItems()
        elementsWithCarouselItemZero.forEach((element) => {
            element.classList.remove('hide');
            element.classList.remove('hidden');
            element.classList.add('show');
        });
    }
    $wire.on('backToLastImage', value => {
        const elementsWithCarouselItemZero = document.querySelectorAll('[data-carousel-item=\'3\']');
        currentItem = parseInt(3)+1;
        hideCarouselItems()
        elementsWithCarouselItemZero.forEach((element) => {
            element.classList.remove('hide');
            element.classList.remove('hidden');
            element.classList.add('show');
        });
    })
    " @touchmove="onTouchMove"
    @touchend="onTouchEnd" id="scrollable-element" data-carousel="slide" @touchstart="startX = $event.touches[0].clientX" x-on:wheel="scrollHandler()">
    <style>
        @keyframes fadeOut {
            from {
                opacity: 1;
            }
            to {
                opacity: 0;
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        /* Terapkan animasi pada elemen dengan kelas animasi */
        .hide {
            animation: fadeOut 1s ease-out forwards;
        }

        .show {
            animation:  fadeIn 1s ease-out forwards;
        }
    </style>

    <div data-carousel-item="0" class="w-screen relative md:w-full md:max-w-md max-w-full overflow-auto h-full bg-white hide-scrollbar no-select">
        <div class="absolute">
            <img src="{{ asset('src/images/onboard1.png') }}" alt="">
        </div>
        <div class="flex relative flex-col gap-[60px] justify-center h-full">
            <div class="w-full flex justify-center">
                <img src="{{ asset('src/images/imageonboard1.png') }}" width="300" alt="">
            </div>
            <div class="flex flex-col gap-5 px-8">
                <div style="line-height: 40px" class="font-bold text-[32px] text-[#27364B]">
                    Customer Loyalty
                </div>
                <div style="line-height: 22px" class="text-[#64748B] text-[18px] font-normal">
                    Integrated Platform
                </div>
                <div class="flex items-center gap-1">
                    <div class="w-2 h-2 rounded-full bg-[#D83232]">

                    </div>
                    <div class="w-2 h-2 rounded-full border-[#C7C7CC] border">

                    </div>
                    <div class="w-2 h-2 rounded-full border-[#C7C7CC] border">

                    </div>
                </div>
                <div class="px-8">
                    <div class="mt-6">
                        <div aria-current="true" aria-label="Slide 4" @click="showItem($event.target)" data-carousel-slide-to="3" style="font-weight: 600;" class="w-full h-[56px] bg-[#D83232] cursor-pointer text-white rounded-xl text-center flex justify-center items-center text-[16px]">
                            Register
                        </div>
                    </div>
                    <a href="{{ route('login', ['data' => encrypt(['from_register' => true])]) }}" style="line-height: 18px" class="text-[#64748B] cursor-pointer pb-12 mt-4 text-[14px] flex justify-center items-center font-semibold">
                        Login
                    </a>
                </div>
            </div>
        </div>

    </div>

    <div data-carousel-item="1" class="w-screen hidden hide relative md:w-full md:max-w-md max-w-full overflow-auto h-full bg-white hide-scrollbar no-select">
        <div class="absolute">
            <img src="{{ asset('src/images/onboard1.png') }}" alt="">
        </div>
        <div class="flex relative flex-col gap-[60px] justify-center h-full">
            <div class="w-full flex justify-center">
                <img src="{{ asset('src/images/imageonboard2.png') }}" width="300" alt="">
            </div>
            <div class="flex flex-col gap-5 px-8">
                <div style="line-height: 40px" class="font-bold text-[32px] text-[#27364B]">
                    Customer Loyalty
                </div>
                <div style="line-height: 22px" class="text-[#64748B] text-[18px] font-normal">
                    Integrated Platform
                </div>
                <div class="flex items-center gap-1">
                    <div class="w-2 h-2 rounded-full border-[#C7C7CC] border">

                    </div>
                    <div class="w-2 h-2 rounded-full bg-[#D83232]">

                    </div>
                    <div class="w-2 h-2 rounded-full border-[#C7C7CC] border">

                    </div>
                </div>
                <div class="px-8">
                    <div class="mt-6">
                        <div aria-current="true" aria-label="Slide 4" @click="showItem($event.target)" data-carousel-slide-to="3" style="font-weight: 600;" class="w-full h-[56px] bg-[#D83232] cursor-pointer text-white rounded-xl text-center flex justify-center items-center text-[16px]">
                            Register
                        </div>
                    </div>
                    <a href="{{ route('login', ['data' => encrypt(['from_register' => true])]) }}"  style="line-height: 18px" class="text-[#64748B] cursor-pointer pb-12 mt-4 text-[14px] flex justify-center items-center font-semibold">
                        Login
                    </a>
                </div>
            </div>
        </div>

    </div>

    <div data-carousel-item="2" class="w-screen hidden hide relative md:w-full md:max-w-md max-w-full overflow-auto h-full bg-white hide-scrollbar no-select">
        <div class="absolute">
            <img src="{{ asset('src/images/onboard1.png') }}" alt="">
        </div>
        <div class="flex relative flex-col gap-[60px] justify-center h-full">
            <div class="w-full flex justify-center">
                <img src="{{ asset('src/images/imageonboard3.png') }}" width="300" alt="">
            </div>
            <div class="flex flex-col gap-5 px-8">
                <div style="line-height: 40px" class="font-bold text-[32px] text-[#27364B]">
                    Customer Loyalty
                </div>
                <div style="line-height: 22px" class="text-[#64748B] text-[18px] font-normal">
                    Integrated Platform
                </div>
                <div class="flex items-center gap-1">
                    <div class="w-2 h-2 rounded-full border-[#C7C7CC] border">

                    </div>
                    <div class="w-2 h-2 rounded-full border-[#C7C7CC] border">

                    </div>
                    <div class="w-2 h-2 rounded-full bg-[#D83232]">

                    </div>
                </div>
                <div class="px-8">
                    <div class="mt-6">
                        <div aria-current="true" aria-label="Slide 4" @click="showItem($event.target)" data-carousel-slide-to="3" style="font-weight: 600;" class="w-full h-[56px] bg-[#D83232] cursor-pointer text-white rounded-xl text-center flex justify-center items-center text-[16px]">
                            Register
                        </div>
                    </div>
                    <a href="{{ route('login', ['data' => encrypt(['from_register' => true])]) }}"  style="line-height: 18px" class="text-[#64748B] cursor-pointer pb-12 mt-4 text-[14px] flex justify-center items-center font-semibold">
                        Login
                    </a>
                </div>
            </div>
        </div>

    </div>

    <div data-carousel-item="3" class="w-screen hidden hide relative md:w-full md:max-w-md max-w-full max-h-screen overflow-auto h-full bg-white hide-scrollbar">
        <div class="">
            <img src="{{ asset('src/images/bg-profile.png') }}" alt="">
        </div>
        <div class="absolute left-0 lg:right-0 right-0 lg:top-[160px] top-[50px]">
            <div class="flex px-8  flex-col gap-2">
                <div>
                    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_15_1062)">
                            <path d="M39.9448 21.4998H32.8002C26.5593 21.4998 21.5002 26.559 21.5002 32.7998V39.9444C31.3501 39.214 39.2144 31.3497 39.9448 21.4998Z" fill="white"/>
                            <path d="M18.5003 39.9444V32.7998C18.5003 26.559 13.4411 21.4998 7.20026 21.4998H0.0556641C0.785998 31.3497 8.65036 39.214 18.5003 39.9444Z" fill="white"/>
                            <path d="M39.9448 18.4998C39.2144 8.64987 31.3501 0.78551 21.5002 0.0551758V7.19977C21.5002 13.4406 26.5593 18.4998 32.8002 18.4998H39.9448Z" fill="white"/>
                            <path d="M18.5003 0.0551758C8.65036 0.78551 0.785998 8.64987 0.0556641 18.4998H7.20026C13.4411 18.4998 18.5003 13.4406 18.5003 7.19977V0.0551758Z" fill="white"/>
                            <path d="M13.583 19.9998C16.3555 18.6145 18.615 16.355 20.0002 13.5825C21.3855 16.355 23.6449 18.6145 26.4175 19.9998C23.6449 21.385 21.3855 23.6445 20.0002 26.417C18.615 23.6445 16.3555 21.385 13.583 19.9998Z" fill="#FFDE81"/>
                        </g>
                        <defs>
                            <clipPath id="clip0_15_1062">
                                <rect width="40" height="40" fill="white"/>
                            </clipPath>
                        </defs>
                    </svg>
                </div>
                <div class="text-[#F6F8FC] text-[32px] font-bold" style="line-height: 40px">
                    Customer Loyalty
                </div>
                <div class="text-[#E2E8F0] text-[18px] font-normal" style="line-height: 22px">
                    Integrated Platform
                </div>
            </div>
            <div class="mt-[30px] bg-white rounded-t-2xl p-6">
                <div style="font-weight: 600;" class="w-full h-8 text-[16px] flex items-center">
                    Create account
                </div>
                <form class="mt-4" x-on:submit.prevent="register()">
                    <div class="relative border-2 pt-5 rounded-xl">
                        <div class="form-group">
                            <input type="text" id="name" style="font-weight: 400;" class="w-full h-11 p-3 text-[16px] rounded-xl" required>
                            <label for="name" style="font-weight: 400;" class="w-full h-7 p-1 flex items-center text-[#6A6A75] text-[14px]">Name</label>
                        </div>
                        <div class="relative">
                            @if(isset($errorMessages['name']))
                                <p style="font-size: 12px;" class="absolute text-red-600">{{ $errorMessages['name'][0] }}</p>
                            @endif
                        </div>
                    </div>
                    <div class="relative border-2 mt-6 rounded-xl pt-5">
                        <div class="form-group">
                            <input type="email" id="email" style="font-weight: 400;" class="w-full h-11 p-3 text-[16px] rounded-xl" required>
                            <label for="email" style="font-weight: 400;" class="w-full h-7 p-1 flex items-center text-[#6A6A75] text-[14px]">Email</label>
                        </div>
                        <div class="relative">
                            @if(isset($errorMessages['email']))
                                <p style="font-size: 12px;" class="absolute text-red-600">{{ $errorMessages['email'][0] }}</p>
                            @endif
                        </div>
                    </div>
                    <div class="relative border-2 mt-6 rounded-xl pt-5">
                        <div class="form-group">
                            <input type="text" id="phone_number" style="font-weight: 400;" class="w-full h-11 p-3 text-[16px] rounded-xl" required>
                            <label for="phone_number" style="font-weight: 400;" class="w-full h-7 p-1 flex items-center text-[#6A6A75] text-[14px]">Phone number</label>
                        </div>
                        <div class="relative">
                            @if(isset($errorMessages['phone_number']))
                                <p style="font-size: 12px;" class="absolute text-red-600">{{ $errorMessages['phone_number'][0] }}</p>
                            @endif
                        </div>
                    </div>
                    <div class="relative border-x-2 border-2 pt-5 rounded-xl mt-5">
                        <div class="form-group">
                            <div class="flex items-center">
                                <input type="text" id="day" style="font-weight: 400;width:40px" wire:change="checkDay" class="h-11 p-3 text-[16px] rounded-b-lg" required maxlength="2">/
                                <input type="text" id="month" style="font-weight: 400;width:40px" wire:change="checkMonth" class="h-11 p-3 text-[16px] rounded-b-lg" required maxlength="2">/
                                <input type="text" id="year" style="font-weight: 400;width:80px" wire:change="checkYear" class="h-11 p-3 text-[16px] rounded-b-lg" required maxlength="4">
                            </div>
                            <label style="font-weight: 400;color: #9AA0A6;top:10px;font-size: 12px;transform: translateY(-100%) scale(0.8);color: #333;" class="w-full h-7 p-1 flex items-center text-[#6A6A75] text-[14px]">Birth date</label>
                        </div>
                        @if(isset($errorMessages['day']))
                        <div class="absolute text-[12px] ml-3 text-red-500">
                            {{ $errorMessages['day'][0] }}
                        </div>
                        @elseif(isset($errorMessages['month']))
                        <div class="absolute text-[12px] ml-3 text-red-500">
                            {{ $errorMessages['month'][0] }}
                        </div>
                        @elseif(isset($errorMessages['year']))
                        <div class="absolute text-[12px] ml-3 text-red-500">
                            {{ $errorMessages['year'][0] }}
                        </div>
                        @endif
                    </div>
                    <div class="relative mt-6 rounded-xl border-2 pt-5">
                        <div class="form-group">
                            <input type="password" id="input-password" style="font-weight: 400;" class="w-full h-11 p-3 text-[16px] rounded-b-lg rounded-xl rounded-xl" required>
                            <label for="input-password" style="font-weight: 400;" class="w-full h-7 p-1 flex items-center text-[#6A6A75] text-[14px]">Password</label>
                            <div onclick="seePassword('hide-password', 'view-password', 'input-password')" class="absolute right-4 top-0 cursor-pointer">
                                <img src="{{asset('src/icons/hide.png')}}" id="hide-password" class="w-[20px] h-[20px]" alt="">
                                <img src="{{asset('src/icons/view.png')}}" id="view-password" class="w-[20px] h-[20px] hidden" alt="">
                            </div>
                        </div>
                        <div class="relative">
                            @if(isset($errorMessages['password']))
                                <p style="font-size: 12px;" class="absolute text-red-600">{{ $errorMessages['password'][0] }}</p>
                            @endif
                        </div>
                    </div>
                    <div class="relative mt-6 border-2 pt-5 rounded-xl">
                        <div class="form-group">
                            <input type="password" id="input-confirmation-password" style="font-weight: 400;" class="w-full h-11 p-3 text-[16px] rounded-xl" required>
                            <label for="input-confirmation-password" style="font-weight: 400;" class="w-full h-7 p-1 flex items-center text-[#6A6A75] text-[14px]">Password confirmation</label>
                            <div onclick="seePassword('hide-confirmation-password', 'view-confirmation-password', 'input-confirmation-password')" class="absolute right-4 top-0 cursor-pointer">
                                <img src="{{asset('src/icons/hide.png')}}" id="hide-confirmation-password" class="w-[20px] h-[20px]" alt="">
                                <img src="{{asset('src/icons/view.png')}}" id="view-confirmation-password" class="w-[20px] h-[20px] hidden" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="mt-6">
                        <button type="submit" style="font-weight: 600;@if($name && $email && $phone_number && $day && $month && $year && $password && $passwordConfirmation) background-color:#DA0713;color:white @else background-color:#F6F8FC;color:#757575 @endif" class="w-full h-[56px] rounded-xl text-center flex justify-center items-center text-[16px]">
                            Create account
                        </button>
                    </div>
                    <div class="mt-6">
                        <a href="{{ route('login', ['data' => encrypt(['from_register' => true])]) }}" style="font-weight: 700;background-color:white;" class="w-full h-[56px] border-2 rounded-xl text-center flex justify-center items-center text-[16px]">
                            Already have an account? Login
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="{{asset('src/js/seePassword.js')}}"></script>
</div>
