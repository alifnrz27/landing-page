<div class="w-screen flex justify-center bg-white min-h-screen" x-data="{openForm:false, openMaxPointList:false}" x-init="
    $wire.on('formOpen', value => {
        openForm = value;
    });
    ">
    <div style="margin-top:95px;max-width:500px" class="absolute w-full flex justify-center px-12 text-black bg-white">
        <div class="flex-1 overflow-y-auto hide-scrollbar w-52">
            <div class="p-5">
                <div class="w-full border border-[#EDEDED] p-5 truncate no-select">
                    <div class="w-full flex justify-center items-center">
                        <div class="border border-gray-400 p-2 rounded-full">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                                <path class="stroke-dark" d="M3.99994 18.2402C3.99994 17.1794 4.42137 16.162 5.17151 15.4118C5.92166 14.6617 6.93907 14.2402 7.99994 14.2402H15.9999C17.0608 14.2402 18.0782 14.6617 18.8284 15.4118C19.5785 16.162 19.9999 17.1794 19.9999 18.2402C19.9999 18.7707 19.7892 19.2794 19.4142 19.6544C19.0391 20.0295 18.5304 20.2402 17.9999 20.2402H5.99994C5.46951 20.2402 4.9608 20.0295 4.58573 19.6544C4.21065 19.2794 3.99994 18.7707 3.99994 18.2402Z" stroke="#6A6A75" stroke-width="2" stroke-linejoin="round"/>
                                <path class="stroke-dark" d="M11.9999 10.2402C13.6568 10.2402 14.9999 8.89709 14.9999 7.24023C14.9999 5.58338 13.6568 4.24023 11.9999 4.24023C10.3431 4.24023 8.99994 5.58338 8.99994 7.24023C8.99994 8.89709 10.3431 10.2402 11.9999 10.2402Z" stroke="#6A6A75" stroke-width="2"/>
                            </svg>
                        </div>
                    </div>
                    <div style="font-weight: 700;" class="w-full flex justify-center items-center mt-1 text-[24px] text-dark">
                        {{ auth()->user()->name }}
                    </div>
                    <div style="font-weight: 400;" class="w-full flex justify-center items-center mt-1 text-[16px] text-[#6A6A75]">
                        {{ auth()->user()->email }}
                    </div>
                    <div style="font-weight: 400;" class="w-full flex justify-center items-center mt-1 text-[16px] text-[#6A6A75]">
                        {{ auth()->user()->phone_number }}
                    </div>
                </div>
            </div>

            <div class="w-full mt-6 px-5">
                {{-- <div class="flex items-center justify-center mt-4 no-select">
                    <div class="flex">
                        <span class="mr-2 text-sm text-dark">
                            light
                        </span>
                        <input type="checkbox" class="hidden" id="dark-toggle" />
                        <label for="dark-toggle">
                            <div class="flex h-5 w-9 cursor-pointer items-center rounded-full p-1 bg-primary">
                                <div class="toggle-circle h-4 w-4 rounded-full bg-white transition duration-300 ease-in-out">
                                </div>
                            </div>
                        </label>
                        <span class="ml-2 text-sm text-dark">
                            dark
                        </span>
                    </div>
                </div> --}}

                @if(auth()->user()->role_id == 2)
                <div>
                    <div @click="openMaxPointList=true" class="flex w-full justify-center items-center p-3 border border-[#EDEDED] mt-4 cursor-pointer no-select">
                        Maximum point
                    </div>
                </div>
                @endif

                <form action="{{route('logout')}}" method="POST">
                    @csrf
                    <button type="submit" class="flex w-full justify-center items-center p-3 border border-[#EDEDED] text-[#FE5C5C] mt-4 cursor-pointer no-select">
                        Log Out
                    </button>
                </form>

            </div>
        </div>
    </div>


    @if(auth()->user()->role_id == 2)
    <div x-cloak x-show="openMaxPointList" style="z-index: 50" class="fixed w-screen h-screen top-0 flex items-center justify-center  bg-dark-primary bg-opacity-60">
        <div @click.outside="openMaxPointList=false" class="w-[350px] p-4 bg-white rounded-lg">
            <div class="flex justify-between items-center border-b pb-2 px-2 no-select">
                <div class="text-[16px]">
                    Max point
                </div>
                <div @click="openMaxPointList=false" class="cursor-pointer">
                    x
                </div>
            </div>
            <div class="my-3 flex flex-col gap-3 max-h-[400px] overflow-auto">
                <table style="width: 100%; border-collapse: collapse; border: 1px solid #000;">
                    <thead>
                        <tr>
                            <th style="border: 1px solid #000;">Point</th>
                            <th style="border: 1px solid #000;">Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($max_points as $index => $max_point)
                        <tr>
                            <td class="text-center relative" style="border: 1px solid #000;">
                                <div>
                                    {{ $max_point->max_point }}
                                </div>
                                @if($max_point->status)
                                <div class="absolute w-3 h-3 bg-green-500 rounded-full top-2 left-2">

                                </div>
                                @endif
                            </td>
                            <td class="text-center" style="border: 1px solid #000;">{{ $max_point->type == 1 ? 'Monthly' : 'Yearly' }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="w-full flex items-center justify-end">
                <div class="flex gap-2 no-select">
                    <div @click="openForm=false" class="cursor-pointer px-3 py-2 bg-red-500 text-white rounded-lg">
                        Cancel
                    </div>
                    <div @click="openForm=true" class="cursor-pointer px-3 py-2 bg-blue-500 text-white rounded-lg">
                        Add
                    </div>
                </div>
            </div>

            <div x-cloak x-show="openForm" style="z-index: 50" class="fixed w-screen h-screen left-0 top-0 flex items-center justify-center  bg-dark-primary bg-opacity-60">
                <div @click.outside="openForm=false" class="w-[350px] p-4 bg-white rounded-lg">
                    <div class="flex justify-between items-center border-b pb-2 px-2 no-select">
                        <div class="text-[16px]">
                            Update maximum point
                        </div>
                        <div @click="openForm=false" class="cursor-pointer">
                            x
                        </div>
                    </div>
                    <div class="my-3 flex flex-col gap-3">
                        <div class="text-[14px]">
                            Type
                        </div>
                        <div>
                            <select wire:model.lazy="type" class="w-full rounded-md">
                                <option>Choose type</option>
                                <option value="1">Monthly</option>
                                <option value="2">Yearly</option>
                            </select>
                        </div>
                    </div>
                    <div class="my-3 flex flex-col gap-3">
                        <div class="text-[14px]">
                            Maximum point (<0 = infinite)
                        </div>
                        <div>
                            <input type="number" wire:model.lazy='max_point' class="w-full rounded-md">
                        </div>
                    </div>
                    <div class="w-full flex items-center justify-end">
                        <div class="flex gap-2 no-select">
                            <div @click="openForm=false" class="cursor-pointer px-3 py-2 bg-red-500 text-white rounded-lg">
                                Cancel
                            </div>
                            <div wire:click="updateMaxPoint" class="cursor-pointer px-3 py-2 bg-blue-500 text-white rounded-lg">
                                Save
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @endif
</div>
