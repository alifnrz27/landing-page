<div class="w-screen relative"  x-data="{open:false, openConfirm:false, loading:false, notification:false}" x-init="
            $wire.on('updateOpen', value => {
                open = value;
                openConfirm = false;
                scrollToTop();
            });
            $wire.on('closeLoader', value => {
                loading=false;
                scrollToTop();
            });
            $wire.on('showNotification', value => {
                notification=true;
                setTimeout(function() {
                    notification=false;
                }, 2000);
            })
        ">
    <div class="w-full flex fixed">
        <div x-show="notification" class="w-full bg-green-500 h-10 flex items-center px-12">
            <div class="w-full">
                <div class="relative justify-center items-center flex">
                    <div style="font-weight: 600;" class="text-[16px] text-white">
                        🎉 New promo created successfully
                    </div>
                    <div @click="notification=false" class="absolute right-0 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 11.9996L16.2563 8.80273C16.5469 8.51211 16.5469 8.03398 16.2563 7.74336C15.9656 7.45273 15.4875 7.45273 15.1969 7.74336L12 10.9402L8.80313 7.74336C8.5125 7.45273 8.03437 7.45273 7.74375 7.74336C7.59844 7.88867 7.52344 8.08086 7.52344 8.27305C7.52344 8.46523 7.59844 8.65742 7.74375 8.80273L10.9406 11.9996L7.74375 15.1965C7.59844 15.3418 7.52344 15.534 7.52344 15.7262C7.52344 15.9184 7.59844 16.1105 7.74375 16.2559C8.03437 16.5465 8.5125 16.5465 8.80313 16.2559L12 13.059L15.1969 16.2559C15.4875 16.5465 15.9656 16.5465 16.2563 16.2559C16.5469 15.9652 16.5469 15.4871 16.2563 15.1965L13.0594 11.9996Z" fill="white"/>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div x-show="loading">
        <x-layouts.loading/>
    </div>

    <div class="px-12">
        <div x-cloak x-show="!open" class="w-full max-w-screen flex mt-6" >
            <div class="{{ $isShow ? 'hidden md:block md:w-9/12' : 'w-full' }} pr-0 md:pr-22">
                <div class="w-full flex">
                    <div class="w-full md:w-3/5 ">
                        <div>
                            <div class="w-full lg:w-[550px] mb-10">
                                <div style="font-weight: 700;" class="text-dark-primary text-[24px] mb-2">
                                    Promo
                                </div>
                                <div style="font-weight: 400;" class="text-[16px] text-dark-primary">
                                    This page is for creating and publishing promotions in your your store
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="w-full h-[44px] justify-between flex mt-12">
                    <div class="w-11/12 md:w-6/12 h-full flex">
                        <div class="relative w-6/12 h-full bg-red-300 mr-6">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                                <img src="{{ asset('src/icons/ios-search.svg') }}" />
                            </span>
                            <input class="w-full h-full rounded-sm text-[16px]" wire:model="search" placeholder="Find promo...." style="padding-left:38px;border-radius: var(--corner-radius-corner-xs, 2px);" />
                        </div>
                        <div class="w-4/12 md:w-3/12 h-full">
                            <select class="w-full h-full rounded-sm">
                                <option style="font-weight: 400;" class="text-[16px]">All</option>
                            </select>
                        </div>
                    </div>
                    @if(auth()->user()->role_id == 2)
                    <div class="w-1/12" @click="open=true">
                        <button type="button" style="font-weight: 600;" class="flex text-white text-[16px] bg-primary p-3 rounded-sm">
                            <div class="mr-1">
                                +
                            </div>
                            @if(!$isShow)
                            <div class="hidden xl:block">
                                Add new
                            </div>
                            @endif
                        </button>
                    </div>
                    @endif
                </div>

                <div class="w-full overflow-auto">
                    <table class="w-full min-w-[1336px] mt-6">
                        <thead class="items-center h-[68px] text-gray-500 text-[16px]">
                            <th class="border text-dark-primary" style="width:312px">TITLE</th>
                            <th class="border justify-center  text-dark-primary" style="width:192px">
                                <div class="flex justify-center items-center">
                                    <div class="mr-1">
                                        STATUS
                                    </div>
                                    <div>
                                        <img src="{{ asset('src/icons/ios-code.svg') }}" />
                                    </div>
                                </div>
                            </th>
                            <th class="border text-dark-primary" style="width:250px">
                                <div class="flex justify-center items-center">
                                    <div class="mr-1">
                                        EFFECTIVE DATE
                                    </div>
                                    <div>
                                        <img src="{{ asset('src/icons/ios-code.svg') }}" />
                                    </div>
                                </div>
                            </th>
                            <th class="border text-dark-primary" style="width:210px">
                                <div class="flex justify-center items-center">
                                    <div class="mr-1">
                                        LOCATION
                                    </div>
                                    <div>
                                        <img src="{{ asset('src/icons/ios-code.svg') }}" />
                                    </div>
                                </div>
                            </th>
                            <th class="border text-dark-primary" style="width:134px">
                                <div class="flex justify-center items-center">
                                    <div class="mr-1">
                                        LIMIT
                                    </div>
                                    <div>
                                        <img src="{{ asset('src/icons/ios-code.svg') }}" />
                                    </div>
                                </div>
                            </th>
                        </thead>
                        <tbody>
                            @foreach ($promotions as $promo)
                            <tr class="border {{ isset($show_data->id) ? $promo->id == $show_data->id ? 'bg-gray-300' : '' : '' }}">
                                <td>
                                    <div class="flex mb-2 items-center px-6 py-3">
                                        <div class="h-10 w-10 bg-[#DDF1E2] rounded-full flex items-center justify-center mr-1">
                                            <img class="w-5 h-5" src="{{ asset('src/icons/iconamoon_discount-fill.svg') }}" />
                                        </div>
                                        <div style="font-weight: 400; max-width: 264px;" class="text-[16px] text-gray-500">
                                            <div style="font-weight: 600;" class="text-[16px] text-black truncate">
                                                {{$promo->title}}
                                            </div>
                                            <div class="text-[14px] truncate">
                                                {{$promo->description}}
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-2 px-6">
                                    <div class="inline-block border px-2 py-1 rounded-3xl">
                                        <div class="flex items-center">
                                            <div class="w-[6px] h-[6px] @if(getStatusPromo($promo) == 'Active') bg-[#2C9854]  @elseif(getStatusPromo($promo) == 'Not active') bg-[#EDEDED] @else bg-[#FF8933] @endif  rounded-full mr-1">
                                            </div>
                                            <div style="font-weight: 400;" class="text-[14px] text-dark-primary">
                                                {{ getStatusPromo($promo) }}
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td style="font-weight: 400;" class="w-[210px] px-6 py-3 text-center text-[14px] text-dark-primary">{{ changeDateFormat($promo->start_date) }} - {{ changeDateFormat($promo->end_date) }}</td>
                                <td style="font-weight: 400;" class="max-w-[210px] px-6 py-3 text-center text-[14px] truncate flex justify-center">
                                    <div style="margin-left:-10px;margin-top:15px" class="relative flex items-center max-w-[200px] scroll-container">
                                        @if($promo->is_all_stores)
                                            <div class="px-2 py-1 bg-gray-400 rounded-full text-white flex mr-2">
                                                <div class="w-[100px] h-full truncate" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                                                    All store
                                                </div>
                                            </div>
                                        @else
                                        @foreach($promo->promotionStores as $store)
                                            <div class="px-2 py-1 bg-gray-400 rounded-full text-white flex mr-2">
                                                <div class="w-[100px] h-full truncate" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                                                    {{$store->store->name}}
                                                </div>
                                            </div>
                                        @endforeach
                                        @endif
                                    </div>
                                </td>
                                <td style="font-weight: 400;" class="w-[210px] px-6 py-3 text-center text-[14px] text-dark-primary">
                                    <div class="flex justify-between items-center mx-6 my-3">
                                        {{ $promo->limit == 0 ? "Unlimited" : $promo->limit." X" }}
                                        <div class="cursor-pointer">
                                            <div wire:click="showPromotion({{ $promo->id }})">
                                                <img src="{{ asset('src/icons/md-more.svg') }}" />
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>

                    {{-- <div>
                        <div class="mb-4">
                            <label for="per_page">Items per Page:</label>
                            <input wire:model="perPage" type="number" id="per_page" min="1">
                        </div>

                        <div class="pagination">
                            <!-- Custom pagination links -->
                            <ul>
                                @if ($promotions->onFirstPage())
                                    <li class="disabled"><span>Previous</span></li>
                                @else
                                    <li><a wire:click="previousPage" href="#">Previous</a></li>
                                @endif

                                @foreach ($promotions->getUrlRange(1, $promotions->lastPage()) as $page => $url)
                                    @if ($page == $promotions->currentPage())
                                        <li class="active"><span>{{ $page }}</span></li>
                                    @else
                                        <li><a wire:click="gotoPage({{ $page }})" href="{{ $url }}">{{ $page }}</a></li>
                                    @endif
                                @endforeach

                                @if ($promotions->hasMorePages())
                                    <li><a wire:click="nextPage" href="#">Next</a></li>
                                @else
                                    <li class="disabled"><span>Next</span></li>
                                @endif
                            </ul>
                        </div>
                    </div> --}}


                </div>
            </div>

            @if($isShow)
            <div style="margin-top:-35px;z-index:40" class="w-full md:w-3/12 md:border-l">
                <div  class="w-full px-6 py-3 border-b">
                    <div class=" w-full flex justify-between">
                        <div class="cursor-pointer" wire:click="deleteShow">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M21 3V21" stroke="#B1B1B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M3 12H16.5" stroke="#B1B1B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M10 19L17 12L10 5" stroke="#B1B1B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                        @if(auth()->user()->role_id == 2)
                        <div class="flex items-center cursor-pointer" wire:click="showUpdatePromotion({{ $show_data->id }})">
                            <div>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M2.5 14.5501V17.0834C2.5 17.3167 2.68333 17.5001 2.91667 17.5001H5.45C5.55833 17.5001 5.66667 17.4584 5.74167 17.3751L14.8417 8.28342L11.7167 5.15842L2.625 14.2501C2.54167 14.3334 2.5 14.4334 2.5 14.5501ZM17.2583 5.86675C17.3356 5.78966 17.3969 5.69808 17.4387 5.59727C17.4805 5.49646 17.502 5.38839 17.502 5.27925C17.502 5.17011 17.4805 5.06204 17.4387 4.96123C17.3969 4.86042 17.3356 4.76885 17.2583 4.69175L15.3083 2.74175C15.2312 2.6645 15.1397 2.60321 15.0389 2.56139C14.938 2.51957 14.83 2.49805 14.7208 2.49805C14.6117 2.49805 14.5036 2.51957 14.4028 2.56139C14.302 2.60321 14.2104 2.6645 14.1333 2.74175L12.6083 4.26675L15.7333 7.39175L17.2583 5.86675Z" fill="#3688EF"/>
                                </svg>
                            </div>
                            <div class="text-[16px] text-primary ml-1" style="font-weight: 600;">
                                Edit
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
                <br>
                <div class="p-6">
                    <div id="thumbnailUploadContainer" class="w-full overflow-hidden flex mb-6 {{$thumbnail_image ? 'items-start justify-end' : 'items-center justify-center'}}">
                        @if ($thumbnail_image)
                        <img src="{{ asset('storage/' . $thumbnail_image) }}" class= "w-[100%] mt-6" alt="Image">
                        @else
                            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
                                <path d="M35 31.6666V8.33336C35 6.49984 33.5002 5 31.6666 5H8.33336C6.49984 5 5 6.49984 5 8.33336V31.6666C5 33.5002 6.49984 35 8.33336 35H31.6666C33.5002 35 35 33.5002 35 31.6666ZM14.1666 22.5L18.3334 27.5L24.1666 20L31.6666 30H8.33336L14.1666 22.5Z" fill="#DEE3E9"/>
                            </svg>
                        @endif
                    </div>

                    <div class="w-full mb-6">
                        <div style="font-weight: 600;" class="truncate text-[20px] text-dark-primary">
                            {{ $title }}
                        </div>
                        <div style="font-weight: 400;" class="line-clamp-2 text-[16px] text-gray-500 mt-2">
                            {{ $description }}
                        </div>
                    </div>

                    <div>
                        @if($show_data)
                        @if(!$show_data->status_by_admin)
                        <div class="p-3 mb-5 flex bg-[#FAF1F1]">
                            <div class="mr-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                                    <path d="M10.7297 3.99531L2.42815 19.1453C1.90315 20.0922 2.60159 21.25 3.69847 21.25H20.3063C21.3985 21.25 22.0969 20.0922 21.5766 19.1453L13.2703 3.99531C12.7219 3.00156 11.2782 3.00156 10.7297 3.99531ZM12.825 10.2812L12.6563 16H11.3438L11.175 10.2812H12.825ZM12 19.1125C11.4985 19.1125 11.1047 18.7328 11.1047 18.25C11.1047 17.7672 11.4985 17.3875 12 17.3875C12.5016 17.3875 12.8953 17.7672 12.8953 18.25C12.8953 18.7328 12.5016 19.1125 12 19.1125Z" fill="#FE5C5C"/>
                                </svg>
                            </div>
                            <div>
                                <div style="font-weight: 600;line-height: 20px;" class="text-[16px]">
                                    You're not allowed to edit
                                </div>
                                <div style="font-weight: 400;line-height: 20px;" class="text-[14px]">
                                    This promo has been disabled by admin. Contact the admin if you want to reactivate it.
                                </div>
                            </div>
                        </div>
                        @endif
                        @endif
                        <div class="flex justify-between mb-5">
                            <div style="font-weight: 400;" class="text-[16px] text-gray-500">
                                Status
                            </div>
                            <div @if($show_data)@if(auth()->user()->role_id == 2 && $show_data->status_by_admin) wire:click="changeStatus()" @endif @endif class="text-dark-primary">
                                <div class="flex items-center justify-center mt-4 no-select">
                                    <div class="flex">
                                        <label>
                                            <div class="flex h-5 w-9 cursor-pointer items-center rounded-full p-1 @if($show_data) @if(!$show_data->status_by_admin) 'bg-[#EDEDED]' @else {{$status ? 'bg-primary' : 'bg-dark-secondary'}} @endif @endif">
                                                <div class="toggle-circle h-4 w-4 rounded-full {{$status ? 'translate-x-3' : ''}} bg-white transition duration-300 ease-in-out">
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flex justify-between mb-5">
                            <div style="font-weight: 400;" class="text-[16px] text-gray-500">
                                Effective Date
                            </div>
                            <div style='font-weight: 400;' class="text-[16px] text-dark-primary">
                                {{changeDateFormat($start_date)}} - {{changeDateFormat($end_date)}}
                            </div>
                        </div>
                        <div class="flex justify-between mb-5">
                            <div style="font-weight: 400;" class="text-[16px] text-gray-500">
                                Location
                            </div>
                            <div>
                                @if($is_all_stores)
                                    <div  style="font-weight: 400;" class="text-[16px] text-dark-primary">
                                        All store
                                    </div>
                                @else
                                @foreach ($show_data->promotionStores as $store)
                                    <div  style="font-weight: 400;" class="text-[16px] text-dark-primary">
                                        {{$store->store->name}}
                                    </div>
                                @endforeach
                                @endif
                            </div>
                        </div>
                        <div class="flex justify-between mb-5">
                            <div style="font-weight: 400;" class="text-[16px] text-gray-500">
                                Limit
                            </div>
                            <div style='font-weight: 400;' class="text-[16px] text-dark-primary">
                                {{ $limit == 0 ? "Unlimited" : $limit." X" }}
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            @endif
        </div>


        @if(auth()->user()->role_id == 2)
        <div x-cloak x-show="open" style="z-index:50;left:0;overflow: auto;" class="fixed w-screen h-full bg-white">
            <form wire:submit.prevent="{{$isShowUpdate ? 'updatePromo('. $show_data->id .')' : 'submitPromo'}}">
                <div class="w-full px-0 md:px-[100px] lg:px-[399px] bg-[#F9FAFB]">
                    <div>
                        <div class="inline-block cursor-pointer" wire:click="clearForm" @click="open=false" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                            <div class="flex items-center mt-[40px]">
                                <div class="mr-1">
                                    <img src="{{ asset('src/icons/ios-arrow-round-back.svg') }}" />
                                </div>
                                <div style="font-weight: 600;" class="text-[16px] text-primary">
                                    Back
                                </div>
                            </div>
                        </div>
                        <div style="font-weight: 700;" class="text-[24px] text-dark-primary">
                            {{$isShowUpdate ? 'Update promo' : 'Create new promo'}}
                        </div>

                        <div class="mt-6 p-6 bg-white w-full" x-data="{
                            deleteImage(){
                                const thumbnailContainer = document.getElementById('thumbnailUploadContainer');
                                const thumbnailInput = document.getElementById('thumbnailInput');
                                let thumbnailImage = null;
                            },
                            addImage(){
                                const thumbnailInput = document.getElementById('thumbnailInput');
                                thumbnailInput.click();
                            }
                        }">
                            <div class="mb-5" >
                                <div style="font-weight: 400;" class="text-[14px] text-gray-500 mb-1">
                                    Thumbnail
                                </div>
                                <input type="file" id="thumbnailInput" wire:model="thumbnail" class="hidden">
                                <input type="file" id="thumbnailImage" class="hidden image" accept="image/png, image/jpeg">
                                @if ($thumbnail)
                                <div class="relative">
                                    <img src="{{ substr($thumbnail, 0, 4) != "data" ?  asset('storage/'.$thumbnail) : $thumbnail }}" class= "w-[100%]" alt="Uploaded Image">
                                    <div wire:click="removeThumbnail" @click="deleteImage()" class="absolute top-5 right-5 items-start p-1 text-white cursor-pointer rounded-full bg-black opacity-50">
                                        x
                                    </div>
                                </div>
                                @else
                                <label for="thumbnailImage" class="w-full h-[134px] cursor-pointer flex {{$thumbnail ? 'items-start justify-end' : 'items-center justify-center'}} border border-dashed">
                                    <div style="font-weight: 400;" class="w-full text-center">
                                        <div class="flex justify-center mb-[2px]">
                                            <img class="justify-center" src="{{ asset('src/icons/ios-cloud-upload.svg') }}" />
                                        </div>
                                        <div class="text-[16px] mb-2 text-dark-primary">
                                            Upload thumbnail image
                                        </div>
                                        <div class="text-[14px] text-gray-500">
                                            PNG, atau JPG maximum 8MB
                                        </div>
                                    </div>
                                </label>
                                @endif
                                @if(isset($errorMessages['thumbnail']))
                                    <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['thumbnail'][0] }}</p>
                                @endif
                            </div>
                            <div class="mb-5">
                                <div class="inline-block mb-1">
                                    <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                        <div class="mr-1 text-gray-500">
                                            Title
                                        </div>
                                        <div class="text-red-600">
                                            *
                                        </div>
                                    </div>
                                </div>
                                <div class="w-full">
                                    <input style="font-weight: 400;" wire:model="title" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert title here...." />
                                    @if(isset($errorMessages['title']))
                                        <p class="relative text-sm text-red-600">{{ $errorMessages['title'][0] }}</p>
                                    @endif
                                </div>
                            </div>

                            <div class="mb-5">
                                <div class="inline-block mb-1">
                                    <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                        <div class="mr-1 text-gray-500">
                                            Description
                                        </div>
                                        <div class="text-red-600">
                                            *
                                        </div>
                                    </div>
                                </div>
                                <div class="w-full">
                                    <textarea class="w-full h-[100px]" wire:model="description" placeholder="Insert promo terms & conditions...."></textarea>
                                    @if(isset($errorMessages['description']))
                                        <p class="relative text-sm text-red-600 -mt-2">{{ $errorMessages['description'][0] }}</p>
                                    @endif
                                </div>
                            </div>

                            <div class="flex mb-5">
                                <div class="w-6/12 mr-5">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500">
                                                Choose store
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>


                                    <div class="w-full">
                                        <input type="hidden" id="store-id" wire:model="store_id" />
                                        <select style="font-weight: 400;" onchange="selectStore(this)" class="w-full h-[44px] border border-gray-500 p-3 text-[16px] text-gray-500 text-hidden text-transparent">
                                            <option class="text-black">Choose store</option>
                                            <?php $array_store_id = explode(",", $store_id); ?>
                                            <option class="text-black {{ in_array(0, $array_store_id) || $store_id == 0 ? 'hidden' : '' }} store-list" onclick="selectStore(this)" id="store-selected-0" value="0">All store</option>
                                            @foreach ($stores as $store)
                                                <option class="text-black {{ in_array($store->id, $array_store_id) || $store_id == 0 ? 'hidden' : '' }}" onclick="selectStore(this)" id="store-selected-{{ $store->id }}" value="{{ $store->id }}">{{ $store->name }}</option>
                                            @endforeach
                                        </select>
                                        <div class="relative w-10/12 h-[35px] flex items-center pl-3 pt-1" style="margin-top:-44px;">
                                            <div id='selected-store' class="absolute flex max-w-[270px] scroll-container">
                                                @if($store_id == 0)
                                                    <div class="px-2 py-1 bg-gray-400 rounded-full text-white flex mr-2">
                                                        <div class="w-[100px] truncate" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                                                            All store
                                                        </div>
                                                        <div class="justify-end text-red-500 cursor-pointer" onclick="removeStore(this, 0)" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                                                            x
                                                        </div>
                                                    </div>
                                                @endif
                                                @foreach($stores as $store)
                                                    @if(in_array($store->id, $array_store_id))
                                                        <div class="px-2 py-1 bg-gray-400 rounded-full text-white flex mr-2">
                                                            <div class="w-[100px] truncate" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                                                                {{$store->name}}
                                                            </div>
                                                            <div class="justify-end text-red-500 cursor-pointer" onclick="removeStore(this, {{$store->id}})" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                                                                x
                                                            </div>
                                                        </div>
                                                    @endif
                                                @endforeach
                                            </div>
                                        </div>
                                        @if(isset($errorMessages['store_id']))
                                            <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['store_id'][0] }}</p>
                                        @endif
                                    </div>
                                </div>


                                <div class="w-6/12">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500">
                                                Limit
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <select style="font-weight: 400;" wire:model="limit" class="w-full h-[44px] border border-gray-500 p-3 text-[16px] text-gray-500" >
                                            <option>How many times can it be exchanged</option>
                                            <option value="1">1 X</option>
                                            <option value="2">2 X</option>
                                            <option value="3">3 X</option>
                                            <option value="0">Unlimited</option>
                                        </select>
                                        @if(isset($errorMessages['limit']))
                                            <p class="relative text-sm text-red-600">{{ $errorMessages['limit'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="flex mb-5">
                                <div class="w-6/12 mr-5">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500">
                                                Start date
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input type="date" style="font-weight: 400;" wire:model="start_date" class="w-full h-[44px] border border-gray-500 p-3 text-[16px] text-gray-500" placeholder="Tanggal mulai aktif" />
                                        @if(isset($errorMessages['start_date']))
                                            <p class="relative text-sm text-red-600">{{ $errorMessages['start_date'][0] }}</p>
                                    @endif
                                    </div>
                                </div>
                                <div class="w-6/12">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500">
                                                End date
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input type="date" style="font-weight: 400;" wire:model="end_date" class="w-full h-[44px] border border-gray-500 p-3 text-[16px] text-gray-500" placeholder="Tanggal selesai aktif" />
                                        @if(isset($errorMessages['end_date']))
                                            <p class="relative text-sm text-red-600">{{ $errorMessages['end_date'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                            </div>

                        </div>
                        <hr>
                        <div class="mb-20 p-6 bg-white">
                            <div class="flex justify-end">
                                <div class="mr-[14px]">
                                    <button style="font-weight: 600;" wire:click="clearForm" @click="open=false" class="w-[83px] h-[44px] text-primary text-center text-[16px]">
                                        Cancel
                                    </button>
                                </div>
                                <div>
                                    <button type="button" @click="openConfirm=true" style="font-weight: 600;" class="w-[83px] h-[44px] bg-primary text-white text-center text-[16px]">
                                        Save
                                    </button>

                                    <div x-cloak x-show="openConfirm" x-transition class="fixed top-0 left-0  pt-20 w-full min-h-screen bg-black/50 flex justify-center items-center z-10">
                                        <section @click.outside="openConfirm=false" class="fixed w-[446px] mb-5 mx-auto my-auto bg-white" style="margin-top: -50px">
                                            <div class="w-full max-h-[650px] overflow-hidden">
                                                <div class="w-full  p-6">
                                                    <div style="font-weight: 600;font-size:20px" class="mt-5 mb-2 text-[20px]">
                                                        Are you sure?
                                                    </div>
                                                    <div style="font-size:16px" class="text-gray-500 mb-6">
                                                        Make sure you have filled in the data correctly. If there are errors after saving, you can change it back.
                                                    </div>
                                                    <div class="flex justify-end items-center">
                                                        <p x-on:click="openConfirm = false" style="font-weight: 600;" class="text-[16px] text-primary hover:cursor-pointer hover:opacity-50 duration-150 p-3 mr-[14px]">
                                                            Cancel
                                                        </p>
                                                        <button @click="loading=true;openConfirm=false;" style="font-weight: 600;" class="text-[16px] bg-primary text-white p-3">
                                                            Confirm
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        @endif
    </div>

    <div id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" class="hidden fixed w-screen h-screen top-0 left-0 right-0 bottom-0" style="z-index: 200">
        <div class="absolute top-0 left-0 right-0 bottom-0 flex w-screen h-screen justify-center items-center bg-black bg-opacity-70">
            <div class="modal fade p-10 rounded-lg justify-center items-center w-[500px] h-fit bg-white" style="z-index: 200">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true" class="text-[20px]">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="img-container">
                                <div class="row">
                                    <div class="col-md-8">
                                        <img id="image" class="w-[400px]">
                                    </div>
                                    <div class="col-md-4">
                                        <div class="preview"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="w-full flex gap-2 items-center justify-end mt-5">
                            <button type="button" style=" --tw-bg-opacity: 1;background-color: rgb(248 113 113 / var(--tw-bg-opacity)); color:white;" class="px-3 py-2 bg-red-400 rounded-lg text-white" data-dismiss="modal">Cancel</button>
                            <button type="button" style=" --tw-bg-opacity: 1;background-color: rgb(74 222 128 / var(--tw-bg-opacity)); color:white;" class="px-3 py-2 bg-green-400 rounded-lg text-white" id="crop">Crop</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="{{ asset('src/js/scrollToTop.js') }}"></script>
    <script src="{{ asset('src/js/selectStore.js') }}"></script>
    <script src="{{ asset('src/js/cropperJS.js') }}"></script>
</div>
