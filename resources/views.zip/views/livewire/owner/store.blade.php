<div class="w-full relative" x-data="{open: false, openConfirm:false, loading:false, notification:false}" x-init="
            $wire.on('updateOpen', value => {
                open = value;
                scrollToTop();
            });
            $wire.on('closeLoader', value => {
                loading=false;
                scrollToTop();
            });
            $wire.on('showNotification', value => {
                notification=true;
                setTimeout(function() {
                    notification=false;
                }, 2000);
            })
        ">

    <div class="w-full flex fixed">
        <div x-show="notification" class="w-full bg-green-500 h-10 flex items-center px-12">
            <div class="w-full">
                <div class="relative justify-center items-center flex">
                    <div style="font-weight: 600;" class="text-[16px] text-white">
                        🎉 Success create new store
                    </div>
                    <div @click="notification=false" class="absolute right-0 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 11.9996L16.2563 8.80273C16.5469 8.51211 16.5469 8.03398 16.2563 7.74336C15.9656 7.45273 15.4875 7.45273 15.1969 7.74336L12 10.9402L8.80313 7.74336C8.5125 7.45273 8.03437 7.45273 7.74375 7.74336C7.59844 7.88867 7.52344 8.08086 7.52344 8.27305C7.52344 8.46523 7.59844 8.65742 7.74375 8.80273L10.9406 11.9996L7.74375 15.1965C7.59844 15.3418 7.52344 15.534 7.52344 15.7262C7.52344 15.9184 7.59844 16.1105 7.74375 16.2559C8.03437 16.5465 8.5125 16.5465 8.80313 16.2559L12 13.059L15.1969 16.2559C15.4875 16.5465 15.9656 16.5465 16.2563 16.2559C16.5469 15.9652 16.5469 15.4871 16.2563 15.1965L13.0594 11.9996Z" fill="white"/>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div x-show="loading">
        <x-layouts.loading/>
    </div>

    <div class="px-12">
        <div x-cloak x-show="!open" class="w-full">
            <div class="w-full flex">
                <div class="w-full md:w-3/5 pr-0 md:pr-24">
                    <div>
                        <div class="w-full lg:w-[550px] mb-10">
                            <div style="font-weight: 700;" class="text-black text-[24px] mb-2">
                                Store
                            </div>
                            <div style="font-weight: 400;" class="text-[16px] text-dark-primary">
                                This page is to record the location of your shop. You can add the number of stores according to your needs.
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="w-full h-[44px] justify-between flex mt-12">
                <div class="w-11/12 md:w-6/12 h-full flex">
                    <div class="relative w-6/12 h-full bg-red-300 mr-6">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                            <!-- Add your icon here -->
                            <img src="{{ asset('src/icons/ios-search.svg') }}" />
                        </span>
                        <input class="w-full h-full rounded-sm text-[16px]" wire:model="search" placeholder="Find address...." style="padding-left:38px;border-radius: var(--corner-radius-corner-xs, 2px);" />
                    </div>

                </div>
                <div class="w-1/12" @click="open=true">
                    <button type="button" style="font-weight: 600;" class="flex text-white text-[16px] bg-primary p-3 rounded-sm">
                        <div class="mr-1">
                            +
                        </div>
                        <div class="hidden xl:block">
                            Create
                        </div>
                    </button>
                </div>
            </div>

            <div class="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                @foreach ($stores as $store)
                <div class="w-full flex mx-3 p-6 border rounded-sm justify-between">
                    <div class="flex w-10/12 border-r">
                        <div class="mr-3 w-[24px] h-[24px]">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M3.77802 3.655C3.59702 4.015 3.50802 4.461 3.33002 5.351L2.73202 8.341C2.64727 8.74867 2.64662 9.16936 2.73009 9.5773C2.81357 9.98523 2.97943 10.3718 3.21751 10.7135C3.45559 11.0551 3.76089 11.3445 4.11471 11.564C4.46853 11.7835 4.86344 11.9285 5.27525 11.9901C5.68706 12.0518 6.1071 12.0287 6.50968 11.9223C6.91225 11.8159 7.28888 11.6285 7.61651 11.3715C7.94414 11.1145 8.21588 10.7934 8.41508 10.4277C8.61428 10.0621 8.73676 9.65963 8.77502 9.245L8.84502 8.555C8.80634 8.99423 8.8598 9.43669 9.00198 9.85406C9.14416 10.2714 9.37192 10.6545 9.67069 10.9788C9.96946 11.3031 10.3327 11.5614 10.737 11.7372C11.1414 11.913 11.578 12.0024 12.0189 11.9998C12.4598 11.9971 12.8953 11.9024 13.2975 11.7218C13.6997 11.5411 14.0598 11.2784 14.3546 10.9506C14.6495 10.6227 14.8726 10.2369 15.0097 9.81786C15.1469 9.3988 15.195 8.95573 15.151 8.517L15.225 9.245C15.2633 9.65963 15.3858 10.0621 15.585 10.4277C15.7842 10.7934 16.0559 11.1145 16.3835 11.3715C16.7112 11.6285 17.0878 11.8159 17.4904 11.9223C17.8929 12.0287 18.313 12.0518 18.7248 11.9901C19.1366 11.9285 19.5315 11.7835 19.8853 11.564C20.2392 11.3445 20.5445 11.0551 20.7825 10.7135C21.0206 10.3718 21.1865 9.98523 21.27 9.5773C21.3534 9.16936 21.3528 8.74867 21.268 8.341L20.67 5.351C20.492 4.461 20.403 4.016 20.222 3.655C20.0334 3.27904 19.7679 2.94694 19.4426 2.68025C19.1174 2.41356 18.7397 2.21826 18.334 2.107C17.944 2 17.49 2 16.582 2H7.41802C6.51002 2 6.05602 2 5.66602 2.107C5.26039 2.21826 4.88269 2.41356 4.55743 2.68025C4.23217 2.94694 3.96662 3.27904 3.77802 3.655ZM18.268 13.5C19.0497 13.5021 19.8186 13.302 20.5 12.919V14C20.5 17.771 20.5 19.657 19.328 20.828C18.385 21.772 16.98 21.955 14.5 21.991V18.5C14.5 17.565 14.5 17.098 14.299 16.75C14.1674 16.522 13.978 16.3326 13.75 16.201C13.402 16 12.935 16 12 16C11.065 16 10.598 16 10.25 16.201C10.022 16.3326 9.83267 16.522 9.70102 16.75C9.50002 17.098 9.50002 17.565 9.50002 18.5V21.991C7.02002 21.955 5.61502 21.771 4.67202 20.828C3.50002 19.657 3.50002 17.771 3.50002 14V12.919C4.18144 13.302 4.95036 13.5021 5.73202 13.5C6.88768 13.5008 8.00033 13.0618 8.84402 12.272C9.7039 13.0641 10.8309 13.5026 12 13.5C13.1687 13.5022 14.2953 13.0637 15.155 12.272C15.9995 13.0625 17.1133 13.5016 18.27 13.5H18.268Z" fill="#B1B1B1"/>
                            </svg>
                        </div>
                        <div class=" pr-3">
                            <div style="font-weight: 600;" class="line-clamp-1 text-[18px] mb-2 text-dark-primary">
                                {{  $store->name }}
                            </div>
                            <div style="font-weight: 400;" class="line-clamp-2 text-[14px] text-dark-primary">
                                {{ $store->address }}, {{ $store->urban_village }}, {{ $store->subdistrict }}, {{ $store->city }}, {{ $store->province }} ({{ $store->postal_code }})
                            </div>
                        </div>
                    </div>
                    <div wire:click="updateStore({{ $store->id }})" class="flex ml-3 items-center w-2/12 cursor-pointer">
                        <div class="mr-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M2.5 14.5501V17.0834C2.5 17.3167 2.68333 17.5001 2.91667 17.5001H5.45C5.55833 17.5001 5.66667 17.4584 5.74167 17.3751L14.8417 8.28342L11.7167 5.15842L2.625 14.2501C2.54167 14.3334 2.5 14.4334 2.5 14.5501ZM17.2583 5.86675C17.3356 5.78966 17.3969 5.69808 17.4387 5.59727C17.4805 5.49646 17.502 5.38839 17.502 5.27925C17.502 5.17011 17.4805 5.06204 17.4387 4.96123C17.3969 4.86042 17.3356 4.76885 17.2583 4.69175L15.3083 2.74175C15.2312 2.6645 15.1397 2.60321 15.0389 2.56139C14.938 2.51957 14.83 2.49805 14.7208 2.49805C14.6117 2.49805 14.5036 2.51957 14.4028 2.56139C14.302 2.60321 14.2104 2.6645 14.1333 2.74175L12.6083 4.26675L15.7333 7.39175L17.2583 5.86675Z" fill="#3688EF"/>
                            </svg>
                        </div>
                        <div style="font-weight: 600;" class="text-primary text-[16px]">
                            Edit
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>



        <form wire:submit.prevent="{{$isUpdate ? 'updateData('.$update_data->id.')' : 'submitStore'}}">
            <div x-cloak x-show="open" style="z-index:50;left:0;overflow: auto;" class="fixed w-screen h-full">
                <div class="w-full px-0 md:px-[100px] lg:px-[399px] bg-[#F9FAFB]">
                    <div>
                        <div class="inline-block cursor-pointer" wire:click="cancelStore()" @click="open=false">
                            <div class="flex items-center mt-[40px]">
                                <div class="mr-1">
                                    <img src="{{ asset('src/icons/ios-arrow-round-back.svg') }}" />
                                </div>
                                <div style="font-weight: 600;" class="text-[16px] text-primary">
                                    Back
                                </div>
                            </div>
                        </div>
                        <div style="font-weight: 700;" class="text-[24px] text-black">
                            {{$isUpdate ? 'Update store' : 'Create new store'}}
                        </div>

                        <div class="mt-6 p-6 bg-white w-full">
                            <div style="font-weight: 600;" class="text-[20px] mb-5 text-dark-primary">
                                Address
                            </div>

                            <div class="mb-5 flex flex-col items-center" x-data="{
                                deleteImage(){
                                    const thumbnailContainer = document.getElementById('thumbnailUploadContainer');
                                    const thumbnailInput = document.getElementById('thumbnailInput');
                                    let thumbnailImage = null;
                                },
                                addImage(){
                                    const thumbnailInput = document.getElementById('thumbnailInput');
                                    thumbnailInput.click();
                                }
                                }">
                                <div style="font-weight: 400;" class="text-[14px] text-gray-500 mb-1">
                                    Image
                                </div>
                                <input type="file" id="thumbnailInput" wire:model="store_image" class="hidden">
                                <input type="file" id="storeImage" class="hidden image" accept="image/png, image/jpeg">
                                @if ($store_image)
                                    <div class="relative w-[100px] flex justify-center items-center">
                                        <img src="{{ substr($store_image, 0, 4) != "data" ?  asset('storage/'.$store_image) : $store_image }}" class= "w-[100px]" alt="Uploaded Image">
                                        <div wire:click="removeImage" class="absolute top-2 right-2 items-start p-1 text-white cursor-pointer rounded-full bg-black opacity-50">
                                            x
                                        </div>
                                    </div>
                                @else
                                <label for="storeImage" class="w-[100px] h-[120px] cursor-pointer flex {{$store_image ? 'items-start justify-end' : 'items-center justify-center'}} border border-dashed">
                                    <div style="font-weight: 400;" class="w-full text-center">
                                        <div class="flex justify-center mb-[2px]">
                                            <img class="justify-center" src="{{ asset('src/icons/ios-cloud-upload.svg') }}" />
                                        </div>
                                        <div class="text-[12px] mb-2 text-dark-primary">
                                            Upload store image
                                        </div>
                                    </div>
                                </label>
                                @endif
                                @if(isset($errorMessages['store_image']))
                                    <p class="relative text-sm text-red-600">{{ $errorMessages['store_image'][0] }}</p>
                                @endif
                            </div>

                            <div class="mb-5">
                                <div class="inline-block mb-1">
                                    <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                        <div class="mr-1 text-gray-500">
                                            Store name
                                        </div>
                                        <div class="text-red-600">
                                            *
                                        </div>
                                    </div>
                                </div>
                                <div class="w-full">
                                    <input style="font-weight: 400;" wire:model="name" value="{{ $isUpdate ? $update_data->name : '' }}" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert your store name here...." />
                                    @if(isset($errorMessages['name']))
                                        <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['name'][0] }}</p>
                                    @endif
                                </div>
                            </div>

                            <div class="mb-5">
                                <div class="inline-block mb-1">
                                    <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                        <div class="mr-1 text-gray-500">
                                            Address
                                        </div>
                                        <div class="text-red-600">
                                            *
                                        </div>
                                    </div>
                                </div>
                                <div class="w-full">
                                    <input style="font-weight: 400;" wire:model="address" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert your store address here...." />
                                    @if(isset($errorMessages['address']))
                                        <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['address'][0] }}</p>
                                    @endif
                                </div>
                            </div>

                            <div class="flex mb-5">
                                <div class="w-6/12 mr-5">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500">
                                                Province
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input style="font-weight: 400;" wire:model="province" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert your store province here...." />
                                        @if(isset($errorMessages['province']))
                                            <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['province'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                                <div class="w-6/12">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500">
                                                City/District
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input style="font-weight: 400;" wire:model="city" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert your city /district here...." />
                                        @if(isset($errorMessages['city']))
                                            <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['city'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="flex mb-5">
                                <div class="w-6/12 mr-5">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500">
                                                Subdistrict
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input style="font-weight: 400;" wire:model="subdistrict" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert subdistrict here...." />
                                        @if(isset($errorMessages['subdistrict']))
                                            <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['subdistrict'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                                <div class="w-6/12">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500">
                                                Kelurahan
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input style="font-weight: 400;" wire:model="urban_village" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert kelurahan here...." />
                                        @if(isset($errorMessages['urban_village']))
                                            <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['urban_village'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="flex mb-8">
                                <div class="w-6/12 mr-5">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500">
                                                Postal Code
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input style="font-weight: 400;" wire:model="postal_code" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert postal code...." />
                                        @if(isset($errorMessages['postal_code']))
                                            <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['postal_code'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="mt-8 p-6 bg-white">
                                <div style="font-weight: 600;" class="mb-5 text-[20px] text-dark-primary">
                                    {{$isUpdate ? 'Update admin account' : 'Create admin account'}}
                                </div>

                                <div class="mb-5">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500">
                                                Username
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input style="font-weight: 400;" wire:model="username" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert username...." />
                                        @if(isset($errorMessages['username']))
                                            <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['username'][0] }}</p>
                                        @endif
                                    </div>
                                </div>

                                <div class="flex">
                                    <div class="w-6/12 mr-5">
                                        <div class="inline-block mb-1">
                                            <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                                <div class="mr-1 text-gray-500">
                                                    Password
                                                </div>
                                                @if(!$isUpdate)
                                                <div class="text-red-600">
                                                    *
                                                </div>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="w-full">
                                            <input type="password" wire:model="password" style="font-weight: 400;" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Create new password" />
                                            @if(isset($errorMessages['password']))
                                                <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['password'][0] }}</p>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="w-6/12">
                                        <div class="inline-block mb-1">
                                            <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                                <div class="mr-1 text-gray-500">
                                                    Konfirmasi Password
                                                </div>
                                                @if(!$isUpdate)
                                                <div class="text-red-600">
                                                    *
                                                </div>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="w-full">
                                            <input type="password" wire:model="passwordConfirmation" style="font-weight: 400;" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Password confirmation" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="mb-20 p-6 bg-white">
                                <div class="flex justify-end">
                                    <div class="mr-[14px]">
                                        <button style="font-weight: 600;" wire:click="cancelStore()" type="button" @click="open=false" class="w-[83px] h-[44px] text-primary text-center text-[16px]">
                                            Cancel
                                        </button>
                                    </div>
                                    <div>
                                        <button @click="openConfirm=true" type="button" style="font-weight: 600;" class="w-[83px] h-[44px] bg-primary text-white text-center text-[16px] disabled:bg-gray-300 disabled:cursor-not-allowed">
                                            Save
                                        </button>

                                        <div x-cloak x-show="openConfirm" x-transition class="fixed top-0 left-0  pt-20 w-full min-h-screen bg-black/50 flex justify-center items-center z-10">
                                            <section @click.outside="openConfirm=false" class="fixed w-[446px] mb-5 mx-auto my-auto bg-white" style="margin-top: -50px">
                                                <div class="w-full max-h-[650px] overflow-hidden">
                                                    <div class="w-full  p-6">
                                                        <div style="font-weight: 600;font-size:20px" class="mt-5 mb-2 text-[20px]">
                                                            Are you sure?
                                                        </div>
                                                        <div style="font-size:16px" class="text-gray-500 mb-6">
                                                            Make sure you have filled in the data correctly, if there are errors after saving. You can change it back.
                                                        </div>
                                                        <div class="flex justify-end items-center">
                                                            <p x-on:click="openConfirm = false" style="font-weight: 600;" class="text-[16px] text-primary hover:cursor-pointer hover:opacity-50 duration-150 p-3 mr-[14px]">
                                                                Cancel
                                                            </p>
                                                            <button type="submit" @click="loading=true;openConfirm=false" style="font-weight: 600;" x-on:click="openConfirm = false" class="text-[16px] bg-primary text-white p-3">
                                                                Confirm
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </form>
    </div>

    <div id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" class="hidden fixed w-screen h-screen top-0 left-0 right-0 bottom-0" style="z-index: 200">
        <div class="absolute top-0 left-0 right-0 bottom-0 flex w-screen h-screen justify-center items-center bg-black bg-opacity-70">
            <div class="modal fade p-10 rounded-lg justify-center items-center w-[500px] h-fit bg-white" style="z-index: 200">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true" class="text-[20px]">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="img-container">
                                <div class="row">
                                    <div class="col-md-8">
                                        <img id="image" class="w-[400px]">
                                    </div>
                                    <div class="col-md-4">
                                        <div class="preview"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="w-full flex gap-2 items-center justify-end mt-5">
                            <button type="button" style=" --tw-bg-opacity: 1;background-color: rgb(248 113 113 / var(--tw-bg-opacity)); color:white;" class="px-3 py-2 bg-red-400 rounded-lg text-white" data-dismiss="modal">Cancel</button>
                            <button type="button" style=" --tw-bg-opacity: 1;background-color: rgb(74 222 128 / var(--tw-bg-opacity)); color:white;" class="px-3 py-2 bg-green-400 rounded-lg text-white" id="crop">Crop</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="{{ asset('src/js/scrollToTop.js') }}"></script>
    <script src="{{ asset('src/js/cropperJS.js') }}"></script>
</div>
