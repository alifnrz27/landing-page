<div class="w-full relative pt-3" x-data="{
    open:false,
    showRedeem:false,
    showRedeemConfirm:false,
    showOptionHistory:false,
    openConfirm:false,
    loading:false,
    notification:false,
    notificationSendClaim:false,
    notificationUndelivered:true,
    showRedeemNotification:false,
    showRedeemDetail:true,
    showHistoryRedeem:false,
    detailSend:false,
    allRedeems:true,
    allRedeemVouchers:false,
    allRedeemGifts:false,
    allHistoryRedeems:true,
    allHistoryRedeemVouchers:false,
    allHistoryRedeemGifts:false,
    customersTable:true,
    salesTable:false,
    cashiersTable:false,
    activeTab:false,
}" x-init="
            $wire.on('formOpen', value => {
                open = value;
                openConfirm = false;
                detailSend =false;
                loading=false;
                scrollToTop();
            });
            $wire.on('closeLoader', value => {
                loading=false;
                scrollToTop();
            });
            $wire.on('detailSend', value => {
                detailSend=value;
                scrollToTop();
            });
            $wire.on('showRedeem', value => {
                showRedeem=value;
                showRedeemDetail=true;
                showHistoryRedeem=false;
                loading=false;
            });
            $wire.on('showRedeemConfirm', value => {
                showRedeemConfirm=value;
            });
            $wire.on('showOptionHistory', value => {
                showOptionHistory=value;
            });
            $wire.on('showHistoryRedeem', value => {
                showHistoryRedeem=value;
                showRedeemDetail = !value;
            });
            $wire.on('showRedeemNotification', value => {
                showRedeemNotification=true;
                loading=false;
                setTimeout(function() {
                    showRedeemNotification=false;
                }, 2000);
            });
            $wire.on('showNotification', value => {
                notification=true;
                setTimeout(function() {
                    notification=false;
                }, 2000);
            });
            $wire.on('showNotificationSendClaim', value => {
                notificationSendClaim=value;
                setTimeout(function() {
                    notificationSendClaim=false;
                }, 5000);
            })

        " x-ref="scrollContainer">
    <div class="w-full flex fixed -mt-3">
        <div x-cloak x-show="notification" class="w-full bg-green-500 h-10 flex items-center px-12">
            <div class="w-full">
                <div class="relative justify-center items-center flex">
                    <div style="font-weight: 600;" class="text-[16px] text-white">
                        🎉 Success create new user
                    </div>
                    <div @click="notification=false" class="absolute right-0 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 11.9996L16.2563 8.80273C16.5469 8.51211 16.5469 8.03398 16.2563 7.74336C15.9656 7.45273 15.4875 7.45273 15.1969 7.74336L12 10.9402L8.80313 7.74336C8.5125 7.45273 8.03437 7.45273 7.74375 7.74336C7.59844 7.88867 7.52344 8.08086 7.52344 8.27305C7.52344 8.46523 7.59844 8.65742 7.74375 8.80273L10.9406 11.9996L7.74375 15.1965C7.59844 15.3418 7.52344 15.534 7.52344 15.7262C7.52344 15.9184 7.59844 16.1105 7.74375 16.2559C8.03437 16.5465 8.5125 16.5465 8.80313 16.2559L12 13.059L15.1969 16.2559C15.4875 16.5465 15.9656 16.5465 16.2563 16.2559C16.5469 15.9652 16.5469 15.4871 16.2563 15.1965L13.0594 11.9996Z" fill="white"/>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div x-show="loading">
        <x-layouts.loading/>
    </div>

    <div class="px-12 w-full">
        <div x-cloak x-show="!open && !showRedeem" class="w-full flex mt-3">
            <div  class="md:block md:w-9/12 pr-0 md:pr-22">
                <div class="w-full h-[44px] justify-between flex mt-12">
                    <div class="w-5/12  md:w-6/12 h-full flex">
                        <div class="relative w-6/12 h-full bg-red-300 mr-6">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                                <!-- Add your icon here -->
                                <img src="{{ asset('src/icons/ios-search.svg') }}" />
                            </span>
                            <input wire:model="search" class="w-full h-full rounded-sm text-[16px]" placeholder="Find users..." style="padding-left:38px;border-radius: var(--corner-radius-corner-xs, 2px);" />
                        </div>
                        <div class="w-4/12 md:w-3/12 h-full relative">
                            <div @click="activeTab = !activeTab" class="px-3 py-2 border flex justify-between gap-2 no-select cursor-pointer">
                                <div>
                                    Choose User
                                </div>
                                <div>
                                    V
                                </div>
                            </div>
                            <div @click.outside="activeTab = false" x-show="activeTab" class="absolute bg-white p-3 shadow-xl rounded-lg flex flex-col gap-2">
                                <div @click="customersTable=true; salesTable=false; cashiersTable=false;activeTab = false;" style="font-weight: 400;" class="text-[16px] cursor-pointer no-select">Customer</div>
                                <div @click="customersTable=false; salesTable=true; cashiersTable=false;activeTab = false;" style="font-weight: 400;" class="text-[16px] cursor-pointer no-select">Sales</div>
                                <div @click="customersTable=false; salesTable=false; cashiersTable=true;activeTab = false;" style="font-weight: 400;" class="text-[16px] cursor-pointer no-select">Cashier</div>

                            </div>
                        </div>
                    </div>
                    @if(auth()->user()->role_id == 2)
                    <div class="flex gap-1">
                        <div class="w-4/12 flex items-center cursor-pointer no-select justify-end">
                            <div  wire:click="openForm('sales')">
                                <button type="button" style="font-weight: 600;" class="flex text-white text-[12px] bg-primary p-3 rounded-sm">
                                    <div class="mr-1">
                                        +
                                    </div>
                                    @if(!$isShow)
                                    <div class="hidden xl:block">
                                        Add Sales
                                    </div>
                                    @endif
                                </button>
                            </div>
                        </div>
                        <div class="w-4/12 flex items-center cursor-pointer no-select justify-end truncate">
                            <div wire:click="openForm('cashier')">
                                <button type="button" style="font-weight: 600;" class="flex text-white text-[12px] bg-green-500 p-3 rounded-sm">
                                    <div class="mr-1">
                                        +
                                    </div>
                                    @if(!$isShow)
                                    <div class="hidden xl:block">
                                        Add Cashier
                                    </div>
                                    @endif
                                </button>
                            </div>
                        </div>
                        <a href="{{route('owner.pdfCustomer', ['data' => encrypt(['print' => true])])}}" target="_blank" class="border p-3">
                            <button class="flex">
                                <div class="mr-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <path d="M5 9.6875V17.5C5 17.8438 5.28125 18.125 5.625 18.125H14.375C14.7188 18.125 15 17.8438 15 17.5V9.6875C15 9.34375 14.7188 9.0625 14.375 9.0625H5.625C5.28125 9.0625 5 9.34375 5 9.6875ZM15 1.875H5C4.65625 1.875 4.375 2.15625 4.375 2.5V3.28125C4.375 3.36719 4.44531 3.4375 4.53125 3.4375H15.4688C15.5547 3.4375 15.625 3.36719 15.625 3.28125V2.5C15.625 2.15625 15.3438 1.875 15 1.875Z" fill="#3688EF"/>
                                        <path d="M16.8945 4.375H3.14453C2.45703 4.375 1.875 4.91406 1.875 5.59766V12.4102C1.875 13.0938 2.45703 13.6719 3.14453 13.6719H3.75C3.92188 13.6719 4.0625 13.5312 4.0625 13.3594V9.21875C4.0625 8.61328 4.55078 8.125 5.15625 8.125H14.8438C15.4492 8.125 15.9375 8.61328 15.9375 9.21875V13.3594C15.9375 13.5312 16.0781 13.6719 16.25 13.6719H16.8945C17.582 13.6719 18.125 13.0938 18.125 12.4102V5.59766C18.125 4.91406 17.582 4.375 16.8945 4.375Z" fill="#3688EF"/>
                                    </svg>
                                </div>
                                <div style="font-weight: 600;" class="text-[12px] hidden lg:block lg:text-[16px] text-primary truncate">
                                    Print Customer Data
                                </div>
                            </button>
                        </a>
                    </div>
                    @endif
                </div>

                <div x-cloak x-show="customersTable" class="lg:flex overflow-auto justify-center items-start gap-3">
                    <div class="w-full overflow-auto flex flex-col items-center justify-center">
                        <div class="font-bold text-[24px] mt-8 text-dark-primary">
                            List of Customers
                        </div>
                        <div class="max-w-[250px]  md:max-w-[250px] lg:max-w-none overflow-auto">
                            <table class="w-ful mt-6">
                                <thead class="items-center h-[68px] text-gray-500 text-[16px]">
                                    <th wire:click="orderCustomerBy('name')" class="border" style="width:400px">
                                        <div class="flex gap-1 items-center justify-center no-select">
                                            <div>
                                                Name
                                            </div>
                                            @if($orderBy == 'name')
                                            <div>
                                                <img style="width:8px;" class="transform {{ $order == 'DESC' ? 'rotate-180' : '' }}" src="{{ asset('src/icons/plain-triangle.png') }}" alt="">
                                            </div>
                                            @endif
                                        </div>
                                    </th>
                                    <th wire:click="orderCustomerBy('email')" class="border" style="width:312px">
                                        <div class="flex gap-1 items-center justify-center no-select">
                                            <div>
                                                Email
                                            </div>
                                            @if($orderBy == 'email')
                                            <div>
                                                <img style="width:8px;" class="transform {{ $order == 'DESC' ? 'rotate-180' : '' }}" src="{{ asset('src/icons/plain-triangle.png') }}" alt="">
                                            </div>
                                            @endif
                                        </div>
                                    </th>
                                    <th wire:click="orderCustomerBy('total_point')" class="border" style="width:312px">
                                        <div class="flex gap-1 items-center justify-center no-select">
                                            <div>
                                                Point
                                            </div>
                                            @if($orderBy == 'total_point')
                                            <div>
                                                <img style="width:8px;" class="transform {{ $order == 'DESC' ? 'rotate-180' : '' }}" src="{{ asset('src/icons/plain-triangle.png') }}" alt="">
                                            </div>
                                            @endif
                                        </div>
                                    </th>
                                </thead>
                                <tbody>
                                    @foreach ($customers as $customer)
                                    <tr class="border">
                                        <td class="py-2 px-2 border">
                                            <div class="inline-block px-2 py-1 rounded-3xl">
                                                <div class="flex items-center">
                                                    <div class="w-[6px] h-[6px] rounded-full mr-1">
                                                    </div>
                                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary line-clamp-1">
                                                        {{ $customer->name }}
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="py-2 px-2 border">
                                            <div class="inline-block px-2 py-1 rounded-3xl">
                                                <div class="flex items-center">
                                                    <div class="w-[6px] h-[6px] rounded-full mr-1">
                                                    </div>
                                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary line-clamp-1">
                                                        {{ $customer->email }}
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="py-2 px-6 border flex justify-center">
                                            <div style="font-weight: 400;" class="w-[74px] h-[28px] text-[14px] px-2 py-1 border-2 border-gray-500 rounded-[39px] flex items-center justify-center overflow-hidden">
                                                <div class=" flex items-center justify-center">
                                                    <div class="mr-1 w-[20px] h-[20px]">
                                                        <img class="w-[20px] h-[20px]" src="{{ asset('src/icons/ri_copper-coin-fill.svg') }}" alt="he" />
                                                    </div>
                                                    <div style="font-weight: 400;font-size: 12px;" class="text-dark-primary">
                                                        {{$customer->total_point}}pts
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div x-cloak x-show="salesTable" class="lg:flex overflow-auto justify-center items-start gap-3">
                    <div class="w-full overflow-auto flex flex-col items-center justify-center">
                        <div class="font-bold text-[24px] mt-8 text-dark-primary">
                            List of Sales
                        </div>
                        <div class="max-w-[250px]  md:max-w-[250px] lg:max-w-none overflow-auto">
                            <table class="w-ful mt-6">
                                <thead class="items-center h-[68px] text-gray-500 text-[16px]">
                                    <th class="border" style="width:312px">Name</th>
                                    <th class="border-y justify-center" style="">
                                        <div class="flex justify-center items-center">
                                            <div class="mr-1">
                                                Role
                                            </div>
                                        </div>
                                    </th>
                                    <th class="border-y border-r justify-center" style="width:50px">
                                        <div class="flex justify-center items-center">
                                            <div class="mr-1">

                                            </div>
                                        </div>
                                    </th>
                                </thead>
                                <tbody>
                                    @foreach ($users as $sales)
                                    <tr class="border">
                                        <td class="py-2 px-6 border">
                                            <div class="inline-block px-2 py-1 rounded-3xl">
                                                <div class="flex items-center">
                                                    <div class="w-[6px] h-[6px] rounded-full mr-1">
                                                    </div>
                                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary">
                                                        {{ $sales->name }}
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td style="font-weight: 400;" class="w-[210px] px-6 py-3 text-center text-[14px] text-dark-primary">{{ $sales->role->name }}</td>
                                        <td>
                                            <div>
                                                <div class="cursor-pointer" wire:click="showUser({{ $sales->id }})">
                                                    <img src="{{ asset('src/icons/md-more.svg') }}" />
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div x-cloak x-show="cashiersTable" class="lg:flex overflow-auto justify-center items-start gap-3">
                    <div class="w-full overflow-auto flex flex-col items-center justify-center">
                        <div class="font-bold text-[24px] mt-8 text-dark-primary">
                            List of cashiers
                        </div>
                        <div class="max-w-[250px]  md:max-w-[250px] lg:max-w-none overflow-auto">
                            <table class="w-ful mt-6">
                                <thead class="items-center h-[68px] text-gray-500 text-[16px]">
                                    <th class="border" style="width:312px">Name</th>
                                    <th class="border-y justify-center" style="">
                                        <div class="flex justify-center items-center">
                                            <div class="mr-1">
                                                Role
                                            </div>
                                        </div>
                                    </th>
                                    <th class="border-y border-r justify-center" style="width:50px">
                                        <div class="flex justify-center items-center">
                                            <div class="mr-1">

                                            </div>
                                        </div>
                                    </th>
                                </thead>
                                <tbody>
                                    @foreach ($cashiers as $cashier)
                                    <tr class="border">
                                        <td class="py-2 px-6 border">
                                            <div class="inline-block px-2 py-1 rounded-3xl">
                                                <div class="flex items-center">
                                                    <div class="w-[6px] h-[6px] rounded-full mr-1">
                                                    </div>
                                                    <div style="font-weight: 400;" class="text-[14px] text-dark-primary">
                                                        {{ $cashier->name }}
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td style="font-weight: 400;" class="w-[210px] px-6 py-3 text-center text-[14px] text-dark-primary">{{ $cashier->role->name }}</td>
                                        <td>
                                            <div>
                                                <div class="cursor-pointer" wire:click="showUser({{ $cashier->id }})">
                                                    <img src="{{ asset('src/icons/md-more.svg') }}" />
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        @if(auth()->user()->role_id == 2)
        <div  x-cloak x-show="open" style="margin-top:-33px; z-index:50;left:0;overflow: auto;" class="fixed w-screen h-full" x-ref="scrollContainer">
            <form wire:submit.prevent="{{$user ? 'update' : 'submit'}}">
                <div class="w-full px-0 md:px-[100px] lg:px-[399px] bg-[#F9FAFB]">
                    <div>
                        <div class="inline-block cursor-pointer" wire:click="clearForm" @click="open=false">
                            <div class="flex items-center mt-[40px]">
                                <div class="mr-1">
                                    <img src="{{ asset('src/icons/ios-arrow-round-back.svg') }}" />
                                </div>
                                <div style="font-weight: 600;" class="text-[16px] text-primary">
                                    Kembali ke Users
                                </div>
                            </div>
                        </div>
                        <div style="font-weight: 700;" class="text-[24px] text-black">
                            {{ $user ? 'Update User' : 'Create new user' }}
                        </div>

                        <div class="mt-6 p-6 bg-white w-full">
                            <div class="mb-5">
                                <div class="inline-block mb-1">
                                    <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                        <div class="mr-1 text-gray-500">
                                            Name
                                        </div>
                                        <div class="text-red-600">
                                            *
                                        </div>
                                    </div>
                                </div>
                                <div class="w-full">
                                    <input wire:model="name" style="font-weight: 400;" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert name...." />
                                    @if(isset($errorMessages['name']))
                                        <p class="relative text-sm text-red-600">{{ $errorMessages['name'][0] }}</p>
                                    @endif
                                </div>
                            </div>

                            <div class="mb-5">
                                <div class="inline-block mb-1">
                                    <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                        <div class="mr-1 text-gray-500">
                                            Username
                                        </div>
                                        <div class="text-red-600">
                                            *
                                        </div>
                                    </div>
                                </div>
                                <div class="w-full">
                                    <input wire:model="username" style="font-weight: 400;" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert username...." />
                                    @if(isset($errorMessages['username']))
                                        <p class="relative text-sm text-red-600">{{ $errorMessages['username'][0] }}</p>
                                    @endif
                                </div>
                            </div>

                            <div class="flex mb-5">
                                <div class="w-6/12 mr-5">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500">
                                                Password
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input wire:model="password" type="password" style="font-weight: 400;" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert password...." />
                                        @if(isset($errorMessages['password']))
                                            <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['password'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                                <div class="w-6/12">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500">
                                                Password Confirmation
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input wire:model="passwordConfirmation" type="password" style="font-weight: 400;" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Password confirmation...." />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="mb-20 p-6 bg-white">
                            <div class="flex justify-end">
                                <div class="mr-[14px]">
                                    <button type="button" style="font-weight: 600;" wire:click="clearForm" @click="open=false" class="w-[83px] h-[44px] text-primary text-center text-[16px]">
                                        Cancel
                                    </button>
                                </div>
                                <div>
                                    <button type="button" @click="openConfirm=true" style="font-weight: 600;" class="w-[83px] h-[44px] bg-primary text-white text-center text-[16px]">
                                        Save
                                    </button>

                                    <div x-cloak x-show="openConfirm" x-transition class="fixed top-0 left-0  pt-20 w-full min-h-screen bg-black/50 flex justify-center items-center z-10">
                                        <section @click.outside="openConfirm=false" class="fixed w-[446px] mb-5 mx-auto my-auto bg-white" style="margin-top: -50px">
                                            <div class="w-full max-h-[650px] overflow-hidden">
                                                <div class="w-full  p-6">
                                                    <div style="font-weight: 600;font-size:20px" class="mt-5 mb-2 text-[20px]">
                                                        Are you sure?
                                                    </div>
                                                    <div style="font-size:16px" class="text-gray-500 mb-6">
                                                        Make sure you have filled in the data correctly, if there are errors after saving. You can change it back.
                                                    </div>
                                                    <div class="flex justify-end items-center">
                                                        <p x-on:click="openConfirm = false" style="font-weight: 600;" class="text-[16px] text-primary hover:cursor-pointer hover:opacity-50 duration-150 p-3 mr-[14px]">
                                                            Cancel
                                                        </p>
                                                        <button type="submit" @click="loading=true;openConfirm=false" style="font-weight: 600;" class="text-[16px] bg-primary text-white p-3">
                                                            Confirm
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        @endif
    </div>

    <script>
        function changeToInteger(field){
            field.value = field.value.replace(/\D/g, "");
        }
    </script>
    <script src="{{ asset('src/js/scrollToTop.js') }}"></script>
    <script src="{{ asset('src/js/selectStore.js') }}"></script>
</div>
