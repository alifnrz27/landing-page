<div class="w-full relative pt-3" x-data="{
    open:false,
    showRedeem:false,
    showRedeemConfirm:false,
    showOptionHistory:false,
    openConfirm:false,
    loading:false,
    notification:false,
    notificationSendClaim:false,
    notificationUndelivered:true,
    showRedeemNotification:false,
    showRedeemDetail:true,
    showHistoryRedeem:false,
    detailSend:false,
    allRedeems:true,
    allRedeemVouchers:false,
    allRedeemGifts:false,
    allHistoryRedeems:true,
    allHistoryRedeemVouchers:false,
    allHistoryRedeemGifts:false,
}" x-init="
            $wire.on('formOpen', value => {
                open = value;
                openConfirm = false;
                detailSend =false;
                loading=false;
                scrollToTop();
            });
            $wire.on('closeLoader', value => {
                loading=false;
                scrollToTop();
            });
            $wire.on('detailSend', value => {
                detailSend=value;
                scrollToTop();
            });
            $wire.on('showRedeem', value => {
                showRedeem=value;
                showRedeemDetail=true;
                showHistoryRedeem=false;
                loading=false;
            });
            $wire.on('showRedeemConfirm', value => {
                showRedeemConfirm=value;
            });
            $wire.on('showOptionHistory', value => {
                showOptionHistory=value;
            });
            $wire.on('showHistoryRedeem', value => {
                showHistoryRedeem=value;
                showRedeemDetail = !value;
            });
            $wire.on('showRedeemNotification', value => {
                showRedeemNotification=true;
                loading=false;
                setTimeout(function() {
                    showRedeemNotification=false;
                }, 2000);
            });
            $wire.on('showNotification', value => {
                notification=true;
                setTimeout(function() {
                    notification=false;
                }, 2000);
            });
            $wire.on('showNotificationSendClaim', value => {
                notificationSendClaim=value;
                setTimeout(function() {
                    notificationSendClaim=false;
                }, 5000);
            })

        " x-ref="scrollContainer">
    <div class="w-full flex fixed -mt-3">
        <div x-cloak x-show="notification" class="w-full bg-green-500 h-10 flex items-center px-12">
            <div class="w-full">
                <div class="relative justify-center items-center flex">
                    <div style="font-weight: 600;" class="text-[16px] text-white">
                        🎉 Klaim voucher berhasil terbuat
                    </div>
                    <div @click="notification=false" class="absolute right-0 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 11.9996L16.2563 8.80273C16.5469 8.51211 16.5469 8.03398 16.2563 7.74336C15.9656 7.45273 15.4875 7.45273 15.1969 7.74336L12 10.9402L8.80313 7.74336C8.5125 7.45273 8.03437 7.45273 7.74375 7.74336C7.59844 7.88867 7.52344 8.08086 7.52344 8.27305C7.52344 8.46523 7.59844 8.65742 7.74375 8.80273L10.9406 11.9996L7.74375 15.1965C7.59844 15.3418 7.52344 15.534 7.52344 15.7262C7.52344 15.9184 7.59844 16.1105 7.74375 16.2559C8.03437 16.5465 8.5125 16.5465 8.80313 16.2559L12 13.059L15.1969 16.2559C15.4875 16.5465 15.9656 16.5465 16.2563 16.2559C16.5469 15.9652 16.5469 15.4871 16.2563 15.1965L13.0594 11.9996Z" fill="white"/>
                        </svg>
                    </div>
                </div>
            </div>
        </div>

        <div x-cloak x-show="notificationSendClaim" style="z-index:100" class="w-full bg-green-500 h-10 flex items-center px-12">
            <div class="w-full">
                <div class="relative justify-center items-center flex">
                    <div class="flex items-center">
                        <div style="font-weight: 600;" class="text-[16px] text-white mr-4">
                            📬 Penawaran berhasil dikirim ke {{count($sendToCustomers)}} orang
                        </div>
                        <div wire:click="cancelSendClaim" class="px-2 py-1 border rounded-sm no-select cursor-pointer">
                            <div style="font-weight: 400;" class="h-5 flex items-center text-white text-[14px]">
                                Batalkan
                            </div>
                        </div>
                    </div>
                    <div @click="notificationSendClaim=false" class="absolute right-0 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 11.9996L16.2563 8.80273C16.5469 8.51211 16.5469 8.03398 16.2563 7.74336C15.9656 7.45273 15.4875 7.45273 15.1969 7.74336L12 10.9402L8.80313 7.74336C8.5125 7.45273 8.03437 7.45273 7.74375 7.74336C7.59844 7.88867 7.52344 8.08086 7.52344 8.27305C7.52344 8.46523 7.59844 8.65742 7.74375 8.80273L10.9406 11.9996L7.74375 15.1965C7.59844 15.3418 7.52344 15.534 7.52344 15.7262C7.52344 15.9184 7.59844 16.1105 7.74375 16.2559C8.03437 16.5465 8.5125 16.5465 8.80313 16.2559L12 13.059L15.1969 16.2559C15.4875 16.5465 15.9656 16.5465 16.2563 16.2559C16.5469 15.9652 16.5469 15.4871 16.2563 15.1965L13.0594 11.9996Z" fill="white"/>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div x-show="loading">
        <x-layouts.loading/>
    </div>

    <div class="px-12">
        <div x-cloak x-show="!open && !showRedeem" class="w-full flex mt-3">
            <div class="{{ $isShow ? 'hidden md:block md:w-9/12' : 'w-full' }} pr-0 md:pr-22">
                <div class="w-full lg:flex">
                    <div class="w-full md:w-3/5 pr-0 md:pr-24">
                        <div>
                            <div class="w-full lg:w-[550px] mb-10">
                                <div style="font-weight: 700;" class="text-[24px] text-dark-primary  mb-2">
                                    Claim
                                </div>
                                <div style="font-weight: 400;" class="text-[16px] text-dark-primary  ">
                                    This page is to create and manage voucher and gift in your store.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-full md:w-2/5 flex">
                        <div class="w-6/12 rounded-sm">
                            <div class="p-3 border-2">
                                <div class="flex mb-2">
                                    <div class="w-6 h-6 bg-[#E5EDFA] rounded-full flex items-center justify-center mr-1">
                                        <img src="{{ asset('src/icons/bxs_coupon.svg') }}" />
                                    </div>
                                    <div style="font-weight: 400;" class="text-[16px] text-gray-500 truncate">
                                        Voucher
                                    </div>
                                </div>

                                <div>
                                    <div style="font-weight: 700;" class="text-[32px] text-dark-primary ">
                                        {{ $voucher_total }}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="w-6/12 rounded-sm ml-6">
                            <div class="p-3 border-2">
                                <div class="flex mb-2">
                                    <div class="w-6 h-6 bg-[#FAE4E4] rounded-full flex items-center justify-center mr-1">
                                        <img src="{{ asset('src/icons/mdi_present.svg') }}" />
                                    </div>
                                    <div style="font-weight: 400;" class="text-[16px] text-gray-500 truncate">
                                        Gift
                                    </div>
                                </div>

                                <div>
                                    <div style="font-weight: 700;" class="text-[32px] text-dark-primary ">
                                        {{ $gift_total }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="w-full justify-between lg:flex mt-12">
                    <div class="w-10/12 md:w-6/12 h-full flex">
                        <div class="relative w-6/12 h-full bg-red-300 mr-3">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                                <!-- Add your icon here -->
                                <img src="{{ asset('src/icons/ios-search.svg') }}" />
                            </span>
                            <input wire:model="search" class="w-full h-[44px] rounded-sm text-[16px]" placeholder="Find voucher and gift...." style="padding-left:38px;border-radius: var(--corner-radius-corner-xs, 2px);" />
                        </div>
                        <div class="w-4/12 md:w-3/12 h-full">
                            <select class="w-full h-full rounded-sm">
                                <option style="font-weight: 400;" class="text-[16px]">All</option>
                            </select>
                        </div>
                    </div>
                    @if(auth()->user()->role_id == 2)
                    <div class="w-2/12 flex items-center cursor-pointer no-select mt-4 lg:mt-0">
                        <div class="mr-3 border" wire:click="showRedeem">
                            <button type="button" style="font-weight: 600;" class="flex text-[16px] text-primary p-3 rounded-sm">
                                <div class="mr-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <path d="M15.1914 10.4023C14.9922 10.207 14.9883 9.88282 15.1875 9.6836L17.0312 7.8125H8.24219C7.96094 7.8125 7.73437 7.58594 7.73437 7.30469C7.73437 7.02344 7.96094 6.79688 8.24219 6.79688H17.0273L15.1836 4.92578C14.9883 4.72657 14.9883 4.40625 15.1875 4.20703C15.3867 4.01172 15.707 4.01172 15.9062 4.21094L18.6016 6.94532C18.6445 6.99219 18.6836 7.04297 18.707 7.10547C18.7344 7.16797 18.7461 7.23438 18.7461 7.30078C18.7461 7.4336 18.6953 7.5586 18.6016 7.65625L15.9062 10.3906C15.7109 10.5938 15.3906 10.5977 15.1914 10.4023ZM4.80859 15.793C5.00781 15.5977 5.01172 15.2734 4.8125 15.0742L2.97266 13.2031H11.7578C12.0391 13.2031 12.2656 12.9766 12.2656 12.6953C12.2656 12.4141 12.0391 12.1875 11.7578 12.1875H2.97266L4.81641 10.3164C5.01172 10.1172 5.01172 9.79688 4.8125 9.59766C4.61328 9.40235 4.29297 9.40235 4.09375 9.60157L1.39844 12.3359C1.35547 12.3828 1.31641 12.4336 1.29297 12.4961C1.26562 12.5586 1.25391 12.625 1.25391 12.6914C1.25391 12.8242 1.30469 12.9492 1.39844 13.0469L4.09375 15.7813C4.28906 15.9844 4.60937 15.9883 4.80859 15.793Z" fill="#3688EF"/>
                                    </svg>
                                </div>
                                @if(!$isShow)
                                <div class="hidden xl:block">
                                    Redeem
                                </div>
                                @endif
                            </button>
                        </div>
                        <div  @click="open=true">
                            <button type="button" style="font-weight: 600;" class="flex text-white text-[16px] bg-primary p-3 rounded-sm">
                                <div class="mr-1">
                                    +
                                </div>
                                @if(!$isShow)
                                <div class="hidden xl:block">
                                    Add new
                                </div>
                                @endif
                            </button>
                        </div>
                    </div>
                    @endif
                </div>

                <div class="w-full overflow-auto">
                    <table class="w-full min-w-[1336px] mt-6">
                        <thead class="items-center h-[68px] text-gray-500 text-[16px]">
                            <th class="border" style="width:312px">TITLE</th>
                            <th class="border justify-center" style="width:220px">
                                <div class="flex justify-center items-center">
                                    <div class="mr-1">
                                        STATUS
                                    </div>
                                    <div>
                                        <img src="{{ asset('src/icons/ios-code.svg') }}" />
                                    </div>
                                </div>
                            </th>
                            <th class="border" style="width:250px">
                                <div class="flex justify-center items-center">
                                    <div class="mr-1">
                                        EFFECTIVE DATE
                                    </div>
                                    <div>
                                        <img src="{{ asset('src/icons/ios-code.svg') }}" />
                                    </div>
                                </div>
                            </th>
                            <th class="border" style="width:210px">
                                <div class="flex justify-center items-center">
                                    <div class="mr-1">
                                        LOCATION
                                    </div>
                                    <div>
                                        <img src="{{ asset('src/icons/ios-code.svg') }}" />
                                    </div>
                                </div>
                            </th>
                            <th class="border" style="width:134px">
                                <div class="flex justify-center items-center">
                                    <div class="mr-1">
                                        LIMIT
                                    </div>
                                    <div>
                                        <img src="{{ asset('src/icons/ios-code.svg') }}" />
                                    </div>
                                </div>
                            </th>
                            <th class="border" style="width:139px">
                                <div class="flex justify-center items-center">
                                    <div class="mr-1">
                                        VALID
                                    </div>
                                    <div>
                                        <img src="{{ asset('src/icons/ios-code.svg') }}" />
                                    </div>
                                </div>
                            </th>
                            <th class="border" style="width:170px">
                                <div class="flex justify-center items-center">
                                    <div class="mr-1">
                                        POINT
                                    </div>
                                    <div>
                                        <img src="{{ asset('src/icons/ios-code.svg') }}" />
                                    </div>
                                </div>
                            </th>
                        </thead>
                        <tbody>
                            @foreach ($claims as $claim)
                            <tr class="border {{ isset($show_data->id) ? $claim->id == $show_data->id ? 'bg-gray-300' : '' : '' }}">
                                <td>
                                    <div class="flex mb-2 items-center px-6 py-3">
                                        @if ($claim->claim_type_id == 1)
                                        <div class="h-10 w-10 bg-[#E5EDFA] rounded-full flex items-center justify-center mr-1">
                                            <img class="w-5 h-5" src="{{ asset('src/icons/bxs_coupon.svg') }}" />
                                        </div>
                                        @else
                                        <div class="h-10 w-10 bg-[#FAE4E4] rounded-full flex items-center justify-center mr-1">
                                            <img class="w-5 h-5" src="{{ asset('src/icons/mdi_present.svg') }}" />
                                        </div>
                                        @endif

                                        <div style="font-weight: 400; max-width: 264px;" class="text-[16px] text-gray-500  ">
                                            <div style="font-weight: 600;" class="text-[16px] text-black  truncate">
                                                {{ $claim->title }}
                                            </div>
                                            <div class="text-[14px] truncate">
                                                {{ $claim->description }}
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-2 px-6">
                                    <div class="inline-block border px-2 py-1 rounded-3xl">
                                        <div class="flex items-center">
                                            <div class="w-[6px] h-[6px] @if(getStatusClaim($claim) == 'Active') bg-[#2C9854]  @elseif(getStatusClaim($claim) == 'Not active') bg-[#EDEDED] @else bg-[#FF8933] @endif  rounded-full mr-1">
                                            </div>
                                            <div style="font-weight: 400;" class="text-[14px] text-dark-primary ">
                                                {{ getStatusClaim($claim) }}
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td style="font-weight: 400;" class="w-[210px] px-6 py-3 text-center text-[14px] text-dark-primary ">{{ changeDateFormat($claim->start_date) }} - {{ changeDateFormat($claim->end_date) }}</td>
                                <td style="font-weight: 400;" class="max-w-[210px] px-6 py-3 text-center text-[14px] truncate flex">
                                    <div style="margin-left:-10px;margin-top:15px" class="relative flex items-center max-w-[200px] scroll-container">
                                        @if($claim->is_all_stores)
                                            <div class="px-2 py-1 bg-gray-400 rounded-full text-white flex mr-2">
                                                <div class="w-[100px] h-full truncate" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                                                    All store
                                                </div>
                                            </div>
                                        @else
                                        @foreach($claim->claimStores as $store)
                                            <div class="px-2 py-1 bg-gray-400 rounded-full text-white flex mr-2">
                                                <div class="w-[100px] h-full truncate" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                                                    {{$store->store->name}}
                                                </div>
                                            </div>
                                        @endforeach
                                        @endif
                                    </div>
                                </td>
                                <td style="font-weight: 400;" class="w-[210px] px-6 py-3 text-center text-[14px] text-dark-primary ">{{ $claim->limit == 0 ? "Unlimited" : $claim->limit.' X' }}</td>
                                <td style="font-weight: 400;" class="w-[210px] px-6 py-3 text-center text-[14px] text-dark-primary ">{{ $claim->validity_duration }} days</td>
                                <td>
                                    <div class="flex items-center mx-6 my-3">
                                        <div>
                                            <div style="font-weight: 400;" class="w-[88px] h-[28px] text-[14px] px-2 py-1 border-2 border-gray-500 rounded-[39px] flex items-center justify-center">
                                                <div class=" flex items-center justify-center">
                                                    <div class="mr-1 w-[20px] h-[20px]">
                                                        <img class="w-[20px] h-[20px]" src="{{ asset('src/icons/ri_copper-coin-fill.svg') }}" alt="he" />
                                                    </div>
                                                    <div style="font-weight: 400;font-size: 12px;" class="truncate text-dark-primary ">
                                                        {{ $claim->exchange_rate }} pts
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="cursor-pointer" wire:click="showClaim({{ $claim->id }})">
                                                <img src="{{ asset('src/icons/md-more.svg') }}" />
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            @if($isShow)
            <div style="margin-top:-35px" class="w-full md:w-3/12 md:border-l">
                <div  class="w-full px-6 py-3 border-b">
                    <div class=" w-full flex justify-between">
                        <div class="cursor-pointer" wire:click="deleteShow">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M21 3V21" stroke="#B1B1B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M3 12H16.5" stroke="#B1B1B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M10 19L17 12L10 5" stroke="#B1B1B1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                        @if(auth()->user()->role_id == 2)
                        <div class="flex items-center cursor-pointer" wire:click="showUpdateClaim({{ $show_data->id }})">
                            <div>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M2.5 14.5501V17.0834C2.5 17.3167 2.68333 17.5001 2.91667 17.5001H5.45C5.55833 17.5001 5.66667 17.4584 5.74167 17.3751L14.8417 8.28342L11.7167 5.15842L2.625 14.2501C2.54167 14.3334 2.5 14.4334 2.5 14.5501ZM17.2583 5.86675C17.3356 5.78966 17.3969 5.69808 17.4387 5.59727C17.4805 5.49646 17.502 5.38839 17.502 5.27925C17.502 5.17011 17.4805 5.06204 17.4387 4.96123C17.3969 4.86042 17.3356 4.76885 17.2583 4.69175L15.3083 2.74175C15.2312 2.6645 15.1397 2.60321 15.0389 2.56139C14.938 2.51957 14.83 2.49805 14.7208 2.49805C14.6117 2.49805 14.5036 2.51957 14.4028 2.56139C14.302 2.60321 14.2104 2.6645 14.1333 2.74175L12.6083 4.26675L15.7333 7.39175L17.2583 5.86675Z" fill="#3688EF"/>
                                </svg>
                            </div>
                            <div class="text-[16px] text-primary ml-1" style="font-weight: 600;">
                                Edit
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
                <br>
                <div class="p-6">
                    <div id="thumbnailUploadContainer" class="w-full overflow-hidden flex mb-6 {{$thumbnail_image ? 'items-start justify-end' : 'items-center justify-center bg-[#DEE3E9]'}}">
                        @if ($thumbnail_image)
                        <img src="{{ asset('storage/' . $thumbnail_image) }}" class= "w-[100%] mt-6" alt="Image">
                        @else
                            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
                                <path d="M35 31.6666V8.33336C35 6.49984 33.5002 5 31.6666 5H8.33336C6.49984 5 5 6.49984 5 8.33336V31.6666C5 33.5002 6.49984 35 8.33336 35H31.6666C33.5002 35 35 33.5002 35 31.6666ZM14.1666 22.5L18.3334 27.5L24.1666 20L31.6666 30H8.33336L14.1666 22.5Z" fill="#DEE3E9"/>
                            </svg>
                        @endif
                    </div>

                    <div class="w-full mb-6">
                        <div style="font-weight: 600;" class="truncate text-[20px] text-dark-primary ">
                            {{ $title }}
                        </div>
                        <div style="font-weight: 400;" class="line-clamp-2 text-[16px] text-gray-500   mt-2">
                            {{ $description }}
                        </div>
                    </div>

                    <div>
                        @if($show_data)
                        @if(!$show_data->status_by_admin)
                        <div class="p-3 mb-5 flex bg-[#FAF1F1]">
                            <div class="mr-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                                    <path d="M10.7297 3.99531L2.42815 19.1453C1.90315 20.0922 2.60159 21.25 3.69847 21.25H20.3063C21.3985 21.25 22.0969 20.0922 21.5766 19.1453L13.2703 3.99531C12.7219 3.00156 11.2782 3.00156 10.7297 3.99531ZM12.825 10.2812L12.6563 16H11.3438L11.175 10.2812H12.825ZM12 19.1125C11.4985 19.1125 11.1047 18.7328 11.1047 18.25C11.1047 17.7672 11.4985 17.3875 12 17.3875C12.5016 17.3875 12.8953 17.7672 12.8953 18.25C12.8953 18.7328 12.5016 19.1125 12 19.1125Z" fill="#FE5C5C"/>
                                </svg>
                            </div>
                            <div>
                                <div style="font-weight: 600;line-height: 20px;" class="text-[16px]">
                                    You're not allowed to edit
                                </div>
                                <div style="font-weight: 400;line-height: 20px;" class="text-[14px]">
                                    This promo has been disabled by admin. Contact the admin if you want to reactivate it.
                                </div>
                            </div>
                        </div>
                        @endif
                        @endif
                        <div class="flex justify-between mb-5 text-dark-primary ">
                            <div style="font-weight: 400;" class="text-[16px] text-gray-500">
                                Status
                            </div>
                            <div @if($show_data)@if(auth()->user()->role_id == 2 && $show_data->status_by_admin) wire:click="changeStatus()" @endif @endif class="text-dark-primary ">
                                <div class="flex items-center justify-center mt-4 no-select">
                                    <div class="flex">
                                        <label>
                                            <div class="flex h-5 w-9 cursor-pointer items-center rounded-full p-1 @if($show_data) @if(!$show_data->status_by_admin) 'bg-[#EDEDED]' @else {{$status ? 'bg-primary' : 'bg-dark-secondary'}} @endif @endif">
                                                <div class="toggle-circle h-4 w-4 rounded-full {{$status ? 'translate-x-3' : ''}} bg-white transition duration-300 ease-in-out">
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flex justify-between mb-5">
                            <div style="font-weight: 400;" class="text-[16px] text-gray-500">
                                Claim Type
                            </div>
                            @if ($show_data->claim_type_id == 1)
                            <div class="flex items-center text-dark-primary ">
                                <div class="h-10 w-10 bg-[#E5EDFA] rounded-full flex items-center justify-center mr-1">
                                    <img class="w-5 h-5" src="{{ asset('src/icons/bxs_coupon.svg') }}" />
                                </div>
                                <div>
                                    {{$show_data->claimType->name}}
                                </div>
                            </div>
                            @else
                            <div class="flex items-center text-dark-primary ">
                                <div class="h-10 w-10 bg-[#FAE4E4] rounded-full flex items-center justify-center mr-1">
                                    <img class="w-5 h-5" src="{{ asset('src/icons/mdi_present.svg') }}" />
                                </div>
                                <div>
                                    {{$show_data->claimType->name}}
                                </div>
                            </div>
                            @endif
                        </div>
                        <div class="flex justify-between mb-5">
                            <div style="font-weight: 400;" class="text-[16px] text-gray-500">
                                Effective Date
                            </div>
                            <div style='font-weight: 400;' class="text-[16px] text-dark-primary ">
                                {{changeDateFormat($start_date)}} - {{changeDateFormat($end_date)}}
                            </div>
                        </div>
                        <div class="flex justify-between mb-5">
                            <div style="font-weight: 400;" class="text-[16px] text-gray-500">
                                Valid
                            </div>
                            <div style='font-weight: 400;' class="text-[16px] text-dark-primary ">
                                {{ $validity_duration }} Hari
                            </div>
                        </div>
                        <div class="flex justify-between mb-5">
                            <div style="font-weight: 400;" class="text-[16px] text-gray-500">
                                Stock
                            </div>
                            <div style='font-weight: 400;' class="text-[16px] text-dark-primary ">
                                {{ $stock }}
                            </div>
                        </div>
                        <div class="flex justify-between mb-5">
                            <div style="font-weight: 400;" class="text-[16px] text-gray-500">
                                Location
                            </div>
                            <div>
                                @if($is_all_stores)
                                    <div  style="font-weight: 400;" class="text-[16px] text-dark-primary ">
                                        All store
                                    </div>
                                @else
                                @foreach ($show_data->claimStores as $store)
                                    <div  style="font-weight: 400;" class="text-[16px] text-dark-primary ">
                                        {{$store->store->name}}
                                    </div>
                                @endforeach
                                @endif
                            </div>
                        </div>
                        <div class="flex justify-between mb-5">
                            <div style="font-weight: 400;" class="text-[16px] text-gray-500">
                                Limit
                            </div>
                            <div style='font-weight: 400;' class="text-[16px] text-dark-primary ">
                                {{ $limit == 0 ? "Unlimited" : $limit." X" }}
                            </div>
                        </div>
                        <div class="flex justify-between mb-5">
                            <div style="font-weight: 400;" class="text-[16px] text-gray-500">
                                Point
                            </div>
                            <div style='font-weight: 400;' class="text-[16px]">
                                <div style="font-weight: 400;" class="w-[88px] h-[28px] text-[14px] px-2 py-1 border-2 border-gray-500 rounded-[39px] flex items-center justify-center">
                                    <div class=" flex items-center justify-center">
                                        <div class="mr-1 w-[20px] h-[20px]">
                                            <img class="w-[20px] h-[20px]" src="{{ asset('src/icons/ri_copper-coin-fill.svg') }}" alt="he" />
                                        </div>
                                        <div style="font-weight: 400;font-size: 12px;" class="truncate text-dark-primary ">
                                            {{ $exchange_rate }} pts
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @if(auth()->user()->role_id == 2)
                        <div wire:click="detailSendClaim" class="p-3 flex items-center justify-center rounded-sm border border-[#D6DADF] no-select cursor-pointer">
                            <div class="flex h-5 items-center cursor-pointer no-select">
                                <div class="mr-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
                                        <path d="M17.5273 2.78505L3.18745 9.03505C2.93354 9.15615 2.94135 9.51943 3.19917 9.63271L7.07807 11.8241C7.30854 11.953 7.5937 11.9257 7.79292 11.7538L15.4414 5.16005C15.4921 5.11708 15.6132 5.03505 15.6601 5.08193C15.7109 5.13271 15.6328 5.2499 15.5898 5.30068L8.9726 12.7538C8.78901 12.9608 8.76167 13.2655 8.9101 13.4999L11.4453 17.5663C11.5703 17.8124 11.9257 17.8085 12.039 17.5585L17.9687 3.21865C18.0976 2.9374 17.8046 2.65224 17.5273 2.78505Z" fill="#3688EF"/>
                                    </svg>
                                </div>
                                <div style="font-weight: 600;" class="text-[16px] text-primary">
                                    Send claim to customer
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
            @endif
        </div>


        @if(auth()->user()->role_id == 2)
        <div  x-cloak x-show="open" style="margin-top:-33px; z-index:50;left:0;overflow: auto;" class="fixed w-screen h-full" x-ref="scrollContainer">
            <form wire:submit.prevent="{{$isShowUpdate ? 'updateClaim('. $show_data->id .')' : 'submitClaim'}}">
                <div class="w-full px-0 md:px-[100px] lg:px-[399px] bg-[#F9FAFB]">
                    <div>
                        <div class="inline-block cursor-pointer" wire:click="deleteShow" @click="open=false">
                            <div class="flex items-center mt-[40px]">
                                <div class="mr-1">
                                    <img src="{{ asset('src/icons/ios-arrow-round-back.svg') }}" />
                                </div>
                                <div style="font-weight: 600;" class="text-[16px] text-primary">
                                    Back
                                </div>
                            </div>
                        </div>
                        <div style="font-weight: 700;" class="text-[24px] text-black ">
                            {{$isShowUpdate ? 'Update claim' : 'Create new claim'}}
                        </div>

                        <div class="mt-6 p-6 bg-white w-full">
                            <div class="inline-block">
                                <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                    <div class="mr-1 text-gray-500  ">
                                        Choose claim type
                                    </div>
                                    <div class="text-red-600">
                                        *
                                    </div>
                                </div>
                            </div>
                            <div class="w-full flex justify-between mb-5">
                            <input type="hidden" wire:model="claim_type_id" />
                                <div wire:click="changeClaimType(1)" id="claim-type-id-1" class="w-6/12 mr-5 p-3 flex border {{ $claim_type_id == 1 ? 'border-primary' : '' }} cursor-pointer">
                                    <div>
                                        <div class="h-8 w-8 bg-[#E5EDFA] rounded-full flex items-center justify-center mr-1">
                                            <img class="h-4 w-4" src="{{ asset('src/icons/bxs_coupon.svg') }}" />
                                        </div>
                                    </div>
                                    <div class="mx-2">
                                        <div style="font-weight: 600;" class="text-[18px] text-dark-primary ">
                                            Voucher
                                        </div>
                                        <div style="font-weight: 400;" class="text-[14px] text-gray-500  ">
                                            Used by customers to get discounts or other benefits when shopping.
                                        </div>
                                    </div>
                                    <div>
                                        <div class="h-5 w-5 border rounded-full flex items-center justify-center mr-1">
                                            @if($claim_type_id == 1)
                                            <img class="h-5 w-5" src="{{ asset('src/icons/ios-checkmark.svg') }}" />
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div wire:click="changeClaimType(2)" id="claim-type-id-2" class="w-6/12 p-3 flex border {{ $claim_type_id == 2 ? 'border-[#FAE4E4]' : '' }} cursor-pointer">
                                    <div>
                                        <div class="h-8 w-8 bg-[#FAE4E4] rounded-full flex items-center justify-center mr-1">
                                            <img class="h-4 w-4" src="{{ asset('src/icons/mdi_present.svg') }}" />
                                        </div>
                                    </div>
                                    <div class="mx-2">
                                        <div style="font-weight: 600;" class="text-[18px] text-dark-primary ">
                                            Gift
                                        </div>
                                        <div style="font-weight: 400;" class="text-[14px] text-gray-500  ">
                                            Customers can exchange prizes for other desired goods or services.
                                        </div>
                                    </div>
                                    <div>
                                        <div class="h-5 w-5 border rounded-full flex items-center justify-center mr-1">
                                            @if($claim_type_id == 2)
                                            <img class="h-5 w-5" src="{{ asset('src/icons/ios-checkmark.svg') }}" />
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-5" x-data="{
                                deleteImage(){
                                    const thumbnailContainer = document.getElementById('thumbnailUploadContainer');
                                    const thumbnailInput = document.getElementById('thumbnailInput');
                                    let thumbnailImage = null;
                                },
                                addImage(){
                                    const thumbnailInput = document.getElementById('thumbnailInput');
                                    thumbnailInput.click();
                                }
                                }">
                                <div style="font-weight: 400;" class="text-[14px] text-gray-500   mb-1">
                                    Thumbnail
                                </div>
                                <input type="file" id="thumbnailInput" wire:model="thumbnail" class="hidden">
                                <input type="file" id="thumbnailImage" class="hidden image" accept="image/png, image/jpeg">
                                @if ($thumbnail)
                                    <div class="relative w-full">
                                        <img src="{{ substr($thumbnail, 0, 4) != "data" ?  asset('storage/'.$thumbnail) : $thumbnail }}" class= "w-[100%]" alt="Uploaded Image">
                                        <div wire:click="removeThumbnail" class="absolute top-5 right-5 items-start p-1 text-white cursor-pointer rounded-full bg-black opacity-50">
                                            x
                                        </div>
                                    </div>
                                @else
                                <label for="thumbnailImage" class="w-full h-[134px] cursor-pointer flex {{$thumbnail ? 'items-start justify-end' : 'items-center justify-center'}} border border-dashed">
                                    <div style="font-weight: 400;" class="w-full text-center">
                                        <div class="flex justify-center mb-[2px]">
                                            <img class="justify-center" src="{{ asset('src/icons/ios-cloud-upload.svg') }}" />
                                        </div>
                                        <div class="text-[16px] mb-2 text-dark-primary ">
                                            Upload thumbnail image
                                        </div>
                                        <div class="text-[14px] text-gray-500">
                                            PNG, atau JPG maximum 8MB
                                        </div>
                                    </div>
                                </label>
                                @endif
                                @if(isset($errorMessages['thumbnail']))
                                    <p class="relative text-sm text-red-600">{{ $errorMessages['thumbnail'][0] }}</p>
                                @endif
                            </div>

                            <div class="mb-5">
                                <div class="inline-block mb-1">
                                    <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                        <div class="mr-1 text-gray-500  ">
                                            Title
                                        </div>
                                        <div class="text-red-600">
                                            *
                                        </div>
                                    </div>
                                </div>
                                <div class="w-full">
                                    <input wire:model="title" style="font-weight: 400;" class="w-full h-[44px] border border-gray-500 p-3 text-[16px]" placeholder="Insert title here...." />
                                    @if(isset($errorMessages['title']))
                                        <p class="relative text-sm text-red-600">{{ $errorMessages['title'][0] }}</p>
                                    @endif
                                </div>
                            </div>

                            <div class="mb-5">
                                <div class="inline-block mb-1">
                                    <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                        <div class="mr-1 text-gray-500  ">
                                            Description
                                        </div>
                                        <div class="text-red-600">
                                            *
                                        </div>
                                    </div>
                                </div>
                                <div class="w-full">
                                    <textarea wire:model="description" class="w-full h-[100px]" placeholder="Insert claim terms & conditions...."></textarea>
                                    @if(isset($errorMessages['description']))
                                        <p class="relative text-sm text-red-600">{{ $errorMessages['description'][0] }}</p>
                                    @endif
                                </div>
                            </div>

                            <div class="p-3 border mb-5">
                                <div style="font-weight: 600;" class="text-[16px] mb-1 ">
                                    Validity Duration (day)
                                </div>
                                <div style="font-weight: 400;" class="text-[14px] mb-5 text-gray-500  ">
                                    Set the validity period of the voucher/gift after the customer makes a claim.
                                </div>
                                <div>
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500  ">
                                                Change type
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex">
                                        <select wire:model="change_type_id" class="p-3 w-[144px] h-[44px] mr-11">
                                            @foreach ($change_type as $type)
                                            <option style="font-weight: 400;" class="text-[16px]" value="{{$type->id}}" {{$type->id == $change_type_id ? 'selected' : ''}}>{{$type->name}}</option>
                                            @endforeach
                                        </select>
                                        <div class="flex justify-center items-center">
                                            <div wire:click="subtractValue('validity_duration')" class="cursor-pointer">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path d="M18 12.998H6C5.73478 12.998 5.48043 12.8927 5.29289 12.7052C5.10536 12.5176 5 12.2633 5 11.998C5 11.7328 5.10536 11.4785 5.29289 11.2909C5.48043 11.1034 5.73478 10.998 6 10.998H18C18.2652 10.998 18.5196 11.1034 18.7071 11.2909C18.8946 11.4785 19 11.7328 19 11.998C19 12.2633 18.8946 12.5176 18.7071 12.7052C18.5196 12.8927 18.2652 12.998 18 12.998Z" fill="#6A6A75"/>
                                                    <path d="M0.5 12C0.5 5.64873 5.64873 0.5 12 0.5C18.3513 0.5 23.5 5.64873 23.5 12C23.5 18.3513 18.3513 23.5 12 23.5C5.64873 23.5 0.5 18.3513 0.5 12Z" stroke="#EDEDED"/>
                                                </svg>
                                            </div>
                                            <div class="mx-[15px]">
                                                <input type="text" oninput="changeToInteger(this)" wire:model="validity_duration" style="font-weight: 400;" class="p-3 text-[16px] w-[72px] h-[44px] text-center" placeholder="1" />
                                            </div>
                                            <div wire:click="addValue('validity_duration')" class="cursor-pointer">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path d="M17.2734 11.25H12.75V6.72656C12.75 6.31406 12.4125 5.97656 12 5.97656C11.5875 5.97656 11.25 6.31406 11.25 6.72656V11.25H6.72656C6.31406 11.25 5.97656 11.5875 5.97656 12C5.97656 12.2063 6.06094 12.3937 6.19687 12.5297C6.33281 12.6656 6.52031 12.75 6.72656 12.75H11.25V17.2734C11.25 17.4797 11.3344 17.6672 11.4703 17.8031C11.6062 17.9391 11.7937 18.0234 12 18.0234C12.4125 18.0234 12.75 17.6859 12.75 17.2734V12.75H17.2734C17.6859 12.75 18.0234 12.4125 18.0234 12C18.0234 11.5875 17.6859 11.25 17.2734 11.25Z" fill="#6A6A75"/>
                                                    <path d="M0.5 12C0.5 5.64873 5.64873 0.5 12 0.5C18.3513 0.5 23.5 5.64873 23.5 12C23.5 18.3513 18.3513 23.5 12 23.5C5.64873 23.5 0.5 18.3513 0.5 12Z" stroke="#EDEDED"/>
                                                </svg>
                                            </div>
                                        </div>
                                        @if(isset($errorMessages['change_type_id']))
                                            <p class="relative text-sm text-red-600">{{ $errorMessages['change_type_id'][0] }}</p>
                                        @endif
                                    </div>

                                </div>
                            </div>

                            <div class="flex mb-5">
                                <div class="w-6/12 mr-5">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500  ">
                                                Choose store
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input type="hidden" id="store-id" wire:model="store_id" />
                                        <select style="font-weight: 400;" onchange="selectStore(this)" class="w-full h-[44px] border border-gray-500 p-3 text-[16px] text-gray-500 text-hidden text-transparent">
                                            <option class="text-black">Choose store</option>
                                            <?php $array_store_id = explode(",", $store_id); ?>
                                            <option class="text-black {{ in_array(0, $array_store_id) || $store_id == 0 ? 'hidden' : '' }} store-list" onclick="selectStore(this)" id="store-selected-0" value="0">All store</option>
                                            @foreach ($stores as $store)
                                                <option class="text-black {{ in_array($store->id, $array_store_id) || $store_id == 0 ? 'hidden' : '' }} store-list" onclick="selectStore(this)" id="store-selected-{{ $store->id }}" value="{{ $store->id }}">{{ $store->name }}</option>
                                            @endforeach
                                        </select>
                                        <div class="relative w-10/12 h-[35px] flex items-center pl-3 pt-1" style="margin-top:-44px;">
                                            <div id='selected-store' class="absolute flex max-w-[270px] scroll-container">
                                                @if($store_id == 0)
                                                    <div class="px-2 py-1 bg-gray-400 rounded-full text-white flex mr-2">
                                                        <div class="w-[100px] truncate" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                                                            All store
                                                        </div>
                                                        <div class="justify-end text-red-500 cursor-pointer" onclick="removeStore(this, 0)" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                                                            x
                                                        </div>
                                                    </div>
                                                @else
                                                @foreach($stores as $store)
                                                    @if(in_array($store->id, $array_store_id))
                                                        <div class="px-2 py-1 bg-gray-400 rounded-full text-white flex mr-2">
                                                            <div class="w-[100px] truncate" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                                                                {{$store->name}}
                                                            </div>
                                                            <div class="justify-end text-red-500 cursor-pointer" onclick="removeStore(this, {{$store->id}})" style="-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;">
                                                                x
                                                            </div>
                                                        </div>
                                                    @endif
                                                @endforeach
                                                @endif
                                            </div>
                                        </div>
                                        @if(isset($errorMessages['store_id']))
                                            <p class="relative text-sm text-red-600 mt-2">{{ $errorMessages['store_id'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                                <div class="w-6/12">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500  ">
                                                Limit
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <select style="font-weight: 400;" wire:model="limit" class="w-full h-[44px] border border-gray-500 p-3 text-[16px] text-gray-500" >
                                            <option>How many times can it be exchanged</option>
                                            <option value="1">1 X</option>
                                            <option value="2">2 X</option>
                                            <option value="3">3 X</option>
                                            <option value="0">Unlimited</option>
                                        </select>
                                        @if(isset($errorMessages['limit']))
                                            <p class="relative text-sm text-red-600">{{ $errorMessages['limit'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="flex mb-5">
                                <div class="w-6/12 mr-5">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500  ">
                                                Start date
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input type="date" style="font-weight: 400;" wire:model="start_date" class="w-full h-[44px] border border-gray-500 p-3 text-[16px] text-gray-500" placeholder="Tanggal mulai aktif" />
                                        @if(isset($errorMessages['start_date']))
                                            <p class="relative text-sm text-red-600">{{ $errorMessages['start_date'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                                <div class="w-6/12">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500  ">
                                                End date
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input type="date" style="font-weight: 400;" wire:model="end_date" class="w-full h-[44px] border border-gray-500 p-3 text-[16px] text-gray-500" placeholder="Tanggal selesai aktif" />
                                        @if(isset($errorMessages['end_date']))
                                            <p class="relative text-sm text-red-600">{{ $errorMessages['end_date'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="flex mb-5">
                                <div class="w-6/12 mr-5">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500  ">
                                                Stock
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full">
                                        <input type="number" style="font-weight: 400;" wire:model="stock" class="w-full h-[44px] border border-gray-500 p-3 text-[16px] text-gray-500" placeholder="Number of claim stock" />
                                        @if(isset($errorMessages['stock']))
                                            <p class="relative text-sm text-red-600">{{ $errorMessages['stock'][0] }}</p>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="flex {{ $claim_type_id == 2 ? 'justify-between' : 'justify-center' }} items-center mb-6">
                                @if($claim_type_id == 2)
                                <div>
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500  ">
                                                Change System
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full flex items-center justify-center">
                                        <div class="flex items-center cursor-pointer no-select p-3">
                                            <input type="checkbox" wire:model="takeInStore" id="takeInStore" value="yes" class="mr-2 border-[#D6DADF] w-4 h-4 rounded-sm">
                                            <label style="font-weight: 400;line-height: 20px;" class="text-[16px] text-dark-primary  " for="takeInStore">Directly to the store</label>
                                        </div>
                                        <div class="flex items-center cursor-pointer no-select p-3">
                                            <input type="checkbox" wire:model="takeHome" id="takeHome" value="yes" class="mr-2 border-[#D6DADF] w-4 h-4 rounded-sm">
                                            <label style="font-weight: 400;line-height: 20px;" class="text-[16px] text-dark-primary  " for="takeHome">Send to home</label>
                                        </div>
                                    </div>
                                    @if(isset($errorMessages['change_system']))
                                        <p class="relative text-sm text-red-600">{{ $errorMessages['change_system'] }}</p>
                                    @endif
                                </div>
                                @endif
                                <div class="text-center">
                                    <div class="inline-block mb-1">
                                        <div style="font-weight: 400;font-size: 14px;" class="flex mb-1">
                                            <div class="mr-1 text-gray-500  ">
                                                Point
                                            </div>
                                            <div class="text-red-600">
                                                *
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex justify-center">
                                        <div class="flex justify-center items-center">
                                            <div wire:click="subtractValue('exchange_rate')" class="cursor-pointer">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path d="M18 12.998H6C5.73478 12.998 5.48043 12.8927 5.29289 12.7052C5.10536 12.5176 5 12.2633 5 11.998C5 11.7328 5.10536 11.4785 5.29289 11.2909C5.48043 11.1034 5.73478 10.998 6 10.998H18C18.2652 10.998 18.5196 11.1034 18.7071 11.2909C18.8946 11.4785 19 11.7328 19 11.998C19 12.2633 18.8946 12.5176 18.7071 12.7052C18.5196 12.8927 18.2652 12.998 18 12.998Z" fill="#6A6A75"/>
                                                    <path d="M0.5 12C0.5 5.64873 5.64873 0.5 12 0.5C18.3513 0.5 23.5 5.64873 23.5 12C23.5 18.3513 18.3513 23.5 12 23.5C5.64873 23.5 0.5 18.3513 0.5 12Z" stroke="#EDEDED"/>
                                                </svg>
                                            </div>
                                            <div class="mx-[15px]">
                                                <input id="exchange_rate_input" wire:model="exchange_rate" type="text" oninput="changeToInteger(this)" style="font-weight: 400;" class="p-3 text-[16px] w-[72px] h-[44px] text-center" placeholder="0" />
                                            </div>
                                            <div wire:click="addValue('exchange_rate')" class="cursor-pointer">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path d="M17.2734 11.25H12.75V6.72656C12.75 6.31406 12.4125 5.97656 12 5.97656C11.5875 5.97656 11.25 6.31406 11.25 6.72656V11.25H6.72656C6.31406 11.25 5.97656 11.5875 5.97656 12C5.97656 12.2063 6.06094 12.3937 6.19687 12.5297C6.33281 12.6656 6.52031 12.75 6.72656 12.75H11.25V17.2734C11.25 17.4797 11.3344 17.6672 11.4703 17.8031C11.6062 17.9391 11.7937 18.0234 12 18.0234C12.4125 18.0234 12.75 17.6859 12.75 17.2734V12.75H17.2734C17.6859 12.75 18.0234 12.4125 18.0234 12C18.0234 11.5875 17.6859 11.25 17.2734 11.25Z" fill="#6A6A75"/>
                                                    <path d="M0.5 12C0.5 5.64873 5.64873 0.5 12 0.5C18.3513 0.5 23.5 5.64873 23.5 12C23.5 18.3513 18.3513 23.5 12 23.5C5.64873 23.5 0.5 18.3513 0.5 12Z" stroke="#EDEDED"/>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="mb-20 p-6 bg-white">
                            <div class="flex justify-end">
                                <div class="mr-[14px]">
                                    <button type="button" style="font-weight: 600;" wire:click="deleteShow" @click="open=false" class="w-[83px] h-[44px] text-primary text-center text-[16px]">
                                        Cancel
                                    </button>
                                </div>
                                <div>
                                    <button type="button" @click="openConfirm=true" style="font-weight: 600;" class="w-[83px] h-[44px] bg-primary text-white text-center text-[16px]">
                                        Save
                                    </button>

                                    <div x-cloak x-show="openConfirm" x-transition class="fixed top-0 left-0  pt-20 w-full min-h-screen bg-black/50 flex justify-center items-center z-10">
                                        <section @click.outside="openConfirm=false" class="fixed w-[446px] mb-5 mx-auto my-auto bg-white" style="margin-top: -50px">
                                            <div class="w-full max-h-[650px] overflow-hidden">
                                                <div class="w-full  p-6">
                                                    <div style="font-weight: 600;font-size:20px" class="mt-5 mb-2 text-[20px]">
                                                        Are you sure?
                                                    </div>
                                                    <div style="font-size:16px" class="text-gray-500 mb-6">
                                                        Make sure you have filled in the data correctly. If there are errors after saving, you can change it back.
                                                    </div>
                                                    <div class="flex justify-end items-center">
                                                        <p x-on:click="openConfirm = false" style="font-weight: 600;" class="text-[16px] text-primary hover:cursor-pointer hover:opacity-50 duration-150 p-3 mr-[14px]">
                                                            Cancel
                                                        </p>
                                                        <button type="submit" @click="loading=true;openConfirm=false" style="font-weight: 600;" class="text-[16px] bg-primary text-white p-3">
                                                            Confirm
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        @endif

        <div  x-cloak x-show="showRedeem" style="margin-top:-33px; z-index:50;left:0;overflow: auto;" class="fixed w-screen h-full" x-ref="scrollContainer">
            <div class="w-full px-0 md:px-[100px] lg:px-[399px] bg-[#F9FAFB]">
                <div>
                    <div class="inline-block cursor-pointer" wire:click="closeRedeem" @click="showRedeem=false">
                        <div class="flex items-center mt-[40px]">
                            <div class="mr-1">
                                <img src="{{ asset('src/icons/ios-arrow-round-back.svg') }}" />
                            </div>
                            <div style="font-weight: 600;" class="text-[16px] text-primary">
                                Back
                            </div>
                        </div>
                    </div>
                    <div style="font-weight: 700;" class="text-[24px] text-black ">
                        Redeem
                    </div>

                    <div class="mt-6 bg-white w-full reltive">
                        <div class="border-b px-6 pt-6 border-b-[#EDEDED] mb-5">
                            <div class="relative h-12 no-select w-full">
                                <div class="w-full absolute flex items-center mt-[10px]">
                                    <div @click="showRedeemDetail=true;showHistoryRedeem=false;" :class="showRedeemDetail ? 'text-primary border-b-2 border-b-primary' : 'text-[#6A6A75] items-center' " class="px-6 py-2 cursor-pointer">
                                        <div style="font-weight: 600;" class="flex items-center h-5 text-[16px]">
                                            REDEEM
                                        </div>
                                    </div>
                                    <div wire:click="showHistoryRedeem" @click="showRedeemDetail=false;showHistoryRedeem=true;" :class="showHistoryRedeem ? 'text-primary border-b-2 border-b-primary' : 'text-[#6A6A75] items-center' " class="px-6 py-2 flex cursor-pointer">
                                        <div class="mr-1 h-5 flex items-center text-[16px]">
                                            HISTORY
                                        </div>
                                        @if(count($undeliveredGifts) > 0)
                                        <div class=" flex items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="8" height="8" viewBox="0 0 8 8" fill="none">
                                                <circle cx="4" cy="4" r="4" fill="#FE5C5C"/>
                                            </svg>
                                        </div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div x-show="showRedeemDetail" class="relative">
                            <div x-show="showRedeemNotification" class="absolute -top-5 px-6 py-2 bg-[#2C9854] w-full flex justify-between items-center">
                                <div class="flex items-center gap-2">
                                    <div class="w-5 h-5 rounded-full flex items-center justify-center bg-[#186A37]">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M14.1641 7.53516L13.4766 6.82812C13.4492 6.79687 13.4063 6.78125 13.3672 6.78125C13.3242 6.78125 13.2852 6.79687 13.2578 6.82812L8.49219 11.6289L6.75781 9.89453C6.72656 9.86328 6.6875 9.84766 6.64844 9.84766C6.60937 9.84766 6.57031 9.86328 6.53906 9.89453L5.84375 10.5898C5.78125 10.6523 5.78125 10.75 5.84375 10.8125L8.03125 13C8.17188 13.1406 8.34375 13.2227 8.48828 13.2227C8.69531 13.2227 8.875 13.0703 8.94141 13.0078H8.94531L14.168 7.75781C14.2227 7.69141 14.2227 7.59375 14.1641 7.53516Z" fill="white"/>
                                        </svg>
                                    </div>
                                    <div style="font-weight: 600;line-height: 20px;" class="text[-16px] text-white">
                                        Redeem successfully
                                    </div>
                                </div>
                                <div @click="showRedeemNotification=false" class="cursor-pointer no-select">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="white"/>
                                    </svg>
                                </div>
                            </div>
                            <div class="p-6 ">
                                <div class="relative mb-5">
                                    <input wire:model="searchRedeem" class="w-full h-11 py-3 pr-3 pl-9" placeholder="Find voucher / gift...." />
                                    <div class="absolute top-3 left-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M17.3242 16.4141L13.1523 12.2031C13.9688 11.1797 14.4609 9.88281 14.4609 8.47266C14.4609 5.17188 11.7852 2.49609 8.48047 2.49609C5.17578 2.49609 2.5 5.17578 2.5 8.47656C2.5 11.7773 5.17578 14.4531 8.48047 14.4531C9.91016 14.4531 11.2188 13.9531 12.25 13.1172L16.3945 17.3008C16.5195 17.4336 16.6914 17.5 16.8594 17.5C17.0195 17.5 17.1797 17.4414 17.3008 17.3242C17.5586 17.0781 17.5664 16.6719 17.3242 16.4141ZM8.48047 13.168C7.22656 13.168 6.04688 12.6797 5.16016 11.793C4.27344 10.9062 3.78516 9.72656 3.78516 8.47656C3.78516 7.22266 4.27344 6.04297 5.16016 5.16016C6.04688 4.27344 7.22656 3.78516 8.48047 3.78516C9.73438 3.78516 10.9141 4.27344 11.8008 5.16016C12.6875 6.04688 13.1758 7.22656 13.1758 8.47656C13.1758 9.73047 12.6875 10.9102 11.8008 11.793C10.9141 12.6797 9.73438 13.168 8.48047 13.168Z" fill="#6A6A75"/>
                                        </svg>
                                    </div>
                                </div>

                                <div class="flex items-center no-select mb-5">
                                    <div @click="allRedeems=true;allRedeemVouchers=false;allRedeemGifts=false;" :class="allRedeems ? 'border-primary bg-[#EAF2FA] text-primary' : 'text-dark-primary '" class="px-3 cursor-pointer py-2 mr-5 border  rounded-full">
                                        <div style="font-weight: 400;" class="h-5 flex items-center">
                                            All
                                        </div>
                                    </div>
                                    <div @click="allRedeems=false;allRedeemVouchers=true;allRedeemGifts=false;" :class="allRedeemVouchers ? 'border-primary bg-[#EAF2FA] text-primary' : 'text-dark-primary '" class="px-3 cursor-pointer py-2 mr-5 border rounded-full ">
                                        <div style="font-weight: 400;" class="h-5 flex items-center">
                                            Voucher
                                        </div>
                                    </div>
                                    <div @click="allRedeems=false;allRedeemVouchers=false;allRedeemGifts=true;" :class="allRedeemGifts ? 'border-primary bg-[#EAF2FA] text-primary' : 'text-dark-primary '" class="px-3 cursor-pointer py-2 mr-5 border rounded-full">
                                        <div style="font-weight: 400;" class="h-5 flex items-center">
                                            Gift
                                        </div>
                                    </div>
                                </div>

                                <div x-show="allRedeems">
                                    @foreach($allRedeems as $redeem)
                                    <div class="py-3 border-b">
                                        <div>
                                            <div class="flex items-center justify-between">
                                                <div class="flex items-center">
                                                    <div class="flex items-center mr-8 w-[330px]">
                                                        <div class="mr-4 w-10 h-10 flex items-center justify-center {{$redeem->claim->claim_type_id == 1 ? 'bg-[#E5EDFA]' : 'bg-[#FAE4E4]'}}  rounded-full">
                                                            @if($redeem->claim->claim_type_id == 1)
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                <path d="M17.5003 4.16675H2.50033C2.27931 4.16675 2.06735 4.25455 1.91107 4.41083C1.75479 4.56711 1.66699 4.77907 1.66699 5.00008V8.33342H2.41116C3.24116 8.33342 4.01116 8.90091 4.14449 9.72008C4.18511 9.95928 4.17304 10.2045 4.10913 10.4385C4.04522 10.6726 3.931 10.8899 3.77445 11.0752C3.61789 11.2606 3.42278 11.4095 3.20272 11.5117C2.98265 11.6139 2.74295 11.6668 2.50033 11.6667H1.66699V15.0001C1.66699 15.2211 1.75479 15.4331 1.91107 15.5893C2.06735 15.7456 2.27931 15.8334 2.50033 15.8334H17.5003C17.7213 15.8334 17.9333 15.7456 18.0896 15.5893C18.2459 15.4331 18.3337 15.2211 18.3337 15.0001V11.6667H17.5003C17.2577 11.6668 17.018 11.6139 16.7979 11.5117C16.5779 11.4095 16.3828 11.2606 16.2262 11.0752C16.0697 10.8899 15.9554 10.6726 15.8915 10.4385C15.8276 10.2045 15.8155 9.95928 15.8562 9.72008C15.9895 8.90091 16.7595 8.33342 17.5895 8.33342H18.3337V5.00008C18.3337 4.77907 18.2459 4.56711 18.0896 4.41083C17.9333 4.25455 17.7213 4.16675 17.5003 4.16675ZM9.16699 14.1667H7.50033V12.5001H9.16699V14.1667ZM9.16699 10.8334H7.50033V9.16675H9.16699V10.8334ZM9.16699 7.50008H7.50033V5.83341H9.16699V7.50008Z" fill="#3688EF"/>
                                                            </svg>
                                                            @else
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                <path d="M7.54967 1.60843C5.97468 1.6001 4.44134 3.11677 5.14134 5.0001H2.49967C2.05765 5.0001 1.63372 5.17569 1.32116 5.48825C1.0086 5.80082 0.833008 6.22474 0.833008 6.66677V8.33343C0.833008 8.55445 0.920805 8.76641 1.07709 8.92269C1.23337 9.07897 1.44533 9.16677 1.66634 9.16677H9.16634V6.66677H10.833V9.16677H18.333C18.554 9.16677 18.766 9.07897 18.9223 8.92269C19.0785 8.76641 19.1663 8.55445 19.1663 8.33343V6.66677C19.1663 6.22474 18.9907 5.80082 18.6782 5.48825C18.3656 5.17569 17.9417 5.0001 17.4997 5.0001H14.858C15.833 2.2751 12.1663 0.350099 10.4747 2.7001L9.99967 3.33343L9.52468 2.68343C8.99967 1.94177 8.27468 1.61677 7.54967 1.60843ZM7.49967 3.33343C8.24134 3.33343 8.61634 4.23343 8.09134 4.75843C7.56634 5.28343 6.66634 4.90843 6.66634 4.16677C6.66634 3.94575 6.75414 3.73379 6.91042 3.57751C7.0667 3.42123 7.27866 3.33343 7.49967 3.33343ZM12.4997 3.33343C13.2413 3.33343 13.6163 4.23343 13.0913 4.75843C12.5663 5.28343 11.6663 4.90843 11.6663 4.16677C11.6663 3.94575 11.7541 3.73379 11.9104 3.57751C12.0667 3.42123 12.2787 3.33343 12.4997 3.33343ZM1.66634 10.0001V16.6668C1.66634 17.1088 1.84194 17.5327 2.1545 17.8453C2.46706 18.1578 2.89098 18.3334 3.33301 18.3334H16.6663C17.1084 18.3334 17.5323 18.1578 17.8449 17.8453C18.1574 17.5327 18.333 17.1088 18.333 16.6668V10.0001H10.833V16.6668H9.16634V10.0001H1.66634Z" fill="#FE5C5C"/>
                                                            </svg>
                                                            @endif
                                                        </div>
                                                        <div>
                                                            <div style="font-weight: 600;line-height: 20px;" class="mr-8 text-[16px] text-dark-primary ">
                                                                {{$redeem->code}}
                                                            </div>
                                                            <div  style="font-weight: 400;line-height: 20px;" class="mr-8 text-[14px] text-dark-primary  line-clamp-1">
                                                                {{ $redeem->user->phone_number }}
                                                            </div>
                                                        </div>
                                                        <div class="py-1 px-2 rounded-full border flex items-center gap-1">
                                                            <div class="w-[6px] h-[6px] {{date('Y-m-d') > $redeem->valid_until ? "bg-[#B1B1B1]" : "bg-[#2C9854]"}} rounded-full">

                                                            </div>
                                                            <div style="font-weight: 400;line-height: 20px;" class="text-[14px] text-dark-primary ">
                                                                {{date('Y-m-d') > $redeem->valid_until ? "Expired" : "Active"}}
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="font-weight: 400;line-height: 20px;" class="text-[16px] text-[#6A6A75]  ">
                                                        Valid until {{changeDateFormat($redeem->valid_until)}}
                                                    </div>
                                                </div>
                                                <div @if(date('Y-m-d') <= $redeem->valid_until) wire:click="showRedeemConfirm({{$redeem->id}})" @endif class="border rounded-sm px-3 py-2 flex items-center justify-center cursor-pointer no-select {{date('Y-m-d') > $redeem->valid_until ? 'opacity-40 cursor-not-allowed' : ''}}">
                                                    <div style="font-weight: 600;line-height: 20px;" class="text-[16px] text-primary">
                                                        Redeem
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>

                                <div  x-show="allRedeemVouchers">
                                    @foreach($allRedeemVouchers as $redeem)
                                    <div class="py-3 border-b">
                                        <div>
                                            <div class="flex items-center justify-between">
                                                <div class="flex items-center">
                                                    <div class="flex items-center mr-8 w-[330px]">
                                                        <div class="mr-4 w-10 h-10 flex items-center justify-center {{$redeem->claim->claim_type_id == 1 ? 'bg-[#E5EDFA]' : 'bg-[#FAE4E4]'}}  rounded-full">
                                                            @if($redeem->claim->claim_type_id == 1)
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                <path d="M17.5003 4.16675H2.50033C2.27931 4.16675 2.06735 4.25455 1.91107 4.41083C1.75479 4.56711 1.66699 4.77907 1.66699 5.00008V8.33342H2.41116C3.24116 8.33342 4.01116 8.90091 4.14449 9.72008C4.18511 9.95928 4.17304 10.2045 4.10913 10.4385C4.04522 10.6726 3.931 10.8899 3.77445 11.0752C3.61789 11.2606 3.42278 11.4095 3.20272 11.5117C2.98265 11.6139 2.74295 11.6668 2.50033 11.6667H1.66699V15.0001C1.66699 15.2211 1.75479 15.4331 1.91107 15.5893C2.06735 15.7456 2.27931 15.8334 2.50033 15.8334H17.5003C17.7213 15.8334 17.9333 15.7456 18.0896 15.5893C18.2459 15.4331 18.3337 15.2211 18.3337 15.0001V11.6667H17.5003C17.2577 11.6668 17.018 11.6139 16.7979 11.5117C16.5779 11.4095 16.3828 11.2606 16.2262 11.0752C16.0697 10.8899 15.9554 10.6726 15.8915 10.4385C15.8276 10.2045 15.8155 9.95928 15.8562 9.72008C15.9895 8.90091 16.7595 8.33342 17.5895 8.33342H18.3337V5.00008C18.3337 4.77907 18.2459 4.56711 18.0896 4.41083C17.9333 4.25455 17.7213 4.16675 17.5003 4.16675ZM9.16699 14.1667H7.50033V12.5001H9.16699V14.1667ZM9.16699 10.8334H7.50033V9.16675H9.16699V10.8334ZM9.16699 7.50008H7.50033V5.83341H9.16699V7.50008Z" fill="#3688EF"/>
                                                            </svg>
                                                            @else
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                <path d="M7.54967 1.60843C5.97468 1.6001 4.44134 3.11677 5.14134 5.0001H2.49967C2.05765 5.0001 1.63372 5.17569 1.32116 5.48825C1.0086 5.80082 0.833008 6.22474 0.833008 6.66677V8.33343C0.833008 8.55445 0.920805 8.76641 1.07709 8.92269C1.23337 9.07897 1.44533 9.16677 1.66634 9.16677H9.16634V6.66677H10.833V9.16677H18.333C18.554 9.16677 18.766 9.07897 18.9223 8.92269C19.0785 8.76641 19.1663 8.55445 19.1663 8.33343V6.66677C19.1663 6.22474 18.9907 5.80082 18.6782 5.48825C18.3656 5.17569 17.9417 5.0001 17.4997 5.0001H14.858C15.833 2.2751 12.1663 0.350099 10.4747 2.7001L9.99967 3.33343L9.52468 2.68343C8.99967 1.94177 8.27468 1.61677 7.54967 1.60843ZM7.49967 3.33343C8.24134 3.33343 8.61634 4.23343 8.09134 4.75843C7.56634 5.28343 6.66634 4.90843 6.66634 4.16677C6.66634 3.94575 6.75414 3.73379 6.91042 3.57751C7.0667 3.42123 7.27866 3.33343 7.49967 3.33343ZM12.4997 3.33343C13.2413 3.33343 13.6163 4.23343 13.0913 4.75843C12.5663 5.28343 11.6663 4.90843 11.6663 4.16677C11.6663 3.94575 11.7541 3.73379 11.9104 3.57751C12.0667 3.42123 12.2787 3.33343 12.4997 3.33343ZM1.66634 10.0001V16.6668C1.66634 17.1088 1.84194 17.5327 2.1545 17.8453C2.46706 18.1578 2.89098 18.3334 3.33301 18.3334H16.6663C17.1084 18.3334 17.5323 18.1578 17.8449 17.8453C18.1574 17.5327 18.333 17.1088 18.333 16.6668V10.0001H10.833V16.6668H9.16634V10.0001H1.66634Z" fill="#FE5C5C"/>
                                                            </svg>
                                                            @endif
                                                        </div>
                                                        <div style="font-weight: 600;line-height: 20px;" class="mr-8 text-[16px] text-dark-primary ">
                                                            {{$redeem->code}}
                                                        </div>
                                                        <div class="py-1 px-2 rounded-full border flex items-center gap-1">
                                                            <div class="w-[6px] h-[6px] {{date('Y-m-d') > $redeem->valid_until ? "bg-[#B1B1B1]" : "bg-[#2C9854]"}} rounded-full">

                                                            </div>
                                                            <div style="font-weight: 400;line-height: 20px;" class="text-[14px] text-dark-primary ">
                                                                {{date('Y-m-d') > $redeem->valid_until ? "Expired" : "Active"}}
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="font-weight: 400;line-height: 20px;" class="text-[16px] text-[#6A6A75]  ">
                                                        Valid until {{changeDateFormat($redeem->valid_until)}}
                                                    </div>
                                                </div>
                                                <div @if(date('Y-m-d') <= $redeem->valid_until) wire:click="showRedeemConfirm({{$redeem->id}})" @endif class="border rounded-sm px-3 py-2 flex items-center justify-center cursor-pointer no-select {{date('Y-m-d') > $redeem->valid_until ? 'opacity-40 cursor-not-allowed' : ''}}">
                                                    <div style="font-weight: 600;line-height: 20px;" class="text-[16px] text-primary">
                                                        Redeem
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>

                                <div  x-show="allRedeemGifts">
                                    @foreach($allRedeemGifts as $redeem)
                                    <div class="py-3 border-b">
                                        <div>
                                            <div class="flex items-center justify-between">
                                                <div class="flex items-center">
                                                    <div class="flex items-center mr-8 w-[330px]">
                                                        <div class="mr-4 w-10 h-10 flex items-center justify-center {{$redeem->claim->claim_type_id == 1 ? 'bg-[#E5EDFA]' : 'bg-[#FAE4E4]'}}  rounded-full">
                                                            @if($redeem->claim->claim_type_id == 1)
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                <path d="M17.5003 4.16675H2.50033C2.27931 4.16675 2.06735 4.25455 1.91107 4.41083C1.75479 4.56711 1.66699 4.77907 1.66699 5.00008V8.33342H2.41116C3.24116 8.33342 4.01116 8.90091 4.14449 9.72008C4.18511 9.95928 4.17304 10.2045 4.10913 10.4385C4.04522 10.6726 3.931 10.8899 3.77445 11.0752C3.61789 11.2606 3.42278 11.4095 3.20272 11.5117C2.98265 11.6139 2.74295 11.6668 2.50033 11.6667H1.66699V15.0001C1.66699 15.2211 1.75479 15.4331 1.91107 15.5893C2.06735 15.7456 2.27931 15.8334 2.50033 15.8334H17.5003C17.7213 15.8334 17.9333 15.7456 18.0896 15.5893C18.2459 15.4331 18.3337 15.2211 18.3337 15.0001V11.6667H17.5003C17.2577 11.6668 17.018 11.6139 16.7979 11.5117C16.5779 11.4095 16.3828 11.2606 16.2262 11.0752C16.0697 10.8899 15.9554 10.6726 15.8915 10.4385C15.8276 10.2045 15.8155 9.95928 15.8562 9.72008C15.9895 8.90091 16.7595 8.33342 17.5895 8.33342H18.3337V5.00008C18.3337 4.77907 18.2459 4.56711 18.0896 4.41083C17.9333 4.25455 17.7213 4.16675 17.5003 4.16675ZM9.16699 14.1667H7.50033V12.5001H9.16699V14.1667ZM9.16699 10.8334H7.50033V9.16675H9.16699V10.8334ZM9.16699 7.50008H7.50033V5.83341H9.16699V7.50008Z" fill="#3688EF"/>
                                                            </svg>
                                                            @else
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                <path d="M7.54967 1.60843C5.97468 1.6001 4.44134 3.11677 5.14134 5.0001H2.49967C2.05765 5.0001 1.63372 5.17569 1.32116 5.48825C1.0086 5.80082 0.833008 6.22474 0.833008 6.66677V8.33343C0.833008 8.55445 0.920805 8.76641 1.07709 8.92269C1.23337 9.07897 1.44533 9.16677 1.66634 9.16677H9.16634V6.66677H10.833V9.16677H18.333C18.554 9.16677 18.766 9.07897 18.9223 8.92269C19.0785 8.76641 19.1663 8.55445 19.1663 8.33343V6.66677C19.1663 6.22474 18.9907 5.80082 18.6782 5.48825C18.3656 5.17569 17.9417 5.0001 17.4997 5.0001H14.858C15.833 2.2751 12.1663 0.350099 10.4747 2.7001L9.99967 3.33343L9.52468 2.68343C8.99967 1.94177 8.27468 1.61677 7.54967 1.60843ZM7.49967 3.33343C8.24134 3.33343 8.61634 4.23343 8.09134 4.75843C7.56634 5.28343 6.66634 4.90843 6.66634 4.16677C6.66634 3.94575 6.75414 3.73379 6.91042 3.57751C7.0667 3.42123 7.27866 3.33343 7.49967 3.33343ZM12.4997 3.33343C13.2413 3.33343 13.6163 4.23343 13.0913 4.75843C12.5663 5.28343 11.6663 4.90843 11.6663 4.16677C11.6663 3.94575 11.7541 3.73379 11.9104 3.57751C12.0667 3.42123 12.2787 3.33343 12.4997 3.33343ZM1.66634 10.0001V16.6668C1.66634 17.1088 1.84194 17.5327 2.1545 17.8453C2.46706 18.1578 2.89098 18.3334 3.33301 18.3334H16.6663C17.1084 18.3334 17.5323 18.1578 17.8449 17.8453C18.1574 17.5327 18.333 17.1088 18.333 16.6668V10.0001H10.833V16.6668H9.16634V10.0001H1.66634Z" fill="#FE5C5C"/>
                                                            </svg>
                                                            @endif
                                                        </div>
                                                        <div style="font-weight: 600;line-height: 20px;" class="mr-8 text-[16px] text-dark-primary ">
                                                            {{$redeem->code}}
                                                        </div>
                                                        <div class="py-1 px-2 rounded-full border flex items-center gap-1">
                                                            <div class="w-[6px] h-[6px] {{date('Y-m-d') > $redeem->valid_until ? "bg-[#B1B1B1]" : "bg-[#2C9854]"}} rounded-full">

                                                            </div>
                                                            <div style="font-weight: 400;line-height: 20px;" class="text-[14px] text-dark-primary ">
                                                                {{date('Y-m-d') > $redeem->valid_until ? "Expired" : "Active"}}
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="font-weight: 400;line-height: 20px;" class="text-[16px] text-[#6A6A75]  ">
                                                        Valid until {{changeDateFormat($redeem->valid_until)}}
                                                    </div>
                                                </div>
                                                <div @if(date('Y-m-d') <= $redeem->valid_until) wire:click="showRedeemConfirm({{$redeem->id}})" @endif class="border rounded-sm px-3 py-2 flex items-center justify-center cursor-pointer no-select {{date('Y-m-d') > $redeem->valid_until ? 'opacity-40 cursor-not-allowed' : ''}}">
                                                    <div style="font-weight: 600;line-height: 20px;" class="text-[16px] text-primary">
                                                        Redeem
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>

                        <div x-show="showHistoryRedeem" class="relative">
                            <div x-show="showOptionHistory" class="top-0 left-0 fixed flex items-center justify-center w-screen h-screen bg-opacity-50 bg-black" style="--tw-bg-opacity: 0.5;z-index:100">
                                <div @click.outside="showOptionHistory=false" class=" p-3 bg-white rounded-sm">
                                    <div class="flex items-center gap-4 mb-3">
                                        <div class="w-10 h-10 flex items-center justify-center rounded-full {{$optionHistory ? $optionHistory->claim->claim_type_id == 1 ? 'bg-[#E5EDFA]' : 'bg-[#FAE4E4]' : ''}}  ">
                                            @if($optionHistory)
                                            @if($optionHistory->claim->claim_type_id == 1)
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                <path d="M17.5003 4.1665H2.50033C2.27931 4.1665 2.06735 4.2543 1.91107 4.41058C1.75479 4.56686 1.66699 4.77882 1.66699 4.99984V8.33317H2.41116C3.24116 8.33317 4.01116 8.90067 4.14449 9.71984C4.18511 9.95903 4.17304 10.2042 4.10913 10.4383C4.04522 10.6723 3.931 10.8896 3.77445 11.075C3.61789 11.2603 3.42278 11.4093 3.20272 11.5114C2.98265 11.6136 2.74295 11.6665 2.50033 11.6665H1.66699V14.9998C1.66699 15.2209 1.75479 15.4328 1.91107 15.5891C2.06735 15.7454 2.27931 15.8332 2.50033 15.8332H17.5003C17.7213 15.8332 17.9333 15.7454 18.0896 15.5891C18.2459 15.4328 18.3337 15.2209 18.3337 14.9998V11.6665H17.5003C17.2577 11.6665 17.018 11.6136 16.7979 11.5114C16.5779 11.4093 16.3828 11.2603 16.2262 11.075C16.0697 10.8896 15.9554 10.6723 15.8915 10.4383C15.8276 10.2042 15.8155 9.95903 15.8562 9.71984C15.9895 8.90067 16.7595 8.33317 17.5895 8.33317H18.3337V4.99984C18.3337 4.77882 18.2459 4.56686 18.0896 4.41058C17.9333 4.2543 17.7213 4.1665 17.5003 4.1665ZM9.16699 14.1665H7.50033V12.4998H9.16699V14.1665ZM9.16699 10.8332H7.50033V9.1665H9.16699V10.8332ZM9.16699 7.49984H7.50033V5.83317H9.16699V7.49984Z" fill="#3688EF"/>
                                            </svg>

                                            @else
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                <path d="M7.54967 1.60843C5.97468 1.6001 4.44134 3.11677 5.14134 5.0001H2.49967C2.05765 5.0001 1.63372 5.17569 1.32116 5.48825C1.0086 5.80082 0.833008 6.22474 0.833008 6.66677V8.33343C0.833008 8.55445 0.920805 8.76641 1.07709 8.92269C1.23337 9.07897 1.44533 9.16677 1.66634 9.16677H9.16634V6.66677H10.833V9.16677H18.333C18.554 9.16677 18.766 9.07897 18.9223 8.92269C19.0785 8.76641 19.1663 8.55445 19.1663 8.33343V6.66677C19.1663 6.22474 18.9907 5.80082 18.6782 5.48825C18.3656 5.17569 17.9417 5.0001 17.4997 5.0001H14.858C15.833 2.2751 12.1663 0.350099 10.4747 2.7001L9.99967 3.33343L9.52468 2.68343C8.99967 1.94177 8.27468 1.61677 7.54967 1.60843ZM7.49967 3.33343C8.24134 3.33343 8.61634 4.23343 8.09134 4.75843C7.56634 5.28343 6.66634 4.90843 6.66634 4.16677C6.66634 3.94575 6.75414 3.73379 6.91042 3.57751C7.0667 3.42123 7.27866 3.33343 7.49967 3.33343ZM12.4997 3.33343C13.2413 3.33343 13.6163 4.23343 13.0913 4.75843C12.5663 5.28343 11.6663 4.90843 11.6663 4.16677C11.6663 3.94575 11.7541 3.73379 11.9104 3.57751C12.0667 3.42123 12.2787 3.33343 12.4997 3.33343ZM1.66634 10.0001V16.6668C1.66634 17.1088 1.84194 17.5327 2.1545 17.8453C2.46706 18.1578 2.89098 18.3334 3.33301 18.3334H16.6663C17.1084 18.3334 17.5323 18.1578 17.8449 17.8453C18.1574 17.5327 18.333 17.1088 18.333 16.6668V10.0001H10.833V16.6668H9.16634V10.0001H1.66634Z" fill="#FE5C5C"/>
                                            </svg>
                                            @endif
                                            @endif
                                        </div>
                                        <div>
                                            <div style="font-weight: 600;line-height: 20px;" class="text-[16px]">
                                                {{$optionHistory ? $optionHistory->code : ''}}
                                            </div>
                                            <div style="font-weight: 400;line-height: 20px;" class="text-[16px] text-[#6A6A75]">
                                                Use on {{$optionHistory ? changeDateFormat($optionHistory->use_date) : ''}}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex gap-[7px] mb-3">
                                        @if($optionHistory)
                                        @if($optionHistory->in_store)
                                        <div>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                <path d="M2.51836 2.43683C2.39769 2.67683 2.33836 2.97416 2.21969 3.5675L1.82102 5.56083C1.76452 5.83261 1.76408 6.11307 1.81974 6.38503C1.87539 6.65698 1.98596 6.91472 2.14468 7.14246C2.3034 7.37021 2.50693 7.56316 2.74282 7.70951C2.9787 7.85586 3.24197 7.95253 3.51651 7.9936C3.79104 8.03467 4.07108 8.01927 4.33946 7.94836C4.60784 7.87744 4.85893 7.7525 5.07735 7.58118C5.29577 7.40985 5.47692 7.19576 5.60973 6.95199C5.74253 6.70822 5.82418 6.43992 5.84969 6.1635L5.89636 5.7035C5.87057 5.99631 5.90621 6.29129 6.00099 6.56954C6.09578 6.84779 6.24762 7.10318 6.4468 7.31936C6.64598 7.53554 6.88811 7.70775 7.15768 7.82495C7.42725 7.94216 7.71833 8.00179 8.01227 8.00002C8.30622 7.99825 8.59655 7.93512 8.86469 7.81467C9.13283 7.69422 9.37286 7.51911 9.56942 7.30054C9.76598 7.08197 9.91474 6.82477 10.0062 6.5454C10.0976 6.26603 10.1297 5.97065 10.1004 5.67816L10.1497 6.1635C10.1752 6.43992 10.2569 6.70822 10.3897 6.95199C10.5225 7.19576 10.7036 7.40985 10.922 7.58118C11.1404 7.7525 11.3915 7.87744 11.6599 7.94836C11.9283 8.01927 12.2083 8.03467 12.4829 7.9936C12.7574 7.95253 13.0207 7.85586 13.2566 7.70951C13.4924 7.56316 13.696 7.37021 13.8547 7.14246C14.0134 6.91472 14.124 6.65698 14.1796 6.38503C14.2353 6.11307 14.2349 5.83261 14.1784 5.56083L13.7797 3.5675C13.661 2.97416 13.6017 2.6775 13.481 2.43683C13.3553 2.18619 13.1783 1.96479 12.9614 1.787C12.7446 1.60921 12.4928 1.479 12.2224 1.40483C11.9624 1.3335 11.6597 1.3335 11.0544 1.3335H4.94502C4.33969 1.3335 4.03702 1.3335 3.77702 1.40483C3.5066 1.479 3.2548 1.60921 3.03796 1.787C2.82112 1.96479 2.64409 2.18619 2.51836 2.43683ZM12.1784 9.00016C12.6995 9.00159 13.2121 8.86816 13.6664 8.61283V9.3335C13.6664 11.8475 13.6664 13.1048 12.885 13.8855C12.2564 14.5148 11.3197 14.6368 9.66636 14.6608V12.3335C9.66636 11.7102 9.66636 11.3988 9.53236 11.1668C9.44459 11.0148 9.31836 10.8886 9.16636 10.8008C8.93436 10.6668 8.62302 10.6668 7.99969 10.6668C7.37636 10.6668 7.06502 10.6668 6.83302 10.8008C6.68102 10.8886 6.55479 11.0148 6.46702 11.1668C6.33302 11.3988 6.33302 11.7102 6.33302 12.3335V14.6608C4.67969 14.6368 3.74302 14.5142 3.11436 13.8855C2.33302 13.1048 2.33302 11.8475 2.33302 9.3335V8.61283C2.7873 8.86816 3.29991 9.00159 3.82102 9.00016C4.59146 9.00071 5.33323 8.70801 5.89569 8.1815C6.46894 8.70954 7.2203 9.0019 7.99969 9.00016C8.77884 9.00166 9.5299 8.70933 10.103 8.1815C10.666 8.70848 11.4086 9.00122 12.1797 9.00016H12.1784Z" fill="#B1B1B1"/>
                                            </svg>
                                        </div>
                                        <div style="font-weight: 400;line-height: 20px;" class="text-[#6A6A75] text-[16px]">
                                            @if($optionHistory)
                                            @if($optionHistory->is_used == true && $optionHistory->in_store == true)
                                            {{$optionHistory->store ? $optionHistory->store->name : "Brand owner"}}
                                            @endif
                                            @endif
                                        </div>
                                        @else
                                        <div>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                <path d="M6.5 14V10H9.5V14H12.55V8H14.5L8 2L1.5 8H3.45V14H6.5Z" fill="#B1B1B1"/>
                                            </svg>
                                        </div>
                                        <div style="font-weight: 400;line-height: 20px;" class="text-[#6A6A75] text-[16px]">
                                            @if($optionHistory)
                                            {{$optionHistory->address}}
                                            @endif
                                        </div>
                                        @endif
                                        @endif
                                    </div>
                                    <div>
                                        @if($optionHistory)
                                        @if($optionHistory->in_store)
                                        <select disabled class="w-full p-3 h-[44px]">
                                            <option value="berhasil">Success</option>
                                        </select>
                                        @else
                                        @if($optionHistory->is_delivered == false)
                                        <select wire:model="is_send" class="w-full p-3 h-[44px] mb-3">
                                            <option value="belum dikirim">Not sent</option>
                                            <option value="sudah dikirim">Has been sent</option>
                                        </select>
                                        <div class="w-full flex justify-end">
                                            <div wire:click="sendGift" style="font-weight: 600;line-height: 20px;" class="p-3 bg-primary rounded-sm text-white text-[16px] no-select cursor-pointer">
                                                Save
                                            </div>
                                        </div>
                                        @else
                                        <div style="font-weight: 400;line-height: 20px;" class="text-[#6A6A75] text-[16px]">
                                            Status
                                        </div>
                                        <select wire:model="is_success" class="w-full p-3 h-[44px] mb-3">
                                            <option value="berhasil">Success</option>
                                            <option value="belum berhasil">Not success</option>
                                        </select>
                                        <div style="font-weight: 400;line-height: 20px;" class="text-[#6A6A75] text-[16px]">
                                            Expedition
                                        </div>
                                        <select wire:model="expedition" class="w-full p-3 h-[44px] mb-3">
                                            <option value="JNE">JNE</option>
                                            <option value="Tiki">Tiki</option>
                                            <option value="Pos Indonesia">Pos Indonesia</option>
                                        </select>
                                        <div style="font-weight: 400;line-height: 20px;" class="text-[#6A6A75] text-[16px]">
                                            Receipt
                                        </div>
                                        <input wire:model="receipt_number" type="text" class="h-[44px] mb-3 w-full">
                                        <div class="w-full flex justify-end">
                                            <div wire:click="finishSendGift" style="font-weight: 600;line-height: 20px;" class="p-3 bg-primary rounded-sm text-white text-[16px] cursor-pointer no-select">
                                                Save
                                            </div>
                                        </div>
                                        @endif
                                        @endif
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="p-6 ">
                                <div class="relative mb-5">
                                    <input wire:model="searchHistoryRedeem" class="w-full h-11 py-3 pr-3 pl-9" placeholder="Cari Kode voucher/hadiah..." />
                                    <div class="absolute top-3 left-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M17.3242 16.4141L13.1523 12.2031C13.9688 11.1797 14.4609 9.88281 14.4609 8.47266C14.4609 5.17188 11.7852 2.49609 8.48047 2.49609C5.17578 2.49609 2.5 5.17578 2.5 8.47656C2.5 11.7773 5.17578 14.4531 8.48047 14.4531C9.91016 14.4531 11.2188 13.9531 12.25 13.1172L16.3945 17.3008C16.5195 17.4336 16.6914 17.5 16.8594 17.5C17.0195 17.5 17.1797 17.4414 17.3008 17.3242C17.5586 17.0781 17.5664 16.6719 17.3242 16.4141ZM8.48047 13.168C7.22656 13.168 6.04688 12.6797 5.16016 11.793C4.27344 10.9062 3.78516 9.72656 3.78516 8.47656C3.78516 7.22266 4.27344 6.04297 5.16016 5.16016C6.04688 4.27344 7.22656 3.78516 8.48047 3.78516C9.73438 3.78516 10.9141 4.27344 11.8008 5.16016C12.6875 6.04688 13.1758 7.22656 13.1758 8.47656C13.1758 9.73047 12.6875 10.9102 11.8008 11.793C10.9141 12.6797 9.73438 13.168 8.48047 13.168Z" fill="#6A6A75"/>
                                        </svg>
                                    </div>
                                </div>

                                <div class="flex items-center no-select mb-5">
                                    <div @click="allHistoryRedeems=true;allHistoryRedeemVouchers=false;allHistoryRedeemGifts=false;" :class="allHistoryRedeems ? 'border-primary bg-[#EAF2FA] text-primary' : 'text-dark-primary '" class="px-3 cursor-pointer py-2 mr-5 border  rounded-full">
                                        <div style="font-weight: 400;" class="h-5 flex items-center">
                                            All
                                        </div>
                                    </div>
                                    <div @click="allHistoryRedeems=false;allHistoryRedeemVouchers=true;allHistoryRedeemGifts=false;" :class="allHistoryRedeemVouchers ? 'border-primary bg-[#EAF2FA] text-primary' : 'text-dark-primary '" class="px-3 cursor-pointer py-2 mr-5 border rounded-full ">
                                        <div style="font-weight: 400;" class="h-5 flex items-center">
                                            Voucher
                                        </div>
                                    </div>
                                    <div @click="allHistoryRedeems=false;allHistoryRedeemVouchers=false;allHistoryRedeemGifts=true;" :class="allHistoryRedeemGifts ? 'border-primary bg-[#EAF2FA] text-primary' : 'text-dark-primary '" class="px-3 cursor-pointer py-2 mr-5 border rounded-full">
                                        <div style="font-weight: 400;" class="h-5 flex items-center">
                                            Gift
                                        </div>
                                    </div>
                                </div>

                                <div x-show="notificationUndelivered" class="mb-5 p-5 flex justify-between bg-[#EDEDED] rounded-sm no-select">
                                    <div class="flex">
                                        <div class="mr-1">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path d="M20.97 6.2017L12.72 1.68764C12.4996 1.56584 12.2518 1.50195 12 1.50195C11.7482 1.50195 11.5004 1.56584 11.28 1.68764L3.03 6.20358C2.7944 6.33249 2.59772 6.52229 2.46052 6.75316C2.32331 6.98404 2.25061 7.24751 2.25 7.51608V16.4823C2.25061 16.7509 2.32331 17.0144 2.46052 17.2452C2.59772 17.4761 2.7944 17.6659 3.03 17.7948L11.28 22.3108C11.5004 22.4326 11.7482 22.4965 12 22.4965C12.2518 22.4965 12.4996 22.4326 12.72 22.3108L20.97 17.7948C21.2056 17.6659 21.4023 17.4761 21.5395 17.2452C21.6767 17.0144 21.7494 16.7509 21.75 16.4823V7.51701C21.7499 7.24797 21.6774 6.98391 21.5402 6.7525C21.403 6.52108 21.206 6.33084 20.97 6.2017ZM12 3.00014L19.5328 7.12514L16.7409 8.65233L9.20813 4.52733L12 3.00014ZM12 11.2501L4.46719 7.12514L7.64625 5.3842L15.1791 9.5092L12 11.2501ZM20.25 16.4861L12.75 20.5914V12.5467L15.75 10.9051V14.2501C15.75 14.4491 15.829 14.6398 15.9697 14.7805C16.1103 14.9211 16.3011 15.0001 16.5 15.0001C16.6989 15.0001 16.8897 14.9211 17.0303 14.7805C17.171 14.6398 17.25 14.4491 17.25 14.2501V10.0839L20.25 8.44233V16.4823V16.4861Z" fill="#FE5C5C"/>
                                            </svg>
                                        </div>
                                        <div>
                                            <div style="font-weight: 600;line-height: 20px" class="text-[16px]">
                                                {{count($undeliveredGifts)}} gift need to send
                                            </div>
                                            <div style="font-weight: 400;line-height: 20px;" class="text-[14px] text-[#6A6A75]  ">
                                                Double check the gifts that need to be sent to the customer's address. If so, update the delivery status to update the gift data.
                                            </div>
                                        </div>
                                    </div>
                                    <div @click="notificationUndelivered=false" class="cursor-pointer">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M13.0594 12.0001L16.2563 8.80322C16.5469 8.5126 16.5469 8.03447 16.2563 7.74385C15.9656 7.45322 15.4875 7.45322 15.1969 7.74385L12 10.9407L8.80313 7.74385C8.5125 7.45322 8.03437 7.45322 7.74375 7.74385C7.59844 7.88916 7.52344 8.08135 7.52344 8.27354C7.52344 8.46572 7.59844 8.65791 7.74375 8.80322L10.9406 12.0001L7.74375 15.197C7.59844 15.3423 7.52344 15.5345 7.52344 15.7267C7.52344 15.9188 7.59844 16.111 7.74375 16.2563C8.03437 16.547 8.5125 16.547 8.80313 16.2563L12 13.0595L15.1969 16.2563C15.4875 16.547 15.9656 16.547 16.2563 16.2563C16.5469 15.9657 16.5469 15.4876 16.2563 15.197L13.0594 12.0001Z" fill="#B1B1B1"/>
                                        </svg>
                                    </div>
                                </div>

                                <div x-show="allHistoryRedeems">
                                    @foreach($allHistoryRedeems as $redeem)
                                    <div class="py-3 border-b">
                                        <div>
                                            <div class="flex items-center justify-between">
                                                <div class="w-10/12 flex items-center justify-between">
                                                    <div class="flex items-center mr-8">
                                                        <div class="mr-4 w-10 h-10 flex items-center justify-center {{$redeem->claim->claim_type_id == 1 ? 'bg-[#E5EDFA]' : 'bg-[#FAE4E4]'}}  rounded-full">
                                                            @if($redeem->claim->claim_type_id == 1)
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                <path d="M17.5003 4.16675H2.50033C2.27931 4.16675 2.06735 4.25455 1.91107 4.41083C1.75479 4.56711 1.66699 4.77907 1.66699 5.00008V8.33342H2.41116C3.24116 8.33342 4.01116 8.90091 4.14449 9.72008C4.18511 9.95928 4.17304 10.2045 4.10913 10.4385C4.04522 10.6726 3.931 10.8899 3.77445 11.0752C3.61789 11.2606 3.42278 11.4095 3.20272 11.5117C2.98265 11.6139 2.74295 11.6668 2.50033 11.6667H1.66699V15.0001C1.66699 15.2211 1.75479 15.4331 1.91107 15.5893C2.06735 15.7456 2.27931 15.8334 2.50033 15.8334H17.5003C17.7213 15.8334 17.9333 15.7456 18.0896 15.5893C18.2459 15.4331 18.3337 15.2211 18.3337 15.0001V11.6667H17.5003C17.2577 11.6668 17.018 11.6139 16.7979 11.5117C16.5779 11.4095 16.3828 11.2606 16.2262 11.0752C16.0697 10.8899 15.9554 10.6726 15.8915 10.4385C15.8276 10.2045 15.8155 9.95928 15.8562 9.72008C15.9895 8.90091 16.7595 8.33342 17.5895 8.33342H18.3337V5.00008C18.3337 4.77907 18.2459 4.56711 18.0896 4.41083C17.9333 4.25455 17.7213 4.16675 17.5003 4.16675ZM9.16699 14.1667H7.50033V12.5001H9.16699V14.1667ZM9.16699 10.8334H7.50033V9.16675H9.16699V10.8334ZM9.16699 7.50008H7.50033V5.83341H9.16699V7.50008Z" fill="#3688EF"/>
                                                            </svg>
                                                            @else
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                <path d="M7.54967 1.60843C5.97468 1.6001 4.44134 3.11677 5.14134 5.0001H2.49967C2.05765 5.0001 1.63372 5.17569 1.32116 5.48825C1.0086 5.80082 0.833008 6.22474 0.833008 6.66677V8.33343C0.833008 8.55445 0.920805 8.76641 1.07709 8.92269C1.23337 9.07897 1.44533 9.16677 1.66634 9.16677H9.16634V6.66677H10.833V9.16677H18.333C18.554 9.16677 18.766 9.07897 18.9223 8.92269C19.0785 8.76641 19.1663 8.55445 19.1663 8.33343V6.66677C19.1663 6.22474 18.9907 5.80082 18.6782 5.48825C18.3656 5.17569 17.9417 5.0001 17.4997 5.0001H14.858C15.833 2.2751 12.1663 0.350099 10.4747 2.7001L9.99967 3.33343L9.52468 2.68343C8.99967 1.94177 8.27468 1.61677 7.54967 1.60843ZM7.49967 3.33343C8.24134 3.33343 8.61634 4.23343 8.09134 4.75843C7.56634 5.28343 6.66634 4.90843 6.66634 4.16677C6.66634 3.94575 6.75414 3.73379 6.91042 3.57751C7.0667 3.42123 7.27866 3.33343 7.49967 3.33343ZM12.4997 3.33343C13.2413 3.33343 13.6163 4.23343 13.0913 4.75843C12.5663 5.28343 11.6663 4.90843 11.6663 4.16677C11.6663 3.94575 11.7541 3.73379 11.9104 3.57751C12.0667 3.42123 12.2787 3.33343 12.4997 3.33343ZM1.66634 10.0001V16.6668C1.66634 17.1088 1.84194 17.5327 2.1545 17.8453C2.46706 18.1578 2.89098 18.3334 3.33301 18.3334H16.6663C17.1084 18.3334 17.5323 18.1578 17.8449 17.8453C18.1574 17.5327 18.333 17.1088 18.333 16.6668V10.0001H10.833V16.6668H9.16634V10.0001H1.66634Z" fill="#FE5C5C"/>
                                                            </svg>
                                                            @endif
                                                        </div>
                                                        <div>
                                                            <div style="font-weight: 600;line-height: 20px;" class="mr-8 text-[16px] text-dark-primary ">
                                                                {{$redeem->code}}
                                                            </div>
                                                            <div style="font-weight: 400;line-height: 20px" class="text-[16px] text-[#6A6A75]  ">
                                                                Used on {{changeDateFormat($redeem->use_date) . " " . date("H:i", strtotime($redeem->use_date))}}
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="flex items-center gap-[7px] max-w-[240px]">
                                                        @if($redeem->claim->claim_type_id == 1 || ($redeem->claim->claim_type_id == 2 && $redeem->in_store))
                                                        <div>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                <path d="M2.51836 2.43683C2.39769 2.67683 2.33836 2.97416 2.21969 3.5675L1.82102 5.56083C1.76452 5.83261 1.76408 6.11307 1.81974 6.38503C1.87539 6.65698 1.98596 6.91472 2.14468 7.14246C2.3034 7.37021 2.50693 7.56316 2.74282 7.70951C2.9787 7.85586 3.24197 7.95253 3.51651 7.9936C3.79104 8.03467 4.07108 8.01927 4.33946 7.94836C4.60784 7.87744 4.85893 7.7525 5.07735 7.58118C5.29577 7.40985 5.47692 7.19576 5.60973 6.95199C5.74253 6.70822 5.82418 6.43992 5.84969 6.1635L5.89636 5.7035C5.87057 5.99631 5.90621 6.29129 6.00099 6.56954C6.09578 6.84779 6.24762 7.10318 6.4468 7.31936C6.64598 7.53554 6.88811 7.70775 7.15768 7.82495C7.42725 7.94216 7.71833 8.00179 8.01227 8.00002C8.30622 7.99825 8.59655 7.93512 8.86469 7.81467C9.13283 7.69422 9.37286 7.51911 9.56942 7.30054C9.76598 7.08197 9.91474 6.82477 10.0062 6.5454C10.0976 6.26603 10.1297 5.97065 10.1004 5.67816L10.1497 6.1635C10.1752 6.43992 10.2569 6.70822 10.3897 6.95199C10.5225 7.19576 10.7036 7.40985 10.922 7.58118C11.1404 7.7525 11.3915 7.87744 11.6599 7.94836C11.9283 8.01927 12.2083 8.03467 12.4829 7.9936C12.7574 7.95253 13.0207 7.85586 13.2566 7.70951C13.4924 7.56316 13.696 7.37021 13.8547 7.14246C14.0134 6.91472 14.124 6.65698 14.1796 6.38503C14.2353 6.11307 14.2349 5.83261 14.1784 5.56083L13.7797 3.5675C13.661 2.97416 13.6017 2.6775 13.481 2.43683C13.3553 2.18619 13.1783 1.96479 12.9614 1.787C12.7446 1.60921 12.4928 1.479 12.2224 1.40483C11.9624 1.3335 11.6597 1.3335 11.0544 1.3335H4.94502C4.33969 1.3335 4.03702 1.3335 3.77702 1.40483C3.5066 1.479 3.2548 1.60921 3.03796 1.787C2.82112 1.96479 2.64409 2.18619 2.51836 2.43683ZM12.1784 9.00016C12.6995 9.00159 13.2121 8.86816 13.6664 8.61283V9.3335C13.6664 11.8475 13.6664 13.1048 12.885 13.8855C12.2564 14.5148 11.3197 14.6368 9.66636 14.6608V12.3335C9.66636 11.7102 9.66636 11.3988 9.53236 11.1668C9.44459 11.0148 9.31836 10.8886 9.16636 10.8008C8.93436 10.6668 8.62302 10.6668 7.99969 10.6668C7.37636 10.6668 7.06502 10.6668 6.83302 10.8008C6.68102 10.8886 6.55479 11.0148 6.46702 11.1668C6.33302 11.3988 6.33302 11.7102 6.33302 12.3335V14.6608C4.67969 14.6368 3.74302 14.5142 3.11436 13.8855C2.33302 13.1048 2.33302 11.8475 2.33302 9.3335V8.61283C2.7873 8.86816 3.29991 9.00159 3.82102 9.00016C4.59146 9.00071 5.33323 8.70801 5.89569 8.1815C6.46894 8.70954 7.2203 9.0019 7.99969 9.00016C8.77884 9.00166 9.5299 8.70933 10.103 8.1815C10.666 8.70848 11.4086 9.00122 12.1797 9.00016H12.1784Z" fill="#B1B1B1"/>
                                                            </svg>
                                                        </div>
                                                        <div style="font-weight: 400;line-height: 20px;" class="text-[16px] text-[#6A6A75] truncate">
                                                            {{$redeem->store ? $redeem->store->name : "Pemilik Toko Utama"}}
                                                        </div>
                                                        @else
                                                        <div>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                <path d="M6.5 14V10H9.5V14H12.55V8H14.5L8 2L1.5 8H3.45V14H6.5Z" fill="#B1B1B1"/>
                                                            </svg>
                                                        </div>
                                                        <div style="font-weight: 400;line-height: 20px;" class="text-[16px] text-[#6A6A75] truncate">
                                                            {{$redeem->address}}
                                                        </div>
                                                        @endif
                                                    </div>
                                                    <div class="flex items-center no-select justify-between">
                                                        <div class="flex gap-1 items-center justify-center text-white py-1 px-2 rounded-full border {{$redeem->status ? "bg-[#2C9854]" : "bg-[#FE5C5C]"}}">
                                                            <div style="font-weight: 400;line-height: 20px;" class="text-[14px]">
                                                                {{$redeem->status ? "Success" : "Not sent"}}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div wire:click="showOptionHistory({{$redeem->id}})" class="w-2-12 cursor-pointer">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path d="M13.875 6.375C13.875 5.34366 13.0313 4.5 12 4.5C10.9687 4.5 10.125 5.34366 10.125 6.375C10.125 7.40634 10.9687 8.25 12 8.25C13.0313 8.25 13.875 7.40634 13.875 6.375ZM13.875 17.625C13.875 16.5937 13.0313 15.75 12 15.75C10.9687 15.75 10.125 16.5937 10.125 17.625C10.125 18.6563 10.9687 19.5 12 19.5C13.0313 19.5 13.875 18.6563 13.875 17.625ZM13.875 12C13.875 10.9687 13.0313 10.125 12 10.125C10.9687 10.125 10.125 10.9687 10.125 12C10.125 13.0313 10.9687 13.875 12 13.875C13.0313 13.875 13.875 13.0313 13.875 12Z" fill="#6A6A75"/>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>

                                <div  x-show="allHistoryRedeemVouchers">
                                    @foreach($allHistoryRedeemVouchers as $redeem)
                                    <div class="py-3 border-b">
                                        <div>
                                            <div class="flex items-center justify-between">
                                                <div class="w-10/12 flex items-center justify-between">
                                                    <div class="flex items-center mr-8">
                                                        <div class="mr-4 w-10 h-10 flex items-center justify-center {{$redeem->claim->claim_type_id == 1 ? 'bg-[#E5EDFA]' : 'bg-[#FAE4E4]'}}  rounded-full">
                                                            @if($redeem->claim->claim_type_id == 1)
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                <path d="M17.5003 4.16675H2.50033C2.27931 4.16675 2.06735 4.25455 1.91107 4.41083C1.75479 4.56711 1.66699 4.77907 1.66699 5.00008V8.33342H2.41116C3.24116 8.33342 4.01116 8.90091 4.14449 9.72008C4.18511 9.95928 4.17304 10.2045 4.10913 10.4385C4.04522 10.6726 3.931 10.8899 3.77445 11.0752C3.61789 11.2606 3.42278 11.4095 3.20272 11.5117C2.98265 11.6139 2.74295 11.6668 2.50033 11.6667H1.66699V15.0001C1.66699 15.2211 1.75479 15.4331 1.91107 15.5893C2.06735 15.7456 2.27931 15.8334 2.50033 15.8334H17.5003C17.7213 15.8334 17.9333 15.7456 18.0896 15.5893C18.2459 15.4331 18.3337 15.2211 18.3337 15.0001V11.6667H17.5003C17.2577 11.6668 17.018 11.6139 16.7979 11.5117C16.5779 11.4095 16.3828 11.2606 16.2262 11.0752C16.0697 10.8899 15.9554 10.6726 15.8915 10.4385C15.8276 10.2045 15.8155 9.95928 15.8562 9.72008C15.9895 8.90091 16.7595 8.33342 17.5895 8.33342H18.3337V5.00008C18.3337 4.77907 18.2459 4.56711 18.0896 4.41083C17.9333 4.25455 17.7213 4.16675 17.5003 4.16675ZM9.16699 14.1667H7.50033V12.5001H9.16699V14.1667ZM9.16699 10.8334H7.50033V9.16675H9.16699V10.8334ZM9.16699 7.50008H7.50033V5.83341H9.16699V7.50008Z" fill="#3688EF"/>
                                                            </svg>
                                                            @else
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                <path d="M7.54967 1.60843C5.97468 1.6001 4.44134 3.11677 5.14134 5.0001H2.49967C2.05765 5.0001 1.63372 5.17569 1.32116 5.48825C1.0086 5.80082 0.833008 6.22474 0.833008 6.66677V8.33343C0.833008 8.55445 0.920805 8.76641 1.07709 8.92269C1.23337 9.07897 1.44533 9.16677 1.66634 9.16677H9.16634V6.66677H10.833V9.16677H18.333C18.554 9.16677 18.766 9.07897 18.9223 8.92269C19.0785 8.76641 19.1663 8.55445 19.1663 8.33343V6.66677C19.1663 6.22474 18.9907 5.80082 18.6782 5.48825C18.3656 5.17569 17.9417 5.0001 17.4997 5.0001H14.858C15.833 2.2751 12.1663 0.350099 10.4747 2.7001L9.99967 3.33343L9.52468 2.68343C8.99967 1.94177 8.27468 1.61677 7.54967 1.60843ZM7.49967 3.33343C8.24134 3.33343 8.61634 4.23343 8.09134 4.75843C7.56634 5.28343 6.66634 4.90843 6.66634 4.16677C6.66634 3.94575 6.75414 3.73379 6.91042 3.57751C7.0667 3.42123 7.27866 3.33343 7.49967 3.33343ZM12.4997 3.33343C13.2413 3.33343 13.6163 4.23343 13.0913 4.75843C12.5663 5.28343 11.6663 4.90843 11.6663 4.16677C11.6663 3.94575 11.7541 3.73379 11.9104 3.57751C12.0667 3.42123 12.2787 3.33343 12.4997 3.33343ZM1.66634 10.0001V16.6668C1.66634 17.1088 1.84194 17.5327 2.1545 17.8453C2.46706 18.1578 2.89098 18.3334 3.33301 18.3334H16.6663C17.1084 18.3334 17.5323 18.1578 17.8449 17.8453C18.1574 17.5327 18.333 17.1088 18.333 16.6668V10.0001H10.833V16.6668H9.16634V10.0001H1.66634Z" fill="#FE5C5C"/>
                                                            </svg>
                                                            @endif
                                                        </div>
                                                        <div>
                                                            <div style="font-weight: 600;line-height: 20px;" class="mr-8 text-[16px] text-dark-primary ">
                                                                {{$redeem->code}}
                                                            </div>
                                                            <div style="font-weight: 400;line-height: 20px" class="text-[16px] text-[#6A6A75]  ">
                                                                Used on {{changeDateFormat($redeem->use_date) . " " . date("H:i", strtotime($redeem->use_date))}}
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="flex items-center gap-[7px] max-w-[240px]">
                                                        @if($redeem->claim->claim_type_id == 1 || ($redeem->claim->claim_type_id == 2 && $redeem->in_store))
                                                        <div>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                <path d="M2.51836 2.43683C2.39769 2.67683 2.33836 2.97416 2.21969 3.5675L1.82102 5.56083C1.76452 5.83261 1.76408 6.11307 1.81974 6.38503C1.87539 6.65698 1.98596 6.91472 2.14468 7.14246C2.3034 7.37021 2.50693 7.56316 2.74282 7.70951C2.9787 7.85586 3.24197 7.95253 3.51651 7.9936C3.79104 8.03467 4.07108 8.01927 4.33946 7.94836C4.60784 7.87744 4.85893 7.7525 5.07735 7.58118C5.29577 7.40985 5.47692 7.19576 5.60973 6.95199C5.74253 6.70822 5.82418 6.43992 5.84969 6.1635L5.89636 5.7035C5.87057 5.99631 5.90621 6.29129 6.00099 6.56954C6.09578 6.84779 6.24762 7.10318 6.4468 7.31936C6.64598 7.53554 6.88811 7.70775 7.15768 7.82495C7.42725 7.94216 7.71833 8.00179 8.01227 8.00002C8.30622 7.99825 8.59655 7.93512 8.86469 7.81467C9.13283 7.69422 9.37286 7.51911 9.56942 7.30054C9.76598 7.08197 9.91474 6.82477 10.0062 6.5454C10.0976 6.26603 10.1297 5.97065 10.1004 5.67816L10.1497 6.1635C10.1752 6.43992 10.2569 6.70822 10.3897 6.95199C10.5225 7.19576 10.7036 7.40985 10.922 7.58118C11.1404 7.7525 11.3915 7.87744 11.6599 7.94836C11.9283 8.01927 12.2083 8.03467 12.4829 7.9936C12.7574 7.95253 13.0207 7.85586 13.2566 7.70951C13.4924 7.56316 13.696 7.37021 13.8547 7.14246C14.0134 6.91472 14.124 6.65698 14.1796 6.38503C14.2353 6.11307 14.2349 5.83261 14.1784 5.56083L13.7797 3.5675C13.661 2.97416 13.6017 2.6775 13.481 2.43683C13.3553 2.18619 13.1783 1.96479 12.9614 1.787C12.7446 1.60921 12.4928 1.479 12.2224 1.40483C11.9624 1.3335 11.6597 1.3335 11.0544 1.3335H4.94502C4.33969 1.3335 4.03702 1.3335 3.77702 1.40483C3.5066 1.479 3.2548 1.60921 3.03796 1.787C2.82112 1.96479 2.64409 2.18619 2.51836 2.43683ZM12.1784 9.00016C12.6995 9.00159 13.2121 8.86816 13.6664 8.61283V9.3335C13.6664 11.8475 13.6664 13.1048 12.885 13.8855C12.2564 14.5148 11.3197 14.6368 9.66636 14.6608V12.3335C9.66636 11.7102 9.66636 11.3988 9.53236 11.1668C9.44459 11.0148 9.31836 10.8886 9.16636 10.8008C8.93436 10.6668 8.62302 10.6668 7.99969 10.6668C7.37636 10.6668 7.06502 10.6668 6.83302 10.8008C6.68102 10.8886 6.55479 11.0148 6.46702 11.1668C6.33302 11.3988 6.33302 11.7102 6.33302 12.3335V14.6608C4.67969 14.6368 3.74302 14.5142 3.11436 13.8855C2.33302 13.1048 2.33302 11.8475 2.33302 9.3335V8.61283C2.7873 8.86816 3.29991 9.00159 3.82102 9.00016C4.59146 9.00071 5.33323 8.70801 5.89569 8.1815C6.46894 8.70954 7.2203 9.0019 7.99969 9.00016C8.77884 9.00166 9.5299 8.70933 10.103 8.1815C10.666 8.70848 11.4086 9.00122 12.1797 9.00016H12.1784Z" fill="#B1B1B1"/>
                                                            </svg>
                                                        </div>
                                                        <div style="font-weight: 400;line-height: 20px;" class="text-[16px] text-[#6A6A75] truncate">
                                                            {{$redeem->store ? $redeem->store->name : "Brand owner"}}
                                                        </div>
                                                        @else
                                                        <div>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                <path d="M6.5 14V10H9.5V14H12.55V8H14.5L8 2L1.5 8H3.45V14H6.5Z" fill="#B1B1B1"/>
                                                            </svg>
                                                        </div>
                                                        <div style="font-weight: 400;line-height: 20px;" class="text-[16px] text-[#6A6A75] truncate">
                                                            {{$redeem->address}}
                                                        </div>
                                                        @endif
                                                    </div>
                                                    <div class="flex items-center no-select justify-between">
                                                        <div class="flex gap-1 items-center py-1 px-2 rounded-full border ">
                                                            <div class="w-[6px] h-[6px] rounded-full {{$redeem->status ? "bg-[#2C9854]" : "bg-[#FE5C5C]"}} ">

                                                            </div>
                                                            <div style="font-weight: 400;line-height: 20px;" class="text-[14px] text-dark-primary ">
                                                                {{$redeem->status ? "Success" : "Not sent"}}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div wire:click="showOptionHistory({{$redeem->id}})" class="w-2-12 cursor-pointer">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path d="M13.875 6.375C13.875 5.34366 13.0313 4.5 12 4.5C10.9687 4.5 10.125 5.34366 10.125 6.375C10.125 7.40634 10.9687 8.25 12 8.25C13.0313 8.25 13.875 7.40634 13.875 6.375ZM13.875 17.625C13.875 16.5937 13.0313 15.75 12 15.75C10.9687 15.75 10.125 16.5937 10.125 17.625C10.125 18.6563 10.9687 19.5 12 19.5C13.0313 19.5 13.875 18.6563 13.875 17.625ZM13.875 12C13.875 10.9687 13.0313 10.125 12 10.125C10.9687 10.125 10.125 10.9687 10.125 12C10.125 13.0313 10.9687 13.875 12 13.875C13.0313 13.875 13.875 13.0313 13.875 12Z" fill="#6A6A75"/>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>

                                <div  x-show="allHistoryRedeemGifts">
                                    @foreach($allHistoryRedeemGifts as $redeem)
                                    <div class="py-3 border-b">
                                        <div>
                                            <div class="flex items-center justify-between">
                                                <div class="w-10/12 flex items-center justify-between">
                                                    <div class="flex items-center mr-8">
                                                        <div class="mr-4 w-10 h-10 flex items-center justify-center {{$redeem->claim->claim_type_id == 1 ? 'bg-[#E5EDFA]' : 'bg-[#FAE4E4]'}}  rounded-full">
                                                            @if($redeem->claim->claim_type_id == 1)
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                <path d="M17.5003 4.16675H2.50033C2.27931 4.16675 2.06735 4.25455 1.91107 4.41083C1.75479 4.56711 1.66699 4.77907 1.66699 5.00008V8.33342H2.41116C3.24116 8.33342 4.01116 8.90091 4.14449 9.72008C4.18511 9.95928 4.17304 10.2045 4.10913 10.4385C4.04522 10.6726 3.931 10.8899 3.77445 11.0752C3.61789 11.2606 3.42278 11.4095 3.20272 11.5117C2.98265 11.6139 2.74295 11.6668 2.50033 11.6667H1.66699V15.0001C1.66699 15.2211 1.75479 15.4331 1.91107 15.5893C2.06735 15.7456 2.27931 15.8334 2.50033 15.8334H17.5003C17.7213 15.8334 17.9333 15.7456 18.0896 15.5893C18.2459 15.4331 18.3337 15.2211 18.3337 15.0001V11.6667H17.5003C17.2577 11.6668 17.018 11.6139 16.7979 11.5117C16.5779 11.4095 16.3828 11.2606 16.2262 11.0752C16.0697 10.8899 15.9554 10.6726 15.8915 10.4385C15.8276 10.2045 15.8155 9.95928 15.8562 9.72008C15.9895 8.90091 16.7595 8.33342 17.5895 8.33342H18.3337V5.00008C18.3337 4.77907 18.2459 4.56711 18.0896 4.41083C17.9333 4.25455 17.7213 4.16675 17.5003 4.16675ZM9.16699 14.1667H7.50033V12.5001H9.16699V14.1667ZM9.16699 10.8334H7.50033V9.16675H9.16699V10.8334ZM9.16699 7.50008H7.50033V5.83341H9.16699V7.50008Z" fill="#3688EF"/>
                                                            </svg>
                                                            @else
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                <path d="M7.54967 1.60843C5.97468 1.6001 4.44134 3.11677 5.14134 5.0001H2.49967C2.05765 5.0001 1.63372 5.17569 1.32116 5.48825C1.0086 5.80082 0.833008 6.22474 0.833008 6.66677V8.33343C0.833008 8.55445 0.920805 8.76641 1.07709 8.92269C1.23337 9.07897 1.44533 9.16677 1.66634 9.16677H9.16634V6.66677H10.833V9.16677H18.333C18.554 9.16677 18.766 9.07897 18.9223 8.92269C19.0785 8.76641 19.1663 8.55445 19.1663 8.33343V6.66677C19.1663 6.22474 18.9907 5.80082 18.6782 5.48825C18.3656 5.17569 17.9417 5.0001 17.4997 5.0001H14.858C15.833 2.2751 12.1663 0.350099 10.4747 2.7001L9.99967 3.33343L9.52468 2.68343C8.99967 1.94177 8.27468 1.61677 7.54967 1.60843ZM7.49967 3.33343C8.24134 3.33343 8.61634 4.23343 8.09134 4.75843C7.56634 5.28343 6.66634 4.90843 6.66634 4.16677C6.66634 3.94575 6.75414 3.73379 6.91042 3.57751C7.0667 3.42123 7.27866 3.33343 7.49967 3.33343ZM12.4997 3.33343C13.2413 3.33343 13.6163 4.23343 13.0913 4.75843C12.5663 5.28343 11.6663 4.90843 11.6663 4.16677C11.6663 3.94575 11.7541 3.73379 11.9104 3.57751C12.0667 3.42123 12.2787 3.33343 12.4997 3.33343ZM1.66634 10.0001V16.6668C1.66634 17.1088 1.84194 17.5327 2.1545 17.8453C2.46706 18.1578 2.89098 18.3334 3.33301 18.3334H16.6663C17.1084 18.3334 17.5323 18.1578 17.8449 17.8453C18.1574 17.5327 18.333 17.1088 18.333 16.6668V10.0001H10.833V16.6668H9.16634V10.0001H1.66634Z" fill="#FE5C5C"/>
                                                            </svg>
                                                            @endif
                                                        </div>
                                                        <div>
                                                            <div style="font-weight: 600;line-height: 20px;" class="mr-8 text-[16px] text-dark-primary ">
                                                                {{$redeem->code}}
                                                            </div>
                                                            <div style="font-weight: 400;line-height: 20px" class="text-[16px] text-[#6A6A75]  ">
                                                                Used on {{changeDateFormat($redeem->use_date) . " " . date("H:i", strtotime($redeem->use_date))}}
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="flex items-center gap-[7px] max-w-[240px]">
                                                        @if($redeem->claim->claim_type_id == 1 || ($redeem->claim->claim_type_id == 2 && $redeem->in_store))
                                                        <div>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                <path d="M2.51836 2.43683C2.39769 2.67683 2.33836 2.97416 2.21969 3.5675L1.82102 5.56083C1.76452 5.83261 1.76408 6.11307 1.81974 6.38503C1.87539 6.65698 1.98596 6.91472 2.14468 7.14246C2.3034 7.37021 2.50693 7.56316 2.74282 7.70951C2.9787 7.85586 3.24197 7.95253 3.51651 7.9936C3.79104 8.03467 4.07108 8.01927 4.33946 7.94836C4.60784 7.87744 4.85893 7.7525 5.07735 7.58118C5.29577 7.40985 5.47692 7.19576 5.60973 6.95199C5.74253 6.70822 5.82418 6.43992 5.84969 6.1635L5.89636 5.7035C5.87057 5.99631 5.90621 6.29129 6.00099 6.56954C6.09578 6.84779 6.24762 7.10318 6.4468 7.31936C6.64598 7.53554 6.88811 7.70775 7.15768 7.82495C7.42725 7.94216 7.71833 8.00179 8.01227 8.00002C8.30622 7.99825 8.59655 7.93512 8.86469 7.81467C9.13283 7.69422 9.37286 7.51911 9.56942 7.30054C9.76598 7.08197 9.91474 6.82477 10.0062 6.5454C10.0976 6.26603 10.1297 5.97065 10.1004 5.67816L10.1497 6.1635C10.1752 6.43992 10.2569 6.70822 10.3897 6.95199C10.5225 7.19576 10.7036 7.40985 10.922 7.58118C11.1404 7.7525 11.3915 7.87744 11.6599 7.94836C11.9283 8.01927 12.2083 8.03467 12.4829 7.9936C12.7574 7.95253 13.0207 7.85586 13.2566 7.70951C13.4924 7.56316 13.696 7.37021 13.8547 7.14246C14.0134 6.91472 14.124 6.65698 14.1796 6.38503C14.2353 6.11307 14.2349 5.83261 14.1784 5.56083L13.7797 3.5675C13.661 2.97416 13.6017 2.6775 13.481 2.43683C13.3553 2.18619 13.1783 1.96479 12.9614 1.787C12.7446 1.60921 12.4928 1.479 12.2224 1.40483C11.9624 1.3335 11.6597 1.3335 11.0544 1.3335H4.94502C4.33969 1.3335 4.03702 1.3335 3.77702 1.40483C3.5066 1.479 3.2548 1.60921 3.03796 1.787C2.82112 1.96479 2.64409 2.18619 2.51836 2.43683ZM12.1784 9.00016C12.6995 9.00159 13.2121 8.86816 13.6664 8.61283V9.3335C13.6664 11.8475 13.6664 13.1048 12.885 13.8855C12.2564 14.5148 11.3197 14.6368 9.66636 14.6608V12.3335C9.66636 11.7102 9.66636 11.3988 9.53236 11.1668C9.44459 11.0148 9.31836 10.8886 9.16636 10.8008C8.93436 10.6668 8.62302 10.6668 7.99969 10.6668C7.37636 10.6668 7.06502 10.6668 6.83302 10.8008C6.68102 10.8886 6.55479 11.0148 6.46702 11.1668C6.33302 11.3988 6.33302 11.7102 6.33302 12.3335V14.6608C4.67969 14.6368 3.74302 14.5142 3.11436 13.8855C2.33302 13.1048 2.33302 11.8475 2.33302 9.3335V8.61283C2.7873 8.86816 3.29991 9.00159 3.82102 9.00016C4.59146 9.00071 5.33323 8.70801 5.89569 8.1815C6.46894 8.70954 7.2203 9.0019 7.99969 9.00016C8.77884 9.00166 9.5299 8.70933 10.103 8.1815C10.666 8.70848 11.4086 9.00122 12.1797 9.00016H12.1784Z" fill="#B1B1B1"/>
                                                            </svg>
                                                        </div>
                                                        <div style="font-weight: 400;line-height: 20px;" class="text-[16px] text-[#6A6A75] truncate">
                                                            {{$redeem->store ? $redeem->store->name : "Pemilik Toko Utama"}}
                                                        </div>
                                                        @else
                                                        <div>
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                <path d="M6.5 14V10H9.5V14H12.55V8H14.5L8 2L1.5 8H3.45V14H6.5Z" fill="#B1B1B1"/>
                                                            </svg>
                                                        </div>
                                                        <div style="font-weight: 400;line-height: 20px;" class="text-[16px] text-[#6A6A75] truncate">
                                                            {{$redeem->address}}
                                                        </div>
                                                        @endif
                                                    </div>
                                                    <div class="flex items-center no-select justify-between">
                                                        <div class="flex gap-1 items-center py-1 px-2 rounded-full border ">
                                                            <div class="w-[6px] h-[6px] rounded-full {{$redeem->status ? "bg-[#2C9854]" : "bg-[#FE5C5C]"}} ">

                                                            </div>
                                                            <div style="font-weight: 400;line-height: 20px;" class="text-[14px] text-dark-primary ">
                                                                {{$redeem->status ? "Success" : "Not sent"}}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div wire:click="showOptionHistory({{$redeem->id}})" class="w-2-12 cursor-pointer">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path d="M13.875 6.375C13.875 5.34366 13.0313 4.5 12 4.5C10.9687 4.5 10.125 5.34366 10.125 6.375C10.125 7.40634 10.9687 8.25 12 8.25C13.0313 8.25 13.875 7.40634 13.875 6.375ZM13.875 17.625C13.875 16.5937 13.0313 15.75 12 15.75C10.9687 15.75 10.125 16.5937 10.125 17.625C10.125 18.6563 10.9687 19.5 12 19.5C13.0313 19.5 13.875 18.6563 13.875 17.625ZM13.875 12C13.875 10.9687 13.0313 10.125 12 10.125C10.9687 10.125 10.125 10.9687 10.125 12C10.125 13.0313 10.9687 13.875 12 13.875C13.0313 13.875 13.875 13.0313 13.875 12Z" fill="#6A6A75"/>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div x-cloak x-show="showRedeemConfirm" x-transition style="z-index:100" class="fixed top-0 left-0  pt-20 w-full min-h-screen bg-black/50 flex justify-center items-center">
            <section @click.outside="showRedeemConfirm=false" class="fixed w-[446px] mb-5 mx-auto my-auto bg-white" style="margin-top: -50px">
                <div class="w-full max-h-[650px] overflow-hidden">
                    <div class="w-full  p-6">
                        <div style="font-weight: 600;font-size:20px" class="mt-5 mb-2 text-[20px]">
                            Redeem {{$redeemConfirm ? $redeemConfirm->code : ''}} ?
                        </div>
                        <div style="font-size:16px" class="text-gray-500 mb-6">
                            By confirming the redeem, it means the customer has successfully received this offer.
                        </div>
                        <div class="flex justify-end items-center">
                            <p x-on:click="showRedeemConfirm = false" style="font-weight: 600;" class="text-[16px] text-primary hover:cursor-pointer hover:opacity-50 duration-150 p-3 mr-[14px]">
                                Cancel
                            </p>
                            <button type="buttom" wire:click="redeem" @click="loading=true;showRedeemConfirm=false;" style="font-weight: 600;" class="text-[16px] bg-primary text-white p-3">
                                Confirm
                            </button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    @if($show_data)
    <div x-show="detailSend" class="fixed inset-0 w-screen h-screen z-50 bg-black bg-opacity-50 flex items-center justify-center">
        <div @click.outside="detailSend=false" class="bg-white h-screen lg:h-auto rounded-sm overflow-auto lg:overflow-hidden lg:flex hide-scrollbar">
            <div class="w-full lg:w-[500px] p-6 lg:border-r border-b lg:border-b-0">
                <div class="w-[450px]">
                    <div class="w-[450px] h-[220px] mb-5 bg-[#F5F7F9] flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="47" height="40" viewBox="0 0 47 40" fill="none">
                            <path d="M41.0128 31.6666V8.33336C41.0128 6.49984 39.2617 5 37.121 5H9.87884C7.73817 5 5.98706 6.49984 5.98706 8.33336V31.6666C5.98706 33.5002 7.73817 35 9.87884 35H37.121C39.2617 35 41.0128 33.5002 41.0128 31.6666ZM16.6893 22.5L21.5541 27.5L28.3646 20L37.121 30H9.87884L16.6893 22.5Z" fill="#DEE3E9"/>
                        </svg>
                    </div>

                    <div class="mb-5">
                        <div style="font-weight: 600;" class="h-6 flex items-center text-[20px] mb-2 truncate">
                            {{$title}}
                        </div>
                        <div style="font-weight: 400;" class="text-[16px] text-[#6A6A75] line-clamp-2">
                            {{$description}}
                        </div>
                    </div>

                    <div>
                        <div class="flex items-center justify-between mb-5">
                            <div style="font-weight: 400;" class="h-5 flex items-center text-[#6A6A75] text-[16px]">
                                Type
                            </div>
                            <div class="flex items-center">
                                @if($show_data->claim_type_id == 1)
                                <div class="flex items-center text-dark-primary">
                                    <div class="h-[28px] w-[28px] bg-[#E5EDFA] rounded-full flex items-center justify-center mr-1">
                                        <img class="w-[14px] h-[14px]" src="{{ asset('src/icons/bxs_coupon.svg') }}" />
                                    </div>
                                    <div class="text-dark-primary">
                                        {{$show_data->claimType->name}}
                                    </div>
                                </div>
                                @else
                                <div class="flex items-center text-dark-primary">
                                    <div class="h-10 w-10 bg-[#FAE4E4] rounded-full flex items-center justify-center mr-1">
                                        <img class="w-[14px] h-[14px]" src="{{ asset('src/icons/mdi_present.svg') }}" />
                                    </div>
                                    <div class="text-dark-primary">
                                        {{$show_data->claimType->name}}
                                    </div>
                                </div>
                                @endif
                            </div>
                        </div>

                        <div class="flex items-center justify-between mb-5">
                            <div style="font-weight: 400;" class="h-5 flex items-center text-[#6A6A75] text-[16px]">
                                Effective Date
                            </div>
                            <div class="flex items-center">
                                <div class="h-5 text-[16px] flex items-center mr-2 text-dark-primary">
                                    {{changeDateFormat($start_date)}} - {{changeDateFormat($end_date)}}
                                </div>
                                <div class="border rounded-full px-2 py-1 flex items-center">
                                    <div class="w-[6px] h-[6px] @if(getStatusClaim(['status' => $status, 'start_date' => $start_date, 'end_date' => $end_date]) == 'Aktif') bg-[#2C9854]  @elseif(getStatusClaim(['status' => $status, 'start_date' => $start_date, 'end_date' => $end_date]) == 'Tidak Aktif') bg-[#EDEDED] @else bg-[#FF8933] @endif mr-1 rounded-full">
                                    </div>
                                    <div style="font-weight: 400;" class="h-5 flex items-center text-[14px] text-dark-primary truncate">
                                        {{ getStatusClaim(['status' => $status, 'start_date' => $start_date, 'end_date' => $end_date]) }}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="flex items-center justify-between mb-5">
                            <div style="font-weight: 400;" class="h-5 flex items-center text-[#6A6A75] text-[16px]">
                                Limit
                            </div>
                            <div class="flex items-center">
                                <div style="font-weight: 400;" class="ml-2 h-5 text-[16px] text-dark-primary">
                                    {{ $limit == 'Unlimited' ? $limit : $limit." X" }}
                                </div>
                            </div>
                        </div>

                        <div class="flex items-center justify-between mb-5">
                            <div style="font-weight: 400;" class="h-5 flex items-center text-[#6A6A75] text-[16px]">
                                Point
                            </div>
                            <div class="flex items-center">
                                <div class="px-2 py-1 border rounded-full flex items-center">
                                    <div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                                            <path d="M10.0042 18.5856C5.40173 18.5856 1.6709 14.8548 1.6709 10.2523C1.6709 5.64978 5.40173 1.91895 10.0042 1.91895C14.6067 1.91895 18.3376 5.64978 18.3376 10.2523C18.3376 14.8548 14.6067 18.5856 10.0042 18.5856ZM10.0042 6.71644L6.4684 10.2523L10.0042 13.7881L13.5392 10.2523L10.0042 6.71644Z" fill="#FFA858"/>
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M10.0041 5.53835L14.7174 10.2528L10.0041 14.9672L5.28964 10.2528L10.0041 5.53835ZM2.50399 10.2528C2.50399 14.395 5.86172 17.7528 10.004 17.7528C14.1462 17.7528 17.504 14.395 17.504 10.2528C17.504 6.1105 14.1462 2.75277 10.004 2.75277C5.86172 2.75277 2.50399 6.1105 2.50399 10.2528ZM6.46815 10.2528L10.004 6.71693L13.539 10.2528L10.004 13.7886L6.46815 10.2528ZM1.67065 10.2528C1.67065 14.8553 5.40149 18.5861 10.004 18.5861C14.6065 18.5861 18.3373 14.8553 18.3373 10.2528C18.3373 5.65027 14.6065 1.91943 10.004 1.91943C5.40149 1.91943 1.67065 5.65027 1.67065 10.2528Z" fill="#DF812B"/>
                                        </svg>
                                    </div>
                                    <div style="font-weight: 400;" class="h-5 text-[14px] ml-1 text-dark-primary">
                                        {{ $exchange_rate }} pts
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="w-full lg:w-6/12 p-6">
                <div class="relative w-full">
                    <input wire:model="searchCustomers" class="w-full lg:w-[412px] h-[44px] py-3 pr-3 pl-9 mb-6 border-gray-300 rounded-sm" placeholder="Cari customer/no hp." />
                    <div class="absolute left-[12px] top-[12px]">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                            <path d="M17.3242 16.4141L13.1523 12.2031C13.9688 11.1797 14.4609 9.88281 14.4609 8.47266C14.4609 5.17188 11.7852 2.49609 8.48047 2.49609C5.17578 2.49609 2.5 5.17578 2.5 8.47656C2.5 11.7773 5.17578 14.4531 8.48047 14.4531C9.91016 14.4531 11.2188 13.9531 12.25 13.1172L16.3945 17.3008C16.5195 17.4336 16.6914 17.5 16.8594 17.5C17.0195 17.5 17.1797 17.4414 17.3008 17.3242C17.5586 17.0781 17.5664 16.6719 17.3242 16.4141ZM8.48047 13.168C7.22656 13.168 6.04688 12.6797 5.16016 11.793C4.27344 10.9062 3.78516 9.72656 3.78516 8.47656C3.78516 7.22266 4.27344 6.04297 5.16016 5.16016C6.04688 4.27344 7.22656 3.78516 8.48047 3.78516C9.73438 3.78516 10.9141 4.27344 11.8008 5.16016C12.6875 6.04688 13.1758 7.22656 13.1758 8.47656C13.1758 9.73047 12.6875 10.9102 11.8008 11.793C10.9141 12.6797 9.73438 13.168 8.48047 13.168Z" fill="#6A6A75"/>
                        </svg>
                    </div>
                </div>
                <div class="max-h-[546px] lg:h-[546px] overflow-auto hide-scrollbar mb-6">
                    @foreach ($listCustomers as $index => $customer)
                    <div class="px-3 py-4 border-b flex items-center justify-between">
                        <div class="flex items-center">
                            <div class="w-[40px] h-[40px] flex items-center justify-center rounded-full bg-[#E5EDFA] mr-2">
                                {{ generateInitials($customer->name) }}
                            </div>
                            <div>
                                <div class="text-[18px] h-6 flex items-center mb-[2px] text-dark-primary " style="font-weight: 600;">
                                    {{$customer->name}}
                                </div>
                                <div style="font-weight: 400;" class="h-5 flex items-center text-[#6A6A75]   text-[16px]">
                                    {{$customer->phone_number}}
                                </div>
                            </div>
                        </div>
                        <div class="p-3 flex items-center justify-center">
                            <div wire:click="selectedCustomer({{$customer->id}})" class="no-select cursor-pointer rounded-sm border p-[2px] {{in_array($customer->id, $selectedCustomers) ? 'bg-primary' : 'h-[16px] w-[16px]' }}">
                                @if(in_array($customer->id, $selectedCustomers))
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
                                    <path d="M4.36643 7.96624L2.25 5.84674L1.5 6.56175L4.36643 9.42188L10.5 3.29311L9.75 2.57812L4.36643 7.96624Z" fill="white"/>
                                </svg>
                                @endif
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                <div class="flex items-center">
                    <div @click="detailSend=false" style="font-weight: 600;" class="w-6/12 flex items-center justify-center text-primary text-[16px] mr-6 no-select cursor-pointer">
                        Cancel
                    </div>
                    <div wire:click="sendClaim" class="w-6/12 h-[44px] flex items-center justify-center p-3 bg-primary rounded-sm no-select cursor-pointer">
                        <div class="mr-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
                                <path d="M17.5274 2.53505L3.18757 8.78505C2.93366 8.90615 2.94148 9.26943 3.19929 9.38271L7.07819 11.5741C7.30866 11.703 7.59382 11.6757 7.79304 11.5038L15.4415 4.91005C15.4923 4.86708 15.6133 4.78505 15.6602 4.83193C15.711 4.88271 15.6329 4.9999 15.5899 5.05068L8.97273 12.5038C8.78913 12.7108 8.76179 13.0155 8.91023 13.2499L11.4454 17.3163C11.5704 17.5624 11.9258 17.5585 12.0391 17.3085L17.9688 2.96865C18.0977 2.6874 17.8048 2.40224 17.5274 2.53505Z" fill="white"/>
                            </svg>
                        </div>
                        <div style="font-weight: 600;" class="h-5 flex items-center text-white text-[16px]">
                            Send now
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif
    <div id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" class="hidden fixed w-screen h-screen top-0 left-0 right-0 bottom-0" style="z-index: 200">
        <div class="absolute top-0 left-0 right-0 bottom-0 flex w-screen h-screen justify-center items-center bg-black bg-opacity-70">
            <div class="modal fade p-10 rounded-lg justify-center items-center w-[500px] h-fit bg-white" style="z-index: 200">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true" class="text-[20px]">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="img-container">
                                <div class="row">
                                    <div class="col-md-8">
                                        <img id="image" class="w-[400px]">
                                    </div>
                                    <div class="col-md-4">
                                        <div class="preview"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="w-full flex gap-2 items-center justify-end mt-5">
                            <button type="button" style=" --tw-bg-opacity: 1;background-color: rgb(248 113 113 / var(--tw-bg-opacity)); color:white;" class="px-3 py-2 bg-red-400 rounded-lg text-white" data-dismiss="modal">Cancel</button>
                            <button type="button" style=" --tw-bg-opacity: 1;background-color: rgb(74 222 128 / var(--tw-bg-opacity)); color:white;" class="px-3 py-2 bg-green-400 rounded-lg text-white" id="crop">Crop</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function changeToInteger(field){
            field.value = field.value.replace(/\D/g, "");
        }
    </script>
    <script src="{{ asset('src/js/scrollToTop.js') }}"></script>
    <script src="{{ asset('src/js/selectStore.js') }}"></script>
    <script src="{{ asset('src/js/cropperJS.js') }}"></script>
</div>
