<div class="w-full relative" x-data="{open:false, loading:false}" x-init="

$wire.on('showForm', value => {
    open=value;
});
$wire.on('showLoading', value => {
    loading=value;
});
">
    <div x-cloak x-show="loading">
        <x-layouts.loading/>
    </div>
    <div class="w-full min-h-screen">
        <div class="w-full pr-12 pl-5 flex flex-col justify-center items-center">
            <div class="font-bold text-[20px]">
                Cashier page
            </div>
            <div class="w-full mt-10 overflow-auto max-w-[1000px]">
                @foreach ($points as $index=>$point)
                <div class="w-full min-w-[600px] max-w-[1000px] flex items-center justify-between py-3 px-5 {{$index%2 == 1 ? 'bg-[#F5F7F9]' : ''}}">
                    <div class="flex items-center">
                        <div class="truncate mr-4 max-w-[100px] lg:max-w-[200px]">
                            <div style="font-weight:600" class="text-[16px] mb-1 truncate {{$index%2 == 1 ? 'text-dark-primary' : 'text-dark-primary dark:text-white'}} ">
                                {{changeDateFormat($point->created_at) . " " . date("H:i", strtotime($point->created_at))}}
                            </div>
                            <div style="font-weight: 400;" class="text-[16px] {{$index%2 == 1 ? 'text-gray-500' : 'text-gray-500 dark:text-white dark:text-opacity-70'}}  truncate">
                                {{ $point->user->name }}
                            </div>
                        </div>
                        <div>
                            <div style="font-weight: 400;" class="line-clamp-2 mx-4 text-[16px] max-w-[500px] {{$index%2 == 1 ? 'text-dark-primary' : 'text-dark-primary dark:text-white'}}">
                                {{$point->description}}
                            </div>
                            <div style="font-weight: 400;" class="line-clamp-2 mx-4 text-[16px] max-w-[500px] {{$index%2 == 1 ? 'text-dark-primary' : 'text-dark-primary dark:text-white'}}">
                                {{$point->nominal}}
                            </div>
                        </div>
                        <div>
                            <img src="{{ asset('storage/'.$point->image) }}" style="max-height: 120px" class=" cursor-pointer" alt="">
                        </div>
                    </div>
                    <div class="flex items-center gap-3 justify-center">
                        <div style="font-weight: 400;margin-top:-15px" class="h-[28px] bg-white text-[14px] px-2 py-1 border-2 border-gray-500 rounded-[39px] flex items-center justify-center overflow-hidden">
                            <div class=" flex items-center justify-center">
                                <div class="w-[24px] h-[24px]">
                                    <img class="w-[24px] h-[24px]" src="{{ asset('src/icons/ri_copper-coin-fill.svg') }}" alt="he" />
                                </div>
                                <div style="font-weight: 400;font-size: 12px;">
                                    {{$point->point}}pts
                                </div>
                            </div>
                        </div>

                        <div wire:click="openPoint({{ $point->id }})" class="px-3 py-2 bg-green-600 rounded-md text-white cursor-pointer no-select">
                            Confirm
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>

    <div x-transition x-show="open" x-cloak style="z-index:150" class="fixed flex top-0 left-0  pt-20 w-full min-h-screen bg-black/50 justify-center items-center">
        <section @click.outside="open=false" class="fixed lg:w-[446px] mb-5 mx-auto my-0 bg-white" style="margin-top: -50px;z-index:150">
            <form>
                <div class="w-full max-h-[650px] overflow-hidden">
                    <div style="max-height: 400px" class="p-6 border-b">
                        <table class="w-full text-left ">
                            <tr class=" border-b-2 mb-2">
                              <th>Name</th>
                              <td class="max-w-[200px] truncate">{{ $openPoint ? $openPoint->user->name : "" }}</td>
                            </tr>
                            <tr class=" border-b-2 mb-2">
                                <th>Points</th>
                                <td class="max-w-[200px] truncate">{{ $openPoint ? $openPoint->point : '' }}</td>
                            </tr>
                            <tr class=" border-b-2 mb-2">
                                <th>Description</th>
                                <td class="max-w-[200px] line-clamp-3">{{ $openPoint ? $openPoint->note : "" }}</td>
                            </tr>
                            <tr class=" border-b-2 mb-2">
                                <th>Image</th>
                                <?php
                                $image = $openPoint ? $openPoint->image : '';
                                ?>
                                <td><img src="{{ asset('storage/'.$image) }}" style="max-height: 80px" class=" cursor-pointer" alt=""></td>
                            </tr>
                            <tr>
                                <th>Point Giver</th>
                                @if($openPoint)
                                <td>@if($openPoint->sales_id == 0 && $openPoint->store_id == 0)Brand owner @elseif($openPoint->sales_id > 0){{ $openPoint->sales->name }} @else {{ $openPoint->store->name }} @endif</td>
                                @endif
                            </tr>
                          </table>
                    </div>
                    <div class="w-full px-6 py-3">
                        <div class="flex justify-end items-center">
                            <p x-on:click="open = false" style="font-weight: 600;" class="text-[16px] text-primary hover:cursor-pointer hover:opacity-50 duration-150 p-3 mr-[14px]">
                                Cancel
                            </p>
                            <button wire:click="acceptPoint" @click="loading=true" type="button" style="font-weight: 600;"  class="submit-button text-[16px] bg-primary cursor-pointer text-white p-3 rounded-sm">
                                Submit
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </section>
    </div>
</div>
