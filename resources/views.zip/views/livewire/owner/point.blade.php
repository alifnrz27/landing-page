<div class="w-full relative">
    <style>

        @keyframes marquee {
        0% {
            transform: translateX(0%);
        }
        100% {
            transform: translateX(-100%);
        }
        }
        .marquee {
            animation: marquee 2s linear infinite; /* Adjust the duration (10s) as needed */
        }
    </style>
    <div class="w-full lg:flex" x-data="{open:false, loading:false, notification:false, scanBarcode:{{ $scanBarcode ? $scanBarcode : 'false' }}, removeImage(){
        var preview = document.getElementById('image-preview');
        var pointImage = document.getElementById('point-image');
        var addButton = document.getElementById('add-button');
        pointImage.src = '';
        preview.style.display = 'none';
        addButton.style.display = 'block';
        },
        openForm(state){
            if(state == 'open'){
                document.getElementById('pointForm').classList.add('flex')
                document.getElementById('pointForm').classList.remove('hidden')
            }else{
                document.getElementById('pointForm').classList.remove('flex')
                document.getElementById('pointForm').classList.add('hidden')
            }

        },
        sendData(detailCustomerId, detailCustomerTotalPoint, maxPoint, totalPointUser) {
            document.getElementById('loading').classList.add('block')
            document.getElementById('loading').classList.remove('hidden')
            // Mengambil data dari elemen-elemen form
            var point = document.getElementById('total-point').innerHTML;
            var formData = new FormData(document.getElementById('point-form'));
             formData.append('role_id', {{ auth()->user()->role_id }});
             formData.append('user_id', {{ auth()->user()->id }});
             formData.append('detailCustomerId', detailCustomerId);
             formData.append('detailCustomerTotalPoint', detailCustomerTotalPoint);
             formData.append('maxPoint', maxPoint);
             formData.append('totalPointUser', totalPointUser);
             formData.append('point', point);
            // Lakukan permintaan AJAX ke server
            $.ajax({
               url: '{{ route('owner.point.submit') }}', // Ganti dengan URL tujuan Anda
               method: 'POST', // Sesuaikan dengan metode HTTP yang Anda gunakan
               data: formData,
               processData: false,
               contentType: false,
               success: function(response) {
                  // Berhasil mengirim data, lakukan tindakan selanjutnya
                  if (response && response.error) {
                     if(response.error['image']){
                         document.getElementById('image-error').innerHTML = response.error['image'][0];
                     }
                     if(response.error['nominal']){
                         document.getElementById('nominal-error').innerHTML = response.error['nominal'][0];
                     }
                     if(response.error['note']){
                         document.getElementById('note-error').innerHTML = response.error['note'][0];
                     }
                    document.getElementById('loading').classList.remove('block')
                    document.getElementById('loading').classList.add('hidden')
                 }
                 else{


                    document.getElementById('nominal').value = '';
                    document.getElementById('note').value = '';
                    document.getElementById('MyImage').value = '';
                    document.getElementById('pointForm').classList.remove('flex')
                    document.getElementById('pointForm').classList.add('hidden')
                    document.getElementById('notification').classList.add('flex')
                    document.getElementById('notification').classList.remove('hidden')
                    document.getElementById('loading').classList.remove('block')
                    document.getElementById('loading').classList.add('hidden')
                    setTimeout(function() {
                        document.getElementById('notification').classList.remove('flex')
                        document.getElementById('notification').classList.add('hidden')
                        $wire.openCustomer(response.user_id);
                    }, 2000);

                 }
               },
               error: function(xhr, status, error) {
                  // Terjadi kesalahan, tindakan penanganan kesalahan
                  console.error(error);
               }
            });
         }
}" x-init="

            if(scanBarcode){
                open=true;
            }
            $wire.on('showForm', value => {
                open=false;
                scrollToTop();
            });
            $wire.on('showLoader', value => {
                loading=false;
                scrollToTop();
            });
            $wire.on('updatePoint', value => {
                document.getElementById('total-point').innerHTML  = value;
            });
            $wire.on('showNotification', value => {
                document.getElementById('notification').classList.add('flex')
                document.getElementById('notification').classList.remove('hidden')
                setTimeout(function() {
                    document.getElementById('notification').classList.remove('flex')
                    document.getElementById('notification').classList.add('hidden')
                }, 2000);
            })

        " @keydown.window.escape="$wire.deleteDetail">

        <div id="loading" class="hidden">
            <x-layouts.loading/>
        </div>

        <div id="notification" class="w-full hidden bg-green-500 h-10 items-center px-12 absolute top-0">
            <div class="w-full">
                <div class="relative justify-center items-center flex">
                    <div style="font-weight: 600;" class="text-[16px] text-white">
                        🎉 Point added successfully
                    </div>
                    <div @click="notification=false" class="absolute right-0 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.0594 11.9996L16.2563 8.80273C16.5469 8.51211 16.5469 8.03398 16.2563 7.74336C15.9656 7.45273 15.4875 7.45273 15.1969 7.74336L12 10.9402L8.80313 7.74336C8.5125 7.45273 8.03437 7.45273 7.74375 7.74336C7.59844 7.88867 7.52344 8.08086 7.52344 8.27305C7.52344 8.46523 7.59844 8.65742 7.74375 8.80273L10.9406 11.9996L7.74375 15.1965C7.59844 15.3418 7.52344 15.534 7.52344 15.7262C7.52344 15.9184 7.59844 16.1105 7.74375 16.2559C8.03437 16.5465 8.5125 16.5465 8.80313 16.2559L12 13.059L15.1969 16.2559C15.4875 16.5465 15.9656 16.5465 16.2563 16.2559C16.5469 15.9652 16.5469 15.4871 16.2563 15.1965L13.0594 11.9996Z" fill="white"/>
                        </svg>
                    </div>
                </div>
            </div>
        </div>

        <div class="{{$detailCustomer ? 'hidden lg:block lg:w-4/12' :'w-full lg:w-4/12'}} py-10 px-12 border-r">
            <div style="font-weight: 700;" class="text-[32px] mb-2 text-dark-primary">
                Point
            </div>
            <div style="font-weight: 400;" class="text-[16px] text-gray-500 mb-12">
                Halaman page is to show list of customers and points.
            </div>
            <div class="relative w-full bg-red-300 mb-6">
                <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                    <!-- Add your icon here -->
                    <img src="{{ asset('src/icons/ios-search.svg') }}" />
                </span>
                <input class="w-full h-full rounded-sm text-[16px]" wire:model="search" placeholder="Find customer / phone number...." style="padding-left:38px;border-radius: var(--corner-radius-corner-xs, 2px);" />
            </div>

            <div class="w-full max-h-[430px] overflow-y-auto pr-5">
                @foreach ($customers as $customer)
                <div wire:click="openCustomer({{$customer->id}})" class="w-full flex justify-between border-b pb-4 pt-4 cursor-pointer">
                    <div class="w-full flex items-center justify-between">
                        <div class="w-1/12 relative mr-5">
                            @if(auth()->user()->image_path)
                            <img @click="open=true" class="w-[28px] h-[28px] rounded-full hover:cursor-pointer hover:scale-105 shadow-md hover:shadow-lg" src="{{asset('src/img/background/astronaut.jpg')}}" />
                            @else
                            <div @click="open=true" style="font-weight: 600;background-color:#{{generateRandomHexColor()}};-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;" class="w-[40px] h-[40px] rounded-full text-[13px] text-center flex justify-center items-center text-white hover:cursor-pointer">
                                {{ generateInitials($customer->name) }}
                            </div>
                            @endif
                        </div>
                        <div class="w-8/12 ml-2">
                            <div style="font-weight: 600;font-size:18px" class="flex justify-between">
                                <div class="w-full truncate text-dark-primary">
                                    {{$customer->name}}
                                </div>
                            </div>
                            <div class="text-[14px] flex items-center">
                                <div style="font-weight: 400;" class="pt-[2px] ml-[2px] text-[16px] text-gray-500 line-clamp-1">
                                    {{$customer->phone_number}}
                                </div>
                            </div>
                        </div>

                        <div class="w-2/12">
                            @if(auth()->user()->role_id == 2 || auth()->user()->role_id == 3)
                            <div style="font-weight: 400;" class="w-[74px] h-[28px] text-[14px] px-2 py-1 border-2 border-gray-500 rounded-[39px] flex items-center justify-center overflow-hidden">
                                <div class=" flex items-center justify-center">
                                    <div class="mr-1 w-[20px] h-[20px]">
                                        <img class="w-[20px] h-[20px]" src="{{ asset('src/icons/ri_copper-coin-fill.svg') }}" alt="he" />
                                    </div>
                                    <div style="font-weight: 400;font-size: 12px;" class="text-dark-primary">
                                        {{$customer->total_point}}pts
                                    </div>
                                </div>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>

        <div class="{{ $detailCustomer ? 'lg:block lg:w-8/12' : 'hidden lg:block lg:w-8/12' }} min-h-screen">
            @if($detailCustomer)
            <div class="px-5 py-[18px] border-b">
                <div wire:click="deleteDetail" class="flex cursor-pointer">
                    <div class="mr-4">
                        <img src="{{ asset('src/icons/line-md_arrow-close-left.svg') }}" />
                    </div>
                    <div style="font-weight: 600;" class="text-[16px] text-dark-primary">
                        Back
                    </div>
                </div>
            </div>


            <div class="px-5 py-10">
                <div class="w-full">
                    <div class="w-full flex justify-between border-b pb-10">
                        <div class="w-full flex items-center justify-between">
                            <div class="w-10/12 pr-3 flex items-center gap-3">
                                <div class=" relative justify-center">
                                    @if(auth()->user()->image_path)
                                    <img @click="open=true" class="w-[68px] h-[68px] rounded-full hover:cursor-pointer hover:scale-105 shadow-md hover:shadow-lg" src="{{asset('src/img/background/astronaut.jpg')}}" />
                                    @else
                                    <div @click="open=true" style="font-weight: 600;background-color:#{{generateRandomHexColor()}};-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;" class="w-[68px] h-[68px] rounded-full text-[13px] text-center flex justify-center items-center text-white hover:cursor-pointer">
                                        {{generateInitials($detailCustomer->name)}}
                                    </div>
                                    @endif
                                    <div style="font-weight: 400;margin-top:-15px" class="absolute w-[70px] h-[28px] bg-white text-[14px] px-2 py-1 border-2 border-gray-500 rounded-[39px] flex items-center justify-center overflow-hidden">
                                        <div class=" flex items-center justify-center">
                                            <div class="w-[24px] h-[24px]">
                                                <img class="w-[24px] h-[24px]" src="{{ asset('src/icons/ri_copper-coin-fill.svg') }}" alt="he" />
                                            </div>
                                            <div style="font-weight: 400;font-size: 12px;">
                                                {{ $detailCustomer->total_point }}pts
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=" relative truncate">
                                    <div style="font-weight: 700" class="flex text-[24px] lg:text-[32px] justify-between truncate">
                                        <div class="w-full truncate line-clamp-1 text-dark-primary">
                                            {{$detailCustomer->name}}
                                        </div>
                                    </div>
                                    <div class="text-[14px] flex items-center">
                                        <div style="font-weight: 600;" class="pt-[2px] ml-[2px] text-[18px] text-gray-500 line-clamp-1">
                                            {{$detailCustomer->phone_number}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="w-2/12">
                                <button @click="openForm('open')" type="button" style="font-weight: 600;" class="flex text-white text-[16px] bg-primary p-3 rounded-sm">
                                    <div class="mr-1">
                                        +
                                    </div>
                                    <div class="hidden xl:block">
                                        Add new
                                    </div>
                                </button>
                                <div x-transition id="pointForm" style="z-index:150" class="hidden fixed top-0 left-0  pt-20 w-full min-h-screen bg-black/50 justify-center items-center">
                                    <section class="fixed lg:w-[446px] mb-5 mx-auto my-0 bg-white" style="margin-top: -50px;z-index:150">
                                        <form id="point-form">
                                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                            <div class="w-full max-h-[650px] overflow-hidden">
                                                <div class="flex px-5 py-[18px] border-b">
                                                    <div @click="openForm('close')" class="mr-4 cursor-pointer">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                            <path d="M13.0594 11.9996L16.2563 8.80273C16.5469 8.51211 16.5469 8.03398 16.2563 7.74336C15.9656 7.45273 15.4875 7.45273 15.1969 7.74336L12 10.9402L8.80313 7.74336C8.5125 7.45273 8.03437 7.45273 7.74375 7.74336C7.59844 7.88867 7.52344 8.08086 7.52344 8.27305C7.52344 8.46523 7.59844 8.65742 7.74375 8.80273L10.9406 11.9996L7.74375 15.1965C7.59844 15.3418 7.52344 15.534 7.52344 15.7262C7.52344 15.9184 7.59844 16.1105 7.74375 16.2559C8.03437 16.5465 8.5125 16.5465 8.80313 16.2559L12 13.059L15.1969 16.2559C15.4875 16.5465 15.9656 16.5465 16.2563 16.2559C16.5469 15.9652 16.5469 15.4871 16.2563 15.1965L13.0594 11.9996Z" fill="#B1B1B1"/>
                                                        </svg>
                                                    </div>
                                                    <div style="font-weight: 600;" class="text-[16px] text-dark-primary">
                                                        Add point
                                                    </div>
                                                </div>
                                                <div style="max-height: 400px" class="p-6 border-b overflow-auto">
                                                    <div class="flex items-center justify-between">
                                                        <div class="w-9/12">
                                                            <input class="w-full rounded-sm" id="nominal" name="nominal" onclick="selectAllText(this)" oninput="formatRupiah(this, {{$brand->total_shopping/$brand->point}}, {{ $maxPoint ? $maxPoint['max_point'] : 0 }}, {{ $totalPointUser }})" placeholder="Price" />
                                                        </div>
                                                        <div class="px-2 py-1 rounded-full border flex items-center">
                                                            <div class="mr-1">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                                    <path d="M10.0042 18.3356C5.40167 18.3356 1.67084 14.6048 1.67084 10.0023C1.67084 5.39978 5.40167 1.66895 10.0042 1.66895C14.6067 1.66895 18.3375 5.39978 18.3375 10.0023C18.3375 14.6048 14.6067 18.3356 10.0042 18.3356ZM10.0042 6.46644L6.46834 10.0023L10.0042 13.5381L13.5392 10.0023L10.0042 6.46644Z" fill="#FFA858"/>
                                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M10.0041 5.28786L14.7174 10.0023L10.0041 14.7167L5.2897 10.0023L10.0041 5.28786ZM2.50405 10.0023C2.50405 14.1445 5.86179 17.5023 10.004 17.5023C14.1463 17.5023 17.504 14.1445 17.504 10.0023C17.504 5.86002 14.1463 2.50228 10.004 2.50228C5.86179 2.50228 2.50405 5.86002 2.50405 10.0023ZM6.46821 10.0023L10.004 6.46644L13.539 10.0023L10.004 13.5381L6.46821 10.0023ZM1.67072 10.0023C1.67072 14.6048 5.40155 18.3356 10.004 18.3356C14.6065 18.3356 18.3374 14.6048 18.3374 10.0023C18.3374 5.39978 14.6065 1.66895 10.004 1.66895C5.40155 1.66895 1.67072 5.39978 1.67072 10.0023Z" fill="#DF812B"/>
                                                                </svg>
                                                            </div>
                                                            <div class="h-5 flex items-center text-[14px] text-dark-primary" style="font-weight: 400;">
                                                                <span id="total-point">0</span> pts
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="relative">
                                                        <p id="nominal-error" class="absolute text-sm text-red-600"></p>
                                                    </div>

                                                    <div class="w-full mt-6">
                                                        <textarea name="note" id="note" name="note" class="w-full h-[124px] rounded-sm" ></textarea>
                                                    </div>
                                                    <div class="relative">
                                                        <p id="note-error" class="absolute text-sm text-red-600"></p>
                                                    </div>

                                                    <label class="p-3 flex items-center mt-3">
                                                        Upload image
                                                    </label>
                                                    <div class="flex items-center mt-2">
                                                        {{-- @if($image) --}}
                                                        <div id="image-preview" style="display: none" class="relative w-fit">
                                                            <img id="point-image" class= "w-[150px]" alt="Uploaded Image">
                                                            <div @click="removeImage()" class="absolute top-1 right-1 items-start p-1 text-white cursor-pointer rounded-full bg-black opacity-50">
                                                                x
                                                            </div>
                                                        </div>
                                                        {{-- @else --}}
                                                        <label id="add-button" for="MyImage" class="p-3 border flex items-center justify-center rounded-lg bg-white cursor-pointer">
                                                            <img src="{{ asset('src/icons/plus.png') }}" class="w-5" alt="">
                                                        </label>
                                                        {{-- @endif --}}
                                                        <input type="file" name="image" id="MyImage" class="hidden">
                                                    </div>

                                                        <p id="image-error" class="absolute text-sm text-red-600"></p>
                                                </div>
                                                <div class="w-full px-6 py-3">
                                                    <div class="flex justify-end items-center">
                                                        <p @click="openForm('close')" style="font-weight: 600;" class="text-[16px] text-primary hover:cursor-pointer hover:opacity-50 duration-150 p-3 mr-[14px]">
                                                            Cancel
                                                        </p>
                                                        <button type="button" id="submit-button" style="font-weight: 600;" @click="sendData({{ $detailCustomer ? $detailCustomer->id : '' }}, {{ $detailCustomer ? $detailCustomer->total_point : 0 }}, {{ $maxPoint ? $maxPoint['max_point'] : 0 }}, {{ $totalPointUser }})" class="submit-button text-[16px] bg-primary cursor-pointer text-white p-3 rounded-sm">
                                                            Submit
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>

                                        <script>
                                            document.getElementById('MyImage').addEventListener('change', function (e) {
                                                var preview = document.getElementById('image-preview');
                                                var pointImage = document.getElementById('point-image');
                                                var addButton = document.getElementById('add-button');
                                                pointImage.src = URL.createObjectURL(e.target.files[0]);
                                                preview.style.display = 'block';
                                                addButton.style.display = 'none';
                                            });
                                        </script>

                                    </section>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="w-full pr-12 pl-5">
                <div class="w-full lg:flex justify-between">
                    <div style="font-weight: 600;" class="text-[18px] lg:w-3/12 mb-3 text-dark-primary">
                        Point history
                    </div>
                    <div class="w-12/12 lg:w-6/12 lg:flex justify-end gap-3 items-center">
                        <div class="mb-3 lg:mb-0">
                            <select wire:model="orderDetail" x-on:change="$wire.changeOrderDetail" class="w-[120px] lg:w-[124px] h-[44px] text-[12px]">
                                <option value="desc" style="font-weight: 400;" class="text-[12px]">Latest</option>
                                <option value="asc" style="font-weight: 400;" class="text-[12px]">Oldest</option>
                            </select>
                        </div>
                        <div class="mb-3 lg:mb-0">
                            <select wire:model="storeDetail" x-on:change="$wire.changeOrderDetail" class="w-[120px] lg:w-[124px] h-[44px] text-[12px]">
                                <option value="0" style="font-weight: 400;" class="text-[12px]">All store</option>
                                @foreach ($listStores as $store)
                                    <option value="{{$store['id']}}" style="font-weight: 400;" class="text-[12px]">{{ $store->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <a href="{{route('owner.pdf', ['data' => encrypt(['user_id' => $detailCustomer->id])])}}" target="_blank" class="mb-3 lg:mb-0">
                            <button class="flex border p-3">
                                <div class="mr-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <path d="M5 9.6875V17.5C5 17.8438 5.28125 18.125 5.625 18.125H14.375C14.7188 18.125 15 17.8438 15 17.5V9.6875C15 9.34375 14.7188 9.0625 14.375 9.0625H5.625C5.28125 9.0625 5 9.34375 5 9.6875ZM15 1.875H5C4.65625 1.875 4.375 2.15625 4.375 2.5V3.28125C4.375 3.36719 4.44531 3.4375 4.53125 3.4375H15.4688C15.5547 3.4375 15.625 3.36719 15.625 3.28125V2.5C15.625 2.15625 15.3438 1.875 15 1.875Z" fill="#3688EF"/>
                                        <path d="M16.8945 4.375H3.14453C2.45703 4.375 1.875 4.91406 1.875 5.59766V12.4102C1.875 13.0938 2.45703 13.6719 3.14453 13.6719H3.75C3.92188 13.6719 4.0625 13.5312 4.0625 13.3594V9.21875C4.0625 8.61328 4.55078 8.125 5.15625 8.125H14.8438C15.4492 8.125 15.9375 8.61328 15.9375 9.21875V13.3594C15.9375 13.5312 16.0781 13.6719 16.25 13.6719H16.8945C17.582 13.6719 18.125 13.0938 18.125 12.4102V5.59766C18.125 4.91406 17.582 4.375 16.8945 4.375Z" fill="#3688EF"/>
                                    </svg>
                                </div>
                                <div style="font-weight: 600;" class="text-[12px] lg:text-[16px] text-primary truncate">
                                    Print history
                                </div>
                            </button>
                        </a>
                    </div>
                </div>

                <div class="w-full mt-10 max-h-[400px] overflow-auto">
                    @foreach ($points as $index=>$point)
                    <div class="w-full min-w-[600px] max-w-[1000px] flex items-center justify-between py-3 px-5 {{$index%2 == 1 ? 'bg-[#F5F7F9]' : ''}}">
                        <div class="flex items-center">
                            <div class="mr-2">
                                <img src="{{ $point->is_income_point==1 ? asset('src/icons/up.png') : asset('src/icons/down.png') }}" class="w-[40px]" alt="">
                            </div>
                            <div class="truncate mr-4 max-w-[100px] lg:max-w-[200px]">
                                <div style="font-weight:600" class="text-[16px] mb-1 truncate {{$index%2 == 1 ? 'text-dark-primary' : 'text-dark-primary dark:text-white'}} ">
                                    {{changeDateFormat($point->created_at) . " " . date("H:i", strtotime($point->created_at))}}
                                </div>
                                @if($point->points)
                                <div style="font-weight: 400;" class="text-[16px] {{$index%2 == 1 ? 'text-gray-500' : 'text-gray-500 dark:text-white dark:text-opacity-70'}}  truncate">
                                    @if($point->points->sales_id == 0 && $point->points->store_id == 0)Brand Owner @elseif($point->points->sales_id > 0){{ $point->points->sales->name }} @else {{ $point->points->store->name }} @endif
                                </div>
                                @endif
                            </div>
                            <div>
                                <div style="font-weight: 400;" class="line-clamp-2 mx-4 text-[16px] max-w-[500px] {{$index%2 == 1 ? 'text-dark-primary' : 'text-dark-primary dark:text-white'}}">
                                    {{$point->description}}
                                </div>
                                @if($point->points)
                                <div style="font-weight: 400;" class="line-clamp-2 mx-4 text-[16px] max-w-[500px] {{$index%2 == 1 ? 'text-dark-primary' : 'text-dark-primary dark:text-white'}}">
                                    {{$point->points ? $point->points->nominal : "-"}}
                                </div>
                                @endif
                            </div>
                            @if($point->points)
                            <div wire:click="showImage('{{ asset('storage/'.$point->points->image) }}')">
                                <img src="{{ asset('storage/'.$point->points->image) }}" style="max-height: 120px" class=" cursor-pointer" alt="">
                            </div>
                            @endif
                        </div>
                        <div class="flex items-center">
                            <div style="font-weight: 400;margin-top:-15px" class="h-[28px] bg-white text-[14px] px-2 py-1 border-2 border-gray-500 rounded-[39px] flex items-center justify-center overflow-hidden">
                                <div class=" flex items-center justify-center">
                                    <div class="w-[24px] h-[24px]">
                                        <img class="w-[24px] h-[24px]" src="{{ asset('src/icons/ri_copper-coin-fill.svg') }}" />
                                    </div>
                                    <div style="font-weight: 400;font-size: 12px;">
                                        {{$point->point}}pts
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
            @endif
        </div>
        @if($showImage)
        <div class="absolute top-0 left-0 right-0 bottom-0 bg-black bg-opacity-70 flex items-center justify-center">
            <div class="w-full h-full relative flex items-center justify-center">
                <img @click.outside="$wire.deleteShowImage" src="{{ $showImage }}" class="w-[350px]" alt="">
                <div class="absolute w-5 h-5 flex items-center justify-center bg-gray-500 top-5 right-5 rounded-full cursor-pointer no-select">
                    x
                </div>
            </div>
        </div>
        @endif
    </div>



    <script>
        function formatRupiah(input, valuePoint=0, maxPoint = 0, totalPoint = 0) {
            calculatePoint(input, valuePoint);
            // Menghapus semua karakter selain angka
            let value = input.value.replace(/\D/g, '');

            // var point = document.getElementById('total-point').innerHTML;
            // if(maxPoint >= 0){
            //     if(totalPoint + point > maxPoint){
            //         document.getElementById('submit-button').disabled = true;
            //         document.getElementById('submit-button').classList.add('bg-gray-500', 'cursor-not-allowed');
            //         document.getElementById('submit-button').classList.remove('bg-primary', 'cursor-pointer');

            //     }
            // }else{
            //     document.getElementById('submit-button').disabled = false;
            //     document.getElementById('submit-button').classList.remove('bg-gray-500', 'cursor-not-allowed');
            //     document.getElementById('submit-button').classList.add('bg-primary', 'cursor-pointer');
            // }
            // Format menjadi rupiah dengan menggunakan fungsi toLocaleString()
            let formattedValue = parseInt(value).toLocaleString('id-ID', {
                style: 'currency',
                currency: 'IDR',
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            });

            // Mengubah nilai input menjadi format rupiah
            input.value = formattedValue;
        }
        function selectAllText(input) {
            input.select();
        }

        function calculatePoint(input, value){
            //document.querySelector('#total-point').html = parseInt(input.value.replace(/\D/g, ''))/value
            const totalPointElement = document.querySelector('#total-point');
            const inputValue = input.value.replace(/\D/g, '');
            const calculatedPoint = parseInt(inputValue) / value;

            totalPointElement.textContent = Math.floor(calculatedPoint); // Menetapkan nilai dan membatasi desimal menjadi 2 digit
        }
    </script>



    <script src="{{ asset('src/js/scrollToTop.js') }}"></script>
</div>
